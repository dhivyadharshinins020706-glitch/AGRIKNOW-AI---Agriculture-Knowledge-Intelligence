/**
 * Query Understanding & Agricultural Intent Classification Engine.
 * Extracts crops, diseases, pests, nutrients, soils, regions, and normalizes regional Tamil & English farmer phrasing.
 */

export type AgriculturalIntent =
  | 'disease_diagnosis'
  | 'pest_control'
  | 'nutrient_fertilizer'
  | 'water_irrigation'
  | 'crop_selection'
  | 'soil_management'
  | 'market_price'
  | 'government_scheme'
  | 'document_query'
  | 'general_agronomy';

export interface QueryAnalysis {
  originalQuery: string;
  normalizedQuery: string;
  detectedLanguage: 'ta' | 'en';
  intent: AgriculturalIntent;
  confidence: number;
  cropMention?: string;
  diseasePestMention?: string;
  extractedEntities: {
    crops: string[];
    diseases: string[];
    pests: string[];
    symptoms: string[];
    nutrients: string[];
    regions: string[];
  };
  expandedKeywords: string[];
  requiresMultiHop: boolean;
  requiresGraphRag: boolean;
}

// Regional Tamil & English agricultural terminology map
const SYNONYM_MAP: Record<string, { standardEn: string; standardTa: string; category: string }> = {
  // Symptoms & Local terms
  'குருத்து காய்வு': { standardEn: 'dead heart stem borer', standardTa: 'மஞ்சள் தண்டு துளைப்பான் குருத்து காய்வு', category: 'symptom' },
  'dead heart': { standardEn: 'stem borer dead heart', standardTa: 'தண்டு துளைப்பான் குருத்து காய்வு', category: 'symptom' },
  'வெண் கதிர்': { standardEn: 'white earhead stem borer', standardTa: 'வெண் கதிர் தண்டு துளைப்பான்', category: 'symptom' },
  'white ear': { standardEn: 'white ear stem borer', standardTa: 'வெண் கதிர் தண்டு துளைப்பான்', category: 'symptom' },
  'பொக்கு காய்': { standardEn: 'pop pods hollow groundnut calcium gypsum', standardTa: 'பொக்கு காய் கால்சியம் ஜிப்சம்', category: 'symptom' },
  'pop pod': { standardEn: 'pop pods groundnut calcium gypsum deficiency', standardTa: 'பொக்கு காய் கால்சியம் பற்றாக்குறை', category: 'symptom' },
  'காய்ச்சலும் பாய்ச்சலும்': { standardEn: 'alternate wetting and drying AWD irrigation', standardTa: 'காய்ச்சலும் பாய்ச்சலும் பாசனம்', category: 'irrigation' },
  'AWD': { standardEn: 'alternate wetting and drying AWD rice', standardTa: 'காய்ச்சலும் பாய்ச்சலும் பாசனம்', category: 'irrigation' },
  'பாம்பு தோல் புள்ளி': { standardEn: 'sheath blight rice snake skin', standardTa: 'மடல் கருகல் பாம்பு தோல் புள்ளி', category: 'symptom' },
  'sheath blight': { standardEn: 'sheath blight rhizoctonia', standardTa: 'மடல் அழுகல் மடல் கருகல்', category: 'disease' },
  'குலை நோய்': { standardEn: 'rice blast magnaporthe tricyclazole', standardTa: 'நெல் குலை நோய் ட்ரைசைக்ளசோல்', category: 'disease' },
  'blast': { standardEn: 'rice blast magnaporthe tricyclazole', standardTa: 'குலை நோய்', category: 'disease' },
  'டிக்கா': { standardEn: 'tikka leaf spot groundnut cercospora', standardTa: 'டிக்கா இலைப்புள்ளி நிலக்கடலை', category: 'disease' },
  'சிகடோகா': { standardEn: 'sigatoka leaf spot banana mycosphaerella', standardTa: 'வாழை சிகடோகா இலைப்புள்ளி', category: 'disease' },
  'படைப்புழு': { standardEn: 'fall armyworm spodoptera maize', standardTa: 'மக்காச்சோளப் படைப்புழு', category: 'pest' },
  'fall armyworm': { standardEn: 'fall armyworm spodoptera frugiperda maize', standardTa: 'மக்காச்சோளப் படைப்புழு', category: 'pest' },
  'காய்ப்புழு': { standardEn: 'cotton bollworm helicoverpa pheromone trap', standardTa: 'பருத்தி காய்ப்புழு இனக்கவர்ச்சி பொறி', category: 'pest' },
  'bollworm': { standardEn: 'cotton bollworm helicoverpa armigera', standardTa: 'பருத்தி காய்ப்புழு', category: 'pest' },
  'ஜிப்சம்': { standardEn: 'gypsum calcium groundnut pod filling 40-45 DAS', standardTa: 'விவசாய ஜிப்சம் கால்சியம் நிலக்கடலை', category: 'fertilizer' },
  'gypsum': { standardEn: 'gypsum calcium sulphate pod filling groundnut', standardTa: 'விவசாய ஜிப்சம் கால்சியம்', category: 'fertilizer' },
  'செம்மை நெல்': { standardEn: 'system of rice intensification SRI cono weeder', standardTa: 'செம்மை நெல் சாகுபடி உருளைக் களை எடுப்பான்', category: 'practice' },
  'SRI': { standardEn: 'system of rice intensification SRI nursery', standardTa: 'செம்மை நெல் சாகுபடி பாய் நாற்றங்கால்', category: 'practice' },
};

/**
 * Detects if string contains Tamil script (\u0B80-\u0BFF) or Tanglish markers (Tamil in Latin alphabet)
 */
export function detectLanguage(text: string): 'ta' | 'en' {
  const tamilChars = (text.match(/[\u0B80-\u0BFF]/g) || []).length;
  if (tamilChars > 2) return 'ta';

  // Detect Tanglish patterns
  const lower = text.toLowerCase();
  const tanglishMarkers = [
    'nellu', 'paruthi', 'karumbu', 'nilakadalai', 'makkacholam', 'vazhai', 'thakkali',
    'marundhu', 'uram', 'poochi', 'puzhu', 'ilai', 'azhugal', 'karugal', 'thulaipaan',
    'podanum', 'eppadi', 'irukku', 'sollunga', 'seiyanum', 'panradhu', 'vandhurukku'
  ];
  if (tanglishMarkers.some((m) => lower.includes(m))) {
    return 'ta';
  }

  return 'en';
}

export interface ConversationTurn {
  role: 'user' | 'assistant';
  text: string;
}

/**
 * Analyzes natural language farmer questions in Tamil or English with multi-turn conversation context.
 */
export function analyzeFarmerQuery(
  query: string,
  history?: ConversationTurn[]
): QueryAnalysis {
  const trimmed = query.trim();
  const lang = detectLanguage(trimmed);
  const lower = trimmed.toLowerCase();

  // If follow-up query is short or elliptical, look back at recent conversation history to inherit active crop/disease
  let historicalContextString = '';
  if (history && history.length > 0) {
    const recentTurns = history.slice(-3);
    historicalContextString = recentTurns.map((t) => t.text.toLowerCase()).join(' ');
  }

  const extractedEntities = {
    crops: [] as string[],
    diseases: [] as string[],
    pests: [] as string[],
    symptoms: [] as string[],
    nutrients: [] as string[],
    regions: [] as string[],
  };

  const expandedKeywords: string[] = [];

  // 1. Detect Crops (including regional Tamil and Tanglish phrasing)
  if (lower.includes('paddy') || lower.includes('rice') || lower.includes('நெல்') || lower.includes('nellu') || lower.includes('arisi')) {
    extractedEntities.crops.push('Paddy (நெல்)');
    expandedKeywords.push('paddy', 'rice', 'நெல்');
  }
  if (lower.includes('cotton') || lower.includes('பருத்தி') || lower.includes('paruthi')) {
    extractedEntities.crops.push('Cotton (பருத்தி)');
    expandedKeywords.push('cotton', 'பருத்தி');
  }
  if (lower.includes('groundnut') || lower.includes('நிலக்கடலை') || lower.includes('வேர்க்கடலை') || lower.includes('மணிலா') || lower.includes('nilakadalai') || lower.includes('kadalai')) {
    extractedEntities.crops.push('Groundnut (நிலக்கடலை)');
    expandedKeywords.push('groundnut', 'நிலக்கடலை');
  }
  if (lower.includes('sugarcane') || lower.includes('கரும்பு') || lower.includes('கரும்ப') || lower.includes('karumbu')) {
    extractedEntities.crops.push('Sugarcane (கரும்பு)');
    expandedKeywords.push('sugarcane', 'கரும்பு', 'மூடாக்கு', 'fertigation');
  }
  if (lower.includes('banana') || lower.includes('வாழை') || lower.includes('vazhai') || lower.includes('valai')) {
    extractedEntities.crops.push('Banana (வாழை)');
    expandedKeywords.push('banana', 'வாழை');
  }
  if (lower.includes('maize') || lower.includes('corn') || lower.includes('மக்காச்சோளம்') || lower.includes('makkacholam') || lower.includes('cholam')) {
    extractedEntities.crops.push('Maize (மக்காச்சோளம்)');
    expandedKeywords.push('maize', 'மக்காச்சோளம்');
  }
  if (lower.includes('tomato') || lower.includes('தக்காளி') || lower.includes('thakkali')) {
    extractedEntities.crops.push('Tomato (தக்காளி)');
    expandedKeywords.push('tomato', 'தக்காளி');
  }
  if (lower.includes('chilli') || lower.includes('pepper') || lower.includes('மிளகாய்') || lower.includes('milagai') || lower.includes('melagai')) {
    extractedEntities.crops.push('Chilli (மிளகாய்)');
    expandedKeywords.push('chilli', 'மிளகாய்');
  }
  if (lower.includes('onion') || lower.includes('வெங்காயம்') || lower.includes('சின்ன வெங்காயம்') || lower.includes('vengayam')) {
    extractedEntities.crops.push('Onion (வெங்காயம்)');
    expandedKeywords.push('onion', 'வெங்காயம்');
  }
  if (lower.includes('turmeric') || lower.includes('மஞ்சள்') || lower.includes('manjal')) {
    extractedEntities.crops.push('Turmeric (மஞ்சள்)');
    expandedKeywords.push('turmeric', 'மஞ்சள்');
  }
  if (lower.includes('coconut') || lower.includes('தென்னை') || lower.includes('thennai')) {
    extractedEntities.crops.push('Coconut (தென்னை)');
    expandedKeywords.push('coconut', 'தென்னை');
  }
  if (lower.includes('blackgram') || lower.includes('உளுந்து') || lower.includes('greengram') || lower.includes('பாசிப்பயறு') || lower.includes('pulses') || lower.includes('பருப்பு') || lower.includes('ulundu') || lower.includes('payaru')) {
    extractedEntities.crops.push('Pulses (பயறு வகைகள்)');
    expandedKeywords.push('pulses', 'பயறு', 'உளுந்து');
  }
  if (lower.includes('wheat') || lower.includes('கோதுமை')) {
    extractedEntities.crops.push('Wheat (கோதுமை)');
    expandedKeywords.push('wheat', 'கோதுமை');
  }
  if (lower.includes('millet') || lower.includes('ragi') || lower.includes('கேழ்வரகு') || lower.includes('கம்பு') || lower.includes('தினை')) {
    extractedEntities.crops.push('Millets (சிறு தானியங்கள்)');
    expandedKeywords.push('millet', 'ragi', 'கேழ்வரகு');
  }

  // 2. Detect Diseases & Pests
  if (lower.includes('blast') || lower.includes('குலை நோய்') || lower.includes('கதிர் கருகல்')) {
    extractedEntities.diseases.push('Rice Blast');
    expandedKeywords.push('blast', 'குலை நோய்', 'tricyclazole');
  }
  if (lower.includes('stem borer') || lower.includes('தண்டு துளைப்பான்') || lower.includes('dead heart') || lower.includes('குருத்து காய்வு')) {
    extractedEntities.pests.push('Yellow Stem Borer');
    expandedKeywords.push('stem borer', 'தண்டு துளைப்பான்', 'dead heart');
  }
  if (lower.includes('bollworm') || lower.includes('காய்ப்புழு') || lower.includes('helicoverpa')) {
    extractedEntities.pests.push('Cotton Bollworm');
    expandedKeywords.push('bollworm', 'காய்ப்புழு', 'pheromone trap');
  }
  if (lower.includes('fall armyworm') || lower.includes('படைப்புழு') || lower.includes('spodoptera')) {
    extractedEntities.pests.push('Fall Armyworm');
    expandedKeywords.push('fall armyworm', 'படைப்புழு', 'metarhizium');
  }
  if (lower.includes('sigatoka') || lower.includes('சிகடோகா')) {
    extractedEntities.diseases.push('Sigatoka Leaf Spot');
    expandedKeywords.push('sigatoka', 'சிகடோகா');
  }
  if (lower.includes('tikka') || lower.includes('டிக்கா')) {
    extractedEntities.diseases.push('Tikka Leaf Spot');
    expandedKeywords.push('tikka', 'டிக்கா');
  }
  if (lower.includes('bph') || lower.includes('planthopper') || lower.includes('புகையான்')) {
    extractedEntities.pests.push('Brown Planthopper (BPH)');
    expandedKeywords.push('bph', 'brown planthopper', 'புகையான்');
  }
  if (lower.includes('whitefly') || lower.includes('வெள்ளை ஈ')) {
    extractedEntities.pests.push('Whitefly (வெள்ளை ஈ)');
    expandedKeywords.push('whitefly', 'வெள்ளை ஈ');
  }
  if (lower.includes('wilt') || lower.includes('வாடல் நோய்') || lower.includes('panama')) {
    extractedEntities.diseases.push('Wilt Disease (வாடல் நோய்)');
    expandedKeywords.push('wilt', 'fusarium', 'வாடல் நோய்');
  }

  // 3. Detect Nutrients & Fertilizers
  if (lower.includes('gypsum') || lower.includes('ஜிப்சம்') || lower.includes('calcium') || lower.includes('கால்சியம்')) {
    extractedEntities.nutrients.push('Calcium / Gypsum');
    expandedKeywords.push('gypsum', 'calcium', 'ஜிப்சம்');
  }
  if (lower.includes('potash') || lower.includes('பொட்டாஷ்') || lower.includes('potassium') || lower.includes('சாம்பல் சத்து')) {
    extractedEntities.nutrients.push('Potassium');
    expandedKeywords.push('potassium', 'potash', 'சாம்பல் சத்து');
  }
  if (lower.includes('nitrogen') || lower.includes('urea') || lower.includes('தழைச்சத்து') || lower.includes('யூரியா')) {
    extractedEntities.nutrients.push('Nitrogen / Urea');
    expandedKeywords.push('nitrogen', 'urea', 'தழைச்சத்து');
  }

  // 4. Detect Regions
  if (lower.includes('delta') || lower.includes('cauvery') || lower.includes('டெல்டா') || lower.includes('தஞ்சாவூர்') || lower.includes('thanjavur')) {
    extractedEntities.regions.push('Cauvery Delta');
    expandedKeywords.push('cauvery delta', 'டெல்டா');
  }
  if (lower.includes('coimbatore') || lower.includes('கோவை') || lower.includes('erode') || lower.includes('ஈரோடு') || lower.includes('tirupur') || lower.includes('திருப்பூர்')) {
    extractedEntities.regions.push('Western Tamil Nadu');
  }

  // Contextual Follow-Up Memory: Inherit active crop/pest from previous turn if omitted in follow-up
  if (extractedEntities.crops.length === 0 && historicalContextString) {
    if (historicalContextString.includes('paddy') || historicalContextString.includes('rice') || historicalContextString.includes('நெல்')) {
      extractedEntities.crops.push('Paddy (நெல்)');
      expandedKeywords.push('paddy', 'rice', 'நெல்');
    } else if (historicalContextString.includes('cotton') || historicalContextString.includes('பருத்தி')) {
      extractedEntities.crops.push('Cotton (பருத்தி)');
      expandedKeywords.push('cotton', 'பருத்தி');
    } else if (historicalContextString.includes('groundnut') || historicalContextString.includes('நிலக்கடலை')) {
      extractedEntities.crops.push('Groundnut (நிலக்கடலை)');
      expandedKeywords.push('groundnut', 'நிலக்கடலை');
    } else if (historicalContextString.includes('banana') || historicalContextString.includes('வாழை')) {
      extractedEntities.crops.push('Banana (வாழை)');
      expandedKeywords.push('banana', 'வாழை');
    } else if (historicalContextString.includes('maize') || historicalContextString.includes('மக்காச்சோளம்')) {
      extractedEntities.crops.push('Maize (மக்காச்சோளம்)');
      expandedKeywords.push('maize', 'மக்காச்சோளம்');
    } else if (historicalContextString.includes('sugarcane') || historicalContextString.includes('கரும்பு')) {
      extractedEntities.crops.push('Sugarcane (கரும்பு)');
      expandedKeywords.push('sugarcane', 'கரும்பு');
    }
  }

  // Inherit disease/pest from conversation history if omitted in elliptical follow-up
  if (extractedEntities.diseases.length === 0 && extractedEntities.pests.length === 0 && historicalContextString) {
    if (historicalContextString.includes('blast') || historicalContextString.includes('குலை')) {
      extractedEntities.diseases.push('Rice Blast');
      expandedKeywords.push('blast', 'குலை நோய்', 'tricyclazole');
    } else if (historicalContextString.includes('stem borer') || historicalContextString.includes('துளைப்பான்') || historicalContextString.includes('dead heart')) {
      extractedEntities.pests.push('Yellow Stem Borer');
      expandedKeywords.push('stem borer', 'தண்டு துளைப்பான்', 'dead heart');
    } else if (historicalContextString.includes('tikka') || historicalContextString.includes('டிக்கா')) {
      extractedEntities.diseases.push('Tikka Leaf Spot');
      expandedKeywords.push('tikka', 'டிக்கா');
    } else if (historicalContextString.includes('bollworm') || historicalContextString.includes('காய்ப்புழு')) {
      extractedEntities.pests.push('Cotton Bollworm');
      expandedKeywords.push('bollworm', 'காய்ப்புழு');
    }
  }

  // 5. Expand Regional Synonyms
  let normalizedQuery = trimmed;
  if (historicalContextString) {
    const inheritedTerms = [...extractedEntities.crops, ...extractedEntities.diseases, ...extractedEntities.pests];
    if (inheritedTerms.length > 0) {
      normalizedQuery += ` ${inheritedTerms.join(' ')}`;
    }
  }

  for (const [key, val] of Object.entries(SYNONYM_MAP)) {
    if (lower.includes(key.toLowerCase())) {
      expandedKeywords.push(val.standardEn, val.standardTa);
      if (lang === 'ta') {
        normalizedQuery += ` (${val.standardTa})`;
      } else {
        normalizedQuery += ` (${val.standardEn})`;
      }
    }
  }

  // 6. Determine Agricultural Intent
  let intent: AgriculturalIntent = 'general_agronomy';
  let confidence = 0.70;

  if (
    lower.includes('disease') ||
    lower.includes('symptom') ||
    lower.includes('spot') ||
    lower.includes('blight') ||
    lower.includes('rot') ||
    lower.includes('நோய்') ||
    lower.includes('புள்ளி') ||
    lower.includes('கருகல்') ||
    lower.includes('அழுகல்')
  ) {
    intent = 'disease_diagnosis';
    confidence = 0.92;
  } else if (
    lower.includes('pest') ||
    lower.includes('insect') ||
    lower.includes('worm') ||
    lower.includes('borer') ||
    lower.includes('பூச்சி') ||
    lower.includes('புழு') ||
    lower.includes('துளைப்பான்')
  ) {
    intent = 'pest_control';
    confidence = 0.93;
  } else if (
    lower.includes('fertilizer') ||
    lower.includes('nutrient') ||
    lower.includes('urea') ||
    lower.includes('dose') ||
    lower.includes('deficiency') ||
    lower.includes('உரம்') ||
    lower.includes('சத்து') ||
    lower.includes('பற்றாக்குறை') ||
    lower.includes('ஜிப்சம்')
  ) {
    intent = 'nutrient_fertilizer';
    confidence = 0.90;
  } else if (
    lower.includes('irrigation') ||
    lower.includes('water') ||
    lower.includes('drip') ||
    lower.includes('awd') ||
    lower.includes('பாசனம்') ||
    lower.includes('நீர்')
  ) {
    intent = 'water_irrigation';
    confidence = 0.88;
  } else if (
    lower.includes('crop choice') ||
    lower.includes('profit') ||
    lower.includes('which crop') ||
    lower.includes('எந்த பயிர்') ||
    lower.includes('லாபம்')
  ) {
    intent = 'crop_selection';
    confidence = 0.85;
  } else if (
    lower.includes('document') ||
    lower.includes('upload') ||
    lower.includes('receipt') ||
    lower.includes('invoice') ||
    lower.includes('bill') ||
    lower.includes('tag') ||
    lower.includes('germination') ||
    lower.includes('lot number') ||
    lower.includes('batch') ||
    lower.includes('expiry') ||
    lower.includes('ஆவணம்') ||
    lower.includes('ரசீது') ||
    lower.includes('அட்டை') ||
    lower.includes('முளைப்பு') ||
    lower.includes('காலாவதி')
  ) {
    intent = 'document_query';
    confidence = 0.95;
  } else if (
    /\b(?:mandi|market price|prices?|rates?|msp|quintal|apmc)\b/i.test(lower) ||
    lower.includes('சந்தை') ||
    lower.includes('மண்டி') ||
    lower.includes('விலை') ||
    lower.includes('கொள்முதல் விலை')
  ) {
    intent = 'market_price';
    confidence = 0.93;
  } else if (
    lower.includes('scheme') ||
    lower.includes('subsidy') ||
    lower.includes('pm-kisan') ||
    lower.includes('pm kisan') ||
    lower.includes('insurance') ||
    lower.includes('pmfby') ||
    lower.includes('kcc') ||
    lower.includes('மானியம்') ||
    lower.includes('திட்டம்') ||
    lower.includes('காப்பீடு')
  ) {
    intent = 'government_scheme';
    confidence = 0.94;
  }

  // Complex multi-hop requirement: When query asks for both cause/disease AND treatment/dosage,
  // or symptom without specifying the pest/disease name
  const hasSymptoms = lower.includes('spot') || lower.includes('dead heart') || lower.includes('புள்ளி') || lower.includes('குருத்து') || lower.includes('பொக்கு');
  const asksForTreatment = lower.includes('control') || lower.includes('remedy') || lower.includes('treatment') || lower.includes('மருந்து') || lower.includes('கட்டுப்பாடு');
  const requiresMultiHop = hasSymptoms && asksForTreatment;

  // Graph RAG is prioritized when relational questions span multiple entities (e.g. soil condition -> deficiency -> crop symptom)
  const requiresGraphRag =
    extractedEntities.crops.length > 0 &&
    (extractedEntities.diseases.length > 0 ||
      extractedEntities.pests.length > 0 ||
      extractedEntities.nutrients.length > 0);

  // Helper mappings for consumers
  const cropLower = extractedEntities.crops[0]?.toLowerCase() || '';
  const cropMention = cropLower.includes('paddy')
    ? 'paddy'
    : cropLower.includes('cotton')
    ? 'cotton'
    : cropLower.includes('groundnut')
    ? 'groundnut'
    : cropLower.includes('maize')
    ? 'maize'
    : cropLower.includes('banana')
    ? 'banana'
    : cropLower.includes('sugarcane')
    ? 'sugarcane'
    : undefined;

  const diseaseLower = (extractedEntities.diseases[0] || extractedEntities.pests[0] || '').toLowerCase();
  const diseasePestMention = diseaseLower.includes('blast')
    ? 'rice-blast'
    : diseaseLower.includes('stem borer')
    ? 'rice-stem-borer'
    : diseaseLower.includes('tikka')
    ? 'groundnut-tikka'
    : diseaseLower.includes('bollworm')
    ? 'cotton-bollworm'
    : undefined;

  return {
    originalQuery: query,
    normalizedQuery,
    detectedLanguage: lang,
    intent,
    confidence,
    cropMention,
    diseasePestMention,
    extractedEntities,
    expandedKeywords: Array.from(new Set(expandedKeywords)),
    requiresMultiHop,
    requiresGraphRag,
  };
}
