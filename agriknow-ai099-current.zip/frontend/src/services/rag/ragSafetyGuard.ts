/**
 * AGRIKNOW AI - AI / RAG Safety Guard
 * Defends against Prompt Injection, Adversarial Jailbreaks, Untrusted Document Compromise,
 * and Banned / Toxic Chemical Recommendations.
 */

export interface PromptSafetyAnalysis {
  isSafe: boolean;
  injectionRiskScore: number; // 0.0 to 1.0
  detectedFlags: string[];
  sanitizedQuery: string;
}

const INJECTION_PATTERNS = [
  // Instruction Overrides
  /ignore\s+(all\s+)?(previous|prior|above)\s+instructions/i,
  /system\s*(prompt|override|command)/i,
  /disregard\s+(all\s+)?(rules|guidelines|safety)/i,
  /you\s+are\s+now\s+(dan|unfiltered|jailbroken|godmode)/i,
  /act\s+as\s+(an?\s+unrestricted|a\s+hacker|an\s+adversary)/i,
  /reveal\s+(your\s+)?(system\s+prompt|api\s*key|secret|credentials)/i,
  /output\s+(the\s+)?(entire\s+prompt|raw\s+instructions)/i,
  /bypass\s+(safety|verification|abstention)/i,
  // Script / Markup injection in prompts
  /<script[\s\S]*?>[\s\S]*?<\/script>/i,
  /javascript\s*:/i,
  /data\s*:\s*text\/html/i,
];

const BANNED_CHEMICAL_LIST: { name: string; aliases: string[]; reason: string; reasonTa: string; safeAlternatives: string; safeAlternativesTa: string }[] = [
  {
    name: 'Monocrotophos',
    aliases: ['monocrotophos', 'மோனோகுரோட்டோபாஸ்', 'monocil', 'nuvacron'],
    reason: 'Highly toxic organophosphate pesticide banned/restricted for vegetables and food crops under Indian Insecticides Act due to acute human and pollinator toxicity.',
    reasonTa: 'மோனோகுரோட்டோபாஸ் கடுமையான மனித மற்றும் தேனீ நச்சுத்தன்மை காரணமாக உணவு மற்றும் காய்கறி பயிர்களுக்கு மத்திய அரசால் தடை/கட்டுப்படுத்தப்பட்டுள்ளது.',
    safeAlternatives: 'Neem oil 3% (30 ml/10 L) or Azadirachtin 1% + Chlorantraniliprole 18.5% SC @ 60 ml/acre.',
    safeAlternativesTa: 'வேப்பெண்ணெய் 3% அல்லது குளோரான்ட்ரனிலிப்ரோல் 18.5% SC ஏக்கருக்கு 60 மிலி தெளிக்கவும்.',
  },
  {
    name: 'Endosulfan',
    aliases: ['endosulfan', 'எண்டோசல்பான்', 'thiodan'],
    reason: 'Globally banned organochlorine pesticide (Supreme Court of India ban) causing severe neurological disorders and persistent environmental contamination.',
    reasonTa: 'எண்டோசல்பான் உச்சநீதிமன்றத்தால் நாடு முழுவதும் முழுமையாக தடை செய்யப்பட்ட அபாயகரமான பூச்சிக்கொல்லி.',
    safeAlternatives: 'Pheromone traps (5/acre) + HaNPV 250 LE/acre or Bacillus thuringiensis (Bt) @ 2 g/L.',
    safeAlternativesTa: 'இனக்கவர்ச்சி பொறி (ஏக்கருக்கு 5) + பேசிலஸ் துரிஞ்சியென்சிஸ் (Bt) 2 கிராம்/லிட்டர்.',
  },
  {
    name: 'Phorate',
    aliases: ['phorate', 'போரேட்', 'thimet'],
    reason: 'WHO Class Ia extremely hazardous organophosphate banned/phased out under Government of India Gazette notification.',
    reasonTa: 'போரேட் (10G) தீவிர நச்சுத்தன்மை கொண்ட அபாயகரமான குருணை மருந்து; தடை செய்யப்பட்டுள்ளது.',
    safeAlternatives: 'Cartap hydrochloride 4% G or neem cake @ 100 kg/acre.',
    safeAlternativesTa: 'கார்டாப் ஹைட்ரோகுளோரைடு 4% G அல்லது வேப்பம்பிண்ணாக்கு ஏக்கருக்கு 100 கிலோ இடவும்.',
  },
  {
    name: 'Carbofuran',
    aliases: ['carbofuran', 'கார்போபியூரான்', 'furadan'],
    reason: 'Banned in several states and restricted for food crops due to groundwater contamination and bird toxicity.',
    reasonTa: 'கார்போபியூரான் பறவைகள் மற்றும் நிலத்தடி நீரை நஞ்சாக்கும் என்பதால் தடை/கட்டுப்படுத்தப்பட்டுள்ளது.',
    safeAlternatives: 'Trichoderma viride @ 1 kg/acre enriched with farmyard manure.',
    safeAlternativesTa: 'டிரைக்கோடெர்மா விரிடி 1 கிலோ தொழு உரத்துடன் கலந்து இடவும்.',
  },
  {
    name: 'Methyl Parathion',
    aliases: ['methyl parathion', 'மித்தைல் பாரத்தியான்', 'metacid', 'parathion'],
    reason: 'Banned by Government of India Gazette notification due to severe acute neurotoxicity and pollinator mortality.',
    reasonTa: 'மித்தைல் பாரத்தியான் தீவிர நரம்பு நச்சுத்தன்மை காரணமாக இந்திய அரசால் முற்றிலும் தடை செய்யப்பட்டுள்ளது.',
    safeAlternatives: 'Flubendiamide 39.35% SC @ 0.2 ml/L or Chlorantraniliprole 18.5% SC.',
    safeAlternativesTa: 'புளூபென்டமைடு அல்லது குளோரான்ட்ரனிலிப்ரோல் பாதுகாப்பான பூச்சிக்கொல்லிகளைப் பயன்படுத்தவும்.',
  },
  {
    name: 'Paraquat',
    aliases: ['paraquat', 'பாராக்குவாட்', 'gramoxone', 'paraquat dichloride'],
    reason: 'Highly toxic herbicide banned/restricted in Tamil Nadu and multiple Indian states due to lack of medical antidote.',
    reasonTa: 'பாராக்குவாட் மாற்று மருந்து இல்லாத கொடிய நச்சுத்தன்மை கொண்டதால் தமிழ்நாட்டில் தடை செய்யப்பட்டுள்ளது.',
    safeAlternatives: 'Glufosinate ammonium 13.5% SL or mechanical weeding.',
    safeAlternativesTa: 'குளூபோசினேட் அம்மோனியம் அல்லது இயந்திர களையெடுப்பு முறையைப் பின்பற்றவும்.',
  },
];

/**
 * Evaluates whether an incoming farmer query contains prompt injection or adversarial jailbreak attempts.
 */
export function inspectPromptSafety(query: string): PromptSafetyAnalysis {
  const flags: string[] = [];
  let riskScore = 0.0;

  for (const pattern of INJECTION_PATTERNS) {
    if (pattern.test(query)) {
      flags.push(`Matched pattern: ${pattern.source}`);
      riskScore += 0.45;
    }
  }

  // Check for delimiter evasion attempts
  if (query.includes('<<<') || query.includes('>>>') || query.includes('[SYSTEM]') || query.includes('<!--')) {
    flags.push('Delimiter boundary spoofing detected');
    riskScore += 0.35;
  }

  // Sanitize query by stripping control characters and script tags
  const sanitizedQuery = query
    .replace(/<[^>]*>/g, '')
    .replace(/[«»<>{}\\]/g, ' ')
    .trim();

  const isSafe = riskScore < 0.50;

  return {
    isSafe,
    injectionRiskScore: Math.min(1.0, riskScore),
    detectedFlags: flags,
    sanitizedQuery,
  };
}

/**
 * Checks for banned chemicals and returns safe regulatory interventions.
 */
export function checkHazardousChemicals(query: string, text = '') {
  const combined = `${query} ${text}`.toLowerCase();
  for (const chemical of BANNED_CHEMICAL_LIST) {
    for (const alias of chemical.aliases) {
      if (combined.includes(alias.toLowerCase())) {
        return {
          isBanned: true,
          chemicalName: chemical.name,
          reason: chemical.reason,
          reasonTa: chemical.reasonTa,
          safeAlternatives: chemical.safeAlternatives,
          safeAlternativesTa: chemical.safeAlternativesTa,
        };
      }
    }
  }
  return { isBanned: false };
}

/**
 * Encapsulates retrieved document chunks within secure untrusted evidence delimiters.
 * Ensures the LLM / synthesis pipeline treats document text strictly as passive data,
 * preventing indirect prompt injection via compromised files.
 */
export function wrapUntrustedDocumentEvidence(
  chunkContent: string,
  docId: string,
  pageNumber: number
): string {
  // Neutralize delimiter spoofing inside document content
  const cleanContent = chunkContent
    .replace(/<<</g, '&lt;&lt;&lt;')
    .replace(/>>>/g, '&gt;&gt;&gt;');

  return `<<<UNTRUSTED_DOCUMENT_EVIDENCE ID="${docId}" PAGE="${pageNumber}">>>\n${cleanContent}\n<<<END_DOCUMENT_EVIDENCE>>>`;
}
