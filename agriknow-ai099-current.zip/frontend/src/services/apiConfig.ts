// AGRIKNOW AI - Backend API Configuration Service
// Reads environment variables securely. Does not leak secrets.

export interface ApiConfiguration {
  apiBaseUrl: string;
  supabaseUrl: string | null;
  supabaseAnonKey: string | null;
  aiModelEndpoint: string;
  aiAskEndpoint: string;
  aiDiagnoseEndpoint: string;
  aiAnalyzeDocumentEndpoint: string;
  aiDocumentQaEndpoint: string;
  weatherApiUrl: string | null;
  mandiApiUrl: string | null;
  isLiveBackendAvailable: boolean;
  isAiEndpointAvailable: boolean;
}

const safeEnv: Record<string, string | undefined> =
  (typeof import.meta !== 'undefined' && (import.meta as any).env) ||
  (typeof process !== 'undefined' && process.env) ||
  {};

export const apiConfig: ApiConfiguration = {
  apiBaseUrl: safeEnv.VITE_API_BASE_URL || '',
  supabaseUrl: safeEnv.VITE_SUPABASE_URL || null,
  supabaseAnonKey: safeEnv.VITE_SUPABASE_ANON_KEY || null,
  aiModelEndpoint: '/api/ai/ask',
  aiAskEndpoint: '/api/ai/ask',
  aiDiagnoseEndpoint: '/api/ai/diagnose',
  aiAnalyzeDocumentEndpoint: '/api/ai/analyze-document',
  aiDocumentQaEndpoint: '/api/ai/document-qa',
  weatherApiUrl: safeEnv.VITE_WEATHER_API_URL || null,
  mandiApiUrl: safeEnv.VITE_MANDI_API_URL || null,
  get isLiveBackendAvailable(): boolean {
    return true;
  },
  get isAiEndpointAvailable(): boolean {
    return true;
  },
};

