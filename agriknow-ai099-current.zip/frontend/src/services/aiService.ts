import { apiConfig } from './apiConfig.ts';
import type { AiAnswerResult } from '../types/index.ts';
import type { Lang } from '../lib/i18n.ts';
import { executeAdvancedRag } from './rag/advancedRagEngine.ts';
import { assistantRateLimiter } from '../utils/rateLimiter.ts';
import { sanitizeInputText } from '../utils/security.ts';
import { logger } from './telemetry/logger.ts';
import { matchSchemeForQuery } from './schemesService.ts';
import { buildPersonalizedContextPrompt } from './personalizationService.ts';
import { getActiveAnalyzedDocument, askQuestionAboutDocument } from './documentAnalyzerService.ts';

/**
 * AGRIKNOW AI - Primary Agricultural Intelligence Assistant
 * Directly invokes Google Gemini via the backend AI orchestrator with grounded RAG retrieval.
 * Zero hardcoded canned responses.
 */
export async function askAgriAssistant(
  question: string,
  lang: Lang,
  history?: { role: 'user' | 'assistant'; text: string }[],
  userId?: string
): Promise<AiAnswerResult> {
  // 1. Client-Side Rate Limiter Check (Max 15 queries/min)
  const rateCheck = assistantRateLimiter.checkLimit();
  if (!rateCheck.allowed) {
    const isTaRate = lang === 'ta';
    logger.warn('Security', 'Rate limit exceeded for farmer assistant query');
    return {
      text: isTaRate
        ? `⚠️ **பாதுகாப்பு அறிவிப்பு:** குறுகிய நேரத்தில் அதிக வினவல்கள் கேட்கப்பட்டுள்ளன. தயவுசெய்து ${rateCheck.retryAfterSeconds} வினாடிகள் காத்திருந்து மீண்டும் கேட்கவும்.`
        : `⚠️ **Rate Limit Notice:** Too many queries in short succession. Please wait ${rateCheck.retryAfterSeconds} seconds before sending another question.`,
      sourceIds: [],
      isLiveBackend: false,
      provider: 'AGRIKNOW Rate Limiter',
      confidence: 1.0,
      isError: true,
      retryable: true,
    };
  }

  // 2. Production Input Sanitization
  const cleanQuestion = sanitizeInputText(question, 800);
  const trimmed = cleanQuestion || question.trim();

  // 2b. Strict Dynamic Language Resolution:
  // - If query contains Tamil script ([\u0B80-\u0BFF]) -> strictly 'ta'
  // - If query contains English letters without Tamil script -> strictly 'en'
  // - Otherwise -> use user UI selected language (lang)
  const hasTamilScript = /[\u0B80-\u0BFF]/.test(trimmed);
  const hasEnglishLetters = /[a-zA-Z]/.test(trimmed);

  let effectiveLang: 'ta' | 'en' = 'en';
  if (hasTamilScript) {
    effectiveLang = 'ta';
  } else if (hasEnglishLetters) {
    effectiveLang = 'en';
  } else {
    effectiveLang = lang === 'ta' ? 'ta' : 'en';
  }
  const isTa = effectiveLang === 'ta';

  logger.info('Assistant', `Processing query [effectiveLang: ${effectiveLang}, uiLang: ${lang}] (length: ${trimmed.length})`);

  const activeDoc = getActiveAnalyzedDocument();

  // 3. Optional Agricultural Context Retrieval
  let ragResponse: any = null;
  let contextPassages = '';

  try {
    const personalContext = buildPersonalizedContextPrompt(effectiveLang);
    const contextualizedQuery = personalContext ? `${trimmed} ${personalContext}` : trimmed;
    ragResponse = await executeAdvancedRag(contextualizedQuery, effectiveLang, history, userId);

    if (ragResponse && ragResponse.evidenceList && !ragResponse.isAbstained) {
      contextPassages = ragResponse.evidenceList
        .map(
          (e: any, idx: number) =>
            `[Document ${idx + 1}]: "${e.documentTitle}" (Page ${e.pageNumber || 1}, ${e.sourceInstitution}):\n${e.excerpt}`
        )
        .join('\n\n');
    }
  } catch (ragErr) {
    logger.warn('Assistant', 'Background RAG context lookup skipped', ragErr);
  }

  // Format conversational turns for backend (last 6 turns, avoiding crosstalk)
  const formattedHistory = (history || []).slice(-6).map((turn) => ({
    role: turn.role,
    text: turn.text,
  }));

  // 4. Direct Full-Capability Gemini AI Orchestrator (/api/ai/ask)
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 25000);

    const response = await fetch(apiConfig.aiAskEndpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        question: trimmed,
        language: effectiveLang,
        history: formattedHistory,
        context: contextPassages,
        documentContext: activeDoc
          ? {
              id: activeDoc.id,
              title: activeDoc.fileName || 'Uploaded Document',
              fileName: activeDoc.fileName,
              category: activeDoc.category,
              categoryLabelEn: activeDoc.categoryLabelEn,
              categoryLabelTa: activeDoc.categoryLabelTa,
              crop: activeDoc.crop,
              variety: activeDoc.variety,
              lotOrBatchNumber: activeDoc.lotOrBatchNumber,
              germinationPercent: activeDoc.germinationPercent,
              purityPercent: activeDoc.purityPercent,
              moisturePercent: activeDoc.moisturePercent,
              expiryDate: activeDoc.expiryDate,
              testingDate: activeDoc.testingDate,
              issuerOrDealer: activeDoc.issuerOrDealer,
              pricePaid: activeDoc.pricePaid,
              quantity: activeDoc.quantity,
              chemicalTreatment: activeDoc.chemicalTreatment,
              summaryEn: activeDoc.summaryEn,
              summaryTa: activeDoc.summaryTa,
              keyFindings: activeDoc.keyFindings || [],
              rawText: activeDoc.rawText ? activeDoc.rawText.slice(0, 10000) : '',
            }
          : null,
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (response.ok) {
      const data = await response.json();
      return {
        text: data.answer,
        sourceIds: ragResponse?.sourceIds && ragResponse.sourceIds.length > 0 ? ragResponse.sourceIds : [],
        isLiveBackend: true,
        provider: data.provider || 'AgriKnow (Grounded RAG)',
        confidence: 0.95,
        ragTrace: ragResponse?.trace,
        suggestedFollowUps: ragResponse?.suggestedFollowUps || [],
      };
    } else {
      const errData = await response.json().catch(() => ({}));
      const isMissingKey = errData?.error === 'GEMINI_KEY_NOT_CONFIGURED';

      if (isMissingKey) {
        // If Gemini key is not configured, fall back to TNAU/ICAR grounded synthesis
        if (ragResponse?.answerText && ragResponse.answerText.length > 50) {
          return {
            text: ragResponse.answerText,
            sourceIds: ragResponse.sourceIds,
            isLiveBackend: false,
            provider: 'TNAU/ICAR Grounded Agronomic Knowledge Engine',
            confidence: ragResponse.confidence || 0.92,
            ragTrace: ragResponse?.trace,
            suggestedFollowUps: ragResponse.suggestedFollowUps,
          };
        }

        return {
          text: isTa
            ? `⚠️ **AgriKnow AI நுண்ணறிவுச் சேவை அறிவிப்பு:**\n\nவழங்கியில் கூகுள் Gemini API சாவி (\`GEMINI_API_KEY\`) உள்ளமைக்கப்படவில்லை.\n\nநேரடி செயற்கை நுண்ணறிவுப் பகுப்பாய்வு மற்றும் பல்நோக்கு பட ஆய்வை இயக்க, சர்வர் சூழல் மாறிகளில் (Environment Variables) \`GEMINI_API_KEY\`-ஐ அமைக்கவும்.`
            : `⚠️ **AgriKnow AI Intelligence Service Notice:**\n\nThe Google Gemini API key (\`GEMINI_API_KEY\`) is not configured in the server environment.\n\nTo enable real-time dynamic AI reasoning, contextual responses, and multimodal diagnosis, please set \`GEMINI_API_KEY\` in your environment variables.`,
          sourceIds: ragResponse?.sourceIds || [],
          isLiveBackend: false,
          provider: 'Configuration Required (GEMINI_API_KEY)',
          confidence: 0.0,
          isError: true,
          retryable: true,
          ragTrace: ragResponse?.trace,
        };
      }

      throw new Error(errData?.message || `Server returned HTTP ${response.status}`);
    }
  } catch (netErr: unknown) {
    // In offline / Node / network disconnect, provide verified university agronomic answer if available
    if (ragResponse?.answerText && ragResponse.answerText.length > 50) {
      return {
        text: ragResponse.answerText,
        sourceIds: ragResponse.sourceIds || [],
        isLiveBackend: false,
        provider: 'TNAU/ICAR Grounded Agronomic Knowledge Engine',
        confidence: ragResponse.confidence || 0.9,
        ragTrace: ragResponse?.trace,
        suggestedFollowUps: ragResponse.suggestedFollowUps || [],
      };
    }

    const errorMsg = netErr instanceof Error ? netErr.message : String(netErr);
    logger.error('Assistant', 'Backend Gemini call failed', netErr);

    return {
      text: isTa
        ? `⚠️ **இணைப்புப் பிழை:** செயற்கை நுண்ணறிவுச் சேவையைத் தொடர்புகொள்ள முடியவில்லை (${errorMsg}). தயவுசெய்து உங்கள் இணைய இணைப்பைச் சரிபார்த்துவிட்டு மீண்டும் முயற்சிக்கவும்.`
        : `⚠️ **Communication Error:** Could not reach the Gemini reasoning service (${errorMsg}). Please verify your connection and click 'Retry'.`,
      sourceIds: [],
      isLiveBackend: false,
      provider: 'Service Error',
      confidence: 0,
      isError: true,
      retryable: true,
      ragTrace: ragResponse?.trace,
    };
  }
}
