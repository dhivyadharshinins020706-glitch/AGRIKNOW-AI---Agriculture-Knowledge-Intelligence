import type { Source } from '@/types';

export const sources: Source[] = [
  {
    id: 'tnau-blast',
    title: 'Rice Blast: Identification and Management',
    publisher: 'Tamil Nadu Agricultural University',
    year: 2024,
    kind: 'Government advisory',
    language: 'English & Tamil',
    reliability: 'Verified',
    topics: ['rice', 'blast', 'disease', 'leaf spots'],
    summary:
      'Field guide for recognising rice blast on leaves, neck and panicles, with cultural and chemical control steps for Tamil Nadu conditions.',
    excerpts: [
      {
        section: 'Symptoms',
        text: 'Lesions on leaves are spindle or diamond shaped with grey centres and brown margins. Heavy infection causes leaves to dry from the tip.',
        relevance: 'high',
      },
      {
        section: 'Cultural control',
        text: 'Drain standing water for 2 to 3 days when lesions first appear. Split nitrogen doses and avoid excess application.',
        relevance: 'high',
      },
      {
        section: 'Chemical control',
        text: 'Tricyclazole 75% WP may be applied at the dose on the product label when lesions are spreading. Follow local Krishi Officer advice.',
        relevance: 'medium',
      },
    ],
  },
  {
    id: 'icar-rice',
    title: 'Rice Production Manual: Crop Health Chapter',
    publisher: 'Indian Council of Agricultural Research',
    year: 2023,
    kind: 'Field manual',
    language: 'English',
    reliability: 'Verified',
    topics: ['rice', 'brown spot', 'disease', 'nutrition'],
    summary:
      'National reference manual covering rice disease identification, nutrient imbalance signs and integrated crop health management.',
    excerpts: [
      {
        section: 'Brown spot',
        text: 'Small oval brown spots with a yellow halo appear on leaves, often linked to potassium deficiency and poor soil fertility.',
        relevance: 'medium',
      },
      {
        section: 'Integrated management',
        text: 'Use resistant varieties, balanced fertilization and timely scouting every 5 to 7 days during the tillering and booting stages.',
        relevance: 'high',
      },
    ],
  },
  {
    id: 'soil-card',
    title: 'Soil Health Card Interpretation Guide',
    publisher: 'Department of Agriculture and Farmers Welfare',
    year: 2022,
    kind: 'Government advisory',
    language: 'English & Tamil',
    reliability: 'Verified',
    topics: ['soil', 'fertilizer', 'nutrients', 'pH'],
    summary:
      'Explains how to read nitrogen, phosphorus, potassium, pH and organic carbon values from a soil health card and convert them into a fertilizer plan.',
    excerpts: [
      {
        section: 'Reading the card',
        text: 'Values below the low threshold indicate deficiency. Values within the medium range respond well to balanced doses of the nutrient.',
        relevance: 'high',
      },
      {
        section: 'pH',
        text: 'Soils with pH below 6.0 may need lime and soils above 8.0 benefit from gypsum or organic matter.',
        relevance: 'medium',
      },
    ],
  },
  {
    id: 'tnau-paddy-fert',
    title: 'Fertilizer Recommendations for Paddy',
    publisher: 'Tamil Nadu Agricultural University',
    year: 2023,
    kind: 'Government advisory',
    language: 'English & Tamil',
    reliability: 'Verified',
    topics: ['paddy', 'urea', 'top dressing', 'fertilizer'],
    summary:
      'Stage-wise nitrogen, phosphorus and potassium schedule for transplanted and direct-sown paddy in the delta region.',
    excerpts: [
      {
        section: 'Top dressing',
        text: 'Apply the second dose of nitrogen at active tillering, about 25 kg urea per acre, after draining the field and mixing with moist soil.',
        relevance: 'high',
      },
      {
        section: 'Timing',
        text: 'Avoid applying fertilizer immediately before heavy rain because nutrients wash away and losses increase.',
        relevance: 'medium',
      },
    ],
  },
  {
    id: 'irri-bph',
    title: 'Brown Planthopper: Monitoring and Management Note',
    publisher: 'International Rice Research Institute',
    year: 2021,
    kind: 'Research paper',
    language: 'English',
    reliability: 'Peer reviewed',
    topics: ['rice', 'planthopper', 'pest', 'hopperburn'],
    summary:
      'Research summary on monitoring planthopper populations at the base of rice hills and avoiding excess nitrogen during outbreaks.',
    excerpts: [
      {
        section: 'Monitoring',
        text: 'Check 10 hills per field at the base of plants. More than 10 hoppers per hill at tillering calls for control action.',
        relevance: 'medium',
      },
    ],
  },
  {
    id: 'tnau-groundnut',
    title: 'Groundnut Nutrition and Irrigation Guide',
    publisher: 'Tamil Nadu Agricultural University',
    year: 2022,
    kind: 'Extension guide',
    language: 'English & Tamil',
    reliability: 'Verified',
    topics: ['groundnut', 'irrigation', 'flowering', 'water'],
    summary:
      'Irrigation schedule, critical water stages and nutrient needs for groundnut grown in red and sandy loam soils.',
    excerpts: [
      {
        section: 'Critical stages',
        text: 'Flowering to pegging is the most sensitive period. Keep the soil moist with light irrigation every 6 to 8 days when rain is absent.',
        relevance: 'high',
      },
      {
        section: 'Harvest',
        text: 'Stop irrigation about two weeks before harvest to improve pod maturity and quality.',
        relevance: 'medium',
      },
    ],
  },
  {
    id: 'iiwbr-rust',
    title: 'Wheat Rust Surveillance Bulletin',
    publisher: 'ICAR Indian Institute of Wheat and Barley Research',
    year: 2024,
    kind: 'Research paper',
    language: 'English',
    reliability: 'Peer reviewed',
    topics: ['wheat', 'rust', 'disease'],
    summary: 'Surveillance findings on stripe and leaf rust with advice on resistant varieties and early spraying.',
    excerpts: [
      {
        section: 'Leaf rust',
        text: 'Orange-brown pustules appear scattered on upper leaf surfaces. Early detection allows timely fungicide application.',
        relevance: 'high',
      },
    ],
  },
  {
    id: 'cicr-bollworm',
    title: 'Pink Bollworm Management in Cotton',
    publisher: 'Central Institute for Cotton Research',
    year: 2023,
    kind: 'Government advisory',
    language: 'English',
    reliability: 'Verified',
    topics: ['cotton', 'bollworm', 'pest'],
    summary: 'Pheromone trap monitoring, rosette flower checks and destruction of infested bolls for pink bollworm control.',
    excerpts: [
      {
        section: 'Monitoring',
        text: 'Install pheromone traps at 5 per acre. Check rosette flowers for larvae and remove infested bolls from the field.',
        relevance: 'high',
      },
    ],
  },
  {
    id: 'iimr-millet',
    title: 'Millet Crop Calendar for Southern India',
    publisher: 'ICAR Indian Institute of Millets Research',
    year: 2024,
    kind: 'Extension guide',
    language: 'English & Tamil',
    reliability: 'Verified',
    topics: ['ragi', 'millet', 'sowing', 'season'],
    summary: 'Sowing windows, variety choices and water needs for finger millet and other millets grown under rainfed conditions.',
    excerpts: [
      {
        section: 'Sowing',
        text: 'Finger millet performs well with June to July sowing under rainfed conditions and needs low to moderate water.',
        relevance: 'medium',
      },
    ],
  },
  {
    id: 'iihr-blight',
    title: 'Tomato Early Blight Field Guide',
    publisher: 'ICAR Indian Institute of Horticultural Research',
    year: 2022,
    kind: 'Field manual',
    language: 'English',
    reliability: 'Verified',
    topics: ['tomato', 'blight', 'disease'],
    summary: 'Identification and integrated control of early blight in tomato, including resistant hybrids and crop rotation.',
    excerpts: [
      {
        section: 'Symptoms',
        text: 'Dark concentric rings form on older leaves, giving a target-like pattern. Remove lower infected leaves early.',
        relevance: 'medium',
      },
    ],
  },
  {
    id: 'tnau-organic-ipm',
    title: 'Organic Pest & Disease Management Protocols',
    publisher: 'Tamil Nadu Agricultural University (TNAU)',
    year: 2024,
    kind: 'Field manual',
    language: 'English & Tamil',
    reliability: 'Verified',
    topics: ['organic', 'panchagavya', 'neem', 'biofertilizer', 'trichoderma'],
    summary:
      'Standard operating procedure for preparing and applying organic bio-inputs including Neem Seed Kernel Extract (NSKE 5%), Panchagavya 3%, and Pseudomonas fluorescens for seed and soil treatment.',
    excerpts: [
      {
        section: 'Neem preparation',
        text: 'Soak 5 kg pulverized neem seed kernels in 100 litres of water with soap solution for 12 hours. Spray uniformly on foliage for sucking pests.',
        relevance: 'high',
      },
      {
        section: 'Bio-fungicide',
        text: 'Treat seeds with Trichoderma viride at 4 g/kg or Pseudomonas fluorescens at 10 g/kg to protect root zone against damping off and root rot.',
        relevance: 'high',
      },
    ],
  },
  {
    id: 'tnau-drip-fert',
    title: 'Precision Farming & Drip Fertigation Schedule',
    publisher: 'TNAU Water Technology Centre',
    year: 2023,
    kind: 'Extension guide',
    language: 'English & Tamil',
    reliability: 'Verified',
    topics: ['irrigation', 'fertigation', 'water', 'drip', 'cotton', 'maize'],
    summary:
      'Water-saving drip irrigation guidelines and stage-wise water soluble fertilizer injection tables for commercial crops in Tamil Nadu.',
    excerpts: [
      {
        section: 'Water efficiency',
        text: 'Drip fertigation achieves 40-50% water savings and 25-30% higher fertilizer use efficiency compared to conventional flood irrigation.',
        relevance: 'high',
      },
    ],
  },
];

export function findSource(id: string): Source | undefined {
  return sources.find((source) => source.id === id);
}
