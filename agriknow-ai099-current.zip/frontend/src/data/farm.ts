export const weather = {
  location: 'Thanjavur, Tamil Nadu',
  tempC: 31,
  humidity: 78,
  windKmh: 12,
  rainChance: 60,
  condition: 'Humid, clouds building by evening',
};

export const moistureSeries = {
  labels: ['Oct 20', 'Oct 22', 'Oct 24', 'Oct 26', 'Oct 28', 'Oct 30', 'Nov 1', 'Nov 2'],
  moisture: [44, 41, 58, 55, 49, 46, 52, 57],
  rainfall: [0, 0, 18, 6, 0, 2, 9, 14],
};

export interface CropStatus {
  id: string;
  name: string;
  nameTa: string;
  stage: string;
  daysToHarvest: number;
  health: number;
  areaAcres: number;
  progress: number;
}

export const cropStatuses: CropStatus[] = [
  { id: 'paddy', name: 'Paddy (Samba)', nameTa: 'நெல் (சம்பா)', stage: 'Tillering', daysToHarvest: 92, health: 86, areaAcres: 2.5, progress: 38 },
  { id: 'groundnut', name: 'Groundnut', nameTa: 'நிலக்கடலை', stage: 'Flowering', daysToHarvest: 46, health: 72, areaAcres: 1.2, progress: 64 },
  { id: 'ragi', name: 'Finger Millet (Ragi)', nameTa: 'ராகி', stage: 'Grain filling', daysToHarvest: 21, health: 91, areaAcres: 0.8, progress: 82 },
];

export const yieldComparison = [
  { label: 'Paddy', lastSeason: 24, expected: 26 },
  { label: 'Groundnut', lastSeason: 8, expected: 9 },
  { label: 'Ragi', lastSeason: 11, expected: 12 },
];

export interface FarmTask {
  id: string;
  title: string;
  when: string;
  done: boolean;
}

export const initialTasks: FarmTask[] = [
  { id: 't1', title: 'Top-dress urea on paddy field A', when: 'Today', done: false },
  { id: 't2', title: 'Scout 10 hills for planthopper', when: 'Today', done: false },
  { id: 't3', title: 'Light irrigation on groundnut', when: 'Tomorrow', done: false },
  { id: 't4', title: 'Collect soil sample from field C', when: 'This week', done: true },
];

export const marketPrices = [
  { crop: 'Paddy (Samba)', price: 2300, change: 2.1 },
  { crop: 'Groundnut pods', price: 6100, change: -0.8 },
  { crop: 'Finger millet', price: 3900, change: 1.2 },
];
