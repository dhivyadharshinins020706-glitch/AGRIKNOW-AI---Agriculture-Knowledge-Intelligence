import type { CannedAnswer } from '@/types';

export const assistantWelcome = {
  en: 'Hello! I am AgriKnow AI. You can ask me anything—from crop care, fertilizer schedules, and pest diagnosis to personal questions, general knowledge, or weather.',
  ta: 'வணக்கம்! நான் AgriKnow AI. வேளாண்மை, உர அட்டவணை, பூச்சி மேலாண்மை மட்டுமின்றி, உங்கள் சந்தேகங்கள், பொது அறிவு அல்லது தனிப்பட்ட ஆலோசனைகள் என எதை வேண்டுமானாலும் கேட்கலாம்.',
};

export const assistantProcessingSteps = {
  en: ['Understanding your question', 'Searching verified farm documents', 'Matching your crop and symptoms', 'Writing a clear answer'],
  ta: ['உங்கள் கேள்வியைப் புரிந்துகொள்கிறது', 'சரிபார்க்கப்பட்ட ஆவணங்களில் தேடுகிறது', 'பயிர் மற்றும் அறிகுறிகளைப் பொருத்துகிறது', 'தெளிவான பதிலை எழுதுகிறது'],
};

export const suggestedPrompts = [
  { en: 'Hi, how can you help me today?', ta: 'வணக்கம், நீங்கள் எனக்கு எவ்வாறு உதவலாம்?' },
  { en: 'When should I apply urea to paddy?', ta: 'நெல்லுக்கு யூரியா எப்போது இட வேண்டும்?' },
  { en: 'I feel exhausted and stressed today', ta: 'இன்று எனக்கு மிகவும் சோர்வாகவும் மன அழுத்தமாகவும் உள்ளது' },
  { en: 'What is the best irrigation method for groundnut?', ta: 'நிலக்கடலைக்கு சிறந்த பாசன முறை எது?' },
  { en: 'What is the weather forecast for farming?', ta: 'விவசாயத்திற்கான வானிலை முன்னறிவிப்பு என்ன?' },
];

export const cannedAnswers: CannedAnswer[] = [
  {
    keywords: ['blast', 'brown', 'spot', 'spots', 'leaf', 'leaves', 'இலை', 'புள்ளி', 'பழுப்பு', 'நோய்'],
    en: 'This looks like rice blast, a fungal disease. Look for diamond-shaped grey spots with brown edges on the leaves.\n\n1. Drain standing water for 2 to 3 days from the affected area.\n2. Avoid extra urea. Apply nitrogen in smaller split doses.\n3. If spots keep spreading, spray tricyclazole 75% WP at the dose on the label. Confirm with your Krishi Officer first.\n\nCheck the field again in 5 days.',
    ta: 'இது நெல் ரைஸ் ப்ளாஸ்ட் நோய் போல் தெரிகிறது. இலைகளில் வைர வடிவ சாம்பல் நிறப் புள்ளிகள், ஓரங்களில் பழுப்பு நிறம் இருந்தால் இதுவே.\n\n1. பாதிக்கப்பட்ட பகுதியில் 2 முதல் 3 நாட்கள் தண்ணீரை வடித்து விடுங்கள்.\n2. கூடுதல் யூரியாவைத் தவிருங்கள். நைட்ரஜனைச் சிறு அளவுகளாகப் பிரித்து இடுங்கள்.\n3. புள்ளிகள் பரவினால், லேபிளில் உள்ள அளவில் ட்ரைசைக்ளசோல் 75% WP தெளிக்கலாம். முதலில் வேளாண் அலுவலரிடம் உறுதி செய்யுங்கள்.\n\n5 நாட்களில் மீண்டும் வயலைப் பாருங்கள்.',
    sourceIds: ['tnau-blast', 'icar-rice'],
  },
  {
    keywords: ['fertilizer', 'fertiliser', 'urea', 'manure', 'top dressing', 'உரம்', 'யூரியா'],
    en: 'For paddy at the tillering stage, the second nitrogen top dressing is due now. Apply about 25 kg urea per acre.\n\n1. Drain the field before applying.\n2. Mix the urea into moist soil.\n3. Apply potash as recommended in your soil health card.\n\nDo not apply fertilizer just before heavy rain, because nutrients wash away.',
    ta: 'நெல் தூர் கட்டும் நிலையில் இருந்தால், இப்போது இரண்டாவது யூரியா மேலுரம் இட வேண்டிய நேரம். ஏக்கருக்கு சுமார் 25 கிலோ யூரியா இடலாம்.\n\n1. இடுவதற்கு முன் வயலில் தண்ணீரை வடித்து விடுங்கள்.\n2. ஈரமான மண்ணுடன் யூரியாவைக் கலக்குங்கள்.\n3. மண் அட்டை பரிந்துரைப்படி பொட்டாஷ் இடுங்கள்.\n\nகனமழைக்கு சற்று முன் உரம் இட வேண்டாம், சத்துக்கள் அடித்துச் செல்லப்படும்.',
    sourceIds: ['tnau-paddy-fert', 'soil-card'],
  },
  {
    keywords: ['water', 'irrigat', 'rain', 'groundnut', 'நீர்', 'பாசனம்', 'மழை', 'நிலக்கடலை'],
    en: 'Groundnut needs steady moisture during flowering. If there is no rain, water lightly every 6 to 8 days.\n\n1. Stop irrigation about two weeks before harvest.\n2. Rain is forecast tomorrow, so check the rain gauge before you irrigate.\n\nKeep the soil moist, not waterlogged.',
    ta: 'நிலக்கடலைக்கு பூக்கும் நிலையில் ஈரப்பதம் தேவை. மழை இல்லையெனில் 6 முதல் 8 நாட்களுக்கு ஒருமுறை லேசாகப் பாய்ச்சுங்கள்.\n\n1. அறுவடைக்கு சுமார் 2 வாரங்கள் முன் பாசனத்தை நிறுத்துங்கள்.\n2. நாளை மழை வர வாய்ப்பிருப்பதால், பாய்ச்சும் முன் மழை அளவைப் பாருங்கள்.\n\nமண் ஈரமாக இருக்கட்டும், நீர் தேங்க வேண்டாம்.',
    sourceIds: ['tnau-groundnut'],
  },
];

export const fallbackAnswer: CannedAnswer = {
  keywords: [],
  en: 'I can help with crop disease, fertilizer, irrigation and choosing crops. Tell me your crop and what you see in the field, for example: "my ragi leaves are turning yellow".',
  ta: 'பயிர் நோய், உரம், பாசனம் மற்றும் பயிர் தேர்வு பற்றி நான் உதவ முடியும். உங்கள் பயிரையும் வயலில் நீங்கள் பார்ப்பதையும் சொல்லுங்கள். உதாரணம்: "என் ராகி இலைகள் மஞ்சளாகின்றன".',
  sourceIds: ['soil-card'],
};

export function findAnswer(question: string): CannedAnswer {
  const lower = question.toLowerCase();
  return cannedAnswers.find((answer) => answer.keywords.some((keyword) => lower.includes(keyword))) ?? fallbackAnswer;
}
