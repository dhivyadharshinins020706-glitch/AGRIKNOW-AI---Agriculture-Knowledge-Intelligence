import type { Retrieval } from '@/types';

export interface EvidenceScenario {
  id: string;
  question: string;
  questionTa: string;
  retrievals: Retrieval[];
  citedInAnswer: string[];
  highlightTerms: string[];
}

export const evidenceScenarios: EvidenceScenario[] = [
  {
    id: 'rice-spots',
    question: 'Why are my rice leaves turning brown with spots?',
    questionTa: 'என் நெல் இலைகளில் பழுப்பு நிறப் புள்ளிகள் ஏன் தோன்றுகின்றன?',
    retrievals: [
      { sourceId: 'tnau-blast', score: 0.94 },
      { sourceId: 'icar-rice', score: 0.88 },
      { sourceId: 'tnau-paddy-fert', score: 0.63 },
      { sourceId: 'irri-bph', score: 0.41 },
    ],
    citedInAnswer: ['tnau-blast', 'icar-rice'],
    highlightTerms: ['brown', 'spots', 'lesions', 'leaves', 'blast', 'halo', 'பழுப்பு', 'புள்ளி', 'இலை'],
  },
  {
    id: 'paddy-urea',
    question: 'When should I apply urea top-dressing to paddy?',
    questionTa: 'நெல்லுக்கு யூரியா மேலுரம் எப்போது இட வேண்டும்?',
    retrievals: [
      { sourceId: 'tnau-paddy-fert', score: 0.96 },
      { sourceId: 'soil-card', score: 0.89 },
      { sourceId: 'icar-rice', score: 0.72 },
      { sourceId: 'tnau-blast', score: 0.45 },
    ],
    citedInAnswer: ['tnau-paddy-fert', 'soil-card'],
    highlightTerms: ['top dressing', 'urea', 'tillering', 'nitrogen', 'moist', 'rain', 'உரம்', 'யூரியா', 'மேலுரம்'],
  },
  {
    id: 'cotton-worm',
    question: 'How to monitor and control pink bollworm in cotton?',
    questionTa: 'பருத்தியில் இளஞ்சிவப்பு காய்ப்புழுவை எப்படிக் கட்டுப்படுத்துவது?',
    retrievals: [
      { sourceId: 'cicr-bollworm', score: 0.95 },
      { sourceId: 'tnau-organic-ipm', score: 0.84 },
      { sourceId: 'soil-card', score: 0.38 },
    ],
    citedInAnswer: ['cicr-bollworm', 'tnau-organic-ipm'],
    highlightTerms: ['pheromone', 'traps', 'bollworm', 'rosette', 'larvae', 'neem', 'பொறி', 'புழு', 'பருத்தி'],
  },
  {
    id: 'soil-lime',
    question: 'What should I do for acidic soil with pH below 6.0?',
    questionTa: 'மண் கார அமில நிலை 6.0-க்கு கீழ் உள்ள அமில மண்ணுக்கு என்ன செய்வது?',
    retrievals: [
      { sourceId: 'soil-card', score: 0.97 },
      { sourceId: 'tnau-organic-ipm', score: 0.81 },
      { sourceId: 'tnau-paddy-fert', score: 0.64 },
    ],
    citedInAnswer: ['soil-card', 'tnau-organic-ipm'],
    highlightTerms: ['acidic', 'lime', 'pH', 'calcium', 'dolomite', 'organic', 'அமில', 'சுண்ணாம்பு'],
  },
];

export const evidenceCorpusSize = 12;

// Default scenario export for backwards compatibility
export const evidenceQuestion = evidenceScenarios[0].question;
export const evidenceRetrievals = evidenceScenarios[0].retrievals;
export const evidenceCitedInAnswer = evidenceScenarios[0].citedInAnswer;
export const evidenceHighlightTerms = evidenceScenarios[0].highlightTerms;
