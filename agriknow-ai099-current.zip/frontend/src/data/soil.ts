import type { SoilSample } from '@/types';

export const soilSamples: SoilSample[] = [
  {
    id: 'field-a',
    label: 'Field A',
    location: 'Thanjavur, delta belt',
    crop: 'Paddy (Samba)',
    pH: 6.4,
    nutrients: [
      { key: 'nitrogen', label: 'Nitrogen', value: 214, unit: 'kg/ha', low: 280, high: 560, max: 600 },
      { key: 'phosphorus', label: 'Phosphorus', value: 18, unit: 'kg/ha', low: 11, high: 22, max: 40 },
      { key: 'potassium', label: 'Potassium', value: 146, unit: 'kg/ha', low: 115, high: 280, max: 400 },
      { key: 'organicCarbon', label: 'Organic carbon', value: 0.48, unit: '%', low: 0.5, high: 0.75, max: 1 },
    ],
    plan: [
      { stage: 'Basal', product: 'DAP', dose: '50 kg per acre', timing: 'At transplanting' },
      { stage: 'Tillering', product: 'Urea', dose: '25 kg per acre', timing: 'Day 21 after transplanting' },
      { stage: 'Panicle', product: 'Potash (MOP)', dose: '20 kg per acre', timing: 'Day 45 after transplanting' },
    ],
  },
  {
    id: 'field-b',
    label: 'Field B',
    location: 'Trichy, red sandy loam',
    crop: 'Groundnut',
    pH: 7.6,
    nutrients: [
      { key: 'nitrogen', label: 'Nitrogen', value: 186, unit: 'kg/ha', low: 280, high: 560, max: 600 },
      { key: 'phosphorus', label: 'Phosphorus', value: 9, unit: 'kg/ha', low: 11, high: 22, max: 40 },
      { key: 'potassium', label: 'Potassium', value: 210, unit: 'kg/ha', low: 115, high: 280, max: 400 },
      { key: 'organicCarbon', label: 'Organic carbon', value: 0.62, unit: '%', low: 0.5, high: 0.75, max: 1 },
    ],
    plan: [
      { stage: 'Basal', product: 'Gypsum', dose: '200 kg per acre', timing: 'Before sowing' },
      { stage: 'Basal', product: 'Single super phosphate', dose: '75 kg per acre', timing: 'At sowing' },
      { stage: 'Pegging', product: 'Gypsum (top dressing)', dose: '150 kg per acre', timing: 'Day 35 to 40' },
    ],
  },
  {
    id: 'field-c',
    label: 'Field C',
    location: 'Salem, black soil uplands',
    crop: 'Finger Millet (Ragi)',
    pH: 5.4,
    nutrients: [
      { key: 'nitrogen', label: 'Nitrogen', value: 298, unit: 'kg/ha', low: 280, high: 560, max: 600 },
      { key: 'phosphorus', label: 'Phosphorus', value: 24, unit: 'kg/ha', low: 11, high: 22, max: 40 },
      { key: 'potassium', label: 'Potassium', value: 128, unit: 'kg/ha', low: 115, high: 280, max: 400 },
      { key: 'organicCarbon', label: 'Organic carbon', value: 0.71, unit: '%', low: 0.5, high: 0.75, max: 1 },
    ],
    plan: [
      { stage: 'Basal', product: 'Farm yard manure', dose: '2 tonnes per acre', timing: 'Before ploughing' },
      { stage: 'Basal', product: 'DAP', dose: '25 kg per acre', timing: 'At sowing' },
      { stage: 'Tillering', product: 'Urea', dose: '15 kg per acre', timing: 'Day 25 after sowing' },
    ],
  },
];
