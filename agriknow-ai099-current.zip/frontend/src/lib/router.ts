import { useEffect, useState } from 'react';

export interface Route {
  path: string;
  params: URLSearchParams;
}

export function normalizePath(rawPath: string): string {
  let clean = (rawPath || '').trim().toLowerCase();
  clean = clean.replace(/\/+$/, '');
  if (!clean || clean === '') return '/';
  if (!clean.startsWith('/')) clean = `/${clean}`;
  return clean;
}

export function readRoute(): Route {
  if (typeof window === 'undefined') {
    return { path: '/', params: new URLSearchParams() };
  }

  // 1. Check hash first (e.g. #/diseases, #/dashboard, #/soil-fertilizer)
  const hashRaw = window.location.hash.replace(/^#![/]?|^#[/]?/, '').trim();

  // 2. If no hash, inspect pathname (e.g. /diseases, /dashboard, /crop-health, /ingestion)
  let raw = hashRaw;
  if (!raw && window.location.pathname && window.location.pathname !== '/' && window.location.pathname !== '/index.html') {
    raw = window.location.pathname;
  }

  if (!raw) raw = '/';

  const [path, query = ''] = raw.split('?');
  const normalized = normalizePath(path);
  const searchParams = query
    ? new URLSearchParams(query)
    : new URLSearchParams(window.location.search || '');

  return { path: normalized, params: searchParams };
}

export function useRoute(): Route {
  const [route, setRoute] = useState<Route>(readRoute);

  useEffect(() => {
    // If the user arrived via direct path like /assistant or /dashboard without a hash, sync cleanly to hash route
    if (typeof window !== 'undefined') {
      if (!window.location.hash && window.location.pathname && window.location.pathname !== '/' && window.location.pathname !== '/index.html') {
        const norm = normalizePath(window.location.pathname);
        if (norm !== '/') {
          try {
            window.history.replaceState(null, '', `/#${norm}`);
          } catch {
            window.location.hash = `#${norm}`;
          }
          setRoute({ path: norm, params: new URLSearchParams(window.location.search || '') });
        }
      }
    }

    const onChange = () => setRoute(readRoute());
    window.addEventListener('hashchange', onChange);
    window.addEventListener('popstate', onChange);

    return () => {
      window.removeEventListener('hashchange', onChange);
      window.removeEventListener('popstate', onChange);
    };
  }, []);

  return route;
}

export function navigate(to: string) {
  if (typeof window === 'undefined') return;
  const clean = to.trim();
  if (clean.startsWith('#')) {
    window.location.hash = clean;
  } else {
    const formatted = clean.startsWith('/') ? clean : `/${clean}`;
    window.location.hash = `#${formatted}`;
  }
}
