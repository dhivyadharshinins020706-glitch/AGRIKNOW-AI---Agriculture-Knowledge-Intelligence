import { useEffect, useState } from 'react';
import { Camera, FlaskConical, GitCompare, MessageCircleQuestion, TrendingDown, TrendingUp, TriangleAlert, ArrowRight, ShieldCheck, type LucideIcon } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useFarmer } from '@/contexts/FarmerContext';
import { PageHeader } from '@/components/ui/PageHeader';
import { Card } from '@/components/ui/Card';
import { Reveal } from '@/components/ui/Reveal';
import { Badge } from '@/components/ui/Badge';
import { AreaChart } from '@/components/charts/AreaChart';
import { BarChart } from '@/components/charts/BarChart';
import { WeatherCard } from '@/components/dashboard/WeatherCard';
import { CropOverview } from '@/components/dashboard/CropOverview';
import { FarmTasks } from '@/components/dashboard/FarmTasks';
import { moistureSeries, yieldComparison } from '@/data/farm';
import { buttonClass } from '@/components/ui/Button';
import { fetchMandiPrices } from '@/services/mandiService';
import type { MarketPriceItem } from '@/types';

interface QuickAction {
  label: string;
  labelTa: string;
  hint: string;
  hintTa: string;
  href: string;
  icon: LucideIcon;
  tone: string;
}

const quickActions: QuickAction[] = [
  { label: 'Ask a question', labelTa: 'கேள்வி கேளுங்கள்', hint: 'Tamil or English', hintTa: 'தமிழ் அல்லது ஆங்கிலம்', href: '#/assistant', icon: MessageCircleQuestion, tone: 'bg-lilac-200 text-lilac-800' },
  { label: 'Check a crop photo', labelTa: 'இலை படம் சரிபார்', hint: 'Find disease early', hintTa: 'நோயை ஆரம்பத்தில் கண்டறி', href: '#/diseases', icon: Camera, tone: 'bg-sun-100 text-sun-800' },
  { label: 'Read my soil', labelTa: 'மண் பரிசோதனை', hint: 'Fertilizer plan', hintTa: 'உரத் திட்டம் பெறு', href: '#/soil', icon: FlaskConical, tone: 'bg-leaf-100 text-leaf-800' },
  { label: 'Compare crops', labelTa: 'பயிர் ஒப்பீடு', hint: 'Best profit per acre', hintTa: 'ஏக்கருக்கு அதிக லாபம்', href: '#/crops', icon: GitCompare, tone: 'bg-aqua-100 text-aqua-800' },
];

export default function DashboardPage() {
  const { t, lang } = useLanguage();
  const { profile } = useFarmer();
  const [mandiItems, setMandiItems] = useState<MarketPriceItem[]>([]);
  const [isLiveMandi, setIsLiveMandi] = useState(false);

  useEffect(() => {
    let isMounted = true;
    fetchMandiPrices().then((res) => {
      if (isMounted) {
        setMandiItems(res.prices);
        setIsLiveMandi(res.isLive);
      }
    });
    return () => {
      isMounted = false;
    };
  }, []);

  const today = new Date().toLocaleDateString(lang === 'ta' ? 'ta-IN' : 'en-IN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });

  const firstName = profile.name.trim().split(' ')[0] || 'Farmer';
  const greeting = `${t('dashboard.greeting')}, ${firstName}`;

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow={today}
        title={greeting}
        subtitle={t('dashboard.subtitle')}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="success">
              <ShieldCheck className="h-3.5 w-3.5" aria-hidden />
              {t('common.verified')}
            </Badge>
            <a href="#/assistant" className={buttonClass('primary', 'lg')}>
              <MessageCircleQuestion className="h-5 w-5" aria-hidden />
              {t('nav.assistant')}
            </a>
          </div>
        }
      />

      <Reveal>
        <WeatherCard />
      </Reveal>

      <section aria-labelledby="crops-heading" className="space-y-4">
        <div className="flex items-end justify-between gap-4">
          <h2 id="crops-heading" className="text-xl font-bold text-ink-900 sm:text-2xl">
            {t('dashboard.yourCrops')}
          </h2>
          <a href="#/crops" className="text-sm font-medium text-leaf-700 hover:text-leaf-800">
            {t('dashboard.planCrop')}
          </a>
        </div>
        <Reveal>
          <CropOverview />
        </Reveal>
      </section>

      <section aria-labelledby="actions-heading" className="space-y-4">
        <h2 id="actions-heading" className="text-xl font-bold text-ink-900 sm:text-2xl">
          {t('dashboard.quickActions')}
        </h2>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <Reveal key={action.label} delay={index * 0.05}>
                <a
                  href={action.href}
                  className="group flex h-full min-h-[148px] flex-col justify-between rounded-2xl border border-ink-200/70 bg-white p-5 shadow-card transition duration-300 hover:-translate-y-0.5 hover:border-ink-300 hover:shadow-lift"
                >
                  <span className={`flex h-12 w-12 items-center justify-center rounded-xl ${action.tone} transition-transform duration-300 group-hover:scale-110`}>
                    <Icon className="h-6 w-6" aria-hidden />
                  </span>
                  <span className="mt-4">
                    <span className="flex items-center justify-between gap-2 text-base font-bold text-ink-900">
                      {lang === 'ta' ? action.labelTa : action.label}
                      <ArrowRight className="h-4 w-4 shrink-0 text-ink-400 transition-transform duration-300 group-hover:translate-x-1 group-hover:text-ink-900" aria-hidden />
                    </span>
                    <span className="text-sm text-ink-500">
                      {lang === 'ta' ? action.hintTa : action.hint}
                    </span>
                  </span>
                </a>
              </Reveal>
            );
          })}
        </div>
      </section>

      <section aria-labelledby="insights-heading" className="space-y-4">
        <div className="flex items-center justify-between gap-3">
          <h2 id="insights-heading" className="text-xl font-bold text-ink-900 sm:text-2xl">
            {t('dashboard.insights')}
          </h2>
          <Badge tone="neutral">
            {profile.district}, {profile.state}
          </Badge>
        </div>

        <div className="grid gap-4 lg:grid-cols-3">
          <Reveal className="lg:col-span-2">
            <Card className="p-5 sm:p-6">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h3 className="text-lg font-bold text-ink-900">{t('dashboard.soilMoisture')}</h3>
                  <p className="text-sm text-ink-500">{t('dashboard.soilMoistureSubtitle')}</p>
                </div>
                <Badge tone="info">
                  {lang === 'ta' ? 'விவரங்களை அறிய வரைபடத்தில் தொடவும்' : 'Hover chart for values'}
                </Badge>
              </div>
              <div className="mt-6">
                <AreaChart labels={moistureSeries.labels} values={moistureSeries.moisture} color="#079CA0" unit="%" />
              </div>
            </Card>
          </Reveal>

          <Reveal delay={0.08}>
            <Card className="h-full p-5 sm:p-6">
              <h3 className="text-lg font-bold text-ink-900">{t('dashboard.expectedYield')}</h3>
              <p className="text-sm text-ink-500">{t('dashboard.expectedYieldSubtitle')}</p>
              <div className="mt-6">
                <BarChart
                  data={yieldComparison.map((row) => ({ label: row.label, values: [row.lastSeason, row.expected] }))}
                  series={[
                    { name: lang === 'ta' ? 'கடந்த பருவம்' : 'Last season', color: '#C6A9D8' },
                    { name: lang === 'ta' ? 'இந்த பருவம்' : 'This season', color: '#53B54F' },
                  ]}
                  formatValue={(value) => `${value} q`}
                  highlightIndex={0}
                />
              </div>
            </Card>
          </Reveal>
        </div>

        <div className="grid gap-4 lg:grid-cols-3">
          <Reveal className="lg:col-span-2">
            <div className="flex h-full flex-col gap-4 rounded-2xl border border-sun-300/70 bg-gradient-to-br from-sun-50 via-white to-white p-5 shadow-card sm:flex-row sm:items-center sm:p-6">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-sun-400 text-ink-900">
                <TriangleAlert className="h-6 w-6" aria-hidden />
              </span>
              <div className="flex-1">
                <p className="text-base font-bold text-ink-900">
                  {lang === 'ta' ? 'உங்கள் பகுதியில் புகையான் பூச்சி அபாயம் அதிகரிக்கிறது' : 'Planthopper risk is rising near you'}
                </p>
                <p className="mt-1 text-sm text-ink-600 leading-relaxed">
                  {lang === 'ta'
                    ? 'ஈரப்பதமான வானிலையும் நெற்பயிரின் அடர்த்தியான தழைப்பும் புகையான் பூச்சியைத் தூண்டுகிறது. இந்த வாரம் ஒரு வயலுக்கு 10 தூர்களை அடிப்பகுதியில் பரிசோதிக்கவும்.'
                    : 'Humid weather and dense paddy canopies favour brown planthopper. Count hoppers at the base of 10 plants per field this week.'}
                </p>
              </div>
              <a href="#/diseases" className={buttonClass('secondary', 'sm', 'shrink-0')}>
                {lang === 'ta' ? 'வழிகாட்டல் பார்' : 'See guidance'}
              </a>
            </div>
          </Reveal>

          <Reveal delay={0.08}>
            <FarmTasks />
          </Reveal>
        </div>

        <Reveal>
          <Card className="p-5 sm:p-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-lg font-bold text-ink-900">{t('dashboard.mandiPrices')}</h3>
                <p className="text-sm text-ink-500">{t('dashboard.mandiPricesSubtitle')}</p>
              </div>
              <Badge tone={isLiveMandi ? 'success' : 'neutral'}>
                {isLiveMandi
                  ? (lang === 'ta' ? 'நேரடி மண்டி விலை' : 'Live Mandi Feed')
                  : (lang === 'ta' ? 'அரசு நிர்ணய மாதிரி விலை' : 'Benchmark APMC Rates')}
              </Badge>
            </div>
            <ul className="mt-5 grid gap-3 md:grid-cols-3">
              {mandiItems.slice(0, 6).map((item) => {
                const up = item.change >= 0;
                const TrendIcon = up ? TrendingUp : TrendingDown;
                return (
                  <li key={item.crop} className="flex items-center justify-between gap-3 rounded-xl bg-ink-50 p-4">
                    <div className="min-w-0">
                      <p className="truncate text-sm text-ink-600 font-medium">
                        {lang === 'ta' && item.cropTa ? item.cropTa : item.crop}
                      </p>
                      <p className="text-xs text-ink-400">{item.mandi}</p>
                      <p className="mt-1 text-lg font-bold text-ink-900">
                        ₹{item.price.toLocaleString('en-IN')}{' '}
                        <span className="text-xs font-normal text-ink-500">/{item.unit}</span>
                      </p>
                    </div>
                    <span
                      className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ${
                        up ? 'bg-leaf-100 text-leaf-800' : 'bg-danger-100 text-danger-700'
                      }`}
                    >
                      <TrendIcon className="h-3.5 w-3.5" aria-hidden />
                      {up ? '+' : ''}
                      {item.change}%
                    </span>
                  </li>
                );
              })}
            </ul>
          </Card>
        </Reveal>
      </section>
    </div>
  );
}
