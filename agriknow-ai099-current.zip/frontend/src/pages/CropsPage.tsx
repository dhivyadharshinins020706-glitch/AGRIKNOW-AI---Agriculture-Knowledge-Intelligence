import { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Calculator,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Compass,
  Droplets,
  Scale,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { PageHeader } from '@/components/ui/PageHeader';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Segmented } from '@/components/ui/Segmented';
import { BarChart } from '@/components/charts/BarChart';
import { CropSelectCard, ComparisonTable } from '@/components/crops/CropComparison';
import { crops, profitPerAcre } from '@/data/crops';
import { useToast } from '@/contexts/ToastContext';
import { useFarmer } from '@/contexts/FarmerContext';
import { useLanguage } from '@/contexts/LanguageContext';

type SeasonFilter = 'all' | 'Kharif' | 'Rabi';
type WaterFilter = 'all' | 'Low' | 'Medium' | 'High';

interface CropRecommendation {
  cropId: string;
  suitabilityScore: number;
  reasonEn: string;
  reasonTa: string;
  limitationsEn: string;
  limitationsTa: string;
  sourceEn: string;
  sourceTa: string;
}

const MAX_COMPARE = 3;
const defaultSelection = ['paddy', 'groundnut', 'ragi'];

export default function CropsPage() {
  const { profile } = useFarmer();
  const { t, lang } = useLanguage();
  const isTa = lang === 'ta';
  const { show } = useToast();

  const [season, setSeason] = useState<SeasonFilter>('all');
  const [water, setWater] = useState<WaterFilter>('all');
  const [farmAcres, setFarmAcres] = useState<number>(profile.acres || 2.5);
  const [selectedIds, setSelectedIds] = useState<string[]>(defaultSelection);

  // Advisor Form State
  const [advisorOpen, setAdvisorOpen] = useState(false);
  const [region, setRegion] = useState('delta');
  const [soilType, setSoilType] = useState('alluvial');
  const [selectedSeason, setSelectedSeason] = useState('samba');
  const [waterResource, setWaterResource] = useState('canal');
  const [landType, setLandType] = useState('wetland');
  const [recommendations, setRecommendations] = useState<CropRecommendation[] | null>(null);

  const seasonOptions: { value: SeasonFilter; label: string }[] = [
    { value: 'all', label: isTa ? 'அனைத்து பருவம்' : 'All seasons' },
    { value: 'Kharif', label: 'Kharif' },
    { value: 'Rabi', label: 'Rabi' },
  ];

  const visibleCrops = useMemo(
    () =>
      crops.filter((crop) => {
        const matchesSeason = season === 'all' || crop.season === season;
        const matchesWater = water === 'all' || crop.waterNeed === water;
        return matchesSeason && matchesWater;
      }),
    [season, water],
  );

  const selectedCrops = crops.filter((crop) => selectedIds.includes(crop.id));
  const atLimit = selectedIds.length >= MAX_COMPARE;

  const toggle = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds((items) => items.filter((item) => item !== id));
      return;
    }
    if (atLimit) {
      show(
        isTa ? `அதிகபட்சம் ${MAX_COMPARE} பயிர்களை மட்டுமே ஒப்பிட முடியும்` : `You can compare up to ${MAX_COMPARE} crops`,
        {
          description: isTa ? 'வேறொரு பயிரைச் சேர்க்க ஒன்றை நீக்கவும்.' : 'Unselect one crop to add another.',
          tone: 'warning',
        }
      );
      return;
    }
    setSelectedIds((items) => [...items, id]);
  };

  // Algorithmic Crop Recommendation engine
  const handleRunAdvisor = () => {
    const results: CropRecommendation[] = [];

    // Logic based on TNAU Agro-Climatic Zone Matrix
    if (region === 'delta' || landType === 'wetland' || waterResource === 'canal') {
      results.push({
        cropId: 'paddy',
        suitabilityScore: 96,
        reasonEn: 'Heavy clay/alluvial soil with canal water in Delta Samba is the state benchmark for medium/long duration paddy.',
        reasonTa: 'காவிரி டெல்டாவில் வண்டல் மற்றும் நன்செய் நிலத்திற்கு கால்வாய் பாசனத்தில் சம்பா நெல் மிகவும் சிறந்தது.',
        limitationsEn: 'Vulnerable to excess flooding during North-East Monsoon peaks and Brown Planthopper (BPH) outbreaks.',
        limitationsTa: 'வடகிழக்குப் பருவமழையின் போது வெள்ள நீர் தேங்குதல் மற்றும் புகையான் பூச்சி தாக்குதல் அபாயம்.',
        sourceEn: 'TNAU Crop Production Guide 2024 - Wetlands Paddy Advisory',
        sourceTa: 'தமிழ்நாடு வேளாண்மைப் பல்கலைக்கழக கையேடு 2024 - நன்செய் நெல் வழிகாட்டி',
      });
      results.push({
        cropId: 'blackgram',
        suitabilityScore: 90,
        reasonEn: 'Excellent as a rice-fallow pulse utilizing residual soil moisture in Jan-Feb without additional irrigation.',
        reasonTa: 'சம்பா நெல் அறுவடைக்கு முன் பனிப்பயிராக (Rice Fallow) உளுந்து விதைப்பது கூடுதல் வருவாய் தரும்.',
        limitationsEn: 'Sensitive to heavy waterlogging and yellow mosaic virus; requires seed treatment with Imidacloprid.',
        limitationsTa: 'தேங்கி நிற்கும் தண்ணீரைத் தாங்காது; மஞ்சள் தேமல் நோய் வராமல் தடுக்க விதை நேர்த்தி அவசியம்.',
        sourceEn: 'TNAU Pulses Department - Rice Fallow Pulse Advisory',
        sourceTa: 'TNAU பயறு வகைத்துறை - நெல் தரிசு உளுந்து வழிகாட்டி',
      });
    }

    if (soilType === 'red' || region === 'western' || waterResource === 'borewell') {
      results.push({
        cropId: 'groundnut',
        suitabilityScore: 93,
        reasonEn: 'Well-drained red loam soil is optimal for peg penetration and rapid pod development in groundnut.',
        reasonTa: 'நல்ல வடிகால் கொண்ட செம்மண் நிலக்கடலை விழுது இறங்குவதற்கும் திரண்ட காய்கள் உருவாகவும் சிறந்தது.',
        limitationsEn: 'Mandatory 160-200 kg/acre gypsum application at 40-45 DAS to prevent empty pods ("பொக்கு காய்").',
        limitationsTa: '40-45 ஆம் நாளில் ஏக்கருக்கு 160-200 கிலோ ஜிப்சம் இடாவிட்டால் பொக்குக்காய் அதிகமாகும்.',
        sourceEn: 'TNAU Oilseeds Research Station - Groundnut Best Practices',
        sourceTa: 'TNAU எண்ணெய்வித்து ஆராய்ச்சி நிலையம் - நிலக்கடலை வழிகாட்டுதல்',
      });
      results.push({
        cropId: 'maize',
        suitabilityScore: 88,
        reasonEn: 'High productivity in garden land with borewell irrigation. Responsive to hybrid nutrient management.',
        reasonTa: 'ஆழ்துளை கிணற்றுப் பாசன வசதியுள்ள தோட்டக்கால் நிலத்தில் குறுகிய காலத்தில் அதிக விளைச்சல் தரும்.',
        limitationsEn: 'High susceptibility to Fall Armyworm (Spodoptera frugiperda); requires scouting from 10 DAS.',
        limitationsTa: 'படைப்புழு (Fall Armyworm) தாக்குதல் அதிகம்; விதைத்த 10 ஆம் நாள் முதல் தீவிரக் கண்காணிப்பு தேவை.',
        sourceEn: 'ICAR-IIMR Maize Production Technologies Guide',
        sourceTa: 'மத்திய மக்காச்சோளம் ஆராய்ச்சி நிறுவனம் (ICAR) தொழில்நுட்ப கையேடு',
      });
    }

    if (soilType === 'black' || region === 'southern') {
      results.push({
        cropId: 'cotton',
        suitabilityScore: 89,
        reasonEn: 'Deep black cotton soil with high moisture capacity supports long-duration taproot growth.',
        reasonTa: 'ஆழமான கரிசல் மண் ஈரப்பதத்தைத் தக்கவைத்து பருத்தியின் ஆணிவேர் வளர்ச்சிக்கு உறுதுணையாக இருக்கும்.',
        limitationsEn: 'Higher input costs; requires strict sucking pest monitoring and square drop management.',
        limitationsTa: 'அதிக முதலீட்டுச் செலவு; சாறு உறிஞ்சும் பூச்சிகள் மற்றும் பூ மொட்டு உதிர்வதைக் கட்டுப்படுத்த வேண்டும்.',
        sourceEn: 'Central Institute for Cotton Research (CICR) Advisory',
        sourceTa: 'மத்திய பருத்தி ஆராய்ச்சி நிறுவனம் (CICR) வழிகாட்டுதல்',
      });
    }

    if (waterResource === 'rainfed' || soilType === 'sandy') {
      results.push({
        cropId: 'ragi',
        suitabilityScore: 95,
        reasonEn: 'Extremely drought-resilient C4 crop requiring minimal water, highly tolerant to heat and marginal soils.',
        reasonTa: 'வறட்சியைத் தாங்கி குறைந்த நீரில் செழித்து வளரும். மிகக் குறைந்த முதலீடு மற்றும் சத்துமிக்க தானியம்.',
        limitationsEn: 'Lower market price compared to commercial pulses; blast susceptibility during prolonged cloudy weather.',
        limitationsTa: 'சந்தையில் நெல்லை விட விலை குறைவாக இருக்கலாம்; மேகமூட்டமான நாட்களில் குலைநோய் வரக்கூடும்.',
        sourceEn: 'ICAR-IIMR Nutri-cereals Advisory Bulletin',
        sourceTa: 'மத்திய சிறுதானிய ஆராய்ச்சி நிறுவனம் (ICAR) வழிகாட்டுதல்',
      });
    }

    // Sort by suitability score descending
    results.sort((a, b) => b.suitabilityScore - a.suitabilityScore);
    const topPicks = results.slice(0, 3);
    setRecommendations(topPicks);

    show(
      isTa
        ? 'உங்கள் நில நிலைமைகளுக்கான பயிர் பரிந்துரைகள் தயார்!'
        : 'Agro-climatic crop suitability recommendations ready!',
      { tone: 'success' }
    );
  };

  const handleSelectRecommended = (cropId: string) => {
    if (!selectedIds.includes(cropId)) {
      if (selectedIds.length >= MAX_COMPARE) {
        setSelectedIds([selectedIds[0], selectedIds[1], cropId]);
      } else {
        setSelectedIds([...selectedIds, cropId]);
      }
    }
    show(isTa ? 'பயிர் ஒப்பீட்டு அட்டவணையில் சேர்க்கப்பட்டது' : 'Added to side-by-side comparison', { tone: 'info' });
  };

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow={isTa ? 'பயிர் தேர்வு & லாப கணிப்பான்' : 'Crop choice & profit calculator'}
        title={t('crops.title')}
        subtitle={t('crops.subtitle')}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setAdvisorOpen(!advisorOpen)}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-aqua-300 bg-aqua-50 px-3.5 text-xs font-semibold text-aqua-950 transition hover:bg-aqua-100"
            >
              <Compass className="h-4 w-4 text-aqua-700" aria-hidden />
              {isTa ? 'பயிர் தேர்வு ஆலோசகர்' : 'Crop Suitability Advisor'}
              {advisorOpen ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
            </button>
            <Segmented
              id="crop-season"
              label="Season"
              options={seasonOptions}
              value={season}
              onChange={setSeason}
            />
          </div>
        }
      />

      {/* Interactive Crop Suitability Advisor Panel */}
      <AnimatePresence>
        {advisorOpen && (
          <motion.div
            initial={{ opacity: 0, y: -16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            className="rounded-2xl border-2 border-aqua-400 bg-gradient-to-br from-white via-aqua-50/30 to-leaf-50/40 p-6 shadow-lift"
          >
            <div className="flex items-center justify-between border-b border-ink-100 pb-4">
              <div className="flex items-center gap-2.5">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-aqua-100 text-aqua-900">
                  <Compass className="h-5 w-5" />
                </span>
                <div>
                  <h3 className="text-base font-bold text-ink-900">
                    {isTa ? 'விவசாய பயிர் தேர்வு ஆலோசகர் (TNAU வழிகாட்டி)' : 'Agricultural Crop Suitability Advisor'}
                  </h3>
                  <p className="text-xs text-ink-500">
                    {isTa
                      ? 'உங்கள் பகுதி, மண், பருவம் மற்றும் நீர் வசதியைத் தேர்ந்தெடுத்து சிறந்த பயிர்களை அறியவும்.'
                      : 'Provide agro-climatic parameters to rank university-recommended crops with scientific reasoning and limitations.'}
                  </p>
                </div>
              </div>
              <Badge tone="neutral">Phase 5 Intelligence</Badge>
            </div>

            <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
              <label className="space-y-1">
                <span className="text-xs font-semibold text-ink-800">{isTa ? 'வேளாண் மண்டலம்' : 'Agro-Climatic Zone'}</span>
                <select
                  value={region}
                  onChange={(e) => setRegion(e.target.value)}
                  className="h-10 w-full rounded-xl border border-ink-200 bg-white px-3 text-xs font-medium focus:border-aqua-500 focus:outline-none"
                >
                  <option value="delta">{isTa ? 'காவிரி டெல்டா மண்டலம்' : 'Cauvery Delta Zone'}</option>
                  <option value="western">{isTa ? 'மேற்கு மண்டலம் (கொங்கு)' : 'Western Zone (Kongu)'}</option>
                  <option value="southern">{isTa ? 'தென் மண்டலம்' : 'Southern Zone'}</option>
                  <option value="northeastern">{isTa ? 'வடகிழக்கு மண்டலம்' : 'North-Eastern Zone'}</option>
                </select>
              </label>

              <label className="space-y-1">
                <span className="text-xs font-semibold text-ink-800">{isTa ? 'மண் வகை' : 'Soil Type'}</span>
                <select
                  value={soilType}
                  onChange={(e) => setSoilType(e.target.value)}
                  className="h-10 w-full rounded-xl border border-ink-200 bg-white px-3 text-xs font-medium focus:border-aqua-500 focus:outline-none"
                >
                  <option value="alluvial">{isTa ? 'வண்டல் மண் / களிமண்' : 'Clayey / Alluvial'}</option>
                  <option value="red">{isTa ? 'செம்மண்' : 'Red Loam'}</option>
                  <option value="black">{isTa ? 'கரிசல் மண்' : 'Black Cotton Soil'}</option>
                  <option value="sandy">{isTa ? 'மணல் கலந்த செம்மண்' : 'Sandy Loam'}</option>
                </select>
              </label>

              <label className="space-y-1">
                <span className="text-xs font-semibold text-ink-800">{isTa ? 'பருவம்' : 'Season'}</span>
                <select
                  value={selectedSeason}
                  onChange={(e) => setSelectedSeason(e.target.value)}
                  className="h-10 w-full rounded-xl border border-ink-200 bg-white px-3 text-xs font-medium focus:border-aqua-500 focus:outline-none"
                >
                  <option value="samba">{isTa ? 'சம்பா / தாளடி (ஆக-ஜன)' : 'Samba / Thaladi (Aug-Jan)'}</option>
                  <option value="kuruvai">{isTa ? 'குறுவை / சொர்ணவாரி (ஜூன்-செப்)' : 'Kuruvai / Sornavari (Jun-Sep)'}</option>
                  <option value="navarai">{isTa ? 'நவரை / கோடை (ஜன-மே)' : 'Navarai / Summer (Jan-May)'}</option>
                </select>
              </label>

              <label className="space-y-1">
                <span className="text-xs font-semibold text-ink-800">{isTa ? 'நீர் வசதி' : 'Water Availability'}</span>
                <select
                  value={waterResource}
                  onChange={(e) => setWaterResource(e.target.value)}
                  className="h-10 w-full rounded-xl border border-ink-200 bg-white px-3 text-xs font-medium focus:border-aqua-500 focus:outline-none"
                >
                  <option value="canal">{isTa ? 'கால்வாய் / ஆற்றுப் பாசனம்' : 'Perennial Canal / River'}</option>
                  <option value="borewell">{isTa ? 'ஆழ்துளை கிணறு' : 'Assured Borewell / Well'}</option>
                  <option value="rainfed">{isTa ? 'மானாவாரி / குறைந்த நீர்' : 'Rainfed / Limited'}</option>
                </select>
              </label>

              <label className="space-y-1">
                <span className="text-xs font-semibold text-ink-800">{isTa ? 'நில வகை' : 'Land Classification'}</span>
                <select
                  value={landType}
                  onChange={(e) => setLandType(e.target.value)}
                  className="h-10 w-full rounded-xl border border-ink-200 bg-white px-3 text-xs font-medium focus:border-aqua-500 focus:outline-none"
                >
                  <option value="wetland">{isTa ? 'நன்செய் (Wetland)' : 'Wetland (Lowland)'}</option>
                  <option value="garden">{isTa ? 'தோட்டக்கால் (Garden Land)' : 'Garden Land (Upland)'}</option>
                  <option value="dryland">{isTa ? 'புன்செய் (Dryland)' : 'Rainfed Dryland'}</option>
                </select>
              </label>
            </div>

            <div className="mt-4 flex justify-end">
              <button
                type="button"
                onClick={handleRunAdvisor}
                className="inline-flex items-center gap-2 rounded-xl bg-leaf-400 px-5 py-2.5 text-xs font-bold text-ink-900 shadow-card transition hover:bg-leaf-300 active:scale-95"
              >
                <Sparkles className="h-4 w-4" />
                {isTa ? 'பொருத்தமான பயிர்களைக் கண்டறிக' : 'Find Best Suitable Crops'}
              </button>
            </div>

            {/* Recommendations Display */}
            {recommendations && (
              <div className="mt-6 space-y-4 border-t border-ink-200/60 pt-5">
                <h4 className="flex items-center gap-2 text-sm font-bold text-ink-900">
                  <CheckCircle2 className="h-4 w-4 text-leaf-700" />
                  {isTa ? 'பரிந்துரைக்கப்பட்ட பயிர்கள் & காரணங்கள்:' : 'Ranked Agricultural Recommendations:'}
                </h4>

                <div className="grid gap-4 md:grid-cols-3">
                  {recommendations.map((rec) => {
                    const cropInfo = crops.find((c) => c.id === rec.cropId);
                    if (!cropInfo) return null;
                    return (
                      <div
                        key={rec.cropId}
                        className="flex flex-col justify-between rounded-xl border border-ink-200 bg-white p-4 shadow-sm"
                      >
                        <div className="space-y-2.5">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-ink-900">
                              {isTa && cropInfo.nameTa ? cropInfo.nameTa : cropInfo.name}
                            </span>
                            <Badge tone="success">{rec.suitabilityScore}% Match</Badge>
                          </div>

                          <div>
                            <span className="text-[11px] font-bold uppercase tracking-wider text-leaf-800">
                              {isTa ? 'காரணம்:' : 'Agronomic Reasoning:'}
                            </span>
                            <p className="text-xs text-ink-700 leading-relaxed mt-0.5">
                              {isTa ? rec.reasonTa : rec.reasonEn}
                            </p>
                          </div>

                          <div className="rounded-lg bg-amber-50/70 p-2 text-[11px] text-amber-900 leading-snug">
                            <strong className="block font-semibold">
                              {isTa ? 'கட்டுப்பாடுகள் & அபாயங்கள்:' : 'Limitations & Risks:'}
                            </strong>
                            {isTa ? rec.limitationsTa : rec.limitationsEn}
                          </div>

                          <div className="flex items-center gap-1.5 text-[10px] text-ink-500">
                            <ShieldCheck className="h-3 w-3 text-leaf-600 shrink-0" />
                            <span className="truncate">{isTa ? rec.sourceTa : rec.sourceEn}</span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleSelectRecommended(rec.cropId)}
                          className="mt-3 w-full rounded-lg border border-leaf-300 bg-leaf-50 py-1.5 text-xs font-semibold text-leaf-900 transition hover:bg-leaf-100"
                        >
                          {isTa ? 'ஒப்பீட்டில் சேர்க்க' : 'Add to Comparison'}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Acreage & Water Resource Filter Bar */}
      <Card className="flex flex-col gap-4 bg-gradient-to-br from-leaf-50/70 via-white to-aqua-50/70 p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6">
        <div className="flex items-center gap-3">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-leaf-400 text-ink-900 shadow-card">
            <Calculator className="h-5 w-5" aria-hidden />
          </span>
          <div>
            <label htmlFor="farm-acres-input" className="text-xs font-bold uppercase tracking-[0.1em] text-ink-600">
              {t('crops.landSize')}
            </label>
            <div className="flex items-center gap-2 mt-1">
              <input
                id="farm-acres-input"
                type="number"
                min="0.5"
                max="100"
                step="0.5"
                value={farmAcres}
                onChange={(e) => setFarmAcres(Math.max(0.5, parseFloat(e.target.value) || 1))}
                className="h-10 w-24 rounded-xl border border-ink-300 bg-white px-3 text-base font-bold text-ink-900 focus:border-leaf-500 focus:outline-none"
              />
              <span className="text-sm font-semibold text-ink-700">
                {isTa ? 'ஏக்கர்' : 'Acres'}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 text-xs font-semibold text-ink-600">
            <Droplets className="h-4 w-4 text-aqua-600" aria-hidden />
            {isTa ? 'பாசன நீர் வசதி:' : 'Water availability:'}
          </span>
          <div className="flex gap-1">
            {(['all', 'Low', 'Medium', 'High'] as const).map((level) => (
              <button
                key={level}
                type="button"
                onClick={() => setWater(level)}
                className={`rounded-lg px-2.5 py-1 text-xs font-medium transition ${
                  water === level
                    ? 'bg-ink-900 text-white'
                    : 'bg-white border border-ink-200 text-ink-700 hover:bg-ink-100'
                }`}
              >
                {level === 'all' ? (isTa ? 'அனைத்தும்' : 'All') : level}
              </button>
            ))}
          </div>
        </div>
      </Card>

      <section aria-labelledby="choose-heading" className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 id="choose-heading" className="text-xl font-bold text-ink-900 sm:text-2xl">
            {t('crops.chooseUpTo')}
          </h2>
          <p className="text-sm text-ink-500">
            {selectedIds.length} of {MAX_COMPARE} {isTa ? 'தேர்ந்தெடுக்கப்பட்டது' : 'selected'}
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {visibleCrops.map((crop, index) => (
            <motion.div
              key={crop.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05, duration: 0.35 }}
            >
              <CropSelectCard
                crop={crop}
                selected={selectedIds.includes(crop.id)}
                disabled={atLimit}
                onToggle={() => toggle(crop.id)}
                acres={farmAcres}
              />
            </motion.div>
          ))}
        </div>
      </section>

      <section aria-labelledby="compare-heading" className="space-y-4">
        <h2 id="compare-heading" className="flex items-center gap-2 text-xl font-bold text-ink-900 sm:text-2xl">
          <Scale className="h-6 w-6 text-aqua-700" aria-hidden />
          {t('crops.sideBySide')}
        </h2>

        {selectedCrops.length < 2 ? (
          <Card className="p-8 text-center sm:p-10">
            <p className="text-base font-bold text-ink-900">
              {isTa ? 'ஒப்பிடுவதற்கு குறைந்தது இரண்டு பயிர்களைத் தேர்ந்தெடுக்கவும்' : 'Select at least two crops to compare'}
            </p>
            <p className="mt-1 text-sm text-ink-500">
              {isTa ? 'ஒவ்வொரு வரிசையிலும் சிறந்த மதிப்பு பச்சை நிறத்தில் குறிக்கப்படும்.' : 'The best value in each row is highlighted in green.'}
            </p>
          </Card>
        ) : (
          <div className="grid gap-4 xl:grid-cols-[1fr_340px]">
            <ComparisonTable crops={selectedCrops} acres={farmAcres} />
            <Card className="h-fit p-5 sm:p-6">
              <h3 className="text-lg font-bold text-ink-900">{t('crops.calculateProfit')}</h3>
              <p className="text-sm text-ink-500">
                {isTa ? `${farmAcres} ஏக்கருக்கு கணக்கிடப்பட்ட நிகர லாபம்` : `Projected net profit for ${farmAcres} acres`}
              </p>
              <div className="mt-6">
                <BarChart
                  data={selectedCrops.map((crop) => ({
                    label: isTa && crop.nameTa ? crop.nameTa : crop.name,
                    values: [Math.round(profitPerAcre(crop) * farmAcres)],
                  }))}
                  series={[{ name: isTa ? 'மொத்த லாபம் (₹)' : 'Total profit (₹)', color: '#53B54F' }]}
                  formatValue={(value) => `₹${value.toLocaleString('en-IN')}`}
                />
              </div>
            </Card>
          </div>
        )}
      </section>
    </div>
  );
}
