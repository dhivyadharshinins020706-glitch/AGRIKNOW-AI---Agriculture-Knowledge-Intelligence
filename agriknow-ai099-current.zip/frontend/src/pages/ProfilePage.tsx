import { useState, type FormEvent } from 'react';
import { motion } from 'framer-motion';
import {
  CheckCircle2,
  Download,
  Languages,
  LogIn,
  LogOut,
  MapPin,
  Phone,
  RotateCcw,
  Save,
  Sprout,
  UserRound,
  Trash2,
  Shield,
  Sparkles,
} from 'lucide-react';
import {
  hasPersonalizationConsent,
  setPersonalizationConsent,
  getPersonalizationContext,
  updatePersonalizationContext,
  purgePersonalizationContext,
  type FarmerPersonalizationContext,
} from '@/services/personalizationService';
import { useLanguage } from '@/contexts/LanguageContext';
import { useFarmer } from '@/contexts/FarmerContext';
import { useAuth, type UserRole } from '@/contexts/AuthContext';
import { useToast } from '@/contexts/ToastContext';
import { PageHeader } from '@/components/ui/PageHeader';
import { Card } from '@/components/ui/Card';
import { Segmented } from '@/components/ui/Segmented';
import { Switch } from '@/components/ui/Switch';
import { Badge } from '@/components/ui/Badge';
import { crops } from '@/data/crops';
import type { FarmerProfile, FarmerPreferences } from '@/types';
import type { Lang } from '@/lib/i18n';

const languageOptions: { value: Lang; label: string }[] = [
  { value: 'en', label: 'English' },
  { value: 'ta', label: 'தமிழ்' },
];

const tnDistricts = [
  'Thanjavur',
  'Tiruvarur',
  'Nagapattinam',
  'Tiruchirappalli',
  'Madurai',
  'Coimbatore',
  'Erode',
  'Salem',
  'Dharmapuri',
  'Tirunelveli',
  'Villupuram',
  'Cuddalore',
  'Theni',
  'Dindigul',
  'Pudukkottai',
];

const phonePattern = /^[6-9]\d{9}$/;

const fieldClass =
  'h-12 w-full rounded-xl border border-ink-200 bg-white px-4 text-base text-ink-900 placeholder:text-ink-400 transition focus:border-aqua-500 focus:outline-none focus:ring-4 focus:ring-aqua-200/60';

export default function ProfilePage() {
  const { lang, setLang, t } = useLanguage();
  const { profile, updateProfile, preferences, updatePreferences, resetToDefaults, tasks, fields } = useFarmer();
  const { user, role, switchRole, openAuthModal, signOut } = useAuth();
  const { show } = useToast();
  const isTa = lang === 'ta';

  const [formData, setFormData] = useState<FarmerProfile>(profile);
  const [prefData, setPrefData] = useState<FarmerPreferences>(preferences);
  const [personalizationConsent, setPersConsent] = useState(() => hasPersonalizationConsent());
  const [personalContext, setPersContext] = useState(() => getPersonalizationContext());
  const [errors, setErrors] = useState<Partial<Record<'name' | 'phone', string>>>({});

  const handlePurgeAllData = () => {
    const confirmed = window.confirm(
      isTa
        ? 'எச்சரிக்கை: உங்கள் அனைத்து பண்ணை விவரங்கள், மண் வள அட்டைகள் மற்றும் உரையாடல்கள் நிரந்தரமாக அழிக்கப்படும். தொடரவா?'
        : 'Warning: This will permanently delete your farm profile, custom soil health cards, and chat history (Right to Erasure). Continue?'
    );
    if (!confirmed) return;

    try {
      localStorage.clear();
      show(isTa ? 'அனைத்து பண்ணை விவரங்களும் அழிக்கப்பட்டன' : 'All farm data purged successfully', { tone: 'info' });
      setTimeout(() => {
        window.location.reload();
      }, 600);
    } catch {
      // Ignore
    }
  };

  const updateField = <K extends keyof FarmerProfile>(key: K, value: FarmerProfile[K]) => {
    setFormData((current) => ({ ...current, [key]: value }));
  };

  const toggleCrop = (id: string) => {
    setFormData((current) => ({
      ...current,
      cropIds: current.cropIds.includes(id)
        ? current.cropIds.filter((cropId) => cropId !== id)
        : [...current.cropIds, id],
    }));
  };

  const handleLangChange = (newLang: Lang) => {
    setLang(newLang);
    show(newLang === 'ta' ? 'மொழி தமிழுக்கு மாற்றப்பட்டது' : 'Language switched to English', {
      tone: 'info',
    });
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextErrors: typeof errors = {};
    if (!formData.name.trim()) nextErrors.name = isTa ? 'தயவுசெய்து உங்கள் பெயரை உள்ளிடவும்.' : 'Please enter your name.';
    if (!phonePattern.test(formData.phone)) nextErrors.phone = isTa ? 'சரியான 10 இலக்க மொபைல் எண்ணை உள்ளிடவும்.' : 'Enter a valid 10-digit mobile number.';
    setErrors(nextErrors);

    if (Object.keys(nextErrors).length > 0) {
      show(isTa ? 'தயவுசெய்து சுட்டிக்காட்டப்பட்ட புலங்களைச் சரிபார்க்கவும்' : 'Please check the highlighted fields', { tone: 'error' });
      return;
    }

    updateProfile(formData);
    updatePreferences(prefData);
    show(isTa ? 'பண்ணை விவரங்கள் சேமிக்கப்பட்டன' : 'Profile saved', {
      description: isTa ? 'உங்கள் பண்ணை விவரங்கள் மற்றும் எச்சரிக்கை அமைப்புகள் புதுப்பிக்கப்பட்டன.' : 'Your farm details and alert settings are up to date.',
      tone: 'success',
    });
  };

  const exportData = () => {
    const backup = {
      profile: formData,
      preferences: prefData,
      tasks,
      fields,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `agriknow_farm_backup_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    show(isTa ? 'பண்ணைத் தரவு பதிவிறக்கம் செய்யப்பட்டது' : 'Farm data backup exported', { tone: 'success' });
  };

  const handleResetDefaults = () => {
    if (confirm(isTa ? 'மாதிரி பண்ணை அமைப்புகளுக்கு மீட்டமைக்கவா?' : 'Reset farm data to initial sample values?')) {
      resetToDefaults();
      setFormData(profile);
      setPrefData(preferences);
      show(isTa ? 'தரவுகள் மீட்டமைக்கப்பட்டன' : 'Defaults restored', { tone: 'info' });
    }
  };

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow={isTa ? 'பண்ணை அமைப்புகள்' : 'Profile and settings'}
        title={t('profile.title')}
        subtitle={t('profile.subtitle')}
      />

      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        <form onSubmit={handleSubmit} noValidate className="space-y-6">
          <Card className="space-y-6 p-5 sm:p-7">
            <h2 className="flex items-center gap-2 text-lg font-bold text-ink-900">
              <UserRound className="h-5 w-5 text-leaf-700" aria-hidden />
              {t('profile.personal')}
            </h2>

            <div className="grid gap-5 sm:grid-cols-2">
              <label className="space-y-2 sm:col-span-2">
                <span className="text-sm font-semibold text-ink-800">{t('profile.fullName')}</span>
                <input
                  className={fieldClass}
                  value={formData.name}
                  onChange={(event) => updateField('name', event.target.value)}
                  aria-invalid={Boolean(errors.name)}
                  autoComplete="name"
                />
                {errors.name && <span className="text-sm text-danger-700">{errors.name}</span>}
              </label>

              <label className="space-y-2">
                <span className="flex items-center gap-2 text-sm font-semibold text-ink-800">
                  <MapPin className="h-4 w-4 text-ink-500" aria-hidden />
                  {t('profile.village')}
                </span>
                <input
                  className={fieldClass}
                  value={formData.village}
                  onChange={(event) => updateField('village', event.target.value)}
                />
              </label>

              <label className="space-y-2">
                <span className="text-sm font-semibold text-ink-800">{t('profile.district')}</span>
                <select
                  className={fieldClass}
                  value={formData.district}
                  onChange={(event) => updateField('district', event.target.value)}
                >
                  {tnDistricts.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </label>

              <label className="space-y-2 sm:col-span-2">
                <span className="flex items-center gap-2 text-sm font-semibold text-ink-800">
                  <Phone className="h-4 w-4 text-ink-500" aria-hidden />
                  {t('profile.mobile')}
                </span>
                <input
                  className={fieldClass}
                  inputMode="numeric"
                  maxLength={10}
                  value={formData.phone}
                  onChange={(event) => updateField('phone', event.target.value.replace(/\D/g, ''))}
                  aria-invalid={Boolean(errors.phone)}
                  autoComplete="tel-national"
                />
                {errors.phone && <span className="text-sm text-danger-700">{errors.phone}</span>}
              </label>

              <label className="space-y-2">
                <span className="text-sm font-semibold text-ink-800">{t('profile.landAcres')}</span>
                <input
                  type="number"
                  step="0.5"
                  min="0.5"
                  className={fieldClass}
                  value={formData.acres}
                  onChange={(event) => updateField('acres', parseFloat(event.target.value) || 1)}
                />
              </label>

              <label className="space-y-2">
                <span className="text-sm font-semibold text-ink-800">{t('profile.soilType')}</span>
                <select
                  className={fieldClass}
                  value={formData.soilType}
                  onChange={(event) => updateField('soilType', event.target.value as FarmerProfile['soilType'])}
                >
                  <option value="Alluvial Clay">Alluvial Clay (வண்டல் களிமண்)</option>
                  <option value="Red Sandy Loam">Red Sandy Loam (செம்மண் சரளை)</option>
                  <option value="Black Cotton">Black Cotton (கரிசல் மண்)</option>
                  <option value="Laterite">Laterite (செம்பொறை மண்)</option>
                  <option value="Coastal Sand">Coastal Sand (கடலோர மணல்)</option>
                </select>
              </label>

              <label className="space-y-2 sm:col-span-2">
                <span className="text-sm font-semibold text-ink-800">{t('profile.irrigation')}</span>
                <select
                  className={fieldClass}
                  value={formData.irrigationSource}
                  onChange={(event) => updateField('irrigationSource', event.target.value as FarmerProfile['irrigationSource'])}
                >
                  <option value="Canal">Canal Irrigation (ஆற்றுப் பாசனம்)</option>
                  <option value="Borewell">Borewell (ஆழ்குழாய் கிணறு)</option>
                  <option value="Open Well">Open Well (திறந்த வெளி கிணறு)</option>
                  <option value="Rainfed">Rainfed (மானாவாரி)</option>
                  <option value="Drip Irrigation">Drip Irrigation (சொட்டு நீர்ப் பாசனம்)</option>
                </select>
              </label>
            </div>
          </Card>

          <Card className="space-y-5 p-5 sm:p-7">
            <div>
              <h2 className="flex items-center gap-2 text-lg font-bold text-ink-900">
                <Sprout className="h-5 w-5 text-leaf-700" aria-hidden />
                {t('profile.myCrops')}
              </h2>
              <p className="mt-1 text-sm text-ink-500">
                {isTa ? 'இந்த பருவத்தில் நீங்கள் பயிரிடும் பயிர்களைத் தேர்ந்தெடுக்கவும்.' : 'Choose the crops you grow this season.'}
              </p>
            </div>
            <div className="flex flex-wrap gap-2" role="group" aria-label="My crops">
              {crops.map((crop) => {
                const selected = formData.cropIds.includes(crop.id);
                return (
                  <button
                    key={crop.id}
                    type="button"
                    aria-pressed={selected}
                    onClick={() => toggleCrop(crop.id)}
                    className={`min-h-11 rounded-full border px-4 text-sm font-semibold transition duration-200 active:scale-[0.97] ${
                      selected
                        ? 'border-leaf-500 bg-leaf-100 text-leaf-900'
                        : 'border-ink-200 bg-white text-ink-700 hover:border-ink-300 hover:bg-ink-50'
                    }`}
                  >
                    {isTa && crop.nameTa ? crop.nameTa : crop.name}
                  </button>
                );
              })}
            </div>
          </Card>

          <div className="flex justify-end">
            <motion.button
              type="submit"
              whileTap={{ scale: 0.98 }}
              className="inline-flex h-12 items-center gap-2 rounded-xl bg-leaf-400 px-6 text-base font-bold text-ink-900 shadow-[0_10px_24px_-12px_rgba(83,181,79,0.9)] transition hover:bg-leaf-300"
            >
              <Save className="h-5 w-5" aria-hidden />
              {t('profile.save')}
            </motion.button>
          </div>
        </form>

        <aside className="space-y-6">
          <Card className="p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-2 text-lg font-bold text-ink-900">
                <UserRound className="h-5 w-5 text-leaf-700" aria-hidden />
                {isTa ? 'கிளவுட் கணக்கு' : 'Cloud Account'}
              </h2>
              {user ? (
                <Badge tone="success">
                  <CheckCircle2 className="h-3.5 w-3.5" aria-hidden />
                  {isTa ? 'இணைக்கப்பட்டது' : 'Active'}
                </Badge>
              ) : (
                <Badge tone="neutral">{isTa ? 'உள்ளூர் முறை' : 'Local Mode'}</Badge>
              )}
            </div>

            {user ? (
              <div className="space-y-3">
                <div className="rounded-xl bg-ink-50 p-3">
                  <p className="text-xs text-ink-500 font-semibold">{isTa ? 'மின்னஞ்சல்' : 'Account Email'}</p>
                  <p className="text-sm font-bold text-ink-900 truncate mt-0.5">{user.email}</p>
                </div>
                <button
                  type="button"
                  onClick={() => signOut()}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border border-ink-200 py-2.5 text-xs font-semibold text-danger-700 hover:bg-danger-50 transition"
                >
                  <LogOut className="h-4 w-4" />
                  {isTa ? 'வெளியேறு (Sign Out)' : 'Sign Out'}
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-xs text-ink-600 leading-relaxed">
                  {isTa
                    ? 'உங்கள் பண்ணை விவரங்களையும் உரத் திட்டங்களையும் பல சாதனங்களில் ஒத்திசைக்க கணக்கில் உள்நுழையவும்.'
                    : 'Sign in to sync your farm profile, field tests, and tasks across your phone and tablet.'}
                </p>
                <div className="flex flex-col gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => openAuthModal('login')}
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-leaf-400 py-2.5 text-xs font-bold text-ink-900 shadow-card hover:bg-leaf-300 transition"
                  >
                    <LogIn className="h-4 w-4" />
                    {isTa ? 'உள்நுழையவும் (Sign In)' : 'Sign In'}
                  </button>
                  <button
                    type="button"
                    onClick={() => openAuthModal('register')}
                    className="flex w-full items-center justify-center gap-2 rounded-xl border border-ink-200 bg-white py-2.5 text-xs font-semibold text-ink-800 hover:bg-ink-50 transition"
                  >
                    {isTa ? 'புதிய கணக்கு பதிவு செய்' : 'Create Free Account'}
                  </button>
                </div>
              </div>
            )}
          </Card>

          <Card className="space-y-4 p-5 sm:p-6">
            <h2 className="flex items-center gap-2 text-lg font-bold text-ink-900">
              <Languages className="h-5 w-5 text-aqua-700" aria-hidden />
              {t('profile.language')}
            </h2>
            <Segmented
              id="profile-language"
              label="Preferred language"
              options={languageOptions}
              value={lang}
              onChange={handleLangChange}
              className="w-full"
            />
            <p className="text-sm text-ink-500">
              {isTa ? 'முழு செயலியின் மெனுக்களும் விடைகளும் இந்த மொழியில் மாறும்.' : 'Assistant answers and menus switch to this language immediately.'}
            </p>
          </Card>

          <Card className="space-y-1 p-5 sm:p-6">
            <h2 className="mb-3 text-lg font-bold text-ink-900">{t('profile.alerts')}</h2>
            <ul className="divide-y divide-ink-100">
              <li className="flex items-center justify-between gap-4 py-3.5">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-ink-900">
                    {isTa ? 'மழை & வானிலை எச்சரிக்கைகள்' : 'Weather & Rain Alerts'}
                  </p>
                  <p className="text-xs text-ink-500">
                    {isTa ? 'கனமழை அல்லது வெப்ப எச்சரிக்கைகள்' : 'Heavy rain and storm advisories'}
                  </p>
                </div>
                <Switch
                  label="Weather Alerts"
                  checked={prefData.weatherAlerts}
                  onChange={(c) => setPrefData((prev) => ({ ...prev, weatherAlerts: c }))}
                />
              </li>

              <li className="flex items-center justify-between gap-4 py-3.5">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-ink-900">
                    {isTa ? 'பூச்சி & நோய் எச்சரிக்கைகள்' : 'Crop Disease Warnings'}
                  </p>
                  <p className="text-xs text-ink-500">
                    {isTa ? 'வட்டார பூச்சி பரவல் தகவல்' : 'Pest outbreak alerts in your district'}
                  </p>
                </div>
                <Switch
                  label="Disease Alerts"
                  checked={prefData.diseaseAlerts}
                  onChange={(c) => setPrefData((prev) => ({ ...prev, diseaseAlerts: c }))}
                />
              </li>

              <li className="flex items-center justify-between gap-4 py-3.5">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-ink-900">
                    {isTa ? 'மண்டி விலை மாறுதல் தகவல்' : 'Mandi Price Movements'}
                  </p>
                  <p className="text-xs text-ink-500">
                    {isTa ? 'விலை 5% மாறும்போது தகவல்' : 'When crop prices move by 5%'}
                  </p>
                </div>
                <Switch
                  label="Price Alerts"
                  checked={prefData.priceAlerts}
                  onChange={(c) => setPrefData((prev) => ({ ...prev, priceAlerts: c }))}
                />
              </li>
            </ul>
          </Card>

          {/* Phase 9 AI Personalization Memory & Consent Control */}
          <Card className="p-5 sm:p-6 space-y-4 border-clay-200 bg-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-clay-600" />
                <h2 className="text-sm font-bold text-ink-900">
                  {isTa ? 'AI தனிப்பயனாக்க நினைவகம் (Phase 9)' : 'AI Farm Memory & Context'}
                </h2>
              </div>
              <Switch
                label="Personalization Consent"
                checked={personalizationConsent}
                onChange={(c) => {
                  setPersonalizationConsent(c);
                  setPersConsent(c);
                  setPersContext(getPersonalizationContext());
                  show(
                    isTa
                      ? c
                        ? 'தனிப்பயனாக்க ஒப்புதல் வழங்கப்பட்டது'
                        : 'தனிப்பயனாக்க நினைவகம் அழிக்கப்பட்டது'
                      : c
                      ? 'Personalization context enabled'
                      : 'Personalization memory purged',
                    { tone: 'info' }
                  );
                }}
              />
            </div>

            <p className="text-xs text-ink-500 leading-relaxed">
              {isTa
                ? 'உங்கள் ஒப்புதலுடன் மட்டுமே உங்கள் மாவட்டம், பயிர் மற்றும் வளர்ச்சி நிலை AI வழிகாட்டலில் நினைவில் வைக்கப்படும். எந்நேரமும் இதை மாற்றலாம் அல்லது அழிக்கலாம்.'
                : 'With your explicit consent, AGRIKNOW recalls your current crop, growth stage, and district to give tailored agronomic guidance. You retain full control to edit or purge anytime.'}
            </p>

            {personalizationConsent && (
              <div className="space-y-3 pt-2 border-t border-ink-100">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-ink-800">
                    {isTa ? 'நடப்பு முதன்மை பயிர்:' : 'Current Primary Crop:'}
                  </label>
                  <select
                    className="h-9 w-full rounded-lg border border-ink-200 bg-white px-2.5 text-xs text-ink-900"
                    value={personalContext.primaryCrop || 'Paddy'}
                    onChange={(e) => {
                      updatePersonalizationContext({ primaryCrop: e.target.value });
                      setPersContext(getPersonalizationContext());
                    }}
                  >
                    <option value="Paddy">Paddy (நெல்)</option>
                    <option value="Cotton">Cotton (பருத்தி)</option>
                    <option value="Sugarcane">Sugarcane (கரும்பு)</option>
                    <option value="Maize">Maize (மக்காச்சோளம்)</option>
                    <option value="Groundnut">Groundnut (நிலக்கடலை)</option>
                    <option value="Banana">Banana (வாழை)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-ink-800">
                    {isTa ? 'பயிர் வளர்ச்சி நிலை:' : 'Current Growth Stage:'}
                  </label>
                  <select
                    className="h-9 w-full rounded-lg border border-ink-200 bg-white px-2.5 text-xs text-ink-900"
                    value={personalContext.currentCropStage || 'tillering'}
                    onChange={(e) => {
                      updatePersonalizationContext({
                        currentCropStage: e.target.value as FarmerPersonalizationContext['currentCropStage'],
                      });
                      setPersContext(getPersonalizationContext());
                    }}
                  >
                    <option value="land_preparation">Land Preparation (நிலம் தயாரித்தல்)</option>
                    <option value="sowing">Sowing / Nursery (நாற்று / விதைப்பு)</option>
                    <option value="vegetative">Vegetative Growth (வளர்ச்சிப் பருவம்)</option>
                    <option value="tillering">Tillering (தூர் கட்டும் பருவம்)</option>
                    <option value="flowering">Flowering / Heading (பூக்கும் பருவம் / கதிர்)</option>
                    <option value="grain_filling">Grain Filling (பால் பருவம் / காய் திரட்சி)</option>
                    <option value="harvesting">Harvesting (அறுவடை)</option>
                  </select>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    purgePersonalizationContext();
                    setPersConsent(false);
                    setPersContext(getPersonalizationContext());
                    show(
                      isTa
                        ? 'தனிப்பயனாக்க நினைவகம் முழுமையாக அழிக்கப்பட்டது'
                        : 'Personalization memory erased',
                      { tone: 'info' }
                    );
                  }}
                  className="w-full rounded-lg border border-clay-300 bg-clay-50/60 py-1.5 text-[11px] font-semibold text-clay-800 hover:bg-clay-100 transition"
                >
                  {isTa ? 'நினைவகத்தை மட்டும் அழி' : 'Erase Context Memory'}
                </button>
              </div>
            )}
          </Card>

          <Card className="p-5 sm:p-6 space-y-3">
            <h2 className="text-base font-bold text-ink-900">{t('profile.dataManagement')}</h2>
            <p className="text-xs text-ink-500 leading-relaxed">
              {isTa
                ? 'உங்கள் பண்ணை விவரங்கள் மற்றும் சேமித்த மண் வள அட்டைகள் உங்கள் உலாவியில் பாதுகாப்பாக உள்ளன.'
                : 'Your farm profile and custom field records are stored safely on your device.'}
            </p>
            <div className="flex flex-col gap-2 pt-2">
              <button
                type="button"
                onClick={exportData}
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-ink-200 bg-white py-2 text-xs font-semibold text-ink-800 hover:bg-ink-50"
              >
                <Download className="h-4 w-4 text-leaf-700" aria-hidden />
                {t('profile.exportData')}
              </button>
              <button
                type="button"
                onClick={handleResetDefaults}
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-ink-200 bg-white py-2 text-xs font-semibold text-ink-700 hover:bg-ink-50"
              >
                <RotateCcw className="h-4 w-4" aria-hidden />
                {t('profile.resetDefaults')}
              </button>
              <button
                type="button"
                onClick={handlePurgeAllData}
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-danger-200 bg-danger-50 py-2 text-xs font-semibold text-danger-700 hover:bg-danger-100 transition"
              >
                <Trash2 className="h-4 w-4 text-danger-700" aria-hidden />
                {isTa ? 'அனைத்து தரவுகளையும் நீக்கு (Right to Erasure)' : 'Purge All Farm Data (Right to Erasure)'}
              </button>
            </div>
          </Card>

          {/* Role-Based Permissions Selector */}
          <Card className="p-5 sm:p-6 space-y-3 border-leaf-200 bg-leaf-50/40">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-leaf-700" />
              <h2 className="text-sm font-bold text-ink-900">
                {isTa ? 'பணிப்பொறுப்பு & அணுகல் உரிமை' : 'User Role & Permissions (RBAC)'}
              </h2>
            </div>
            <p className="text-xs text-ink-600 leading-relaxed">
              {isTa
                ? 'உங்கள் அணுகல் நிலையை மாற்றலாம். வேளாண் அலுவலர் அல்லது விஞ்ஞானி பொறுப்புகள் ஆவண செயலாக்கத்தை அனுமதிக்கும்.'
                : 'Select your system authorization tier. Officers and Scientists have verified document ingestion rights.'}
            </p>
            <div className="grid grid-cols-2 gap-2 pt-1">
              {(
                [
                  { id: 'farmer', label: isTa ? 'விவசாயி' : 'Farmer' },
                  { id: 'officer', label: isTa ? 'வேளாண் அலுவலர்' : 'Extension Officer' },
                  { id: 'scientist', label: isTa ? 'விஞ்ஞானி' : 'Scientist' },
                  { id: 'admin', label: isTa ? 'நிர்வாகி' : 'Admin' },
                ] as const
              ).map((tier) => (
                <button
                  key={tier.id}
                  type="button"
                  onClick={() => {
                    switchRole(tier.id as UserRole);
                    show(
                      isTa
                        ? `பணிப்பொறுப்பு மாற்றப்பட்டது: ${tier.label}`
                        : `Role switched to ${tier.label}`,
                      { tone: 'success' }
                    );
                  }}
                  className={`rounded-xl py-2 px-2 text-xs font-semibold border transition text-center ${
                    role === tier.id
                      ? 'border-leaf-500 bg-white text-leaf-950 shadow-sm ring-2 ring-leaf-200'
                      : 'border-ink-200 bg-white/70 text-ink-600 hover:bg-white hover:text-ink-900'
                  }`}
                >
                  {tier.label}
                </button>
              ))}
            </div>
          </Card>
        </aside>
      </div>
    </div>
  );
}
