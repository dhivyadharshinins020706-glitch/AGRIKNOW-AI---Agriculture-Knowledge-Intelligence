import { Fragment, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { BookMarked, CheckCircle2, FileText, Search, Sparkles } from 'lucide-react';
import { PageHeader } from '@/components/ui/PageHeader';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { useRoute } from '@/lib/router';
import { findSource } from '@/data/sources';
import {
  evidenceCorpusSize,
  evidenceScenarios,
} from '@/data/evidence';
import type { Excerpt, Source } from '@/types';
import { useLanguage } from '@/contexts/LanguageContext';

function highlight(text: string, terms: string[]) {
  if (!terms || terms.length === 0) return text;
  const pattern = new RegExp(`(${terms.join('|')})`, 'gi');
  return text.split(pattern).map((part, index) =>
    index % 2 === 1 ? (
      <mark key={index} className="rounded bg-aqua-200/80 px-0.5 text-ink-900 font-medium">
        {part}
      </mark>
    ) : (
      <Fragment key={index}>{part}</Fragment>
    ),
  );
}

function ExcerptBlock({ excerpt, index, terms }: { excerpt: Excerpt; index: number; terms: string[] }) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08, duration: 0.3 }}
      className="rounded-2xl border border-ink-200 bg-white p-5 shadow-card"
    >
      <div className="flex items-center justify-between gap-3">
        <p className="text-xs font-bold uppercase tracking-[0.1em] text-ink-500">{excerpt.section}</p>
        <Badge tone={excerpt.relevance === 'high' ? 'success' : 'neutral'}>
          {excerpt.relevance === 'high' ? 'Strong match' : 'Partial match'}
        </Badge>
      </div>
      <p className="mt-3 text-[15px] leading-relaxed text-ink-800">{highlight(excerpt.text, terms)}</p>
    </motion.article>
  );
}

export default function EvidencePage() {
  const { params } = useRoute();
  const { t, lang } = useLanguage();
  const isTa = lang === 'ta';

  const [selectedScenarioId, setSelectedScenarioId] = useState(evidenceScenarios[0].id);

  const scenario = evidenceScenarios.find((s) => s.id === selectedScenarioId) ?? evidenceScenarios[0];

  const retrieved = useMemo(
    () =>
      scenario.retrievals
        .map((item) => ({ ...item, source: findSource(item.sourceId) }))
        .filter((item): item is typeof item & { source: Source } => item.source !== undefined),
    [scenario],
  );

  const requestedDoc = params.get('doc');
  const active = retrieved.find((item) => item.sourceId === requestedDoc) ?? retrieved[0];
  const doc = active?.source;
  const cited = doc ? scenario.citedInAnswer.includes(doc.id) : false;

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow={isTa ? 'ஆதார ஆய்வுக்கூடம்' : 'Evidence explorer'}
        title={t('evidence.title')}
        subtitle={t('evidence.subtitle')}
        actions={
          <div className="flex items-center gap-2">
            <Badge tone="info">
              {isTa ? 'ஆய்வு செய்யப்பட்ட ஆவணங்கள்:' : 'Corpus indexed:'} {evidenceCorpusSize}
            </Badge>
          </div>
        }
      />

      {/* Scenario Question Selector */}
      <Card className="space-y-4 p-5 sm:p-6 bg-gradient-to-br from-lilac-50 via-white to-aqua-50">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-lilac-200 text-lilac-800">
              <Sparkles className="h-5 w-5" aria-hidden />
            </span>
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.12em] text-ink-500">
                {t('evidence.questionAsked')}
              </p>
              <h2 className="mt-1 text-lg font-bold text-ink-900">
                &ldquo;{isTa ? scenario.questionTa : scenario.question}&rdquo;
              </h2>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 pt-2 border-t border-ink-100">
          <span className="text-xs font-semibold text-ink-500 py-1.5">
            {isTa ? 'கேள்வி உதாரணங்கள்:' : 'Sample query tests:'}
          </span>
          {evidenceScenarios.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => setSelectedScenarioId(s.id)}
              className={`rounded-full px-3 py-1.5 text-xs font-medium transition ${
                selectedScenarioId === s.id
                  ? 'bg-ink-900 text-white'
                  : 'border border-ink-200 bg-white text-ink-700 hover:border-ink-300'
              }`}
            >
              {isTa ? s.questionTa.slice(0, 32) + '...' : s.question.slice(0, 36) + '...'}
            </button>
          ))}
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-[360px_1fr]">
        <section aria-labelledby="retrieved-heading" className="space-y-3">
          <h2 id="retrieved-heading" className="flex items-center gap-2 text-lg font-bold text-ink-900">
            <Search className="h-5 w-5 text-aqua-700" aria-hidden />
            {t('evidence.retrievedDocs')}
          </h2>
          <ul className="space-y-3">
            {retrieved.map((item, index) => {
              const isActive = doc && item.sourceId === doc.id;
              const isCited = scenario.citedInAnswer.includes(item.sourceId);
              return (
                <li key={item.sourceId}>
                  <a
                    href={`#/evidence?doc=${item.sourceId}`}
                    className={`block rounded-2xl border p-4 transition duration-200 ${
                      isActive
                        ? 'border-aqua-500 bg-aqua-50/70 shadow-card'
                        : 'border-ink-200 bg-white hover:border-ink-300 hover:shadow-card'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-ink-500">#{index + 1}</span>
                      <div className="flex items-center gap-1.5">
                        {isCited && (
                          <Badge tone="success">
                            <CheckCircle2 className="h-3 w-3" aria-hidden />
                            Cited
                          </Badge>
                        )}
                        <Badge tone="info">{Math.round(item.score * 100)}% match</Badge>
                      </div>
                    </div>
                    <p className="mt-2 text-base font-bold text-ink-900">{item.source.title}</p>
                    <p className="mt-1 text-xs text-ink-500">
                      {item.source.publisher}, {item.source.year}
                    </p>
                  </a>
                </li>
              );
            })}
          </ul>
        </section>

        {doc && (
          <section aria-labelledby="active-doc-heading" className="space-y-5">
            <Card className="p-6">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone="neutral">{doc.kind}</Badge>
                  <Badge tone="neutral">{doc.language}</Badge>
                  <Badge tone={doc.reliability === 'Verified' ? 'success' : 'info'}>
                    {doc.reliability}
                  </Badge>
                  {cited && <Badge tone="success">Directly Cited in Final Answer</Badge>}
                </div>
                <span className="text-xs font-semibold text-ink-500">ID: {doc.id}</span>
              </div>

              <h2 id="active-doc-heading" className="mt-4 text-2xl font-bold text-ink-900">
                {doc.title}
              </h2>
              <p className="mt-1 text-sm text-ink-600">
                {doc.publisher} &bull; {doc.year}
              </p>

              <div className="mt-4 rounded-xl bg-ink-50 p-4">
                <p className="text-xs font-bold uppercase tracking-[0.1em] text-ink-500">
                  {isTa ? 'ஆவணச் சுருக்கம்' : 'Summary'}
                </p>
                <p className="mt-1.5 text-sm leading-relaxed text-ink-800">{doc.summary}</p>
              </div>

              <div className="mt-6 space-y-4">
                <h3 className="flex items-center gap-2 text-base font-bold text-ink-900">
                  <BookMarked className="h-4 w-4 text-leaf-700" aria-hidden />
                  {isTa ? 'பொருந்திய முக்கிய வரிகள் (Excerpts)' : 'Matching Excerpts & Key Passages'}
                </h3>
                <div className="space-y-3">
                  {doc.excerpts.map((excerpt, idx) => (
                    <ExcerptBlock
                      key={`${excerpt.section}-${idx}`}
                      excerpt={excerpt}
                      index={idx}
                      terms={scenario.highlightTerms}
                    />
                  ))}
                </div>
              </div>

              <div className="mt-6 border-t border-ink-100 pt-4 flex justify-between items-center">
                <span className="text-xs text-ink-500">
                  {isTa ? 'அறிவு நூலகத்தில் இந்த ஆவணம் சேமிக்கப்பட்டுள்ளது' : 'This document is verified and stored in Knowledge Library'}
                </span>
                <a
                  href="#/library"
                  className="text-xs font-bold text-leaf-700 hover:text-leaf-800 inline-flex items-center gap-1"
                >
                  <FileText className="h-3.5 w-3.5" aria-hidden />
                  {isTa ? 'நூலகத்தில் பார்' : 'View in Library'}
                </a>
              </div>
            </Card>
          </section>
        )}
      </div>
    </div>
  );
}
