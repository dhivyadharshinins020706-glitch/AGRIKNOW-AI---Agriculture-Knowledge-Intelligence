import { useState, type FormEvent } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  AlertTriangle,
  BookOpen,
  Calculator,
  CheckCircle2,
  Droplet,
  FileText,
  Info,
  Layers,
  Plus,
  ShieldCheck,
  Sprout,
  X,
} from 'lucide-react';
import { PageHeader } from '@/components/ui/PageHeader';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Segmented } from '@/components/ui/Segmented';
import { NutrientGauge } from '@/components/soil/NutrientGauge';
import { useFarmer } from '@/contexts/FarmerContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useToast } from '@/contexts/ToastContext';
import { buttonClass } from '@/components/ui/Button';
import type { SoilNutrient, SoilSample } from '@/types';

function phStatus(pH: number, isTa: boolean): { label: string; tone: 'success' | 'warning' | 'info'; advice: string } {
  if (pH < 6) {
    return {
      label: isTa ? 'அமில மண் (Acidic)' : 'Acidic',
      tone: 'warning',
      advice: isTa
        ? 'விவசாய சுண்ணாம்பு (Lime) ஏக்கருக்கு 250 கிலோ இட்டு உழவும். ஜிப்சம் இடக்கூடாது.'
        : 'Apply agricultural lime at 250 kg/acre to raise soil pH. Avoid gypsum on acid soils.',
    };
  }
  if (pH > 7.8) {
    return {
      label: isTa ? 'கார மண் (Alkaline / Sodic)' : 'Alkaline / Sodic',
      tone: 'info',
      advice: isTa
        ? 'விவசாய ஜிப்சம் (Gypsum) ஏக்கருக்கு 400 கிலோ + தக்கைப்பூண்டு (Daincha) பசுந்தாள் உரம் இட்டு நீர் பாய்ச்சி வடிக்கவும்.'
        : 'Apply agricultural gypsum at 400 kg/acre + Daincha green manure and flush standing water.',
    };
  }
  return {
    label: isTa ? 'சரியான நிலை (Balanced)' : 'Good balanced range',
    tone: 'success',
    advice: isTa
      ? 'பெரும்பாலான பயிர்கள் வளர இந்த pH (6.5 - 7.5) சிறந்தது. தொடர்ந்து தொழு உரம் இடவும்.'
      : 'Optimal range (6.5 - 7.5) for nutrient availability and root development.',
  };
}

interface SoilPreset {
  id: string;
  nameEn: string;
  nameTa: string;
  location: string;
  crop: string;
  pH: number;
  n: number;
  p: number;
  k: number;
  oc: number;
  notesEn: string;
  notesTa: string;
}

const soilPresets: SoilPreset[] = [
  {
    id: 'cauvery-delta',
    nameEn: 'Cauvery Delta Alluvial (Thanjavur)',
    nameTa: 'காவிரி டெல்டா வண்டல் மண் (தஞ்சாவூர்)',
    location: 'Thanjavur, Tamil Nadu',
    crop: 'Paddy (Samba)',
    pH: 6.8,
    n: 185,
    p: 13,
    k: 195,
    oc: 0.45,
    notesEn: 'Low Nitrogen & Organic Carbon. High moisture retention. Responsive to basal DAP + zinc.',
    notesTa: 'குறைந்த தழைச்சத்து & கரிமக் கரிமச் சத்து. அடி உரமாக DAP மற்றும் ஜிங்க் சல்பேட் பரிந்துரைக்கப்படுகிறது.',
  },
  {
    id: 'western-red-loam',
    nameEn: 'Western Zone Red Loam (Coimbatore / Pollachi)',
    nameTa: 'மேற்கு மண்டல செம்மண் (கோயம்புத்தூர்)',
    location: 'Coimbatore, Tamil Nadu',
    crop: 'Groundnut',
    pH: 7.2,
    n: 240,
    p: 22,
    k: 260,
    oc: 0.62,
    notesEn: 'Well-drained red loam. Ideal for oilseeds. Crucial to apply gypsum at 40-45 DAS for pod filling.',
    notesTa: 'நல்ல வடிகால் வசதி கொண்ட செம்மண். 40-45 ஆம் நாளில் ஜிப்சம் இடுவது பொக்குக்காய் உருவாவதைத் தடுக்கும்.',
  },
  {
    id: 'southern-black-cotton',
    nameEn: 'Southern Black Cotton Soil (Madurai / Kovilpatti)',
    nameTa: 'தென்மண்டல கரிசல் மண் (மதுரை / கோவில்பட்டி)',
    location: 'Madurai, Tamil Nadu',
    crop: 'Bt Cotton',
    pH: 8.1,
    n: 165,
    p: 11,
    k: 310,
    oc: 0.38,
    notesEn: 'High clay, deep cracking, alkaline soil. Rich in Potassium, but deficient in Nitrogen and Zinc.',
    notesTa: 'அதிக களிமண் கொண்ட கார கரிசல் மண். சாம்பல் சத்து அதிகம், ஆனால் தழைச்சத்து மற்றும் துத்தநாகம் குறைவு.',
  },
];

const defaultFallbackField: SoilSample = {
  id: 'field-a',
  label: 'Field A',
  location: 'Thanjavur, delta belt',
  crop: 'Paddy (Samba)',
  pH: 6.4,
  nutrients: [
    { key: 'nitrogen', label: 'Nitrogen', value: 214, unit: 'kg/ha', low: 280, high: 560, max: 600 },
    { key: 'phosphorus', label: 'Phosphorus', value: 18, unit: 'kg/ha', low: 11, high: 22, max: 40 },
    { key: 'potassium', label: 'Potassium', value: 146, unit: 'kg/ha', low: 115, high: 280, max: 400 },
    { key: 'organicCarbon', label: 'Organic carbon', value: 0.48, unit: '%', low: 0.5, high: 0.75, max: 1 },
  ],
  plan: [
    { stage: 'Basal', product: 'DAP', dose: '50 kg per acre', timing: 'At transplanting' },
    { stage: 'Tillering', product: 'Urea', dose: '25 kg per acre', timing: 'Day 21 after transplanting' },
    { stage: 'Panicle', product: 'Potash (MOP)', dose: '20 kg per acre', timing: 'Day 45 after transplanting' },
  ],
};

export default function SoilPage() {
  const { fields, addCustomField, profile } = useFarmer();
  const { t, lang } = useLanguage();
  const { show } = useToast();
  const isTa = lang === 'ta';

  const safeFields = Array.isArray(fields) && fields.length > 0 ? fields : [defaultFallbackField];
  const [fieldId, setFieldId] = useState<string>(safeFields[0]?.id || 'field-a');
  const [calcOpen, setCalcOpen] = useState(false);
  const [showParametersGuide, setShowParametersGuide] = useState(false);

  // Form states for new soil health card
  const [newLabel, setNewLabel] = useState('');
  const [newCrop, setNewCrop] = useState('Paddy (Samba)');
  const [newPh, setNewPh] = useState('6.5');
  const [newN, setNewN] = useState('220');
  const [newP, setNewP] = useState('16');
  const [newK, setNewK] = useState('150');
  const [newOc, setNewOc] = useState('0.55');

  const field = safeFields.find((item) => item?.id === fieldId) ?? safeFields[0] ?? defaultFallbackField;
  const ph = phStatus(typeof field.pH === 'number' && !isNaN(field.pH) ? field.pH : 6.5, isTa);

  const applyPreset = (preset: SoilPreset) => {
    setNewLabel(isTa ? preset.nameTa : preset.nameEn);
    setNewCrop(preset.crop);
    setNewPh(preset.pH.toString());
    setNewN(preset.n.toString());
    setNewP(preset.p.toString());
    setNewK(preset.k.toString());
    setNewOc(preset.oc.toString());
    show(
      isTa
        ? `அரசு மண் அட்டை மாதிரி ஏற்றப்பட்டது: ${preset.nameTa}`
        : `Loaded Govt Soil Health Card: ${preset.nameEn}`,
      { tone: 'info' }
    );
  };

  const handleSaveCard = async (e: FormEvent) => {
    e.preventDefault();
    if (!newLabel.trim()) {
      show(isTa ? 'வயலின் பெயரை உள்ளிடவும்' : 'Please enter a field name', { tone: 'error' });
      return;
    }

    const nVal = parseFloat(newN);
    const pVal = parseFloat(newP);
    const kVal = parseFloat(newK);
    const ocVal = parseFloat(newOc);
    const phVal = parseFloat(newPh);

    if (isNaN(nVal) || isNaN(pVal) || isNaN(kVal) || isNaN(ocVal) || isNaN(phVal)) {
      show(
        isTa
          ? 'அனைத்து மண் அளவுகளையும் சரியாக உள்ளிடவும். யூகங்களை உள்ளிட வேண்டாம்.'
          : 'Please provide valid numerical test values. Never guess soil measurements.',
        { tone: 'error' }
      );
      return;
    }

    // Generate dynamic crop-specific fertilizer plan based on soil card numbers and TNAU CPG standards
    let generatedPlan: SoilSample['plan'] = [];

    if (newCrop === 'Groundnut') {
      generatedPlan = [
        {
          stage: isTa ? 'அடி உரம் (Basal)' : 'Basal Application',
          product: 'NPK 10:20:20 + Zinc Sulphate',
          dose: isTa ? 'ஏக்கருக்கு 50 கிலோ காம்ப்ளக்ஸ் + 10 கிலோ ஜிங்க்' : '50 kg Complex + 10 kg Zinc per acre',
          timing: isTa ? 'கடைசி உழவு அல்லது விதைப்பின் போது' : 'At final ploughing or sowing',
        },
        {
          stage: isTa ? 'விழுது இறங்கும் பருவம் (Peg Formation)' : 'Peg Formation (Crucial Stage)',
          product: 'Agricultural Gypsum (ஜிப்சம்)',
          dose: isTa ? 'ஏக்கருக்கு 160-200 கிலோ ஜிப்சம்' : '160-200 kg Gypsum per acre',
          timing: isTa ? 'விதைத்த 40-45 ஆம் நாளில் மண் அணைக்கும் போது (பொக்குக்காய் தடுக்க)' : 'Day 40-45 DAS during earthing up (prevents empty pods)',
        },
        {
          stage: isTa ? 'இலைவழி தெளிப்பு (Foliar Spray)' : 'Foliar Nutrition',
          product: 'TNAU Groundnut Rich or 1% Urea',
          dose: isTa ? 'ஏக்கருக்கு 2 கிலோ / 200 லிட்டர் நீரில்' : '2 kg in 200 L water per acre',
          timing: isTa ? 'விதைத்த 35 மற்றும் 45 ஆம் நாளில்' : 'Day 35 and 45 DAS',
        },
      ];
    } else if (newCrop === 'Bt Cotton') {
      generatedPlan = [
        {
          stage: isTa ? 'அடி உரம் (Basal)' : 'Basal Dressing',
          product: 'DAP + MOP + Micronutrient Mixture',
          dose: isTa ? 'ஏக்கருக்கு 40 கிலோ DAP + 20 கிலோ பொட்டாஷ்' : '40 kg DAP + 20 kg MOP per acre',
          timing: isTa ? 'கடைசி உழவின் போது பாரில் இடுதல்' : 'Apply along ridges at final ploughing',
        },
        {
          stage: isTa ? 'பூ மொட்டு பருவம் (Square Formation)' : 'Square Formation Stage',
          product: 'Neem Coated Urea',
          dose: isTa ? 'ஏக்கருக்கு 35 கிலோ யூரியா' : '35 kg Urea per acre',
          timing: isTa ? 'விதைத்த 40-45 ஆம் நாளில்' : 'Day 40-45 DAS',
        },
        {
          stage: isTa ? 'காய் வெடிப்பு / பூக்கும் பருவம் (Peak Flowering / Boll Development)' : 'Peak Boll Formation',
          product: 'Urea + MOP + MgSO4',
          dose: isTa ? '25 கிலோ யூரியா + 15 கிலோ பொட்டாஷ் + 10 கிலோ மெக்னீசியம் சல்பேட்' : '25 kg Urea + 15 kg MOP + 10 kg MgSO4 per acre',
          timing: isTa ? 'விதைத்த 60-75 ஆம் நாளில்' : 'Day 60-75 DAS',
        },
      ];
    } else {
      // Default: Paddy (Samba)
      generatedPlan = [
        {
          stage: isTa ? 'அடி உரம் (Basal)' : 'Basal Dressing',
          product: pVal < 15 ? 'DAP + Zinc Sulphate' : 'Complex 20:20:0:13 + Zinc Sulphate',
          dose: pVal < 15 ? '50 kg DAP + 10 kg Zinc per acre' : '40 kg per acre + 10 kg Zinc',
          timing: isTa ? 'கடைசி உழவு அல்லது நடவுக்கு முன்' : 'At final ploughing or before transplanting',
        },
        {
          stage: isTa ? 'தூர் கட்டும் நிலை (Active Tillering)' : 'Active Tillering Stage',
          product: 'Neem Coated Urea',
          dose: nVal < 250 ? '30 kg per acre' : '20 kg per acre',
          timing: isTa ? 'நடவு செய்த 20-25 நாட்களில் (காய்ச்சலும் பாய்ச்சலும் முறையில்)' : 'Day 20-25 after transplanting (with AWD water regime)',
        },
        {
          stage: isTa ? 'கதிர் உருவாகும் பருவம் (Panicle Initiation)' : 'Panicle Initiation Stage',
          product: 'MOP (Potash) + Neem Coated Urea',
          dose: kVal < 150 ? '25 kg Potash + 15 kg Urea' : '15 kg Potash per acre',
          timing: isTa ? 'நடவு செய்த 42-45 நாட்களில்' : 'Day 42-45 after transplanting',
        },
      ];
    }

    const nutrients: SoilNutrient[] = [
      { key: 'nitrogen', label: isTa ? 'தழைச்சத்து (Nitrogen)' : 'Nitrogen (N)', value: nVal, unit: 'kg/ha', low: 280, high: 560, max: 600 },
      { key: 'phosphorus', label: isTa ? 'மணிச்சத்து (Phosphorus)' : 'Phosphorus (P)', value: pVal, unit: 'kg/ha', low: 11, high: 22, max: 40 },
      { key: 'potassium', label: isTa ? 'சாம்பல் சத்து (Potassium)' : 'Potassium (K)', value: kVal, unit: 'kg/ha', low: 118, high: 280, max: 400 },
      { key: 'organicCarbon', label: isTa ? 'கரிமக் கரிமச் சத்து (Organic Carbon)' : 'Organic Carbon (OC)', value: ocVal, unit: '%', low: 0.5, high: 0.75, max: 1 },
    ];

    const createdId = await addCustomField({
      label: newLabel.trim(),
      location: `${profile.village}, ${profile.district}`,
      crop: newCrop,
      pH: phVal,
      nutrients,
      plan: generatedPlan,
    });

    setFieldId(createdId);
    setCalcOpen(false);
    show(isTa ? 'மண் வள அட்டை சேமிக்கப்பட்டது!' : 'Soil Health Card saved to your farm!', {
      description: isTa ? 'TNAU வழிகாட்டுதல்படி உர அட்டவணை கணக்கிடப்பட்டுள்ளது.' : 'Stage-wise fertilizer schedule generated according to TNAU guidelines.',
      tone: 'success',
    });
  };

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow={isTa ? 'மண் & உர வழிகாட்டி' : 'Soil and Fertilizer Intelligence'}
        title={t('soil.title')}
        subtitle={t('soil.subtitle')}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setShowParametersGuide(!showParametersGuide)}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-ink-200 bg-white px-3.5 text-xs font-semibold text-ink-700 transition hover:bg-ink-100"
            >
              <BookOpen className="h-4 w-4 text-lilac-700" aria-hidden />
              {isTa ? 'அளவீட்டு விளக்கம்' : 'Parameter Guide'}
            </button>
            <button
              type="button"
              onClick={() => setCalcOpen(true)}
              className={buttonClass('primary', 'md')}
            >
              <Calculator className="h-4 w-4" aria-hidden />
              {t('soil.customCardTitle')}
            </button>
            <Segmented
              id="soil-field"
              label="Choose a field"
              options={safeFields.map((sample) => ({ value: sample.id, label: sample.label || sample.id }))}
              value={fieldId}
              onChange={setFieldId}
            />
          </div>
        }
      />

      {/* Parameter Explanation Accordion */}
      <AnimatePresence>
        {showParametersGuide && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <Card className="border-lilac-200 bg-lilac-50/50 p-6">
              <div className="flex items-center justify-between border-b border-lilac-200 pb-3">
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-lilac-800" />
                  <h3 className="text-base font-bold text-ink-900">
                    {isTa ? 'மண் ஆய்வு முடிவுகளைப் புரிந்து கொள்வது எப்படி?' : 'How to Interpret Your Soil Health Card'}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowParametersGuide(false)}
                  className="rounded-lg p-1 text-ink-500 hover:bg-lilac-100"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <div className="rounded-xl border border-white bg-white/80 p-4 shadow-sm">
                  <span className="font-bold text-ink-900">pH (மண் கார-அமில நிலை)</span>
                  <p className="mt-1 text-xs text-ink-600">
                    {isTa
                      ? '6.5 முதல் 7.5 வரை உகந்தது. 6-க்கு கீழ் அமிலம் (சுண்ணாம்பு தேவை), 8-க்கு மேல் காரம் (ஜிப்சம் தேவை).'
                      : 'Optimal: 6.5 - 7.5. <6.0 is acidic (needs lime), >8.0 is alkaline (needs gypsum & Daincha).'}
                  </p>
                </div>
                <div className="rounded-xl border border-white bg-white/80 p-4 shadow-sm">
                  <span className="font-bold text-ink-900">தழைச்சத்து (Nitrogen - N)</span>
                  <p className="mt-1 text-xs text-ink-600">
                    {isTa
                      ? '<280 குறைவு, 280-560 நடுத்தரம், >560 அதிகம். செடியின் வளர்ச்சி மற்றும் தூர் கட்டுதலுக்கு அவசியம்.'
                      : '<280 kg/ha is Low, 280-560 Medium, >560 High. Crucial for leaf canopy and vegetative tillering.'}
                  </p>
                </div>
                <div className="rounded-xl border border-white bg-white/80 p-4 shadow-sm">
                  <span className="font-bold text-ink-900">மணிச்சத்து (Phosphorus - P)</span>
                  <p className="mt-1 text-xs text-ink-600">
                    {isTa
                      ? '<11 குறைவு, 11-22 நடுத்தரம், >22 அதிகம். வேர் வளர்ச்சி மற்றும் ஆரம்ப கால உறுதிக்கு அவசியம்.'
                      : '<11 kg/ha Low, 11-22 Medium, >22 High. Promotes deep root establishment and early vigor.'}
                  </p>
                </div>
                <div className="rounded-xl border border-white bg-white/80 p-4 shadow-sm">
                  <span className="font-bold text-ink-900">சாம்பல் சத்து (Potassium - K)</span>
                  <p className="mt-1 text-xs text-ink-600">
                    {isTa
                      ? '<118 குறைவு, 118-280 நடுத்தரம், >280 அதிகம். நோய் எதிர்ப்புத்திறன் மற்றும் மணி எடைக்கு இன்றியமையாதது.'
                      : '<118 kg/ha Low, 118-280 Medium, >280 High. Provides pest resistance and solid grain filling.'}
                  </p>
                </div>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {calcOpen && (
          <motion.div
            initial={{ opacity: 0, y: -16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            className="rounded-2xl border-2 border-leaf-300 bg-white p-6 shadow-lift"
          >
            <div className="flex items-center justify-between border-b border-ink-100 pb-4">
              <div className="flex items-center gap-2">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-leaf-100 text-leaf-800">
                  <Calculator className="h-5 w-5" aria-hidden />
                </span>
                <div>
                  <h3 className="text-lg font-bold text-ink-900">{t('soil.customCardTitle')}</h3>
                  <p className="text-xs text-ink-500">{t('soil.customCardSubtitle')}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setCalcOpen(false)}
                className="rounded-lg p-2 text-ink-500 hover:bg-ink-100"
              >
                <X className="h-5 w-5" aria-hidden />
              </button>
            </div>

            {/* Presets Bar */}
            <div className="mt-4 rounded-xl bg-ink-50 p-3.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-ink-600">
                  {isTa ? 'அரசு மாதிரி அட்டைகள் (உடனடி சோதனைக்கு):' : 'Official Soil Health Card Presets (Quick Load):'}
                </span>
              </div>
              <div className="mt-2.5 flex flex-wrap gap-2">
                {soilPresets.map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => applyPreset(preset)}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-leaf-300 bg-white px-3 py-1.5 text-xs font-semibold text-leaf-900 transition hover:bg-leaf-50 active:scale-95"
                  >
                    <FileText className="h-3.5 w-3.5 text-leaf-700" />
                    {isTa ? preset.nameTa : preset.nameEn}
                  </button>
                ))}
              </div>
            </div>

            <form onSubmit={handleSaveCard} className="mt-5 grid gap-4 sm:grid-cols-3">
              <label className="space-y-1 sm:col-span-1">
                <span className="text-xs font-semibold text-ink-800">{t('soil.fieldName')}</span>
                <input
                  required
                  placeholder={isTa ? 'எ.கா: வடக்கு வயல்' : 'e.g. North Canal Field'}
                  value={newLabel}
                  onChange={(e) => setNewLabel(e.target.value)}
                  className="h-10 w-full rounded-xl border border-ink-200 px-3 text-sm focus:border-leaf-500 focus:outline-none"
                />
              </label>

              <label className="space-y-1 sm:col-span-1">
                <span className="text-xs font-semibold text-ink-800">{isTa ? 'பயிர்' : 'Planned Crop'}</span>
                <select
                  value={newCrop}
                  onChange={(e) => setNewCrop(e.target.value)}
                  className="h-10 w-full rounded-xl border border-ink-200 bg-white px-3 text-sm focus:border-leaf-500 focus:outline-none"
                >
                  <option value="Paddy (Samba)">{isTa ? 'நெல் (சம்பா)' : 'Paddy (Samba)'}</option>
                  <option value="Groundnut">{isTa ? 'நிலக்கடலை (மணிலா)' : 'Groundnut'}</option>
                  <option value="Bt Cotton">{isTa ? 'பருத்தி (Bt Cotton)' : 'Bt Cotton'}</option>
                  <option value="Maize">{isTa ? 'மக்காச்சோளம்' : 'Maize'}</option>
                  <option value="Finger Millet">{isTa ? 'கேழ்வரகு (ராகி)' : 'Finger Millet (Ragi)'}</option>
                </select>
              </label>

              <label className="space-y-1 sm:col-span-1">
                <span className="text-xs font-semibold text-ink-800">{isTa ? 'மண் pH (கார அமில நிலை)' : 'Soil pH (1-14)'}</span>
                <input
                  type="number"
                  step="0.1"
                  min="4"
                  max="10"
                  required
                  value={newPh}
                  onChange={(e) => setNewPh(e.target.value)}
                  className="h-10 w-full rounded-xl border border-ink-200 px-3 text-sm focus:border-leaf-500 focus:outline-none"
                />
              </label>

              <label className="space-y-1">
                <span className="text-xs font-semibold text-ink-800">{isTa ? 'நைட்ரஜன் N (kg/ha)' : 'Nitrogen N (kg/ha)'}</span>
                <input
                  type="number"
                  required
                  value={newN}
                  onChange={(e) => setNewN(e.target.value)}
                  className="h-10 w-full rounded-xl border border-ink-200 px-3 text-sm focus:border-leaf-500 focus:outline-none"
                />
              </label>

              <label className="space-y-1">
                <span className="text-xs font-semibold text-ink-800">{isTa ? 'பாஸ்பரஸ் P (kg/ha)' : 'Phosphorus P (kg/ha)'}</span>
                <input
                  type="number"
                  required
                  value={newP}
                  onChange={(e) => setNewP(e.target.value)}
                  className="h-10 w-full rounded-xl border border-ink-200 px-3 text-sm focus:border-leaf-500 focus:outline-none"
                />
              </label>

              <label className="space-y-1">
                <span className="text-xs font-semibold text-ink-800">{isTa ? 'பொட்டாசியம் K (kg/ha)' : 'Potassium K (kg/ha)'}</span>
                <input
                  type="number"
                  required
                  value={newK}
                  onChange={(e) => setNewK(e.target.value)}
                  className="h-10 w-full rounded-xl border border-ink-200 px-3 text-sm focus:border-leaf-500 focus:outline-none"
                />
              </label>

              <label className="space-y-1">
                <span className="text-xs font-semibold text-ink-800">{isTa ? 'கரிமக் கரிமச் சத்து OC (%)' : 'Organic Carbon OC (%)'}</span>
                <input
                  type="number"
                  step="0.01"
                  min="0.1"
                  max="3"
                  required
                  value={newOc}
                  onChange={(e) => setNewOc(e.target.value)}
                  className="h-10 w-full rounded-xl border border-ink-200 px-3 text-sm focus:border-leaf-500 focus:outline-none"
                />
              </label>

              <div className="sm:col-span-3 flex justify-end gap-3 pt-2 border-t border-ink-100">
                <button
                  type="button"
                  onClick={() => setCalcOpen(false)}
                  className={buttonClass('secondary', 'sm')}
                >
                  {t('common.cancel')}
                </button>
                <button
                  type="submit"
                  className={buttonClass('primary', 'sm')}
                >
                  <Plus className="h-4 w-4" aria-hidden />
                  {t('soil.saveField')}
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div key={field?.id || 'field-fallback'} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="space-y-8">
        <div className="grid gap-4 md:grid-cols-3">
          <Card className="p-5 sm:p-6">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-leaf-100 text-leaf-800">
              <Sprout className="h-5 w-5" aria-hidden />
            </span>
            <p className="mt-4 text-sm text-ink-500">{t('soil.currentCrop')}</p>
            <p className="text-lg font-bold text-ink-900">{field?.crop || 'Paddy'}</p>
            <p className="mt-1 text-sm text-ink-500">{field?.location || 'Tamil Nadu'}</p>
          </Card>

          <Card className="p-5 sm:p-6">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-aqua-100 text-aqua-800">
              <Droplet className="h-5 w-5" aria-hidden />
            </span>
            <p className="mt-4 text-sm text-ink-500">{t('soil.soilPh')}</p>
            <div className="flex items-center gap-3">
              <p className="text-lg font-bold text-ink-900">{(field?.pH ?? 6.5).toFixed(1)}</p>
              <Badge tone={ph.tone}>{ph.label}</Badge>
            </div>
            <p className="mt-2 text-sm text-ink-600 leading-relaxed">{ph.advice}</p>
          </Card>

          <Card className="bg-ink-900 p-5 text-white sm:p-6">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/10 text-aqua-300">
              <Info className="h-5 w-5" aria-hidden />
            </span>
            <p className="mt-4 text-sm text-ink-300">{t('soil.howToRead')}</p>
            <p className="mt-1 text-[15px] leading-relaxed text-ink-100">
              {t('soil.howToReadBody')}
            </p>
          </Card>
        </div>

        {/* Missing Information / Field Safety Alert */}
        <div className="flex items-start gap-3 rounded-2xl border border-amber-300 bg-amber-50/70 p-4">
          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-700" />
          <div className="text-xs text-amber-900 leading-relaxed">
            <strong className="font-semibold block text-amber-950">
              {isTa ? '⚠️ மண் ஆய்வு குறித்த முக்கிய எச்சரிக்கை:' : '⚠️ Agricultural Safety & Missing Parameter Protocol:'}
            </strong>
            {isTa
              ? 'மண் ஆய்வு எண்களைத் தோராயமாக யூகிக்க வேண்டாம். தவறான உர அளவு பயிர் வளர்ச்சியைப் பாதிக்கும் அல்லது செலவை உயர்த்தும். அரசு மண் பரிசோதனை நிலையத்தின் (STL) துல்லியமான அறிக்கையின் அடிப்படையில் மட்டுமே இறுதி உரங்களை இடவும்.'
              : 'Never fabricate or guess soil measurements. Inaccurate fertilizer dosing causes nutrient toxicity, economic waste, or deficiency. Always verify with an official Government Soil Testing Laboratory (STL) card.'}
          </div>
        </div>

        <section aria-labelledby="nutrients-heading" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 id="nutrients-heading" className="text-xl font-bold text-ink-900 sm:text-2xl">
              {t('soil.nutrientsTitle')}
            </h2>
            <Badge tone="neutral">{field?.label || 'Field'}</Badge>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {(field?.nutrients ?? defaultFallbackField.nutrients).map((nutrient, index) => (
              <Card key={nutrient.key} className="p-5 sm:p-6">
                <NutrientGauge nutrient={nutrient} delay={index * 0.08} />
              </Card>
            ))}
          </div>
        </section>

        <section aria-labelledby="plan-heading" className="space-y-4">
          <div>
            <h2 id="plan-heading" className="text-xl font-bold text-ink-900 sm:text-2xl">
              {t('soil.fertilizerPlan')}
            </h2>
            <p className="mt-1 text-sm text-ink-500">{t('soil.fertilizerPlanSubtitle')}</p>
          </div>
          <ol className="relative grid gap-4 md:grid-cols-3">
            {(field?.plan ?? defaultFallbackField.plan).map((step, index) => (
              <li key={`${step.product}-${index}`}>
                <Card hover className="h-full p-5 sm:p-6">
                  <div className="flex items-center justify-between gap-3">
                    <Badge tone="success">{step.stage}</Badge>
                    <span className="text-sm font-bold text-ink-400">Step {index + 1}</span>
                  </div>
                  <p className="mt-4 text-lg font-bold text-ink-900">{step.product}</p>
                  <p className="mt-1 text-base font-medium text-leaf-800">{step.dose}</p>
                  <p className="mt-3 border-t border-ink-100 pt-3 text-sm text-ink-600">{step.timing}</p>
                </Card>
              </li>
            ))}
          </ol>

          {/* Evidence and Scientific Source Footer */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-xl border border-leaf-200 bg-leaf-50/60 p-4 text-xs text-ink-700">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-leaf-700 shrink-0" />
              <span>
                {isTa
                  ? 'ஆதாரம்: தமிழ்நாடு வேளாண்மைப் பல்கலைக்கழக (TNAU) பயிர் சாகுபடி கையேடு 2024 & மத்திய மண் வள அட்டை வழிகாட்டுதல்கள்.'
                  : 'Source: TNAU Crop Production Guide (Agriculture) 2024 & Ministry of Agriculture Soil Health Card Guidelines.'}
              </span>
            </div>
            <a
              href="#/library"
              className="inline-flex items-center gap-1 font-semibold text-leaf-800 hover:text-leaf-950 hover:underline shrink-0"
            >
              <CheckCircle2 className="h-3.5 w-3.5" />
              {isTa ? 'ஆவண நூலகத்தைக் காண்க' : 'View Verified Library'}
            </a>
          </div>
        </section>
      </motion.div>
    </div>
  );
}
