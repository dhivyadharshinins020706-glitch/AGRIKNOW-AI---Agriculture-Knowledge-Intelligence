import { useEffect, useRef, useState, type FormEvent } from 'react';
import {
  ArrowUp,
  BookOpen,
  Mic,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  CheckCircle2,
  PlusCircle,
  MessageSquare,
  Trash2,
  Clock,
  Paperclip,
  FileSearch,
  Camera,
  X,
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { PageHeader } from '@/components/ui/PageHeader';
import { Card } from '@/components/ui/Card';
import { Segmented } from '@/components/ui/Segmented';
import { Badge } from '@/components/ui/Badge';
import { AiProcessing } from '@/components/ai/AiProcessing';
import { ChatBubble } from '@/components/assistant/ChatBubble';
import { VoiceInputModal } from '@/components/assistant/VoiceInputModal';
import { DocumentAnalyzerModal } from '@/components/assistant/DocumentAnalyzerModal';
import { ActiveDocumentCard } from '@/components/assistant/ActiveDocumentCard';
import { assistantProcessingSteps, assistantWelcome, suggestedPrompts } from '@/data/assistant';
import { findSource } from '@/data/sources';
import { askAgriAssistant } from '@/services/aiService';
import {
  getActiveAnalyzedDocument,
  setActiveAnalyzedDocument,
} from '@/services/documentAnalyzerService';
import {
  createConversation,
  deleteConversation,
  fetchConversationMessages,
  fetchUserConversations,
  persistChatMessage,
  type DbConversation,
} from '@/services/conversationService';
import type { AiAnswerResult, ChatMessage, AnalyzedDocument } from '@/types';
import { logger } from '@/services/telemetry/logger';
import type { Lang } from '@/lib/i18n';
import { useToast } from '@/contexts/ToastContext';

interface PendingQuestion {
  question: string;
  resultPromise?: Promise<AiAnswerResult>;
}

const languageOptions: { value: Lang; label: string }[] = [
  { value: 'en', label: 'English' },
  { value: 'ta', label: 'தமிழ்' },
];

const CHAT_STORAGE_KEY = 'agriknow_chat_history_v2';

interface SpeechRecognitionEvent {
  results: {
    [index: number]: {
      [index: number]: {
        transcript: string;
      };
    };
  };
}

interface SpeechRecognitionInstance {
  lang: string;
  interimResults: boolean;
  maxAlternatives: number;
  onstart: () => void;
  onresult: (event: SpeechRecognitionEvent) => void;
  onerror: () => void;
  onend: () => void;
  start: () => void;
  stop: () => void;
}

export default function AssistantPage() {
  const { lang, setLang, t } = useLanguage();
  const { user } = useAuth();
  const { show } = useToast();
  const [draft, setDraft] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem(CHAT_STORAGE_KEY);
      if (!saved) return [];
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        return parsed.filter((m) => m && typeof m.text === 'string' && m.id);
      }
      return [];
    } catch {
      return [];
    }
  });
  const [conversations, setConversations] = useState<DbConversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [pending, setPending] = useState<PendingQuestion | null>(null);
  const [pendingResult, setPendingResult] = useState<AiAnswerResult | null>(null);
  const [showVoiceModal, setShowVoiceModal] = useState(false);
  const [showDocModal, setShowDocModal] = useState(false);
  const [activeDoc, setActiveDoc] = useState<AnalyzedDocument | null>(() => getActiveAnalyzedDocument());
  const pendingPromiseRef = useRef<Promise<AiAnswerResult> | null>(null);
  const isCompletingRef = useRef(false);
  const [attachedImage, setAttachedImage] = useState<{
    base64: string;
    previewUrl: string;
    fileName: string;
  } | null>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const handleImageSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      show(lang === 'ta' ? 'தயவுசெய்து புகைப்படத்தை மட்டும் தேர்ந்தெடுக்கவும்' : 'Please select an image file', { tone: 'error' });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string) || '';
      setAttachedImage({
        base64,
        previewUrl: URL.createObjectURL(file),
        fileName: file.name,
      });
      show(lang === 'ta' ? `பயிர் புகைப்படம் இணைக்கப்பட்டது: ${file.name}` : `Attached: ${file.name}`, { tone: 'info' });
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };
  const scrollRef = useRef<HTMLDivElement>(null);
  const activeConversationIdRef = useRef<string | null>(null);

  // Sync ref with state
  useEffect(() => {
    activeConversationIdRef.current = activeConversationId;
  }, [activeConversationId]);

  // Load cloud conversations when authenticated
  useEffect(() => {
    if (!user) return;
    let isMounted = true;

    fetchUserConversations(user.id).then((convs) => {
      if (!isMounted) return;
      setConversations(convs);
      if (convs.length > 0 && !activeConversationIdRef.current) {
        const latest = convs[0];
        setActiveConversationId(latest.id);
        fetchConversationMessages(latest.id).then((dbMsgs) => {
          if (!isMounted || dbMsgs.length === 0) return;
          setMessages(dbMsgs);
        });
      }
    });

    return () => {
      isMounted = false;
    };
  }, [user]);

  useEffect(() => {
    try {
      localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(messages));
    } catch {
      // Ignore
    }
  }, [messages]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, pending]);

  const usedSourceIds = Array.from(new Set(messages.flatMap((message) => message.sourceIds ?? [])));

  const handleStartNewChat = () => {
    setMessages([]);
    setActiveConversationId(null);
    activeConversationIdRef.current = null;
    pendingPromiseRef.current = null;
    isCompletingRef.current = false;
    setPending(null);
    setPendingResult(null);
    setActiveDoc(null);
    setActiveAnalyzedDocument(null);
    try {
      localStorage.removeItem(CHAT_STORAGE_KEY);
    } catch {
      // Ignore
    }
    show(lang === 'ta' ? 'புதிய உரையாடல் தொடங்கப்பட்டது' : 'New conversation started', { tone: 'info' });
  };

  const handleSelectConversation = async (conv: DbConversation) => {
    if (activeConversationId === conv.id) return;
    setActiveConversationId(conv.id);
    activeConversationIdRef.current = conv.id;
    const dbMsgs = await fetchConversationMessages(conv.id);
    setMessages(dbMsgs);
    show(
      lang === 'ta' ? `உரையாடல் திறக்கப்பட்டது: ${conv.title}` : `Loaded: ${conv.title}`,
      { tone: 'info' }
    );
  };

  const handleDeleteConversation = async (convId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    const success = await deleteConversation(convId);
    if (success) {
      setConversations((prev) => prev.filter((c) => c.id !== convId));
      if (activeConversationId === convId) {
        handleStartNewChat();
      }
      show(lang === 'ta' ? 'உரையாடல் நீக்கப்பட்டது' : 'Conversation deleted', { tone: 'info' });
    }
  };

  const submit = async (question: string) => {
    const trimmed = question.trim();
    if (!trimmed || pending) return;

    const currentImage = attachedImage;
    if (currentImage) {
      setAttachedImage(null);
    }

    const userMessage: ChatMessage = {
      id: `m_${Date.now()}`,
      role: 'user',
      text: trimmed,
      imageUrl: currentImage?.previewUrl,
      timestamp: Date.now(),
    };

    setMessages((items) => [...items, userMessage]);
    setDraft('');

    // If authenticated, ensure conversation exists in Supabase
    if (user) {
      if (!activeConversationIdRef.current) {
        const title = trimmed.slice(0, 48);
        const newId = await createConversation(user.id, title, lang);
        if (newId) {
          activeConversationIdRef.current = newId;
          setActiveConversationId(newId);
          fetchUserConversations(user.id).then((convs) => setConversations(convs));
        }
      }
      if (activeConversationIdRef.current) {
        persistChatMessage(activeConversationIdRef.current, user.id, userMessage);
      }
    }

    // Prepare multi-turn history context for Phase 5 Advanced Assistant
    const historyTurns = messages.slice(-6).map((m) => ({
      role: m.role,
      text: m.text,
    }));

    const queryForAssistant = currentImage
      ? `[Crop Image Attached: ${currentImage.fileName}] ${trimmed}`
      : trimmed;

    const queryLang = /[\u0B80-\u0BFF]/.test(trimmed)
      ? 'ta'
      : /[a-zA-Z]/.test(trimmed)
      ? 'en'
      : lang;

    // Set pending state to display live Gemini processing indicator
    setPending({ question: trimmed });

    try {
      const resolved = await askAgriAssistant(queryForAssistant, queryLang, historyTurns, user?.id);

      const assistantMessage: ChatMessage = {
        id: `m_${Date.now()}`,
        role: 'assistant',
        text: resolved.text,
        sourceIds: resolved.sourceIds,
        isLiveBackend: resolved.isLiveBackend,
        provider: resolved.provider,
        ragTrace: resolved.ragTrace,
        suggestedFollowUps: resolved.suggestedFollowUps,
        timestamp: Date.now(),
      };

      setMessages((items) => [...items, assistantMessage]);

      // Persist assistant reply to Supabase if authenticated
      if (user && activeConversationIdRef.current) {
        persistChatMessage(activeConversationIdRef.current, user.id, assistantMessage);
      }
    } catch (err: unknown) {
      logger.error('Assistant', 'Assistant completion error', err);
      const errorMsg = err instanceof Error ? err.message : String(err);
      const assistantMessage: ChatMessage = {
        id: `m_err_${Date.now()}`,
        role: 'assistant',
        text: lang === 'ta'
          ? `⚠️ மன்னிக்கவும், பதிலை உருவாக்குவதில் பிழை ஏற்பட்டது (${errorMsg}). தயவுசெய்து உங்கள் கேள்வியை மீண்டும் கேட்கவும்.`
          : `⚠️ Sorry, an error occurred while generating the answer (${errorMsg}). Please re-send your question or try again.`,
        sourceIds: [],
        isLiveBackend: false,
        provider: 'System Error',
        timestamp: Date.now(),
      };
      setMessages((items) => [...items, assistantMessage]);
    } finally {
      pendingPromiseRef.current = null;
      isCompletingRef.current = false;
      setPending(null);
      setPendingResult(null);
    }
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    submit(draft);
  };

  const clearChat = () => {
    setMessages([]);
    try {
      localStorage.removeItem(CHAT_STORAGE_KEY);
    } catch {
      // Ignore
    }
    show(lang === 'ta' ? 'உரையாடல் அழிக்கப்பட்டது' : 'Chat history cleared', { tone: 'info' });
  };

  const handleVoiceTranscriptReady = (transcript: string) => {
    setDraft(transcript);
    submit(transcript);
    show(lang === 'ta' ? 'குரல் பதிவு செய்யப்பட்டது' : 'Voice captured and submitted', {
      tone: 'info',
    });
  };

  const handleDocumentAnalyzed = (doc: AnalyzedDocument) => {
    setActiveDoc(doc);
    setActiveAnalyzedDocument(doc);

    // Automatically post the document analysis summary as an assistant message
    const docAssistantMessage: ChatMessage = {
      id: `m_doc_${Date.now()}`,
      role: 'assistant',
      text: lang === 'ta' ? doc.summaryTa : doc.summaryEn,
      sourceIds: ['seed-certification-manual'],
      isLiveBackend: false,
      provider: 'AGRIKNOW Document Intelligence',
      confidence: 0.99,
      suggestedFollowUps: doc.suggestedQuestions,
      documentContext: doc,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, docAssistantMessage]);

    // Persist to DB if authenticated
    if (user && activeConversationIdRef.current) {
      persistChatMessage(activeConversationIdRef.current, user.id, docAssistantMessage);
    }

    show(
      lang === 'ta'
        ? `ஆவணம் வெற்றிகரமாக இணைக்கப்பட்டது: ${doc.fileName}`
        : `Document attached to chat: ${doc.fileName}`,
      { tone: 'success' }
    );
  };

  const showWelcome = messages.length === 0;

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow={t('assistant.eyebrow')}
        title={t('assistant.title')}
        subtitle={t('assistant.subtitle')}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleStartNewChat}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-leaf-300 bg-leaf-50 px-3.5 text-xs font-semibold text-leaf-900 transition hover:bg-leaf-100 shadow-2xs"
            >
              <PlusCircle className="h-4 w-4 text-leaf-700" aria-hidden />
              {lang === 'ta' ? 'புதிய உரையாடல்' : 'New Chat'}
            </button>
            <button
              type="button"
              onClick={() => setShowDocModal(true)}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-aqua-300 bg-aqua-50 px-3.5 text-xs font-semibold text-aqua-950 transition hover:bg-aqua-100 shadow-2xs"
            >
              <FileSearch className="h-4 w-4 text-aqua-700" aria-hidden />
              {lang === 'ta' ? 'ஆவண பகுப்பாய்வு' : 'Analyze Document'}
            </button>
            <Segmented
              id="assistant-language"
              label={t('assistant.language')}
              options={languageOptions}
              value={lang}
              onChange={setLang}
            />
            {messages.length > 0 && (
              <button
                type="button"
                onClick={clearChat}
                className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-ink-200 bg-white px-3 text-xs font-semibold text-ink-700 transition hover:bg-ink-100"
              >
                <RotateCcw className="h-3.5 w-3.5" aria-hidden />
                {t('assistant.clearChat')}
              </button>
            )}
          </div>
        }
      />

      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <Card className="flex h-[calc(100vh-260px)] min-h-[540px] flex-col overflow-hidden">
          <div className="flex items-center justify-between border-b border-ink-100 bg-ink-50/70 px-4 py-2.5 sm:px-6">
            <span className="flex items-center gap-2 text-xs font-medium text-ink-600">
              <ShieldCheck className="h-4 w-4 text-leaf-600" aria-hidden />
              {t('common.verified')}
            </span>
            <div className="flex items-center gap-2">
              {user && (
                <Badge tone="success">
                  <CheckCircle2 className="h-3.5 w-3.5" aria-hidden />
                  {lang === 'ta' ? 'கிளவுட் சேமிப்பு' : 'Cloud Saved'}
                </Badge>
              )}
              <Badge tone="success">
                <Sparkles className="mr-1 inline h-3.5 w-3.5 text-leaf-600" aria-hidden />
                {lang === 'ta' ? 'AgriKnow ஆன்லைன்' : 'AgriKnow Online'}
              </Badge>
            </div>
          </div>

          <div ref={scrollRef} className="flex-1 space-y-6 overflow-y-auto scroll-smooth p-4 sm:p-6">
            {showWelcome && (
              <ChatBubble
                message={{ id: 'welcome', role: 'assistant', text: assistantWelcome[lang] }}
                sourcesLabel=""
              />
            )}

            {messages.map((message, idx) => {
              const prevUserMsg =
                message.role === 'assistant'
                  ? [...messages.slice(0, idx)].reverse().find((m) => m.role === 'user')
                  : null;
              return (
                <ChatBubble
                  key={message.id}
                  message={message}
                  sourcesLabel={t('assistant.sources')}
                  onSelectFollowUp={submit}
                  onRegenerate={prevUserMsg ? () => submit(prevUserMsg.text) : undefined}
                />
              );
            })}

            {pending && (
              <div className="flex gap-3">
                <span className="mt-1 hidden h-9 w-9 shrink-0 sm:block" aria-hidden />
                <div className="w-full max-w-xl">
                  <div className="rounded-2xl border border-leaf-200 bg-gradient-to-br from-leaf-50/90 to-aqua-50/60 p-4 shadow-sm" role="status" aria-live="polite">
                    <div className="flex items-center gap-3">
                      <span className="relative flex h-8 w-8 items-center justify-center">
                        <span className="absolute inset-0 animate-ping rounded-full bg-leaf-400/30" />
                        <Sparkles className="relative h-4 w-4 text-leaf-600 animate-spin" />
                      </span>
                      <div>
                        <p className="text-sm font-semibold text-ink-800">
                          {lang === 'ta' ? 'AgriKnow பகுப்பாய்வு செய்கிறது...' : 'AgriKnow is analyzing...'}
                        </p>
                        <p className="text-xs text-ink-500">
                          {lang === 'ta' ? 'TNAU & ICAR பல்கலைக்கழகத் தரவுகளுடன் இணைக்கப்படுகிறது' : 'Cross-referencing verified agronomic knowledge'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-ink-100 bg-white p-4 sm:p-5">
            {/* Active Document Session Card */}
            {activeDoc && (
              <ActiveDocumentCard
                document={activeDoc}
                onRemove={() => {
                  setActiveDoc(null);
                  setActiveAnalyzedDocument(null);
                  show(
                    lang === 'ta' ? 'ஆவணம் அமர்விலிருந்து நீக்கப்பட்டது' : 'Document removed from session',
                    { tone: 'info' }
                  );
                }}
                onAskFollowUp={submit}
                lang={lang}
              />
            )}

            {showWelcome && (
              <div className="mb-4">
                <p className="mb-2 text-xs font-medium uppercase tracking-[0.12em] text-ink-500">
                  {t('assistant.suggestions')}
                </p>
                <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
                  {suggestedPrompts.map((prompt) => (
                    <button
                      key={prompt.en}
                      type="button"
                      onClick={() => submit(prompt[lang])}
                      className="shrink-0 rounded-full border border-ink-200 bg-ink-50 px-4 py-2 text-sm text-ink-800 transition hover:-translate-y-0.5 hover:border-leaf-300 hover:bg-leaf-50"
                    >
                      {prompt[lang]}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Attached Crop Image Preview Pill */}
            {attachedImage && (
              <div className="mb-2.5 flex items-center gap-2 rounded-xl border border-leaf-300 bg-leaf-50 px-3 py-1.5 text-xs text-leaf-900 w-fit shadow-2xs">
                <img
                  src={attachedImage.previewUrl}
                  alt="Attached"
                  className="h-8 w-8 rounded-lg object-cover border border-leaf-400"
                />
                <span className="font-semibold truncate max-w-[200px]">{attachedImage.fileName}</span>
                <button
                  type="button"
                  onClick={() => setAttachedImage(null)}
                  title="Remove image"
                  className="rounded-full p-1 text-leaf-700 hover:bg-leaf-200 transition"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            )}

            <form onSubmit={handleSubmit} className="flex items-end gap-2 sm:gap-3">
              <input
                type="file"
                ref={imageInputRef}
                accept="image/*"
                className="hidden"
                onChange={handleImageSelected}
              />
              <button
                type="button"
                onClick={() => setShowDocModal(true)}
                aria-label={lang === 'ta' ? 'விவசாய ஆவணம் பதிவேற்று' : 'Upload agricultural document'}
                title={lang === 'ta' ? 'விதை அட்டை / உர ரசீது / மண்டி ரசீது பதிவேற்று' : 'Upload Seed Tag / Purchase Invoice / Mandi Bill'}
                className="flex h-14 w-12 sm:w-14 shrink-0 items-center justify-center rounded-2xl border border-ink-200 bg-white text-ink-600 hover:border-leaf-300 hover:bg-leaf-50 hover:text-leaf-800 transition"
              >
                <Paperclip className="h-5 w-5" />
              </button>
              <button
                type="button"
                onClick={() => imageInputRef.current?.click()}
                aria-label={lang === 'ta' ? 'பயிர் புகைப்படம் இணைக்க' : 'Attach crop photo for diagnosis'}
                title={lang === 'ta' ? 'இலை, தண்டு அல்லது பூச்சி புகைப்படம் இணைக்க' : 'Attach photo of leaf, stem, or pest for diagnosis'}
                className="flex h-14 w-12 sm:w-14 shrink-0 items-center justify-center rounded-2xl border border-ink-200 bg-white text-ink-600 hover:border-leaf-300 hover:bg-leaf-50 hover:text-leaf-800 transition"
              >
                <Camera className="h-5 w-5" />
              </button>

              <label className="sr-only" htmlFor="assistant-input">
                {t('assistant.placeholder')}
              </label>
              <input
                id="assistant-input"
                value={draft}
                onChange={(event) => setDraft(event.target.value)}
                placeholder={
                  activeDoc
                    ? (lang === 'ta'
                        ? `கேளுங்கள்: "${(activeDoc.crop && activeDoc.crop !== 'undefined') ? activeDoc.crop : (activeDoc.fileName || 'இணைக்கப்பட்ட ஆவணம்')}" அல்லது உங்கள் கேள்விகள்...`
                        : `Ask about ${(activeDoc.crop && activeDoc.crop !== 'undefined') ? activeDoc.crop : (activeDoc.fileName || 'this document')} or any question...`)
                    : t('assistant.placeholder')
                }
                disabled={pending !== null}
                className="h-14 min-w-0 flex-1 rounded-2xl border border-ink-200 bg-ink-50 px-5 text-base text-ink-900 placeholder:text-ink-500 transition focus:border-aqua-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-aqua-200/60 disabled:opacity-60"
              />
              <button
                type="button"
                onClick={() => setShowVoiceModal(true)}
                aria-label={t('assistant.voiceStart')}
                title={lang === 'ta' ? 'குரல் வழி கேள்வி கேட்க (தமிழ் / English)' : 'Ask with Voice (Tamil / English)'}
                className="flex h-14 w-12 sm:w-14 shrink-0 items-center justify-center rounded-2xl border border-leaf-300 bg-leaf-50 text-leaf-800 hover:bg-leaf-100 transition shadow-2xs"
              >
                <Mic className="h-5 w-5 text-leaf-600" />
              </button>
              <button
                type="submit"
                aria-label={t('assistant.send')}
                disabled={pending !== null || draft.trim() === ''}
                className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-leaf-400 text-ink-900 shadow-[0_10px_24px_-12px_rgba(83,181,79,0.9)] transition hover:bg-leaf-300 active:scale-95 disabled:cursor-not-allowed disabled:bg-ink-200 disabled:text-ink-500 disabled:shadow-none"
              >
                <ArrowUp className="h-6 w-6" aria-hidden />
              </button>
            </form>
          </div>
        </Card>

        <aside className="space-y-4">
          {user && conversations.length > 0 && (
            <Card className="p-4">
              <h2 className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-ink-600">
                <span className="flex items-center gap-1.5">
                  <Clock className="h-3.5 w-3.5 text-leaf-600" aria-hidden />
                  {lang === 'ta' ? 'கடந்த உரையாடல்கள்' : 'Past Conversations'}
                </span>
                <span className="text-[11px] font-normal text-ink-400">{conversations.length}</span>
              </h2>
              <div className="mt-3 max-h-48 space-y-1.5 overflow-y-auto pr-1">
                {conversations.slice(0, 8).map((conv) => {
                  const isActive = conv.id === activeConversationId;
                  return (
                    <div
                      key={conv.id}
                      onClick={() => handleSelectConversation(conv)}
                      className={`group flex cursor-pointer items-center justify-between rounded-lg px-2.5 py-1.5 text-xs transition ${
                        isActive
                          ? 'bg-leaf-100 font-semibold text-leaf-950'
                          : 'text-ink-700 hover:bg-ink-100 hover:text-ink-900'
                      }`}
                    >
                      <div className="flex min-w-0 items-center gap-2">
                        <MessageSquare className="h-3.5 w-3.5 shrink-0 text-ink-400 group-hover:text-leaf-600" />
                        <span className="truncate">{conv.title}</span>
                      </div>
                      <button
                        type="button"
                        onClick={(e) => handleDeleteConversation(conv.id, e)}
                        title={lang === 'ta' ? 'நீக்கு' : 'Delete'}
                        className="ml-1 opacity-0 transition group-hover:opacity-100 hover:text-danger-600"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            </Card>
          )}

          <Card className="p-5">
            <h2 className="flex items-center gap-2 text-base font-bold text-ink-900">
              <BookOpen className="h-4 w-4 text-lilac-700" aria-hidden />
              {t('assistant.usedTitle')}
            </h2>
            {usedSourceIds.length === 0 ? (
              <p className="mt-3 text-sm text-ink-500">{t('assistant.usedEmpty')}</p>
            ) : (
              <ul className="mt-3 space-y-2">
                {usedSourceIds.map((sourceId) => {
                  const source = findSource(sourceId);
                  if (!source) return null;
                  return (
                    <li key={sourceId}>
                      <a
                        href={`#/evidence?doc=${sourceId}`}
                        className="block rounded-xl border border-ink-200 p-3 transition hover:border-lilac-400 hover:bg-lilac-50"
                      >
                        <span className="block text-sm font-medium text-ink-900">{source.title}</span>
                        <span className="text-xs text-ink-500">
                          {source.publisher}, {source.year}
                        </span>
                      </a>
                    </li>
                  );
                })}
              </ul>
            )}
          </Card>

          <Card className="bg-gradient-to-br from-aqua-50 to-white p-5">
            <h2 className="flex items-center gap-1.5 text-base font-bold text-ink-900">
              <Sparkles className="h-4 w-4 text-aqua-700" aria-hidden />
              {t('assistant.tipsTitle')}
            </h2>
            <ul className="mt-3 space-y-2.5 text-sm text-ink-700">
              {(['assistant.tip1', 'assistant.tip2', 'assistant.tip3'] as const).map((key) => (
                <li key={key} className="flex gap-2.5">
                  <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-aqua-600" />
                  {t(key)}
                </li>
              ))}
            </ul>
          </Card>

          <div className="rounded-xl bg-ink-100 p-3 text-xs text-ink-600">
            {t('assistant.offlineNotice')}
          </div>
        </aside>
      </div>

      {/* Voice Input Model Modal (Tamil & English) */}
      <VoiceInputModal
        isOpen={showVoiceModal}
        onClose={() => setShowVoiceModal(false)}
        onTranscriptReady={handleVoiceTranscriptReady}
        currentLang={lang}
      />

      {/* Agricultural Document Analyzer Modal */}
      <DocumentAnalyzerModal
        isOpen={showDocModal}
        onClose={() => setShowDocModal(false)}
        onDocumentAnalyzed={handleDocumentAnalyzed}
        lang={lang}
      />
    </div>
  );
}
