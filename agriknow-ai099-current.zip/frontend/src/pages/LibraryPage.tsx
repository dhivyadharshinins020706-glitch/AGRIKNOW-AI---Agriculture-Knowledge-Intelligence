import { useState, useEffect } from 'react';
import { BookOpen, Printer, Search, Database, Filter, Landmark } from 'lucide-react';
import { PageHeader } from '@/components/ui/PageHeader';
import { Card } from '@/components/ui/Card';
import { Button, buttonClass } from '@/components/ui/Button';
import { Sheet } from '@/components/ui/Sheet';
import { SourceCard } from '@/components/library/SourceCard';
import { SourceDetail } from '@/components/library/SourceDetail';
import { GovernmentSchemesView } from '@/components/schemes/GovernmentSchemesView';
import { sources as staticSources } from '@/data/sources';
import { fetchIngestedDocuments, getIngestionStats } from '@/services/ingestionService';
import type { Source } from '@/types';
import type { IngestedDocument, IngestionStats } from '@/types/ingestion';
import { useLanguage } from '@/contexts/LanguageContext';
import IngestionAdminPage from './IngestionAdminPage';

type KindFilter = 'all' | string;

export default function LibraryPage() {
  const { t, lang } = useLanguage();
  const isTa = lang === 'ta';

  // Top View Tab: 'library', 'schemes', or 'ingestion'
  const [activeTab, setActiveTab] = useState<'library' | 'schemes' | 'ingestion'>('library');

  // Knowledge library states
  const [query, setQuery] = useState('');
  const [kind, setKind] = useState<KindFilter>('all');
  const [cropFilter, setCropFilter] = useState<string>('all');
  const [langFilter, setLangFilter] = useState<'all' | 'Tamil' | 'English'>('all');
  const [selected, setSelected] = useState<Source | null>(null);

  // Dynamic Ingested Documents
  const [ingestedDocs, setIngestedDocs] = useState<IngestedDocument[]>([]);
  const [stats, setStats] = useState<IngestionStats | null>(null);

  useEffect(() => {
    let active = true;
    Promise.all([fetchIngestedDocuments(), getIngestionStats()]).then(([docs, st]) => {
      if (active) {
        setIngestedDocs(docs);
        setStats(st);
      }
    });
    return () => {
      active = false;
    };
  }, []);

  // Merge static sources with ingested documents converted to Source model
  const mergedSources: Source[] = [
    ...staticSources,
    ...ingestedDocs.map(
      (doc): Source => ({
        id: doc.id,
        title: doc.title,
        publisher: doc.institution,
        year: parseInt(doc.publicationDate?.split('-')[0] || '2024', 10),
        kind:
          doc.category === 'Crop Manual'
            ? 'Field manual'
            : doc.category === 'Pest Advisory'
            ? 'Government advisory'
            : doc.category === 'Fertilizer & Soil Guide'
            ? 'Extension guide'
            : 'Research paper',
        language:
          doc.language === 'Bilingual'
            ? 'English & Tamil'
            : doc.language === 'Tamil'
            ? 'Tamil'
            : 'English',
        reliability: doc.verificationStatus === 'verified' ? 'Verified' : 'Peer reviewed',
        topics: [
          ...(Array.isArray(doc.crops) ? doc.crops : []),
          ...(Array.isArray(doc.topics) ? doc.topics : []),
        ],
        summary: doc.description,
        excerpts: [
          {
            section: isTa ? 'விவசாய கையேடு வழிகாட்டுதல்' : 'Field Advisory Guidance',
            text: doc.description,
            relevance: 'high',
          },
          {
            section: isTa ? 'சரிபார்ப்பு தணிக்கை' : 'Audit Verification Status',
            text:
              doc.verificationNotes ||
              (isTa
                ? 'TNAU மற்றும் ICAR கள தரநிலைகளுக்கு இணங்க சரிபார்க்கப்பட்டது.'
                : 'Audited according to ICAR and TNAU regional agronomic standards.'),
            relevance: 'medium',
          },
        ],
      })
    ),
  ];

  // Deduplicate sources by ID
  const uniqueSources = Array.from(new Map(mergedSources.map((s) => [s.id, s])).values());

  const visible = uniqueSources.filter((source) => {
    const matchesKind = kind === 'all' || source.kind.toLowerCase() === kind.toLowerCase();
    const matchesLang =
      langFilter === 'all' ||
      (langFilter === 'Tamil' && source.language.includes('Tamil')) ||
      (langFilter === 'English' && source.language.includes('English'));

    const matchesCrop =
      cropFilter === 'all' ||
      source.topics.some((tp) => tp.toLowerCase().includes(cropFilter.toLowerCase())) ||
      source.title.toLowerCase().includes(cropFilter.toLowerCase());

    const haystack = `${source.title} ${source.publisher} ${source.topics.join(' ')} ${source.summary}`.toLowerCase();
    const matchesQuery = !query.trim() || haystack.includes(query.trim().toLowerCase());

    return matchesKind && matchesLang && matchesCrop && matchesQuery;
  });

  const tamilCount = uniqueSources.filter((source) => source.language.includes('Tamil')).length;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8">
      {/* Tab Switcher: Farmer Library vs Admin Ingestion Pipeline */}
      <div className="flex items-center justify-between border-b border-ink-200 pb-3">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('library')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-bold transition ${
              activeTab === 'library'
                ? 'bg-leaf-500 text-white shadow-sm'
                : 'text-ink-600 hover:bg-ink-100 hover:text-ink-900'
            }`}
          >
            <BookOpen className="h-4 w-4" />
            <span>{isTa ? 'வேளாண் அறிவு நூலகம்' : 'Farmer Knowledge Library'}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('schemes')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-bold transition ${
              activeTab === 'schemes'
                ? 'bg-clay-500 text-white shadow-sm'
                : 'text-ink-600 hover:bg-ink-100 hover:text-ink-900'
            }`}
          >
            <Landmark className="h-4 w-4" />
            <span>{isTa ? 'அரசு நலத்திட்டங்கள்' : 'Government Schemes'}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('ingestion')}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-bold transition ${
              activeTab === 'ingestion'
                ? 'bg-ink-900 text-white shadow-sm'
                : 'text-ink-600 hover:bg-ink-100 hover:text-ink-900'
            }`}
          >
            <Database className="h-4 w-4 text-aqua-400" />
            <span>{isTa ? 'நிர்வாக செயலாக்க மையம்' : 'Admin Ingestion Pipeline'}</span>
          </button>
        </div>

        {activeTab === 'library' && (
          <button
            type="button"
            onClick={handlePrint}
            className={buttonClass('secondary', 'sm')}
          >
            <Printer className="h-4 w-4" aria-hidden />
            {t('library.printGuide')}
          </button>
        )}
      </div>

      {activeTab === 'ingestion' ? (
        <IngestionAdminPage />
      ) : activeTab === 'schemes' ? (
        <>
          <PageHeader
            eyebrow={isTa ? 'அரசு நலத்திட்டங்கள் & மானியங்கள்' : 'Government Welfare & Subsidies'}
            title={isTa ? 'விவசாயிகளுக்கான அரசு திட்டங்கள்' : 'Agricultural Welfare Schemes'}
            subtitle={
              isTa
                ? 'பிரதமர் கிசான், பயிர் காப்பீடு, 100% சொட்டுநீர் பாசன மானியம் மற்றும் குறைந்த வட்டி பயிர்க்கடன் வழிகாட்டி.'
                : 'Verified national and Tamil Nadu agricultural welfare programs, eligibility criteria, and direct portal links.'
            }
          />
          <GovernmentSchemesView />
        </>
      ) : (
        <>
          <PageHeader
            eyebrow={isTa ? 'சரிபார்க்கப்பட்ட அறிவு' : 'Verified Knowledge Library'}
            title={t('library.title')}
            subtitle={t('library.subtitle')}
          />

          {/* Quick Metrics */}
          <div className="grid gap-4 sm:grid-cols-3">
            {[
              {
                label: isTa ? 'சரிபார்க்கப்பட்ட ஆவணங்கள்' : 'Verified Documents',
                value: uniqueSources.length,
                tone: 'bg-leaf-100 text-leaf-800',
              },
              {
                label: isTa ? 'தமிழில் கிடைக்கும் கையேடுகள்' : 'Available in Tamil',
                value: tamilCount,
                tone: 'bg-lilac-200 text-lilac-800',
              },
              {
                label: isTa ? 'வெக்டர் குறியீட்டுத் துண்டுகள்' : 'Indexed Vector Chunks',
                value: stats?.totalChunks || 32,
                tone: 'bg-aqua-100 text-aqua-800',
              },
            ].map((stat) => (
              <Card key={stat.label} className="flex items-center gap-4 p-5">
                <span
                  className={`flex h-12 w-12 items-center justify-center rounded-xl text-xl font-bold ${stat.tone}`}
                >
                  {stat.value}
                </span>
                <div className="min-w-0">
                  <span className="text-sm font-semibold text-ink-900">{stat.label}</span>
                  <p className="text-xs text-ink-500">TNAU, ICAR, KVK, Govt of TN</p>
                </div>
              </Card>
            ))}
          </div>

          {/* Search & Filter Controls */}
          <div className="flex flex-col gap-4">
            <div className="flex flex-col gap-3 sm:flex-row">
              <label className="relative flex-1 block">
                <span className="sr-only">{t('library.search')}</span>
                <Search
                  className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-ink-500"
                  aria-hidden
                />
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder={t('library.search')}
                  className="h-12 w-full rounded-xl border border-ink-200 bg-white pl-11 pr-4 text-base text-ink-900 placeholder:text-ink-500 transition focus:border-leaf-500 focus:outline-none focus:ring-4 focus:ring-leaf-200/60"
                />
              </label>

              <div className="flex items-center gap-1.5 rounded-xl border border-ink-200 bg-white p-1">
                {(['all', 'Tamil', 'English'] as const).map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setLangFilter(opt)}
                    className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                      langFilter === opt
                        ? 'bg-ink-900 text-white'
                        : 'text-ink-600 hover:bg-ink-100'
                    }`}
                  >
                    {opt === 'all' ? (isTa ? 'அனைத்து மொழிகள்' : 'All Languages') : opt}
                  </button>
                ))}
              </div>
            </div>

            {/* Crop Filter Bar */}
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
              <span className="text-xs font-bold text-ink-500 flex items-center gap-1 shrink-0">
                <Filter className="h-3.5 w-3.5" />
                {isTa ? 'பயிர்:' : 'Crop:'}
              </span>
              {[
                { id: 'all', label: isTa ? 'அனைத்து பயிர்கள்' : 'All Crops' },
                { id: 'Paddy', label: 'Paddy (நெல்)' },
                { id: 'Cotton', label: 'Cotton (பருத்தி)' },
                { id: 'Sugarcane', label: 'Sugarcane (கரும்பு)' },
                { id: 'Maize', label: 'Maize (மக்காச்சோளம்)' },
                { id: 'Banana', label: 'Banana (வாழை)' },
                { id: 'Groundnut', label: 'Groundnut (நிலக்கடலை)' },
              ].map((c) => {
                const active = cropFilter === c.id;
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setCropFilter(c.id)}
                    className={`shrink-0 rounded-full px-3 py-1 text-xs font-semibold transition ${
                      active
                        ? 'bg-leaf-500 text-white'
                        : 'border border-ink-200 bg-white text-ink-700 hover:border-ink-300'
                    }`}
                  >
                    {c.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Documents Grid */}
          {visible.length === 0 ? (
            <Card className="p-10 text-center">
              <BookOpen className="mx-auto h-8 w-8 text-ink-400" aria-hidden />
              <p className="mt-3 text-base font-bold text-ink-900">
                {isTa ? 'ஆவணங்கள் எதுவும் பொருந்தவில்லை' : 'No documents match this search'}
              </p>
              <p className="mt-1 text-sm text-ink-500">
                {isTa
                  ? 'நெல், உரம், நிலக்கடலை போன்ற சொற்களைப் பயன்படுத்திப் பார்க்கவும்.'
                  : 'Try a crop or nutrient keyword such as paddy, urea or groundnut.'}
              </p>
              <Button
                variant="secondary"
                className="mt-5"
                onClick={() => {
                  setQuery('');
                  setKind('all');
                  setCropFilter('all');
                  setLangFilter('all');
                }}
              >
                {t('library.clearSearch')}
              </Button>
            </Card>
          ) : (
            <ul className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {visible.map((source) => (
                <li key={source.id}>
                  <SourceCard source={source} onOpen={() => setSelected(source)} />
                </li>
              ))}
            </ul>
          )}

          <Sheet
            open={selected !== null}
            onClose={() => setSelected(null)}
            title={selected?.title ?? ''}
          >
            {selected && <SourceDetail source={selected} />}
          </Sheet>
        </>
      )}
    </div>
  );
}
