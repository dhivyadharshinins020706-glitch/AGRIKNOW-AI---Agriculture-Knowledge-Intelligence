import { useState, useEffect } from 'react';
import {
  UploadCloud,
  Search,
  Filter,
  BookOpen,
  ShieldAlert,
  ShieldCheck,
  Layers,
} from 'lucide-react';
import { PageHeader } from '@/components/ui/PageHeader';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { IngestionStatsCards } from '@/components/library/IngestionStatsCards';
import { IngestedDocumentCard } from '@/components/library/IngestedDocumentCard';
import { IngestionUploaderModal } from '@/components/library/IngestionUploaderModal';
import {
  fetchIngestedDocuments,
  getIngestionStats,
  uploadAndIngestDocument,
  reembedDocumentChunks,
  rollbackEmbeddingsToLocalHash,
} from '@/services/ingestionService';
import type { IngestedDocument, IngestionStats, VerificationStatus } from '@/types/ingestion';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';

export default function IngestionAdminPage() {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';
  const { isOfficer, role, switchRole } = useAuth();

  const [documents, setDocuments] = useState<IngestedDocument[]>([]);
  const [stats, setStats] = useState<IngestionStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [showUploader, setShowUploader] = useState(false);

  // Filters
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | VerificationStatus>('all');
  const [cropFilter, setCropFilter] = useState<string>('all');
  const [ingestingTestDoc, setIngestingTestDoc] = useState(false);
  const [reembedding, setReembedding] = useState(false);
  const [reembedStatus, setReembedStatus] = useState<string | null>(null);

  const handleReembed = async () => {
    if (!window.confirm(isTa ? 'அனைத்து ஆவணங்களையும் gemini-embedding-2 கொண்டு புதிய வெக்டர்களாக மாற்ற வேண்டுமா?' : 'Re-embed all chunks using gemini-embedding-2? Existing 128-D vectors will be upgraded without downtime.')) {
      return;
    }
    setReembedding(true);
    setReembedStatus(null);
    try {
      const res = await reembedDocumentChunks();
      if (res.success) {
        setReembedStatus(isTa ? `வெற்றிகரமாக ${res.newlyEmbedded} துண்டுகள் gemini-embedding-2 கொண்டு உட்பொதிக்கப்பட்டன.` : `Successfully re-embedded ${res.newlyEmbedded} chunks with ${res.model} (${res.dimensions}-D).`);
        await loadData();
      } else {
        setReembedStatus(res.errors[0] || 'Re-embedding deferred.');
      }
    } catch (e: any) {
      setReembedStatus(e?.message || 'Re-embedding failed.');
    } finally {
      setReembedding(false);
    }
  };

  const handleRollback = async () => {
    if (!window.confirm(isTa ? 'அனைத்து துண்டுகளையும் 128-D உள்ளூர் வெக்டர் முறைக்கு மாற்ற வேண்டுமா?' : 'Rollback all chunks to local 128-D hash embeddings?')) {
      return;
    }
    setReembedding(true);
    try {
      const res = await rollbackEmbeddingsToLocalHash();
      setReembedStatus(isTa ? `${res.revertedChunks} துண்டுகள் 128-D முறைக்கு மாற்றப்பட்டன.` : `Rollback complete: ${res.revertedChunks} chunks reverted to 128-D hash.`);
      await loadData();
    } catch (e: any) {
      setReembedStatus(e?.message || 'Rollback failed.');
    } finally {
      setReembedding(false);
    }
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const [docsData, statsData] = await Promise.all([
        fetchIngestedDocuments(),
        getIngestionStats(),
      ]);
      setDocuments(docsData || []);
      setStats(statsData || null);
    } catch {
      // graceful fallback
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Filtered documents with safe null checks
  const filtered = (documents || []).filter((doc) => {
    if (!doc) return false;
    if (statusFilter !== 'all' && doc.verificationStatus !== statusFilter) return false;
    const docCrops = Array.isArray(doc.crops) ? doc.crops : [];
    if (
      cropFilter !== 'all' &&
      !docCrops.some((c) => (c || '').toLowerCase().includes(cropFilter.toLowerCase()))
    )
      return false;

    if (query.trim()) {
      const docTopics = Array.isArray(doc.topics) ? doc.topics : [];
      const haystack = `${doc.title || ''} ${doc.description || ''} ${doc.institution || ''} ${docCrops.join(' ')} ${docTopics.join(' ')}`.toLowerCase();
      if (!haystack.includes(query.trim().toLowerCase())) return false;
    }

    return true;
  });

  // Quick Ingest Real Test Advisory (to test pipeline instantly)
  const handleIngestTestDoc = async () => {
    setIngestingTestDoc(true);
    try {
      const sampleText = `%PDF-1.4\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n3 0 obj\n<< /Type /Page /Parent 2 0 R /Contents 4 0 R >>\nendobj\n4 0 obj\n<< /Length 280 >>\nstream\nBT\n/F1 12 Tf\n72 712 Td\n(Tamil Nadu Agricultural University - Cauvery Delta Special Advisory) Tj\n0 -20 Td\n(Paddy Blast Disease Control Protocol for Thanjavur and Tiruvarur:) Tj\n0 -20 Td\n(Apply Tricyclazole 75% WP at 120 g per acre during cloudy weather.) Tj\n0 -20 Td\n(Split nitrogen application into three equal doses: basal, tillering, and panicle initiation.) Tj\n0 -20 Td\n(Avoid application of restricted chemicals such as Monocrotophos to protect natural predators.) Tj\nET\nendstream\nendobj\nxref\n0 5\n0000000000 65535 f \n0000000009 00000 n \n0000000058 00000 n \n0000000115 00000 n \n0000000174 00000 n \ntrailer\n<< /Size 5 /Root 1 0 R >>\nstartxref\n520\n%%EOF`;

      const encoder = new TextEncoder();
      const bytes = encoder.encode(sampleText);
      const file = new File([bytes], `TNAU_Delta_Paddy_Advisory_${Date.now()}.pdf`, {
        type: 'application/pdf',
      });

      await uploadAndIngestDocument(
        file,
        {
          title: `TNAU Cauvery Delta Paddy Advisory ${new Date().getFullYear()}`,
          description:
            'Rapid disease control and split-fertilizer protocol for Samba paddy in Thanjavur, Tiruvarur, and Nagapattinam districts.',
          institution: 'Tamil Nadu Agricultural University (TNAU)',
          category: 'Disease Management',
          crops: ['Paddy (நெல்)'],
          topics: ['Cauvery Delta', 'Blast Disease', 'Split Nitrogen', 'Tricyclazole'],
          language: 'Bilingual',
          publicationDate: new Date().toISOString().split('T')[0],
        },
        {
          chunkSize: 500,
          chunkOverlap: 100,
        }
      );

      await loadData();
    } catch (e) {
      alert(e instanceof Error ? e.message : 'Test ingestion failed');
    } finally {
      setIngestingTestDoc(false);
    }
  };

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow={isTa ? 'நிர்வாக அறிவு செயலாக்கம்' : 'Knowledge Ingestion & RAG Pipeline'}
        title={isTa ? 'வேளாண் ஆவண நிர்வாக மையம்' : 'Agricultural Knowledge Ingestion Hub'}
        subtitle={
          isTa
            ? 'TNAU, ICAR மற்றும் அரசு கையேடுகளைச் செயலாக்குதல், துண்டாக்குதல், வெக்டர் உட்பொதிவு மற்றும் சரிபார்ப்பு பணிப்பாய்வு.'
            : 'Extract, clean, chunk, embed, and audit university-verified agricultural knowledge for the AGRIKNOW AI RAG engine.'
        }
        actions={
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              disabled={ingestingTestDoc}
              onClick={handleIngestTestDoc}
              className="rounded-xl border border-leaf-300 bg-white px-3.5 py-2 text-xs font-bold text-leaf-800 hover:bg-leaf-50 transition shadow-sm disabled:opacity-40"
            >
              {ingestingTestDoc
                ? isTa
                  ? 'சோதனை ஆவணம் செயலாக்குகிறது...'
                  : 'Ingesting Sample PDF...'
                : isTa
                ? 'மாதிரி PDF ஆவணத்தைச் செயலாக்கு'
                : 'Ingest Real Sample PDF'}
            </button>
            <Button
              variant="primary"
              className="flex items-center gap-2"
              onClick={() => setShowUploader(true)}
            >
              <UploadCloud className="h-4 w-4" />
              <span>{isTa ? 'புதிய ஆவணத்தைப் பதிவேற்று' : 'Upload & Ingest Document'}</span>
            </Button>
          </div>
        }
      />

      {/* Role-Based Access Control (RBAC) Gate Banner */}
      {!isOfficer ? (
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-2xl border-2 border-amber-400 bg-amber-50/90 p-5 shadow-sm">
          <div className="flex items-start gap-3">
            <ShieldAlert className="h-6 w-6 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-ink-900 text-sm">
                {isTa ? 'அங்கீகாரம் கட்டுப்படுத்தப்பட்டுள்ளது (Role-Based Access Control)' : 'Role-Based Access: Restricted Administrative Module'}
              </h4>
              <p className="text-xs text-ink-600 mt-1 leading-relaxed">
                {isTa
                  ? `தற்போதைய பணிப்பொறுப்பு: ${role}. புதிய பல்கலைக்கழக ஆவணங்களை பதிவேற்ற மற்றும் சரிபார்க்க வேளாண் விரிவாக்க அலுவலர் அல்லது விஞ்ஞானி அங்கீகாரம் தேவை.`
                  : `Current Role: ${role}. Uploading and verifying university manuals is restricted to Agricultural Extension Officers, TNAU/ICAR Scientists, and Administrators.`}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => switchRole('officer')}
            className="shrink-0 rounded-xl bg-leaf-400 px-4 py-2 text-xs font-bold text-ink-900 shadow-sm transition hover:bg-leaf-300 active:scale-95"
          >
            {isTa ? 'அலுவலர் பயன்முறைக்கு மாறுக' : 'Switch to Officer / Scientist Mode'}
          </button>
        </div>
      ) : (
        <div className="flex items-center justify-between rounded-xl border border-leaf-300 bg-leaf-50/70 px-4 py-2 text-xs text-leaf-950 font-medium">
          <span className="flex items-center gap-1.5 font-bold">
            <ShieldCheck className="h-4 w-4 text-leaf-700" />
            {isTa ? `அங்கீகரிக்கப்பட்ட பணிப்பொறுப்பு: ${role.toUpperCase()}` : `Active Authorization: ${role.toUpperCase()} (Full Ingestion & Audit Access)`}
          </span>
          <button
            type="button"
            onClick={() => switchRole('farmer')}
            className="text-[11px] underline text-leaf-800 hover:text-leaf-950"
          >
            {isTa ? 'விவசாயி முறைக்குத் திரும்பு' : 'Switch back to Farmer view'}
          </button>
        </div>
      )}

      {/* Stats Summary Cards */}
      {stats && <IngestionStatsCards stats={stats} />}

      {/* Dimensional Embedding Gateway & Re-Embedding Control Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-2xl border border-leaf-200 bg-gradient-to-r from-leaf-50/80 via-white to-leaf-50/50 p-4 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="rounded-xl bg-leaf-500/10 p-2.5 text-leaf-700">
            <Layers className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-ink-900">
                {isTa ? 'வெக்டர் உட்பொதிவு இடப் பாதை (Vector Space Gateway)' : 'Vector Space Gateway & Ingestion Status'}
              </span>
              <span className="rounded-md bg-leaf-100 px-2 py-0.5 text-[10px] font-bold text-leaf-800">
                gemini-embedding-2
              </span>
            </div>
            <p className="text-[11px] text-ink-600 mt-0.5">
              {isTa
                ? `128-D உள்ளூர் முறை மற்றும் Gemini 2.0 இரட்டை ஆதரவு. வெக்டர் இடங்கள் தனிமைப்படுத்தப்பட்டுள்ளன.`
                : `Dual-space support active: Isolated Gemini 2.0 embeddings with resilient 128-D fallback.`}
            </p>
          </div>
        </div>

        {isOfficer && (
          <div className="flex items-center gap-2 self-stretch sm:self-auto">
            <button
              type="button"
              disabled={reembedding}
              onClick={handleRollback}
              className="rounded-xl border border-ink-200 bg-white px-3 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100 transition disabled:opacity-40"
              title="Revert all chunks to 128-D local hash vectors"
            >
              {isTa ? '128-D திரும்பு' : 'Rollback 128-D'}
            </button>
            <button
              type="button"
              disabled={reembedding}
              onClick={handleReembed}
              className="rounded-xl bg-leaf-600 px-3.5 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-leaf-700 transition disabled:opacity-40 flex items-center gap-1.5"
            >
              {reembedding ? (
                <>
                  <div className="h-3 w-3 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  <span>{isTa ? 'உட்பொதிக்கிறது...' : 'Re-embedding...'}</span>
                </>
              ) : (
                <span>{isTa ? 'ஆவணங்களை மறு-உட்பொதி (Gemini)' : 'Re-Embed Corpus (Gemini)'}</span>
              )}
            </button>
          </div>
        )}
      </div>

      {reembedStatus && (
        <div className="rounded-xl border border-leaf-300 bg-leaf-50 p-3 text-xs text-leaf-900 font-medium flex items-center justify-between">
          <span>{reembedStatus}</span>
          <button
            type="button"
            onClick={() => setReembedStatus(null)}
            className="text-[11px] underline text-leaf-700 hover:text-leaf-900"
          >
            {isTa ? 'மூடு' : 'Dismiss'}
          </button>
        </div>
      )}

      {/* Filters & Search Bar */}
      <div className="flex flex-col gap-4">
        <div className="flex flex-col gap-3 sm:flex-row">
          <label className="relative flex-1 block">
            <span className="sr-only">Search ingested documents</span>
            <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-ink-500" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={
                isTa
                  ? 'தலைப்பு, பயிர் அல்லது நிறுவனத்தால் தேடுங்கள்...'
                  : 'Search documents by crop, publisher, or agronomic keywords...'
              }
              className="h-12 w-full rounded-xl border border-ink-200 bg-white pl-11 pr-4 text-sm text-ink-900 placeholder:text-ink-500 transition focus:border-leaf-500 focus:outline-none focus:ring-4 focus:ring-leaf-200/60"
            />
          </label>

          {/* Verification Status Filter Tabs */}
          <div className="flex items-center gap-1 rounded-xl border border-ink-200 bg-white p-1 overflow-x-auto no-scrollbar">
            {[
              { id: 'all', label: isTa ? 'அனைத்தும்' : 'All Status' },
              { id: 'verified', label: isTa ? 'சரிபார்க்கப்பட்டது' : 'Verified' },
              { id: 'pending_review', label: isTa ? 'ஆய்வில்' : 'Pending' },
              { id: 'flagged_conflicting', label: isTa ? 'முரண்பாடு' : 'Conflicted' },
            ].map((tab) => {
              const active = statusFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setStatusFilter(tab.id as 'all' | VerificationStatus)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition ${
                    active ? 'bg-ink-900 text-white' : 'text-ink-600 hover:bg-ink-100'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Crops Filter Bar */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
          <span className="text-xs font-bold text-ink-500 flex items-center gap-1 shrink-0">
            <Filter className="h-3.5 w-3.5" />
            {isTa ? 'பயிர் வடிகட்டி:' : 'Crop:'}
          </span>
          {[
            { id: 'all', label: isTa ? 'அனைத்து பயிர்கள்' : 'All Crops' },
            { id: 'Paddy', label: 'Paddy (நெல்)' },
            { id: 'Cotton', label: 'Cotton (பருத்தி)' },
            { id: 'Sugarcane', label: 'Sugarcane (கரும்பு)' },
            { id: 'Maize', label: 'Maize (மக்காச்சோளம்)' },
            { id: 'Banana', label: 'Banana (வாழை)' },
            { id: 'Groundnut', label: 'Groundnut (நிலக்கடலை)' },
          ].map((c) => {
            const active = cropFilter === c.id;
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => setCropFilter(c.id)}
                className={`shrink-0 rounded-full px-3.5 py-1 text-xs font-medium transition ${
                  active
                    ? 'bg-leaf-500 text-white shadow-sm font-bold'
                    : 'border border-ink-200 bg-white text-ink-700 hover:border-ink-300'
                }`}
              >
                {c.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Documents Grid */}
      {loading ? (
        <div className="py-20 text-center">
          <div className="mx-auto h-8 w-8 animate-spin rounded-full border-4 border-leaf-500 border-t-transparent" />
          <p className="mt-3 text-sm text-ink-500">
            {isTa ? 'ஆவணத் தரவுத்தளத்தை ஏற்றுகிறது...' : 'Loading knowledge index from database...'}
          </p>
        </div>
      ) : filtered.length === 0 ? (
        <Card className="p-12 text-center">
          <BookOpen className="mx-auto h-10 w-10 text-ink-400" />
          <h3 className="mt-3 text-base font-bold text-ink-900">
            {isTa ? 'ஆவணங்கள் எதுவும் பொருந்தவில்லை' : 'No documents match this filter'}
          </h3>
          <p className="mt-1 text-xs text-ink-500">
            {isTa
              ? 'வடிகட்டிகளை மாற்றவும் அல்லது புதிய PDF ஆவணத்தைப் பதிவேற்றவும்.'
              : 'Clear search filters or upload a new PDF manual to the agricultural repository.'}
          </p>
          <Button
            variant="secondary"
            className="mt-4"
            onClick={() => {
              setQuery('');
              setStatusFilter('all');
              setCropFilter('all');
            }}
          >
            {isTa ? 'வடிகட்டிகளை மீட்டமை' : 'Reset Filters'}
          </Button>
        </Card>
      ) : (
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((doc) => (
            <IngestedDocumentCard key={doc.id} document={doc} onRefresh={loadData} />
          ))}
        </div>
      )}

      {/* Ingestion Uploader Modal */}
      {showUploader && (
        <IngestionUploaderModal
          onClose={() => setShowUploader(false)}
          onSuccess={() => {
            setShowUploader(false);
            loadData();
          }}
        />
      )}
    </div>
  );
}
