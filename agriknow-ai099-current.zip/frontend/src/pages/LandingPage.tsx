import { motion, useReducedMotion } from 'framer-motion';
import { ArrowRight, BookOpen, Camera, FlaskConical, GitCompare, MessageCircleQuestion, ShieldCheck, Sprout } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Logo } from '@/components/layout/Logo';
import { Reveal } from '@/components/ui/Reveal';
import { buttonClass } from '@/components/ui/Button';
import type { LucideIcon } from 'lucide-react';

interface Feature {
  title: string;
  body: string;
  href: string;
  icon: LucideIcon;
  tone: string;
}

const features: Feature[] = [
  {
    title: 'Ask in Tamil or English',
    body: 'Type or describe your problem in simple words. Get step-by-step advice you can act on today.',
    href: '#/assistant',
    icon: MessageCircleQuestion,
    tone: 'bg-lilac-200 text-lilac-800',
  },
  {
    title: 'Spot disease from a photo',
    body: 'Upload a leaf photo to find likely diseases early, with treatment steps and safety notes.',
    href: '#/diseases',
    icon: Camera,
    tone: 'bg-sun-100 text-sun-800',
  },
  {
    title: 'Fertilizer plans from your soil',
    body: 'Read your soil health card and see exactly how much nutrient your field needs.',
    href: '#/soil',
    icon: FlaskConical,
    tone: 'bg-leaf-100 text-leaf-800',
  },
  {
    title: 'Choose the most profitable crop',
    body: 'Compare yield, cost, price, and risk side by side before you plant.',
    href: '#/crops',
    icon: GitCompare,
    tone: 'bg-aqua-100 text-aqua-800',
  },
];

const trustPoints = [
  'Answers cite government and university research',
  'Every advice links to the source it came from',
  'Works on a basic phone, in your language',
];

const footerLinks = [
  { label: 'Dashboard', href: '#/dashboard' },
  { label: 'Knowledge library', href: '#/library' },
  { label: 'Crop comparison', href: '#/crops' },
  { label: 'Profile', href: '#/profile' },
];

export default function LandingPage() {
  const { t } = useLanguage();
  const reduceMotion = useReducedMotion();

  const rise = (delay: number) =>
    reduceMotion
      ? {}
      : { initial: { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] as const } };

  return (
    <div className="min-h-screen bg-ink-50 text-ink-900">
      <header className="sticky top-0 z-30 border-b border-ink-200/60 bg-ink-50/85 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6 lg:h-20">
          <Logo />
          <a href="#/dashboard" className={buttonClass('dark', 'sm')}>
            {t('nav.dashboard')}
          </a>
        </div>
      </header>

      <main>
        <section className="relative overflow-hidden">
          <div aria-hidden className="pointer-events-none absolute inset-0">
            <div className="absolute -left-24 -top-24 h-[420px] w-[420px] rounded-full bg-leaf-200/60 blur-3xl" />
            <div className="absolute right-[-120px] top-10 h-[360px] w-[360px] rounded-full bg-lilac-200/70 blur-3xl" />
            <div className="absolute bottom-0 left-1/3 h-[280px] w-[280px] rounded-full bg-aqua-100/80 blur-3xl" />
          </div>

          <div className="relative mx-auto grid max-w-6xl gap-12 px-4 pb-20 pt-14 sm:px-6 sm:pt-20 lg:grid-cols-[1.1fr_0.9fr] lg:items-center lg:pb-28 lg:pt-24">
            <div>
              <motion.span
                {...rise(0)}
                className="inline-flex items-center gap-2 rounded-full border border-leaf-300 bg-white/80 px-4 py-2 text-sm font-semibold text-leaf-800 shadow-card"
              >
                <Sprout className="h-4 w-4" aria-hidden />
                {t('landing.heroBadge')}
              </motion.span>

              <motion.h1 {...rise(0.08)} className="mt-6 text-balance text-4xl font-bold leading-[1.15] text-ink-900 sm:text-5xl lg:text-6xl">
                {t('landing.heroTitle')}
              </motion.h1>

              <motion.p {...rise(0.16)} className="mt-6 max-w-xl text-lg leading-relaxed text-ink-600">
                {t('landing.heroSubtitle')}
              </motion.p>

              <motion.div {...rise(0.24)} className="mt-9 flex flex-col gap-3 sm:flex-row">
                <a href="#/dashboard" className={buttonClass('primary', 'lg', 'group')}>
                  {t('landing.ctaPrimary')}
                  <ArrowRight className="h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" aria-hidden />
                </a>
                <a href="#/assistant" className={buttonClass('secondary', 'lg')}>
                  <MessageCircleQuestion className="h-5 w-5" aria-hidden />
                  {t('landing.ctaSecondary')}
                </a>
              </motion.div>

              <motion.ul {...rise(0.32)} className="mt-10 space-y-3">
                {trustPoints.map((point) => (
                  <li key={point} className="flex items-center gap-3 text-[15px] text-ink-700">
                    <ShieldCheck className="h-5 w-5 shrink-0 text-leaf-600" aria-hidden />
                    {point}
                  </li>
                ))}
              </motion.ul>
            </div>

            <motion.div {...rise(0.2)} className="relative">
              <div className="rounded-3xl border border-ink-200/70 bg-white p-6 shadow-lift sm:p-8">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-ink-500">Today on your farm</p>
                  <span className="rounded-full bg-leaf-100 px-3 py-1 text-xs font-bold text-leaf-800">Healthy</span>
                </div>
                <div className="mt-6 space-y-4">
                  <div className="rounded-2xl bg-sun-50 p-4 ring-1 ring-sun-200">
                    <p className="text-sm font-bold text-sun-900">Planthopper risk is rising</p>
                    <p className="mt-1 text-sm text-ink-600">Count hoppers at the base of 10 plants in your paddy field this week.</p>
                  </div>
                  <div className="rounded-2xl bg-aqua-50 p-4 ring-1 ring-aqua-200">
                    <p className="text-sm font-bold text-ink-900">Rain expected tomorrow</p>
                    <p className="mt-1 text-sm text-ink-600">Hold off on urea top dressing until the field is dry.</p>
                  </div>
                  <div className="rounded-2xl bg-lilac-50 p-4 ring-1 ring-lilac-200">
                    <p className="text-sm font-bold text-ink-900">Source checked</p>
                    <p className="mt-1 flex items-center gap-2 text-sm text-ink-600">
                      <BookOpen className="h-4 w-4 text-lilac-800" aria-hidden />
                      TNAU paddy advisory, 2024
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        <section aria-labelledby="features-heading" className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
          <Reveal>
            <p className="text-sm font-semibold uppercase tracking-[0.14em] text-leaf-700">Everything in one place</p>
            <h2 id="features-heading" className="mt-3 max-w-2xl text-3xl font-bold text-ink-900 sm:text-4xl">
              Four tools for every decision on your farm
            </h2>
          </Reveal>

          <div className="mt-12 grid gap-5 sm:grid-cols-2">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Reveal key={feature.title} delay={index * 0.06}>
                  <a
                    href={feature.href}
                    className="group flex h-full gap-5 rounded-2xl border border-ink-200/70 bg-white p-6 shadow-card transition duration-300 hover:-translate-y-1 hover:border-ink-300 hover:shadow-lift sm:p-7"
                  >
                    <span className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl ${feature.tone} transition-transform duration-300 group-hover:scale-110`}>
                      <Icon className="h-7 w-7" aria-hidden />
                    </span>
                    <span>
                      <span className="flex items-center gap-2 text-lg font-bold text-ink-900">
                        {feature.title}
                        <ArrowRight className="h-4 w-4 opacity-0 transition duration-300 group-hover:translate-x-1 group-hover:opacity-100" aria-hidden />
                      </span>
                      <span className="mt-2 block text-[15px] leading-relaxed text-ink-600">{feature.body}</span>
                    </span>
                  </a>
                </Reveal>
              );
            })}
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 pb-20 sm:px-6 lg:pb-28">
          <Reveal>
            <div className="relative overflow-hidden rounded-3xl bg-ink-900 p-8 text-white sm:p-12">
              <div aria-hidden className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-leaf-400/30 blur-3xl" />
              <div className="relative flex flex-col items-start gap-6 md:flex-row md:items-center md:justify-between">
                <div>
                  <h2 className="text-2xl font-bold sm:text-3xl">Start with your next field decision</h2>
                  <p className="mt-2 max-w-xl text-base text-ink-300">Open your dashboard and see what needs attention today.</p>
                </div>
                <a href="#/dashboard" className={buttonClass('primary', 'lg', 'group shrink-0')}>
                  {t('landing.ctaPrimary')}
                  <ArrowRight className="h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" aria-hidden />
                </a>
              </div>
            </div>
          </Reveal>
        </section>
      </main>

      <footer className="border-t border-ink-200/70 bg-white">
        <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-10 sm:px-6 md:flex-row md:items-center md:justify-between">
          <Logo />
          <nav aria-label="Footer" className="flex flex-wrap gap-x-6 gap-y-2">
            {footerLinks.map((link) => (
              <a key={link.href} href={link.href} className="text-sm font-medium text-ink-600 transition hover:text-ink-900">
                {link.label}
              </a>
            ))}
          </nav>
          <p className="text-sm text-ink-500">Sample data for demonstration. Advice is for guidance only.</p>
        </div>
      </footer>
    </div>
  );
}
