import React, { useState } from 'react';
import { X, Star, ThumbsUp, ThumbsDown, CheckCircle, AlertTriangle } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { submitPilotFeedback, type PilotModule, type ReviewerRole } from '@/services/feedbackService';

interface PilotFeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  module: PilotModule;
  queryText: string;
  answerSnippet: string;
  onSubmitted?: () => void;
}

const ACCURACY_OPTIONS = [
  { id: 'wrong_diagnosis', label: 'Inaccurate Pest / Disease Diagnosis', labelTa: 'தவறான பயிர் / பூச்சி நோய் கணிப்பு' },
  { id: 'wrong_dosage', label: 'Inaccurate Fertilizer Dosage', labelTa: 'தவறான உர அளவு அல்லது பரிந்துரை' },
  { id: 'unnatural_tamil', label: 'Unnatural Tamil / Awkward Terminology', labelTa: 'இயற்கையற்ற தமிழ் அல்லது பிழையான கலைச்சொற்கள்' },
  { id: 'unsafe_chemical', label: 'Safety / Banned Chemical Concern', labelTa: 'பாதுகாப்பற்ற / தடை செய்யப்பட்ட வேதிப்பொருள் கவலை' },
  { id: 'missing_inspection', label: 'Missing Field Inspection Advisory', labelTa: 'நேரடி கள ஆய்வுக் குறிப்பு விடுபட்டுள்ளது' },
];

export const PilotFeedbackModal: React.FC<PilotFeedbackModalProps> = ({
  isOpen,
  onClose,
  module,
  queryText,
  answerSnippet,
  onSubmitted,
}) => {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';

  const [role, setRole] = useState<ReviewerRole>('farmer');
  const [isHelpful, setIsHelpful] = useState<boolean>(true);
  const [rating, setRating] = useState<number>(5);
  const [tamilRating, setTamilRating] = useState<number>(5);
  const [selectedFlags, setSelectedFlags] = useState<string[]>([]);
  const [comments, setComments] = useState<string>('');
  const [consentGranted, setConsentGranted] = useState<boolean>(true);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  if (!isOpen) return null;

  const toggleFlag = (flagId: string) => {
    setSelectedFlags((prev) =>
      prev.includes(flagId) ? prev.filter((f) => f !== flagId) : [...prev, flagId]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!consentGranted) {
      setErrorMsg(isTa ? 'கருத்துக்களை சேமிக்க ஒப்புதல் அளிக்க வேண்டும்.' : 'Please provide consent to submit feedback.');
      return;
    }

    setSubmitting(true);
    setErrorMsg('');

    const res = await submitPilotFeedback({
      reviewerRole: role,
      module,
      queryText,
      answerSnippet,
      isHelpful,
      rating,
      accuracyFlags: selectedFlags,
      tamilQualityRating: tamilRating,
      comments: comments.trim() || undefined,
      consentGranted,
    });

    setSubmitting(false);
    if (res.success) {
      setSubmitted(true);
      if (onSubmitted) onSubmitted();
      setTimeout(() => {
        setSubmitted(false);
        onClose();
      }, 1800);
    } else {
      setErrorMsg(res.error || 'Failed to submit feedback');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
      <div className="relative max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl">
        <button
          type="button"
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-2 text-ink-400 hover:bg-ink-100 hover:text-ink-700"
          aria-label="Close"
        >
          <X className="h-5 w-5" />
        </button>

        {submitted ? (
          <div className="py-8 text-center">
            <CheckCircle className="mx-auto h-12 w-12 text-leaf-500" />
            <h3 className="mt-3 text-lg font-bold text-ink-900">
              {isTa ? 'முன்னோடி ஆய்வு கருத்து பதிவு செய்யப்பட்டது!' : 'Pilot Feedback Submitted!'}
            </h3>
            <p className="mt-1 text-sm text-ink-600">
              {isTa
                ? 'உங்கள் மதிப்பாய்வு எங்கள் வேளாண் மாதிரி மற்றும் தமிழ் மொழி துல்லியத்தை மேம்படுத்த உதவும்.'
                : 'Your verification helps us improve agricultural accuracy and farmer usability.'}
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="rounded-full bg-brand-100 px-2.5 py-0.5 text-xs font-bold text-brand-800">
                  Phase 7 Pilot Validation
                </span>
                <span className="text-xs font-semibold text-ink-500 uppercase">
                  {module.replace('_', ' ')}
                </span>
              </div>
              <h2 className="mt-1 text-lg font-bold text-ink-900">
                {isTa ? 'வேளாண் விடை மதிப்பாய்வு & கருத்து' : 'Agricultural Answer Review & Feedback'}
              </h2>
              <p className="text-xs text-ink-500">
                {isTa
                  ? 'விவசாயிகள் மற்றும் வல்லுநர்களின் உண்மை அனுபவத்தை அறிய இந்த முன்னோடி மதிப்பீடு பயன்படுகிறது.'
                  : 'Used by farmers, agronomists, and field officers to evaluate accuracy, Tamil quality, and usability.'}
              </p>
            </div>

            {errorMsg && (
              <div className="flex items-center gap-2 rounded-xl bg-danger-50 p-3 text-xs text-danger-700">
                <AlertTriangle className="h-4 w-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Role Selection */}
            <div>
              <label className="block text-xs font-semibold text-ink-700">
                {isTa ? 'உங்கள் பங்கு (Reviewer Role)' : 'Your Role as Reviewer'}
              </label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as ReviewerRole)}
                className="mt-1 w-full rounded-xl border border-ink-200 bg-white px-3 py-2 text-xs font-medium text-ink-800 focus:border-brand-500 focus:outline-none"
              >
                <option value="farmer">{isTa ? 'உழவர் / விவசாயி (Farmer)' : 'Farmer'}</option>
                <option value="officer">{isTa ? 'வேளாண் அலுவலர் (Agricultural Officer)' : 'Field Agricultural Officer'}</option>
                <option value="scientist">{isTa ? 'வேளாண் விஞ்ஞானி / ஆசிரியர் (Agronomist / Scientist)' : 'Agronomist / Scientist'}</option>
                <option value="extension_worker">{isTa ? 'விரிவாக்கப் பணியாளர் (Extension Worker)' : 'KVK / Extension Worker'}</option>
                <option value="general_user">{isTa ? 'பொது பயனர் (General Tester)' : 'General Tester'}</option>
              </select>
            </div>

            {/* Helpfulness Toggle */}
            <div>
              <label className="block text-xs font-semibold text-ink-700">
                {isTa ? 'இந்த விடை உங்களுக்கு பயனுள்ளதாக இருந்ததா?' : 'Was this recommendation helpful?'}
              </label>
              <div className="mt-1.5 flex gap-3">
                <button
                  type="button"
                  onClick={() => setIsHelpful(true)}
                  className={`flex flex-1 items-center justify-center gap-2 rounded-xl py-2 text-xs font-bold transition ${
                    isHelpful ? 'bg-leaf-500 text-white shadow-md' : 'bg-ink-100 text-ink-700 hover:bg-ink-200'
                  }`}
                >
                  <ThumbsUp className="h-4 w-4" />
                  <span>{isTa ? 'ஆம், பயனுள்ளது' : 'Yes, Helpful'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsHelpful(false)}
                  className={`flex flex-1 items-center justify-center gap-2 rounded-xl py-2 text-xs font-bold transition ${
                    !isHelpful ? 'bg-danger-600 text-white shadow-md' : 'bg-ink-100 text-ink-700 hover:bg-ink-200'
                  }`}
                >
                  <ThumbsDown className="h-4 w-4" />
                  <span>{isTa ? 'இல்லை / திருத்தம் தேவை' : 'Needs Improvement'}</span>
                </button>
              </div>
            </div>

            {/* Overall Rating Stars */}
            <div>
              <label className="block text-xs font-semibold text-ink-700">
                {isTa ? 'ஒட்டுமொத்த வேளாண் துல்லியம் (Overall Accuracy Rating)' : 'Agricultural Accuracy Rating'}
              </label>
              <div className="mt-1 flex items-center gap-1.5">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="p-1 transition hover:scale-110"
                    aria-label={`Rate ${star} stars`}
                  >
                    <Star
                      className={`h-6 w-6 ${
                        star <= rating ? 'fill-brand-500 text-brand-500' : 'text-ink-200'
                      }`}
                    />
                  </button>
                ))}
                <span className="ml-2 text-xs font-bold text-ink-700">{rating} / 5</span>
              </div>
            </div>

            {/* Tamil Language Quality Rating */}
            <div>
              <label className="block text-xs font-semibold text-ink-700">
                {isTa ? 'தமிழ் மொழி தரம் & எளிமை (Tamil Language Quality)' : 'Tamil Language Quality & Clarity'}
              </label>
              <div className="mt-1 flex items-center gap-1.5">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setTamilRating(star)}
                    className="p-1 transition hover:scale-110"
                    aria-label={`Rate Tamil ${star} stars`}
                  >
                    <Star
                      className={`h-6 w-6 ${
                        star <= tamilRating ? 'fill-cyan-500 text-cyan-500' : 'text-ink-200'
                      }`}
                    />
                  </button>
                ))}
                <span className="ml-2 text-xs font-bold text-ink-700">{tamilRating} / 5</span>
              </div>
            </div>

            {/* Accuracy Flags */}
            <div>
              <label className="block text-xs font-semibold text-ink-700">
                {isTa ? 'குறிப்பிட்ட கவலைகள் (Select any concerns that apply):' : 'Specific Concerns (if any):'}
              </label>
              <div className="mt-1.5 space-y-1.5">
                {ACCURACY_OPTIONS.map((opt) => (
                  <label
                    key={opt.id}
                    className="flex cursor-pointer items-center gap-2 rounded-lg p-1.5 hover:bg-ink-50"
                  >
                    <input
                      type="checkbox"
                      checked={selectedFlags.includes(opt.id)}
                      onChange={() => toggleFlag(opt.id)}
                      className="h-4 w-4 rounded border-ink-300 text-brand-500 focus:ring-brand-500"
                    />
                    <span className="text-xs text-ink-700">
                      {isTa ? opt.labelTa : opt.label}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            {/* Comments Field */}
            <div>
              <label className="block text-xs font-semibold text-ink-700">
                {isTa ? 'கூடுதல் கருத்துக்கள் / பரிந்துரைகள் (Optional Comments)' : 'Comments & Field Notes (Optional)'}
              </label>
              <textarea
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                rows={3}
                placeholder={
                  isTa
                    ? 'எ.கா. சம்பா பருவத்தில் பொக்கு காய் வராமல் இருக்க ஜிப்சம் சரியான நேரத்தில் பரிந்துரைக்கப்பட்டுள்ளது...'
                    : 'e.g., Exact dosage verified with TNAU crop guide...'
                }
                className="mt-1 w-full rounded-xl border border-ink-200 p-2.5 text-xs text-ink-800 placeholder:text-ink-400 focus:border-brand-500 focus:outline-none"
              />
            </div>

            {/* Informed Consent Checkbox */}
            <div className="rounded-xl bg-lilac-50 p-3">
              <label className="flex cursor-pointer items-start gap-2.5">
                <input
                  type="checkbox"
                  checked={consentGranted}
                  onChange={(e) => setConsentGranted(e.target.checked)}
                  className="mt-0.5 h-4 w-4 rounded border-ink-300 text-brand-500 focus:ring-brand-500"
                />
                <span className="text-xs leading-relaxed text-ink-700">
                  {isTa
                    ? 'நான் இந்த முன்னோடி ஆய்வு கருத்தினை AGRIKNOW AI மாதிரியின் துல்லியத்தை மேம்படுத்த அநாமதேயமாக சேமிக்க ஒப்புதல் அளிக்கிறேன்.'
                    : 'I consent to my feedback being stored anonymously for Phase 7 pilot quality and model evaluation.'}
                </span>
              </label>
            </div>

            {/* Buttons */}
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 rounded-xl border border-ink-200 py-2.5 text-xs font-bold text-ink-700 hover:bg-ink-50"
              >
                {isTa ? 'ரத்துசெய்' : 'Cancel'}
              </button>
              <button
                type="submit"
                disabled={submitting || !consentGranted}
                className="flex-1 rounded-xl bg-brand-500 py-2.5 text-xs font-bold text-ink-950 shadow-md transition hover:bg-brand-400 disabled:opacity-50"
              >
                {submitting
                  ? (isTa ? 'பதிவாகிறது...' : 'Submitting...')
                  : (isTa ? 'கருத்து சமர்ப்பி' : 'Submit Review')}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
