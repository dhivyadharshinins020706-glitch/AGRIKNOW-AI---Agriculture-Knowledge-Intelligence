import React, { useEffect, useState } from 'react';
import { X, Award, BarChart3, Star, ThumbsUp, ThumbsDown, ShieldAlert, Download, RefreshCw } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { fetchAllPilotFeedback, type PilotFeedbackEntry } from '@/services/feedbackService';
import { getPilotAggregatedMetrics, type PilotAggregatedMetrics } from '@/services/pilotAnalyticsService';

interface PilotReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PilotReviewModal: React.FC<PilotReviewModalProps> = ({ isOpen, onClose }) => {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';

  const [metrics, setMetrics] = useState<PilotAggregatedMetrics | null>(null);
  const [feedbacks, setFeedbacks] = useState<PilotFeedbackEntry[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const loadData = async () => {
    setLoading(true);
    const m = getPilotAggregatedMetrics();
    const fb = await fetchAllPilotFeedback();
    setMetrics(m);
    setFeedbacks(fb);
    setLoading(false);
  };

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const exportJson = () => {
    const data = {
      timestamp: new Date().toISOString(),
      metrics,
      feedbacks,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `agriknow_pilot_report_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
      <div className="relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl">
        <button
          type="button"
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-2 text-ink-400 hover:bg-ink-100 hover:text-ink-700"
          aria-label="Close"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="flex items-center justify-between border-b border-ink-100 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="rounded-full bg-brand-100 px-2.5 py-0.5 text-xs font-bold text-brand-800">
                Phase 7 Pilot Audit
              </span>
              <span className="text-xs text-ink-500">
                {isTa ? 'உண்மை கள முன்னோடி ஆய்வு தணிக்கை' : 'Controlled Field Validation'}
              </span>
            </div>
            <h2 className="mt-1 text-xl font-bold text-ink-900">
              {isTa ? 'முன்னோடி ஆய்வு அளவீடுகள் & கள மதிப்புரை' : 'Pilot Metrics & Field Review Portal'}
            </h2>
          </div>

          <div className="flex items-center gap-2 mr-8">
            <button
              type="button"
              onClick={loadData}
              className="flex items-center gap-1 rounded-xl border border-ink-200 px-3 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-50"
              title="Refresh"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>{isTa ? 'புதுப்பி' : 'Refresh'}</span>
            </button>
            <button
              type="button"
              onClick={exportJson}
              className="flex items-center gap-1 rounded-xl bg-brand-500 px-3 py-1.5 text-xs font-bold text-ink-950 shadow-sm transition hover:bg-brand-400"
            >
              <Download className="h-3.5 w-3.5" />
              <span>{isTa ? 'அறிக்கை பதிவிறக்கு' : 'Export JSON'}</span>
            </button>
          </div>
        </div>

        {/* Notice of Pilot Status */}
        <div className="mt-4 rounded-xl border border-cyan-200 bg-cyan-50 p-3 text-xs text-cyan-900">
          <p className="font-semibold">
            {isTa ? '⚠️ முன்னோடி ஆய்வு நெறிமுறை அறிவிப்பு:' : '⚠️ Pilot Validation Protocol Notice:'}
          </p>
          <p className="mt-0.5 text-cyan-800 leading-relaxed">
            {isTa
              ? 'இந்த தளம் மாதிரித் தரவுகளையும் உண்மையான முன்னோடி விவசாயிகளின் கருத்துக்களையும் தனித்தனியாகப் பதிவு செய்கிறது. உழவர் பங்கேற்பு அல்லது விஞ்ஞானி ஒப்புதல்கள் செயற்கையாக உருவாக்கப்படவில்லை.'
              : 'This portal tracks simulated test cases and actual pilot participant feedback. Real farmer and expert field trials are conducted with informed consent.'}
          </p>
        </div>

        {/* Aggregated Pilot Metrics Grid */}
        {metrics && (
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="rounded-xl border border-ink-100 bg-ink-50 p-3">
              <span className="text-[11px] font-semibold text-ink-500 uppercase">
                {isTa ? 'பணி நிறைவு விகிதம்' : 'Task Completion'}
              </span>
              <p className="mt-1 text-xl font-bold text-leaf-700">{metrics.taskCompletionRate.toFixed(1)}%</p>
              <span className="text-[10px] text-ink-500">{metrics.successfulTasks} / {metrics.totalTasks} tasks</span>
            </div>

            <div className="rounded-xl border border-ink-100 bg-ink-50 p-3">
              <span className="text-[11px] font-semibold text-ink-500 uppercase">
                {isTa ? 'பயனுள்ள விடை விகிதம்' : 'Helpfulness Ratio'}
              </span>
              <p className="mt-1 text-xl font-bold text-brand-600">{metrics.helpfulnessRatio.toFixed(1)}%</p>
              <span className="text-[10px] text-ink-500">{metrics.helpfulCount} / {metrics.totalFeedbackCount} helpful</span>
            </div>

            <div className="rounded-xl border border-ink-100 bg-ink-50 p-3">
              <span className="text-[11px] font-semibold text-ink-500 uppercase">
                {isTa ? 'துல்லிய மதிப்பீடு' : 'Avg Accuracy'}
              </span>
              <div className="mt-1 flex items-center gap-1">
                <Star className="h-4 w-4 fill-brand-500 text-brand-500" />
                <span className="text-xl font-bold text-ink-900">{metrics.averageRating}</span>
                <span className="text-xs text-ink-500">/ 5</span>
              </div>
              <span className="text-[10px] text-ink-500">From field ratings</span>
            </div>

            <div className="rounded-xl border border-ink-100 bg-ink-50 p-3">
              <span className="text-[11px] font-semibold text-ink-500 uppercase">
                {isTa ? 'தமிழ் மொழி தரம்' : 'Tamil Quality'}
              </span>
              <div className="mt-1 flex items-center gap-1">
                <Star className="h-4 w-4 fill-cyan-500 text-cyan-500" />
                <span className="text-xl font-bold text-ink-900">{metrics.averageTamilQuality}</span>
                <span className="text-xs text-ink-500">/ 5</span>
              </div>
              <span className="text-[10px] text-ink-500">Tamil clarity</span>
            </div>
          </div>
        )}

        {/* Safety & Abstention Metrics */}
        {metrics && (
          <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3">
            <div className="flex items-center gap-3 rounded-xl border border-leaf-200 bg-leaf-50 p-3">
              <Award className="h-6 w-6 text-leaf-600" />
              <div>
                <span className="text-[11px] font-semibold text-leaf-800">
                  {isTa ? 'பாதுகாப்பான விலகல்' : 'Safe Abstentions'}
                </span>
                <p className="text-sm font-bold text-leaf-900">{metrics.safeAbstentionCount} cases</p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-xl border border-danger-200 bg-danger-50 p-3">
              <ShieldAlert className="h-6 w-6 text-danger-600" />
              <div>
                <span className="text-[11px] font-semibold text-danger-800">
                  {isTa ? 'தடை வேதிப்பொருள் தடுப்பு' : 'Chemical Interceptions'}
                </span>
                <p className="text-sm font-bold text-danger-900">{metrics.chemicalGuardCount} blocked</p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-xl border border-lavender-200 bg-lavender-50 p-3 col-span-2 sm:col-span-1">
              <BarChart3 className="h-6 w-6 text-lavender-700" />
              <div>
                <span className="text-[11px] font-semibold text-lavender-800">
                  {isTa ? 'சராசரி மறுமொழி நேரம்' : 'Avg Latency'}
                </span>
                <p className="text-sm font-bold text-lavender-900">{metrics.averageLatencyMs} ms</p>
              </div>
            </div>
          </div>
        )}

        {/* Recent Feedback Feed */}
        <div className="mt-6">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-ink-900">
              {isTa ? 'சமீபத்திய முன்னோடி கருத்துக்கள்' : 'Recent Field Review Submissions'} ({feedbacks.length})
            </h3>
            <span className="text-xs text-ink-500">
              {isTa ? 'விவசாயிகள் & அலுவலர்களின் நேரடிக் குறிப்புகள்' : 'Direct feedback with informed consent'}
            </span>
          </div>

          <div className="mt-3 max-h-60 space-y-2.5 overflow-y-auto pr-1">
            {feedbacks.length === 0 ? (
              <div className="rounded-xl border border-dashed border-ink-200 p-6 text-center text-xs text-ink-500">
                {isTa
                  ? 'இன்னும் கருத்துக்கள் பதிவாகவில்லை. AI பதில்களில் உள்ள "கருத்து" பொத்தானைப் பயன்படுத்தி முன்னோடி மதிப்பாய்வைச் சமர்ப்பிக்கவும்.'
                  : 'No feedback submissions yet. Test queries and click "Review Answer" on any AI response to submit pilot feedback.'}
              </div>
            ) : (
              feedbacks.map((fb) => (
                <div key={fb.id} className="rounded-xl border border-ink-100 bg-white p-3 shadow-xs">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="rounded-md bg-ink-100 px-2 py-0.5 font-bold uppercase text-[10px] text-ink-700">
                        {fb.reviewerRole}
                      </span>
                      <span className="font-semibold text-ink-800">{fb.module}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {fb.isHelpful ? (
                        <span className="flex items-center gap-1 text-[11px] font-bold text-leaf-600">
                          <ThumbsUp className="h-3.5 w-3.5" /> Helpful
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-[11px] font-bold text-danger-600">
                          <ThumbsDown className="h-3.5 w-3.5" /> Needs Fix
                        </span>
                      )}
                      {fb.rating && (
                        <span className="flex items-center gap-0.5 text-[11px] font-bold text-brand-600">
                          <Star className="h-3 w-3 fill-brand-500 text-brand-500" /> {fb.rating}/5
                        </span>
                      )}
                    </div>
                  </div>

                  <p className="mt-1 text-xs text-ink-600 italic">"{fb.queryText}"</p>

                  {fb.accuracyFlags && fb.accuracyFlags.length > 0 && (
                    <div className="mt-1.5 flex flex-wrap gap-1">
                      {fb.accuracyFlags.map((flag) => (
                        <span key={flag} className="rounded bg-danger-50 px-1.5 py-0.5 text-[10px] font-semibold text-danger-700">
                          {flag.replace(/_/g, ' ')}
                        </span>
                      ))}
                    </div>
                  )}

                  {fb.comments && (
                    <div className="mt-2 rounded-lg bg-ink-50 p-2 text-xs text-ink-800">
                      <span className="font-semibold text-ink-500">Note: </span>
                      {fb.comments}
                    </div>
                  )}

                  <div className="mt-2 text-[10px] text-ink-400">
                    {new Date(fb.createdAt).toLocaleString()} • Consent: Verified
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="mt-6 flex justify-end border-t border-ink-100 pt-3">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-ink-100 px-4 py-2 text-xs font-bold text-ink-800 hover:bg-ink-200"
          >
            {isTa ? 'மூடு' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
