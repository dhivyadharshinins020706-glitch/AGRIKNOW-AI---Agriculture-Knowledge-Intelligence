import { useEffect, useState, type ReactNode } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Sidebar } from '@/components/layout/Sidebar';
import { MobileNav } from '@/components/layout/MobileNav';
import { TopBar } from '@/components/layout/TopBar';
import { useRoute } from '@/lib/router';
import { ConsentBanner } from '@/components/legal/ConsentBanner';
import { LegalModal } from '@/components/legal/LegalModal';
import { SystemHealthModal } from '@/components/legal/SystemHealthModal';
import { PilotReviewModal } from '@/components/pilot/PilotReviewModal';
import { PricingPlanModal } from '@/components/pricing/PricingPlanModal';

export function AppShell({ children }: { children: ReactNode }) {
  const { path } = useRoute();
  const [legalOpen, setLegalOpen] = useState(false);
  const [healthOpen, setHealthOpen] = useState(false);
  const [pilotReviewOpen, setPilotReviewOpen] = useState(false);
  const [pricingOpen, setPricingOpen] = useState(false);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' });
  }, [path]);

  return (
    <div className="min-h-screen bg-ink-50">
      <Sidebar />
      <div className="lg:pl-64">
        <TopBar
          onOpenHealth={() => setHealthOpen(true)}
          onOpenLegal={() => setLegalOpen(true)}
          onOpenPilotReview={() => setPilotReviewOpen(true)}
          onOpenPricing={() => setPricingOpen(true)}
        />
        <AnimatePresence mode="wait" initial={false}>
          <motion.main
            key={path}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
            className="mx-auto w-full max-w-7xl px-4 pb-32 pt-6 sm:px-6 sm:pt-8 lg:px-10 lg:pb-16 lg:pt-10"
          >
            {children}
          </motion.main>
        </AnimatePresence>
      </div>
      <MobileNav />

      {/* Production Privacy & Informed Consent Banner */}
      <ConsentBanner onOpenLegal={() => setLegalOpen(true)} />

      {/* Production Legal & Advice Disclaimer Modal */}
      {legalOpen && <LegalModal onClose={() => setLegalOpen(false)} />}

      {/* Real-Time System Health & Diagnostic Telemetry Probe */}
      {healthOpen && <SystemHealthModal onClose={() => setHealthOpen(false)} />}

      {/* Phase 7 Pilot Review & Quality Metrics Portal */}
      {pilotReviewOpen && <PilotReviewModal isOpen={pilotReviewOpen} onClose={() => setPilotReviewOpen(false)} />}

      {/* Phase 10 Institutional Pricing & Ethical Packaging Modal */}
      <PricingPlanModal isOpen={pricingOpen} onClose={() => setPricingOpen(false)} />
    </div>
  );
}
