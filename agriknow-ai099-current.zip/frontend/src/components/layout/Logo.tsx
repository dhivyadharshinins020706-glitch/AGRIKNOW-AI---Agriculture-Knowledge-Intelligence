import { Sprout } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export function Logo() {
  const { t } = useLanguage();
  return (
    <a href="#/" className="group flex items-center gap-3" aria-label="AGRIKNOW AI home">
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-leaf-300 via-leaf-400 to-aqua-300 shadow-[0_8px_20px_-8px_rgba(83,181,79,0.9)] transition-transform duration-300 group-hover:-rotate-6">
        <Sprout className="h-5 w-5 text-ink-900" strokeWidth={2.4} aria-hidden />
      </span>
      <span className="min-w-0 leading-none">
        <span className="block text-[15px] font-bold tracking-tight text-ink-900">
          AGRIKNOW <span className="text-leaf-700">AI</span>
        </span>
        <span className="mt-1 block truncate text-[11px] text-ink-500">{t('brand.tagline')}</span>
      </span>
    </a>
  );
}
