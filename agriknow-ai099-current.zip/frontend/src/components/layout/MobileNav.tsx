import { useState } from 'react';
import { motion } from 'framer-motion';
import { Ellipsis } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRoute } from '@/lib/router';
import { mobileMoreNav, mobilePrimaryNav } from '@/config/navigation';
import { Sheet } from '@/components/ui/Sheet';

export function MobileNav() {
  const { t } = useLanguage();
  const { path } = useRoute();
  const [moreOpen, setMoreOpen] = useState(false);
  const moreActive = mobileMoreNav.some((item) => item.path === path);

  return (
    <>
      <nav
        aria-label="Main"
        className="fixed inset-x-3 bottom-3 z-40 rounded-2xl border border-ink-200/80 bg-white/95 shadow-lift backdrop-blur-xl lg:hidden"
      >
        <ul className="grid grid-cols-5">
          {mobilePrimaryNav.map((item) => {
            const active = path === item.path;
            const Icon = item.icon;
            return (
              <li key={item.path}>
                <a
                  href={`#${item.path}`}
                  aria-current={active ? 'page' : undefined}
                  className={`flex min-h-[60px] flex-col items-center justify-center gap-1 rounded-xl px-1 text-[11px] font-medium transition-colors ${
                    active ? 'text-leaf-800' : 'text-ink-600'
                  }`}
                >
                  <span className={`flex h-8 w-14 items-center justify-center rounded-full transition-colors ${active ? 'bg-leaf-100' : ''}`}>
                    <Icon className="h-5 w-5" aria-hidden />
                  </span>
                  <span className="max-w-full truncate">{t(item.labelKey)}</span>
                </a>
              </li>
            );
          })}
          <li>
            <button
              type="button"
              onClick={() => setMoreOpen(true)}
              aria-haspopup="dialog"
              className={`flex min-h-[60px] w-full flex-col items-center justify-center gap-1 rounded-xl px-1 text-[11px] font-medium transition-colors ${
                moreActive ? 'text-leaf-800' : 'text-ink-600'
              }`}
            >
              <span className={`flex h-8 w-14 items-center justify-center rounded-full ${moreActive ? 'bg-leaf-100' : ''}`}>
                <Ellipsis className="h-5 w-5" aria-hidden />
              </span>
              <span>{t('nav.more')}</span>
            </button>
          </li>
        </ul>
      </nav>

      <Sheet open={moreOpen} onClose={() => setMoreOpen(false)} title={t('nav.menu')}>
        <motion.ul
          initial="hidden"
          animate="show"
          variants={{ show: { transition: { staggerChildren: 0.05 } } }}
          className="grid grid-cols-2 gap-3"
        >
          {mobileMoreNav.map((item) => {
            const Icon = item.icon;
            const active = path === item.path;
            return (
              <motion.li key={item.path} variants={{ hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0 } }}>
                <a
                  href={`#${item.path}`}
                  onClick={() => setMoreOpen(false)}
                  className={`flex min-h-[112px] flex-col justify-between rounded-2xl border p-4 transition active:scale-[0.98] ${
                    active ? 'border-leaf-300 bg-leaf-50' : 'border-ink-200 bg-white hover:border-ink-300'
                  }`}
                >
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-aqua-100 text-aqua-800">
                    <Icon className="h-5 w-5" aria-hidden />
                  </span>
                  <span className="text-base font-medium text-ink-900">{t(item.labelKey)}</span>
                </a>
              </motion.li>
            );
          })}
        </motion.ul>
      </Sheet>
    </>
  );
}
