import { motion } from 'framer-motion';
import { LogIn, LogOut, UserRound } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useRoute } from '@/lib/router';
import { appNav } from '@/config/navigation';
import { Logo } from '@/components/layout/Logo';
import { Card } from '@/components/ui/Card';
import { ProgressRing } from '@/components/ui/ProgressRing';

export function Sidebar() {
  const { t, lang } = useLanguage();
  const { path } = useRoute();
  const { user, openAuthModal, signOut } = useAuth();
  const isTa = lang === 'ta';

  return (
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-ink-200/70 bg-white/90 px-4 py-6 backdrop-blur-xl lg:flex">
      <div className="px-2">
        <Logo />
      </div>

      <nav aria-label="Main" className="mt-8 flex flex-1 flex-col gap-1">
        {appNav.map((item) => {
          const active = path === item.path;
          const Icon = item.icon;
          return (
            <a
              key={item.path}
              href={`#${item.path}`}
              aria-current={active ? 'page' : undefined}
              className={`relative flex items-center gap-3 rounded-xl px-3.5 py-3 text-[15px] font-medium transition-colors duration-200 ${
                active ? 'text-ink-900' : 'text-ink-600 hover:bg-ink-100 hover:text-ink-900'
              }`}
            >
              {active && (
                <motion.span
                  layoutId="sidebar-active"
                  className="absolute inset-0 rounded-xl bg-leaf-100"
                  transition={{ type: 'spring', stiffness: 500, damping: 38 }}
                />
              )}
              {active && <span className="absolute left-0 top-2.5 h-7 w-1 rounded-r-full bg-leaf-500" />}
              <Icon className={`relative h-5 w-5 ${active ? 'text-leaf-700' : ''}`} aria-hidden />
              <span className="relative">{t(item.labelKey)}</span>
            </a>
          );
        })}
      </nav>

      <div className="space-y-3">
        {user ? (
          <div className="flex items-center justify-between rounded-xl bg-ink-50 px-3 py-2 text-xs">
            <div className="flex items-center gap-2 min-w-0">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-ink-900 text-white font-bold">
                <UserRound className="h-3.5 w-3.5" />
              </span>
              <span className="truncate font-semibold text-ink-800">{user.email?.split('@')[0]}</span>
            </div>
            <button
              type="button"
              onClick={() => signOut()}
              title={isTa ? 'வெளியேறு' : 'Sign Out'}
              className="p-1 text-ink-400 hover:text-danger-600 transition"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => openAuthModal('login')}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-leaf-300 bg-leaf-50 py-2.5 text-xs font-bold text-leaf-800 hover:bg-leaf-100 transition"
          >
            <LogIn className="h-3.5 w-3.5" />
            <span>{isTa ? 'கணக்கில் உள்நுழை' : 'Sign In to Cloud'}</span>
          </button>
        )}

        <Card className="p-4">
          <div className="flex items-center gap-3">
            <ProgressRing value={86} size={44} stroke={5} label="86" />
            <div className="min-w-0">
              <p className="text-sm font-bold text-ink-900">
                {lang === 'ta' ? 'பண்ணை நலம்' : 'Farm health'}
              </p>
              <p className="text-xs text-ink-500">
                {lang === 'ta' ? 'பயிர்கள் ஆரோக்கியமாக உள்ளன' : 'Paddy is doing well this week'}
              </p>
            </div>
          </div>
        </Card>
      </div>
    </aside>
  );
}
