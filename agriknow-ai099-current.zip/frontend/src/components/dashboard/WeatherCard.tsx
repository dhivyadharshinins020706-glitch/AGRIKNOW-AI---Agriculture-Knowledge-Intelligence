import { useEffect, useState } from 'react';
import { CloudSun, Droplets, Wind, CloudRain, MapPin, Sparkles } from 'lucide-react';
import { useFarmer } from '@/contexts/FarmerContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { fetchDistrictWeather } from '@/services/weatherService';
import type { AgriWeather } from '@/types';

export function WeatherCard() {
  const { profile } = useFarmer();
  const { lang } = useLanguage();
  const [weatherData, setWeatherData] = useState<AgriWeather | null>(null);

  useEffect(() => {
    let isMounted = true;
    fetchDistrictWeather(profile.district || 'Thanjavur').then((data) => {
      if (isMounted) setWeatherData(data);
    });
    return () => {
      isMounted = false;
    };
  }, [profile.district]);

  if (!weatherData) {
    return (
      <div className="relative overflow-hidden rounded-2xl bg-ink-900 p-6 text-white shadow-lift animate-pulse sm:p-7">
        <div className="h-10 w-48 rounded bg-white/10" />
        <div className="mt-4 h-6 w-32 rounded bg-white/10" />
      </div>
    );
  }

  const stats = [
    { icon: Droplets, label: lang === 'ta' ? 'ஈரப்பதம்' : 'Humidity', value: `${weatherData.humidity}%` },
    { icon: Wind, label: lang === 'ta' ? 'காற்று வேகம்' : 'Wind', value: `${weatherData.windKmh} km/h` },
    { icon: CloudRain, label: lang === 'ta' ? 'மழை வாய்ப்பு' : 'Rain chance', value: `${weatherData.rainChance}%` },
  ];

  return (
    <div className="relative overflow-hidden rounded-2xl bg-ink-900 p-6 text-white shadow-lift sm:p-7">
      <div className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-aqua-400/20 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 left-1/3 h-48 w-48 rounded-full bg-leaf-400/20 blur-3xl" />

      <div className="relative flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/10 text-aqua-300 ring-1 ring-white/10">
            <CloudSun className="h-7 w-7" aria-hidden />
          </span>
          <div>
            <p className="text-4xl font-bold tracking-tight">{weatherData.tempC}°C</p>
            <p className="mt-1 text-sm text-ink-300">
              {lang === 'ta' ? weatherData.conditionTa : weatherData.condition}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 sm:gap-6">
          {stats.map((stat) => (
            <div key={stat.label} className="min-w-0">
              <stat.icon className="h-4 w-4 text-aqua-300" aria-hidden />
              <p className="mt-2 text-lg font-bold">{stat.value}</p>
              <p className="text-xs text-ink-300">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-6 flex flex-col gap-3 border-t border-white/10 pt-4 sm:flex-row sm:items-center sm:justify-between">
        <p className="inline-flex items-center gap-1.5 text-xs text-ink-300">
          <MapPin className="h-3.5 w-3.5 text-aqua-300" aria-hidden />
          {weatherData.location}
        </p>
        <p className="inline-flex items-center gap-1.5 text-xs font-medium text-aqua-200">
          <Sparkles className="h-3.5 w-3.5 text-sun-300" aria-hidden />
          {lang === 'ta' ? weatherData.farmingAdviceTa : weatherData.farmingAdvice}
        </p>
      </div>
    </div>
  );
}
