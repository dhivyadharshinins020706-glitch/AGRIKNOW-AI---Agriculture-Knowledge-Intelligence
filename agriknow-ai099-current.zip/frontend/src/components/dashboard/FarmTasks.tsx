import { useState, type FormEvent } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CalendarClock, CheckCircle2, Circle, Plus, Trash2 } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { useFarmer } from '@/contexts/FarmerContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useToast } from '@/contexts/ToastContext';

export function FarmTasks() {
  const { tasks, toggleTask, addTask, deleteTask } = useFarmer();
  const { t, lang } = useLanguage();
  const { show } = useToast();
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newWhen, setNewWhen] = useState(lang === 'ta' ? 'இன்று' : 'Today');

  const handleToggle = (id: string, currentDone: boolean, title: string) => {
    toggleTask(id).catch(console.error);
    show(currentDone ? 'Task moved to to-do' : 'Task completed', {
      description: title,
      tone: 'success',
    });
  };

  const handleCreate = (e: FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    addTask(newTitle.trim(), newWhen || (lang === 'ta' ? 'இன்று' : 'Today')).catch(console.error);
    setNewTitle('');
    setIsAdding(false);
    show(lang === 'ta' ? 'புதிய பணி சேர்க்கப்பட்டது' : 'New task added', { tone: 'success' });
  };

  const remaining = tasks.filter((task) => !task.done).length;

  return (
    <Card className="flex h-full flex-col p-5 sm:p-6">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-ink-900">{t('dashboard.tasksTitle')}</h2>
          <p className="text-sm text-ink-500">
            {remaining} {t('dashboard.tasksRemaining')}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge tone="info">
            <CalendarClock className="h-3.5 w-3.5" aria-hidden />
            {lang === 'ta' ? 'அட்டவணை' : 'Schedule'}
          </Badge>
          <button
            type="button"
            onClick={() => setIsAdding(!isAdding)}
            className="flex h-8 w-8 items-center justify-center rounded-lg bg-leaf-100 text-leaf-800 transition hover:bg-leaf-200"
            aria-label="Add task"
            title="Add task"
          >
            <Plus className="h-4 w-4" aria-hidden />
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.form
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            onSubmit={handleCreate}
            className="mt-4 space-y-3 overflow-hidden rounded-xl border border-leaf-200 bg-leaf-50/60 p-3"
          >
            <input
              type="text"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder={t('dashboard.taskPlaceholder')}
              className="h-10 w-full rounded-lg border border-ink-200 bg-white px-3 text-sm text-ink-900 focus:border-leaf-500 focus:outline-none"
              autoFocus
            />
            <div className="flex items-center justify-between gap-2">
              <select
                value={newWhen}
                onChange={(e) => setNewWhen(e.target.value)}
                className="h-8 rounded-lg border border-ink-200 bg-white px-2 text-xs text-ink-800"
              >
                <option value={lang === 'ta' ? 'இன்று' : 'Today'}>
                  {lang === 'ta' ? 'இன்று' : 'Today'}
                </option>
                <option value={lang === 'ta' ? 'நாளை' : 'Tomorrow'}>
                  {lang === 'ta' ? 'நாளை' : 'Tomorrow'}
                </option>
                <option value={lang === 'ta' ? 'இந்த வாரம்' : 'This week'}>
                  {lang === 'ta' ? 'இந்த வாரம்' : 'This week'}
                </option>
              </select>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="rounded-lg px-2.5 py-1 text-xs text-ink-600 hover:bg-ink-100"
                >
                  {t('common.cancel')}
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-leaf-400 px-3 py-1 text-xs font-bold text-ink-900 hover:bg-leaf-300"
                >
                  {t('dashboard.addTask')}
                </button>
              </div>
            </div>
          </motion.form>
        )}
      </AnimatePresence>

      <ul className="mt-5 flex-1 space-y-2 max-h-[300px] overflow-y-auto pr-1">
        {tasks.map((task) => (
          <li key={task.id} className="group relative flex items-center justify-between gap-2 rounded-xl border border-transparent px-3 py-2 transition hover:border-ink-200 hover:bg-ink-50">
            <button
              type="button"
              onClick={() => handleToggle(task.id, task.done, task.title)}
              aria-pressed={task.done}
              className="flex min-h-[44px] flex-1 items-center gap-3 text-left"
            >
              <span className="shrink-0">
                {task.done ? (
                  <CheckCircle2 className="h-5 w-5 text-leaf-500" aria-hidden />
                ) : (
                  <Circle className="h-5 w-5 text-ink-300 group-hover:text-leaf-500" aria-hidden />
                )}
              </span>
              <span className="min-w-0 flex-1">
                <span className={`block text-sm ${task.done ? 'text-ink-400 line-through' : 'text-ink-900 font-medium'}`}>
                  {task.title}
                </span>
                <span className="text-xs text-ink-500">{task.when}</span>
              </span>
            </button>
            <button
              type="button"
              onClick={() => deleteTask(task.id)}
              aria-label="Delete task"
              className="opacity-0 transition group-hover:opacity-100 p-1 text-ink-400 hover:text-danger-500"
            >
              <Trash2 className="h-4 w-4" aria-hidden />
            </button>
          </li>
        ))}
      </ul>
    </Card>
  );
}
