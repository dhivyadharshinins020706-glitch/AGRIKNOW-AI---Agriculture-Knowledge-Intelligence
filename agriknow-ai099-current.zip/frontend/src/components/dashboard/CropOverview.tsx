import { ArrowUpRight } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { ProgressRing } from '@/components/ui/ProgressRing';
import { Badge } from '@/components/ui/Badge';
import { cropStatuses, type CropStatus } from '@/data/farm';
import { useFarmer } from '@/contexts/FarmerContext';
import { useLanguage } from '@/contexts/LanguageContext';

function healthTone(health: number): string {
  if (health >= 80) return 'stroke-leaf-400';
  if (health >= 70) return 'stroke-sun-400';
  return 'stroke-danger-500';
}

function CropCard({ crop, isFarmerCrop }: { crop: CropStatus; isFarmerCrop: boolean }) {
  const { lang } = useLanguage();

  return (
    <Card hover className="flex flex-col p-5 sm:p-6">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <Badge tone="success">{crop.stage}</Badge>
            {isFarmerCrop && (
              <Badge tone="info">{lang === 'ta' ? 'என் பயிர்' : 'Active'}</Badge>
            )}
          </div>
          <h3 className="mt-3 truncate text-lg font-bold text-ink-900">
            {lang === 'ta' && crop.nameTa ? crop.nameTa : crop.name}
          </h3>
          <p className="text-sm text-ink-500">{crop.areaAcres} acres</p>
        </div>
        <ProgressRing value={crop.health} size={60} stroke={6} colorClass={healthTone(crop.health)} />
      </div>

      <div className="mt-6">
        <div className="mb-2 flex items-center justify-between text-sm">
          <span className="text-ink-600">{lang === 'ta' ? 'வளர்ச்சி நிலை' : 'Growth'}</span>
          <span className="font-bold text-ink-900">{crop.progress}%</span>
        </div>
        <div className="h-2.5 overflow-hidden rounded-full bg-ink-100">
          <div
            className="h-full origin-left rounded-full bg-gradient-to-r from-leaf-400 to-aqua-300 transition-[width] duration-1000"
            style={{ width: `${crop.progress}%` }}
          />
        </div>
      </div>

      <div className="mt-5 flex items-center justify-between border-t border-ink-100 pt-4 text-sm">
        <span className="text-ink-600">
          {lang === 'ta' ? 'அறுவடைக்கு இன்னும்' : 'Harvest in'}{' '}
          <span className="font-bold text-ink-900">{crop.daysToHarvest} {lang === 'ta' ? 'நாட்கள்' : 'days'}</span>
        </span>
        <a href="#/diseases" className="inline-flex items-center gap-1 font-medium text-leaf-700 hover:text-leaf-800">
          {lang === 'ta' ? 'நலம் பார்' : 'Check health'}
          <ArrowUpRight className="h-4 w-4" aria-hidden />
        </a>
      </div>
    </Card>
  );
}

export function CropOverview() {
  const { profile } = useFarmer();

  return (
    <div className="grid gap-4 md:grid-cols-3">
      {cropStatuses.map((crop) => (
        <CropCard
          key={crop.id}
          crop={crop}
          isFarmerCrop={profile.cropIds.includes(crop.id)}
        />
      ))}
    </div>
  );
}
