import { useState, type PointerEvent } from 'react';
import { motion } from 'framer-motion';

interface AreaChartProps {
  labels: string[];
  values: number[];
  color: string;
  unit: string;
  height?: number;
}

const VIEW_W = 640;

export function AreaChart({ labels, values, color, unit, height = 220 }: AreaChartProps) {
  const [hover, setHover] = useState<number | null>(null);
  const padX = 16;
  const padTop = 16;
  const padBottom = 12;
  const max = Math.max(...values) * 1.15;
  const min = 0;
  const innerH = height - padTop - padBottom;
  const innerW = VIEW_W - padX * 2;

  const points = values.map((value, index) => ({
    x: padX + (index * innerW) / (values.length - 1),
    y: padTop + innerH - ((value - min) / (max - min)) * innerH,
  }));

  const line = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
  const area = `${line} L${points[points.length - 1].x.toFixed(1)},${height - padBottom} L${points[0].x.toFixed(1)},${height - padBottom} Z`;

  const handlePointer = (event: PointerEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const ratio = (event.clientX - rect.left) / rect.width;
    setHover(Math.min(values.length - 1, Math.max(0, Math.round(ratio * (values.length - 1)))));
  };

  const active = hover !== null ? points[hover] : null;

  return (
    <div className="relative select-none" onPointerMove={handlePointer} onPointerLeave={() => setHover(null)} onPointerDown={handlePointer}>
      <svg viewBox={`0 0 ${VIEW_W} ${height}`} className="w-full" role="img" aria-label={`Trend chart in ${unit}`}>
        <defs>
          <linearGradient id={`area-${color.replace('#', '')}`} x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.28" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0.25, 0.5, 0.75].map((ratio) => (
          <line
            key={ratio}
            x1={padX}
            x2={VIEW_W - padX}
            y1={padTop + innerH * ratio}
            y2={padTop + innerH * ratio}
            stroke="#EEF0EC"
            strokeWidth="1"
          />
        ))}
        <motion.path
          d={area}
          fill={`url(#area-${color.replace('#', '')})`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        />
        <motion.path
          d={line}
          fill="none"
          stroke={color}
          strokeWidth="3"
          strokeLinejoin="round"
          strokeLinecap="round"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 1.2, ease: 'easeOut' }}
        />
        {active && (
          <g>
            <line x1={active.x} x2={active.x} y1={padTop} y2={height - padBottom} stroke={color} strokeDasharray="4 4" strokeOpacity="0.6" />
            <circle cx={active.x} cy={active.y} r="6" fill="#fff" stroke={color} strokeWidth="3" />
          </g>
        )}
      </svg>
      {active && hover !== null && (
        <div
          className="pointer-events-none absolute top-0 -translate-x-1/2 rounded-lg bg-ink-900 px-3 py-2 text-xs text-white shadow-lift"
          style={{ left: `${(active.x / VIEW_W) * 100}%` }}
        >
          <span className="block text-ink-300">{labels[hover]}</span>
          <span className="font-bold">
            {values[hover]} {unit}
          </span>
        </div>
      )}
      <div className="mt-2 flex justify-between text-xs text-ink-500">
        {labels.map((label, index) => (
          <span key={label} className={index === hover ? 'font-bold text-ink-900' : ''}>
            {index % 2 === 0 || labels.length <= 8 ? label : ''}
          </span>
        ))}
      </div>
    </div>
  );
}
