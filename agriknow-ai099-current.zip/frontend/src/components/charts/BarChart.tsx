import { useState } from 'react';
import { motion } from 'framer-motion';

interface BarSeries {
  name: string;
  color: string;
}

interface BarDatum {
  label: string;
  values: number[];
}

interface BarChartProps {
  data: BarDatum[];
  series: BarSeries[];
  formatValue: (value: number) => string;
  highlightIndex?: number;
}

export function BarChart({ data, series, formatValue, highlightIndex }: BarChartProps) {
  const [hover, setHover] = useState<{ row: number; series: number } | null>(null);
  const max = Math.max(...data.flatMap((row) => row.values)) * 1.1;

  return (
    <div>
      <div className="flex flex-col gap-5">
        {data.map((row, rowIndex) => (
          <div key={row.label} className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className={`font-medium ${highlightIndex === rowIndex ? 'text-ink-900' : 'text-ink-700'}`}>{row.label}</span>
            </div>
            <div className="space-y-1.5">
              {row.values.map((value, seriesIndex) => {
                const isHovered = hover?.row === rowIndex && hover.series === seriesIndex;
                return (
                  <div
                    key={series[seriesIndex].name}
                    className="group flex items-center gap-3"
                    onPointerEnter={() => setHover({ row: rowIndex, series: seriesIndex })}
                    onPointerLeave={() => setHover(null)}
                  >
                    <div className="relative h-3 flex-1 overflow-hidden rounded-full bg-ink-100">
                      <motion.div
                        className="absolute inset-y-0 left-0 rounded-full"
                        style={{ backgroundColor: series[seriesIndex].color }}
                        initial={{ width: 0 }}
                        animate={{ width: `${(value / max) * 100}%`, opacity: hover && !isHovered ? 0.45 : 1 }}
                        transition={{ duration: 0.9, ease: 'easeOut', delay: rowIndex * 0.08 }}
                      />
                    </div>
                    <span className={`w-24 shrink-0 text-right text-sm tabular-nums ${isHovered ? 'font-bold text-ink-900' : 'text-ink-600'}`}>
                      {formatValue(value)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
      <div className="mt-5 flex flex-wrap gap-4 text-xs text-ink-600">
        {series.map((item) => (
          <span key={item.name} className="inline-flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: item.color }} />
            {item.name}
          </span>
        ))}
      </div>
    </div>
  );
}
