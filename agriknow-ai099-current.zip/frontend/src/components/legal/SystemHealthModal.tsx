/**
 * AGRIKNOW AI - Production System Health & Diagnostics Modal
 * Inspects database connectivity, verified corpus status, RAG latency, and offline fallbacks.
 */

import { useState, useEffect } from 'react';
import { X, Activity, RefreshCw, CheckCircle2, AlertTriangle, XCircle, Database, Server, Volume2, HardDrive } from 'lucide-react';
import { runComprehensiveHealthCheck, type SystemHealthReport } from '@/services/healthCheckService';
import { useLanguage } from '@/contexts/LanguageContext';

interface SystemHealthModalProps {
  onClose: () => void;
}

export function SystemHealthModal({ onClose }: SystemHealthModalProps) {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';

  const [report, setReport] = useState<SystemHealthReport | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshProbe = async () => {
    setLoading(true);
    const result = await runComprehensiveHealthCheck();
    setReport(result);
    setLoading(false);
  };

  useEffect(() => {
    refreshProbe();
  }, []);

  const getServiceIcon = (name: string) => {
    if (name.includes('Database')) return <Database className="h-4 w-4" />;
    if (name.includes('Knowledge') || name.includes('RAG')) return <Server className="h-4 w-4" />;
    if (name.includes('Speech')) return <Volume2 className="h-4 w-4" />;
    return <HardDrive className="h-4 w-4" />;
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="health-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/60 p-4 backdrop-blur-sm"
    >
      <div className="relative flex max-h-[85vh] w-full max-w-2xl flex-col rounded-3xl border border-ink-200 bg-white shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-ink-100 bg-ink-50/70 px-6 py-4">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-aqua-100 text-aqua-800">
              <Activity className="h-5 w-5" />
            </span>
            <div>
              <h2 id="health-modal-title" className="text-base font-bold text-ink-900">
                {isTa ? 'கணினி செயல்பாட்டு நிலை & நம்பகத்தன்மை' : 'System Health & Production Reliability'}
              </h2>
              <p className="text-xs text-ink-500">
                {isTa ? 'நேரடி சேவைகள் மற்றும் தரவுத்தள சோதனை' : 'Live telemetry probes for database, RAG engine, and client storage'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl p-2 text-ink-500 transition hover:bg-ink-100"
            aria-label="Close dialog"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Status Badge Card */}
          <div className="flex items-center justify-between rounded-2xl border border-ink-200 bg-ink-50 p-4">
            <div className="flex items-center gap-2.5">
              {loading ? (
                <RefreshCw className="h-5 w-5 text-ink-400 animate-spin" />
              ) : report?.overallStatus === 'healthy' ? (
                <CheckCircle2 className="h-5 w-5 text-leaf-600" />
              ) : report?.overallStatus === 'degraded' ? (
                <AlertTriangle className="h-5 w-5 text-amber-600" />
              ) : (
                <XCircle className="h-5 w-5 text-danger-600" />
              )}
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-ink-500">
                  {isTa ? 'ஒட்டுமொத்த அமைப்பு நிலை:' : 'Overall System Status:'}
                </span>
                <p className="font-bold text-sm text-ink-900 capitalize">
                  {loading
                    ? isTa ? 'சோதிக்கப்படுகிறது...' : 'Probing services...'
                    : report?.overallStatus === 'healthy'
                    ? isTa ? 'முழுமையான ஆரோக்கியம் (Healthy)' : 'Healthy & Production Ready'
                    : report?.overallStatus === 'degraded'
                    ? isTa ? 'சீராக இயங்குகிறது (Degraded/Offline Mode)' : 'Operating in Resilient Offline Mode'
                    : isTa ? 'பழுது (Critical)' : 'Critical Action Required'}
                </p>
              </div>
            </div>

            <button
              type="button"
              disabled={loading}
              onClick={refreshProbe}
              className="inline-flex items-center gap-1.5 rounded-xl border border-ink-200 bg-white px-3 py-1.5 text-xs font-semibold text-ink-700 shadow-sm transition hover:bg-ink-100 active:scale-95 disabled:opacity-50"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>{isTa ? 'மீண்டும் சோதி' : 'Re-test'}</span>
            </button>
          </div>

          {/* Individual Service Probes */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-ink-600">
              {isTa ? 'சேவை வாரியான ஆய்வு முடிவுகள்:' : 'Individual Service Probes:'}
            </h3>

            {report?.services.map((item) => (
              <div
                key={item.service}
                className="flex items-start justify-between rounded-xl border border-ink-200 bg-white p-3.5 shadow-sm transition"
              >
                <div className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-ink-100 text-ink-700">
                    {getServiceIcon(item.service)}
                  </span>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-ink-900 text-xs sm:text-sm">{item.service}</span>
                      <span
                        className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                          item.status === 'healthy'
                            ? 'bg-leaf-100 text-leaf-800'
                            : item.status === 'degraded'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-danger-100 text-danger-800'
                        }`}
                      >
                        {item.status.toUpperCase()}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-ink-600 leading-relaxed">
                      {isTa ? item.detailsTa : item.details}
                    </p>
                  </div>
                </div>

                <span className="text-[11px] font-mono font-semibold text-ink-500 shrink-0 ml-2">
                  {item.latencyMs} ms
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-ink-100 bg-ink-50/70 px-6 py-3 text-xs text-ink-500">
          <span>Last tested: {report?.timestamp ? new Date(report.timestamp).toLocaleTimeString() : '-'}</span>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-ink-200 px-4 py-2 font-semibold text-ink-800 hover:bg-ink-300 transition"
          >
            {isTa ? 'மூடு' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
}
