/**
 * AGRIKNOW AI - Farmer Consent & Regulatory Banner
 * Ensures compliance with Digital Personal Data Protection (DPDP) and Agricultural Advisory Standards.
 */

import { useState, useEffect } from 'react';
import { ShieldCheck, Info } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const CONSENT_STORAGE_KEY = 'agriknow_farmer_consent_v1';

interface ConsentBannerProps {
  onOpenLegal: () => void;
}

export function ConsentBanner({ onOpenLegal }: ConsentBannerProps) {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';
  const [hasConsented, setHasConsented] = useState(true);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(CONSENT_STORAGE_KEY);
      if (!saved) {
        setHasConsented(false);
      }
    } catch {
      setHasConsented(true);
    }
  }, []);

  const handleAccept = () => {
    try {
      localStorage.setItem(CONSENT_STORAGE_KEY, JSON.stringify({ agreed: true, timestamp: new Date().toISOString() }));
    } catch {
      // Ignore
    }
    setHasConsented(true);
  };

  if (hasConsented) return null;

  return (
    <div
      role="region"
      aria-label="Agricultural Advisory and Consent Notice"
      className="fixed bottom-0 left-0 right-0 z-50 border-t-2 border-leaf-400 bg-white/95 p-4 shadow-2xl backdrop-blur-md sm:px-6"
    >
      <div className="mx-auto flex max-w-6xl flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-3">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-leaf-100 text-leaf-800">
            <ShieldCheck className="h-5 w-5" aria-hidden />
          </span>
          <div className="text-xs text-ink-700 leading-relaxed">
            <strong className="block font-bold text-ink-900 text-sm">
              {isTa ? 'வேளாண் ஆலோசனை மற்றும் தகவல் பாதுகாப்பு அறிவிப்பு' : 'Agricultural Advisory Notice & Privacy Protocol'}
            </strong>
            <p className="mt-0.5">
              {isTa
                ? 'AGRIKNOW AI ஆலோசனைகள் TNAU மற்றும் ICAR ஆராய்ச்சி நூல்களின் அடிப்படையில் வழங்கப்படுகின்றன. இது கல்வி மற்றும் வழிகாட்டுதல் பயன்பாட்டிற்கானது மட்டுமே; பூச்சிக்கொல்லி பயன்பாட்டிற்கு முன் வட்டார வேளாண் அலுவலரிடம் (AAO) உறுதி செய்யவும்.'
                : 'AGRIKNOW AI provides intelligence synthesized from verified TNAU & ICAR publications. Recommendations are informational and must be verified with your local Assistant Agricultural Officer (AAO) before chemical application.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 shrink-0 self-end sm:self-center">
          <button
            type="button"
            onClick={onOpenLegal}
            className="inline-flex items-center gap-1 rounded-xl border border-ink-200 bg-white px-3 py-2 text-xs font-semibold text-ink-700 transition hover:bg-ink-100"
          >
            <Info className="h-3.5 w-3.5 text-lilac-700" />
            {isTa ? 'விதிமுறைகளைக் காண்க' : 'Legal & Advice Policy'}
          </button>
          <button
            type="button"
            onClick={handleAccept}
            className="rounded-xl bg-leaf-400 px-4 py-2 text-xs font-bold text-ink-900 shadow-sm transition hover:bg-leaf-300 active:scale-95"
          >
            {isTa ? 'ஏற்றுக்கொள்கிறேன்' : 'I Understand & Accept'}
          </button>
        </div>
      </div>
    </div>
  );
}
