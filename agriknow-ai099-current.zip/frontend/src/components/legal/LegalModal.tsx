/**
 * AGRIKNOW AI - Legal, Privacy & Agricultural Advice Disclaimer Modal
 */

import { useState } from 'react';
import { X, ShieldAlert, FileText, Lock, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

interface LegalModalProps {
  onClose: () => void;
  initialTab?: 'disclaimer' | 'privacy' | 'terms';
}

export function LegalModal({ onClose, initialTab = 'disclaimer' }: LegalModalProps) {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';
  const [tab, setTab] = useState<'disclaimer' | 'privacy' | 'terms'>(initialTab);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="legal-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/60 p-4 backdrop-blur-sm"
    >
      <div className="relative flex max-h-[85vh] w-full max-w-3xl flex-col rounded-3xl border border-ink-200 bg-white shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-ink-100 bg-ink-50/70 px-6 py-4">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-leaf-100 text-leaf-800">
              <ShieldAlert className="h-5 w-5" />
            </span>
            <div>
              <h2 id="legal-modal-title" className="text-base font-bold text-ink-900">
                {isTa ? 'சட்டம், தனியுரிமை & விவசாய ஆலோசனைக் கொள்கை' : 'Legal, Privacy & Agricultural Advisory Terms'}
              </h2>
              <p className="text-xs text-ink-500">
                {isTa ? 'AGRIKNOW AI சட்டப்பூர்வ நிபந்தனைகள் மற்றும் மறுப்புரை' : 'Compliance with Indian Insecticides Act 1968 & DPDP Act'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl p-2 text-ink-500 transition hover:bg-ink-100"
            aria-label="Close dialog"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-ink-100 bg-white px-6 pt-2">
          <button
            type="button"
            onClick={() => setTab('disclaimer')}
            className={`border-b-2 px-4 py-2.5 text-xs font-bold transition ${
              tab === 'disclaimer'
                ? 'border-leaf-500 text-leaf-900'
                : 'border-transparent text-ink-500 hover:text-ink-800'
            }`}
          >
            {isTa ? 'வேளாண் மறுப்புரை (Disclaimer)' : 'Agricultural Advice Disclaimer'}
          </button>
          <button
            type="button"
            onClick={() => setTab('privacy')}
            className={`border-b-2 px-4 py-2.5 text-xs font-bold transition ${
              tab === 'privacy'
                ? 'border-leaf-500 text-leaf-900'
                : 'border-transparent text-ink-500 hover:text-ink-800'
            }`}
          >
            {isTa ? 'தனியுரிமைக் கொள்கை (Privacy)' : 'Privacy Policy'}
          </button>
          <button
            type="button"
            onClick={() => setTab('terms')}
            className={`border-b-2 px-4 py-2.5 text-xs font-bold transition ${
              tab === 'terms'
                ? 'border-leaf-500 text-leaf-900'
                : 'border-transparent text-ink-500 hover:text-ink-800'
            }`}
          >
            {isTa ? 'பயன்பாட்டு விதிகள் (Terms)' : 'Terms of Service'}
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 text-xs text-ink-700 leading-relaxed">
          {tab === 'disclaimer' && (
            <div className="space-y-4">
              <div className="rounded-xl border border-amber-300 bg-amber-50/80 p-4">
                <h3 className="font-bold text-amber-950 text-sm">
                  {isTa ? 'முக்கிய விவசாய ஆலோசனைக் கொள்கை:' : 'Crucial Agricultural Advice Disclaimer:'}
                </h3>
                <p className="mt-1 text-amber-900">
                  {isTa
                    ? 'AGRIKNOW AI ஒரு கணினி சார்ந்த அறிவு உதவி தளமாகும். இதன் மூலம் வழங்கப்படும் பரிந்துரைகள் தமிழ்நாடு வேளாண்மைப் பல்கலைக்கழகம் (TNAU) மற்றும் இந்திய வேளாண் ஆராய்ச்சி குழுமம் (ICAR) வெளியீடுகளை அடிப்படையாகக் கொண்டவை. இது உங்கள் வட்டார வேளாண் விரிவாக்க அலுவலர் (AAO) அல்லது வேளாண் அறிவியல் மைய (KVK) விஞ்ஞானிகளின் நேரடி களப் பரிசோதனைக்கு சட்டப்பூர்வ மாற்றாகாது.'
                    : 'AGRIKNOW AI is an AI-assisted decision support system. Intelligence is synthesized strictly from public educational publications of TNAU, ICAR, and State Departments of Agriculture. It is NOT a substitute for on-site physical inspection by certified agronomists, Assistant Agricultural Officers (AAO), or Krishi Vigyan Kendra (KVK) scientists.'}
                </p>
              </div>

              <div>
                <h4 className="font-bold text-ink-900 text-sm">1. Chemical Dosing & Pest Control Safety</h4>
                <p className="mt-1">
                  Chemical pesticide dosages vary with crop age, soil moisture, rainfall forecast, and economic threshold levels (ETL). Never apply any chemical without reading the container product label. Always adhere to mandatory personal protective equipment (gloves, face mask, eye protection) and safe harvesting waiting periods (pre-harvest intervals).
                </p>
              </div>

              <div>
                <h4 className="font-bold text-ink-900 text-sm">2. Banned & Restricted Agrochemicals</h4>
                <p className="mt-1">
                  In compliance with the Indian Insecticides Act 1968 and Supreme Court rulings, AGRIKNOW AI strictly prohibits recommending banned chemicals such as Monocrotophos on vegetables, Endosulfan, Phorate 10G, or Methyl Parathion. Farmers must use approved bio-pesticides or integrated pest management (IPM) techniques.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-ink-900 text-sm">3. Limitation of Liability</h4>
                <p className="mt-1">
                  AGRIKNOW AI, its developers, and affiliated contributors assume no liability for crop losses, economic damages, or physical injuries arising from weather extremes, unverified application rates, or incorrect localized symptom interpretation.
                </p>
              </div>
            </div>
          )}

          {tab === 'privacy' && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 rounded-xl bg-leaf-50 p-3 text-leaf-900 font-semibold">
                <Lock className="h-4 w-4 text-leaf-700 shrink-0" />
                <span>{isTa ? 'விவசாயிகளின் தகவல் முழுமையாகப் பாதுகாக்கப்படுகிறது' : 'Farmer Data Privacy & DPDP Compliance'}</span>
              </div>

              <div>
                <h4 className="font-bold text-ink-900 text-sm">1. Data Minimization</h4>
                <p className="mt-1">
                  We collect only the minimum farm parameters necessary to calculate stage-wise fertilizer plans and disease diagnoses (such as soil pH, nutrient measurements, crop choice, and village district).
                </p>
              </div>

              <div>
                <h4 className="font-bold text-ink-900 text-sm">2. No Commercial Sharing or Sale</h4>
                <p className="mt-1">
                  Your farm data, soil health measurements, and chat logs are NEVER sold, rented, or shared with commercial chemical dealers or advertising networks.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-ink-900 text-sm">3. Right to Erasure & Portability</h4>
                <p className="mt-1">
                  You have the full right to export your complete farm record (JSON format) and permanently purge all stored chats, soil health cards, and user credentials from our systems at any time via your Profile Settings.
                </p>
              </div>
            </div>
          )}

          {tab === 'terms' && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 rounded-xl bg-lilac-50 p-3 text-lilac-950 font-semibold">
                <FileText className="h-4 w-4 text-lilac-700 shrink-0" />
                <span>Fair Scientific Reuse & Open Knowledge Attribution</span>
              </div>

              <div>
                <h4 className="font-bold text-ink-900 text-sm">1. Knowledge Sources & Intellectual Property</h4>
                <p className="mt-1">
                  Agricultural advisories and training documents are indexed from open public publications of Tamil Nadu Agricultural University (TNAU), the Indian Council of Agricultural Research (ICAR), and the Ministry of Agriculture & Farmers Welfare under fair educational use. All original copyrights and publication metadata are faithfully preserved and attributed.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-ink-900 text-sm">2. Non-Commercial Farmer Support</h4>
                <p className="mt-1">
                  AGRIKNOW AI is built as a public service intelligence layer to empower Indian smallholder and marginal farmers with verified science.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-ink-100 bg-ink-50/70 px-6 py-3">
          <span className="text-[11px] text-ink-500">
            AGRIKNOW AI v1.0.0 Production Engineering Release
          </span>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-leaf-400 px-4 py-2 text-xs font-bold text-ink-900 shadow-sm transition hover:bg-leaf-300 active:scale-95 flex items-center gap-1.5"
          >
            <CheckCircle2 className="h-4 w-4" />
            <span>{isTa ? 'புரிந்துகொண்டேன்' : 'Close & Return'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
