import { useState } from 'react';
import { Search, ExternalLink, Phone, CheckCircle2, FileText, Landmark } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { useLanguage } from '@/contexts/LanguageContext';
import { searchGovernmentSchemes } from '@/services/schemesService';
import type { GovernmentScheme } from '@/data/governmentSchemes';

export function GovernmentSchemesView() {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<
    'all' | 'direct_benefit' | 'insurance' | 'subsidy' | 'credit' | 'soil_health'
  >('all');

  const categories = [
    { id: 'all', label: isTa ? 'அனைத்து திட்டங்கள்' : 'All Schemes' },
    { id: 'direct_benefit', label: isTa ? 'நேரடி மானியம் (PM-KISAN)' : 'Direct Income' },
    { id: 'insurance', label: isTa ? 'பயிர் காப்பீடு (PMFBY)' : 'Crop Insurance' },
    { id: 'subsidy', label: isTa ? 'சொட்டு நீர் & இடுபொருட்கள்' : 'Subsidies' },
    { id: 'credit', label: isTa ? 'பயிர்க்கடன் (KCC)' : 'Concessional Credit' },
    { id: 'soil_health', label: isTa ? 'மண் வள அட்டை' : 'Soil Health' },
  ] as const;

  const schemes = searchGovernmentSchemes({
    category: selectedCategory,
    searchQuery,
  });

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              isTa
                ? 'அரசு திட்டங்கள், மானியங்கள், உதவித் தொகையைத் தேடுங்கள்...'
                : 'Search PM-KISAN, crop insurance, drip subsidies, KCC loans...'
            }
            className="w-full rounded-xl border border-ink-200 bg-white py-2.5 pl-10 pr-4 text-sm text-ink-900 placeholder:text-ink-400 focus:border-leaf-500 focus:outline-none focus:ring-4 focus:ring-leaf-200"
          />
        </div>

        <div className="flex flex-wrap gap-1.5">
          {categories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setSelectedCategory(cat.id)}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                selectedCategory === cat.id
                  ? 'bg-leaf-600 text-white shadow-sm'
                  : 'border border-ink-200 bg-white text-ink-700 hover:bg-ink-50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Schemes Grid */}
      <div className="grid gap-5 md:grid-cols-2">
        {schemes.map((scheme: GovernmentScheme) => (
          <Card
            key={scheme.id}
            className="flex flex-col justify-between border-leaf-200/80 bg-white p-5 shadow-sm hover:border-leaf-400 transition"
          >
            <div className="space-y-4">
              {/* Header Badges */}
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="rounded-md bg-clay-100 px-2 py-0.5 text-[11px] font-bold text-clay-800">
                      {scheme.code}
                    </span>
                    <Badge tone="neutral">
                      {scheme.sponsor === 'Central'
                        ? isTa
                          ? 'மத்திய அரசு'
                          : 'Central Govt'
                        : scheme.sponsor === 'State'
                        ? isTa
                          ? 'மாநில அரசு'
                          : 'State Govt'
                        : isTa
                        ? 'கூட்டு நிதி'
                        : 'Centre-State Shared'}
                    </Badge>
                  </div>
                  <h3 className="mt-2 text-base font-bold text-ink-900">
                    {isTa ? scheme.nameTa : scheme.name}
                  </h3>
                </div>
                <div className="rounded-xl bg-leaf-50 p-2.5 text-leaf-700">
                  <Landmark className="h-5 w-5" />
                </div>
              </div>

              {/* Financial Benefit highlight */}
              <div className="rounded-xl border border-leaf-200 bg-leaf-50/60 p-3">
                <p className="text-xs font-semibold text-leaf-900">
                  💰 {isTa ? 'நிதி உதவி / மானியம்:' : 'Financial Assistance / Subsidy:'}
                </p>
                <p className="mt-1 text-xs text-leaf-950 leading-relaxed font-medium">
                  {isTa ? scheme.financialBenefitTa : scheme.financialBenefit}
                </p>
              </div>

              {/* Eligibility Checklist */}
              <div>
                <p className="text-xs font-bold text-ink-800">
                  {isTa ? 'யாரெல்லாம் தகுதியுடையவர்கள்?' : 'Eligibility Criteria:'}
                </p>
                <ul className="mt-1.5 space-y-1">
                  {(isTa ? scheme.eligibilityTa : scheme.eligibility).map((item, idx) => (
                    <li key={idx} className="flex items-start gap-1.5 text-xs text-ink-600">
                      <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-leaf-600" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Documents Required */}
              <div className="rounded-lg bg-ink-50 p-2.5">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-ink-700">
                  <FileText className="h-3.5 w-3.5 text-ink-500" />
                  <span>{isTa ? 'தேவையான ஆவணங்கள்:' : 'Documents Required:'}</span>
                </div>
                <p className="mt-1 text-xs text-ink-600">
                  {(isTa ? scheme.documentsRequiredTa : scheme.documentsRequired).join(' • ')}
                </p>
              </div>
            </div>

            {/* Footer with Portal Link & Helpline */}
            <div className="mt-5 border-t border-ink-100 pt-3 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 text-xs text-ink-500">
                <Phone className="h-3.5 w-3.5 text-leaf-600" />
                <span>{scheme.helpline}</span>
              </div>

              <a
                href={scheme.officialPortalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-lg bg-ink-900 px-3 py-1.5 text-xs font-semibold text-white hover:bg-ink-800 transition shadow-xs"
              >
                <span>{isTa ? 'அதிகாரப்பூர்வ தளம்' : 'Official Portal'}</span>
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          </Card>
        ))}
      </div>

      {schemes.length === 0 && (
        <div className="rounded-2xl border border-ink-200 bg-white p-8 text-center text-ink-500">
          <p className="text-sm font-semibold">
            {isTa ? 'திட்டங்கள் எதுவும் கிடைக்கவில்லை' : 'No government schemes match your search'}
          </p>
          <p className="mt-1 text-xs">
            {isTa
              ? 'வேறு சொற்களைத் தேடவும் அல்லது வடிகட்டியை மாற்றவும்.'
              : 'Try different search keywords or reset category filters.'}
          </p>
        </div>
      )}
    </div>
  );
}
