import { useState, useRef } from 'react';
import {
  X,
  UploadCloud,
  FileCheck2,
  Terminal,
  AlertCircle,
  Sliders,
  CheckCircle2,
} from 'lucide-react';
import type {
  TrustedInstitution,
  DocumentCategory,
  TargetCrop,
  IngestionStepLog,
} from '@/types/ingestion';
import { uploadAndIngestDocument } from '@/services/ingestionService';
import { useLanguage } from '@/contexts/LanguageContext';
import { validateDocumentUpload } from '@/utils/uploadValidator';

interface IngestionUploaderModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

const institutions: TrustedInstitution[] = [
  'Tamil Nadu Agricultural University (TNAU)',
  'Indian Council of Agricultural Research (ICAR)',
  'Department of Agriculture & Farmers Welfare',
  'Krishi Vigyan Kendra (KVK)',
  'Central Institute for Cotton Research (ICAR-CICR)',
  'National Research Centre for Banana (ICAR-NRCB)',
  'Other',
];

const categories: DocumentCategory[] = [
  'Crop Manual',
  'Disease Management',
  'Fertilizer & Soil Guide',
  'Pest Advisory',
  'Water Management',
  'Government Scheme',
];

const availableCrops: TargetCrop[] = [
  'Paddy (நெல்)',
  'Cotton (பருத்தி)',
  'Sugarcane (கரும்பு)',
  'Maize (மக்காச்சோளம்)',
  'Banana (வாழை)',
  'Groundnut (நிலக்கடலை)',
  'Pulses (பருப்பு வகைகள்)',
  'General Agriculture',
];

export function IngestionUploaderModal({ onClose, onSuccess }: IngestionUploaderModalProps) {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form State
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [institution, setInstitution] = useState<TrustedInstitution>(
    'Tamil Nadu Agricultural University (TNAU)'
  );
  const [category, setCategory] = useState<DocumentCategory>('Crop Manual');
  const [selectedCrops, setSelectedCrops] = useState<string[]>(['Paddy (நெல்)']);
  const [documentLang, setDocumentLang] = useState<'Tamil' | 'English' | 'Bilingual'>('Tamil');
  const [pubDate, setPubDate] = useState(new Date().toISOString().split('T')[0]);

  // Chunking parameters
  const [chunkSize, setChunkSize] = useState(650);
  const [chunkOverlap, setChunkOverlap] = useState(120);

  // Ingestion execution & terminal logs
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDone, setIsDone] = useState(false);
  const [logs, setLogs] = useState<IngestionStepLog[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const toggleCrop = (crop: string) => {
    setSelectedCrops((prev) =>
      prev.includes(crop) ? prev.filter((c) => c !== crop) : [...prev, crop]
    );
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selected = e.target.files[0];
      const validation = await validateDocumentUpload(selected);
      if (!validation.isValid) {
        setErrorMessage(isTa ? validation.errorTa || validation.error! : validation.error!);
        setFile(null);
        return;
      }
      setErrorMessage(null);
      setFile(selected);
      if (!title) {
        setTitle(validation.cleanFilename.replace(/\.[^/.]+$/, '').replace(/_/g, ' '));
      }
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const dropped = e.dataTransfer.files[0];
      const validation = await validateDocumentUpload(dropped);
      if (!validation.isValid) {
        setErrorMessage(isTa ? validation.errorTa || validation.error! : validation.error!);
        setFile(null);
        return;
      }
      setErrorMessage(null);
      setFile(dropped);
      if (!title) {
        setTitle(validation.cleanFilename.replace(/\.[^/.]+$/, '').replace(/_/g, ' '));
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      setErrorMessage(isTa ? 'ஆவணக் கோப்பைத் தேர்ந்தெடுக்கவும்.' : 'Please select a document file.');
      return;
    }
    const validation = await validateDocumentUpload(file);
    if (!validation.isValid) {
      setErrorMessage(isTa ? validation.errorTa || validation.error! : validation.error!);
      return;
    }
    if (selectedCrops.length === 0) {
      setErrorMessage(isTa ? 'குறைந்தது ஒரு பயிரைத் தேர்ந்தெடுக்கவும்.' : 'Please select at least one crop.');
      return;
    }

    setIsProcessing(true);
    setErrorMessage(null);
    setLogs([]);

    try {
      await uploadAndIngestDocument(
        file,
        {
          title: title.trim(),
          description: description.trim(),
          institution,
          category,
          crops: selectedCrops,
          topics: [category, ...selectedCrops],
          language: documentLang,
          publicationDate: pubDate,
        },
        {
          chunkSize,
          chunkOverlap,
        },
        (newLog) => {
          setLogs((prev) => [...prev, newLog]);
        }
      );

      setIsDone(true);
      setTimeout(() => {
        onSuccess();
      }, 1500);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Ingestion failed.';
      setErrorMessage(msg);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/60 p-4 backdrop-blur-sm animate-fade-in"
    >
      <div className="relative flex max-h-[92vh] w-full max-w-4xl flex-col rounded-2xl bg-white shadow-2xl overflow-hidden border border-ink-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-ink-200 bg-leaf-50 px-6 py-4">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-leaf-500 text-white font-bold">
              <UploadCloud className="h-5 w-5" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-ink-900">
                {isTa ? 'அறிவு ஆவண பதிவேற்றம் & செயலாக்கம்' : 'Ingest Agricultural Knowledge Document'}
              </h2>
              <p className="text-xs text-ink-600">
                {isTa
                  ? 'PDF உரை பிரித்தெடுத்தல், நகல் சரிபார்ப்பு, துண்டாக்குதல் மற்றும் வெக்டர் அட்டவணை'
                  : 'PDF stream extraction, duplicate detection, semantic chunking & vector indexing'}
              </p>
            </div>
          </div>
          <button
            type="button"
            disabled={isProcessing}
            onClick={onClose}
            className="rounded-lg p-2 text-ink-400 hover:bg-ink-200 hover:text-ink-700 transition disabled:opacity-30"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {errorMessage && (
            <div className="rounded-xl border border-danger-300 bg-danger-50 p-4 text-xs text-danger-900 flex items-start gap-3">
              <AlertCircle className="h-4 w-4 text-danger-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">{isTa ? 'செயலாக்கம் தோல்வியடைந்தது' : 'Ingestion Error'}</p>
                <p className="mt-0.5">{errorMessage}</p>
              </div>
            </div>
          )}

          {isDone ? (
            <div className="py-12 text-center space-y-3">
              <CheckCircle2 className="mx-auto h-12 w-12 text-leaf-500 animate-bounce" />
              <h3 className="text-lg font-bold text-ink-900">
                {isTa ? 'ஆவணம் வெற்றிகரமாக அட்டவணைப்படுத்தப்பட்டது!' : 'Document Successfully Ingested & Indexed!'}
              </h3>
              <p className="text-xs text-ink-600">
                {isTa
                  ? 'ஆவணம் துண்டாக்கப்பட்டு வெக்டர் தரவுத்தளத்தில் இணைக்கப்பட்டுள்ளது.'
                  : 'Extracted semantic chunks and dense embeddings are ready for agricultural retrieval.'}
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* File Dropzone */}
              <div>
                <label className="block text-xs font-bold text-ink-900 mb-2">
                  {isTa ? 'ஆவணக் கோப்பு (PDF, TXT, MD)' : 'Document Source File (PDF, TXT, MD)'}
                </label>
                <div
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed p-6 transition ${
                    file
                      ? 'border-leaf-500 bg-leaf-50/50'
                      : 'border-ink-300 bg-ink-50/50 hover:border-leaf-400'
                  }`}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,.txt,.md"
                    className="hidden"
                    onChange={handleFileChange}
                  />
                  {file ? (
                    <div className="flex items-center gap-3">
                      <FileCheck2 className="h-8 w-8 text-leaf-600" />
                      <div className="text-left">
                        <p className="text-sm font-bold text-ink-900">{file.name}</p>
                        <p className="text-xs text-ink-500">{(file.size / 1024).toFixed(1)} KB</p>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center">
                      <UploadCloud className="mx-auto h-8 w-8 text-ink-400" />
                      <p className="mt-2 text-sm font-semibold text-ink-800">
                        {isTa ? 'PDF கோப்பை இங்கே இழுக்கவும் அல்லது கிளிக் செய்யவும்' : 'Click to select or drag and drop PDF file here'}
                      </p>
                      <p className="mt-1 text-xs text-ink-500">Max file size: 25 MB</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Title & Description */}
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-bold text-ink-900 mb-1">
                    {isTa ? 'ஆவணத்தின் தலைப்பு' : 'Document Title'}
                  </label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. TNAU SRI Rice Production Manual"
                    className="w-full rounded-xl border border-ink-200 px-3.5 py-2 text-sm text-ink-900 focus:border-leaf-500 focus:outline-none focus:ring-2 focus:ring-leaf-200"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-ink-900 mb-1">
                    {isTa ? 'வெளியீட்டுத் தேதி' : 'Publication Date'}
                  </label>
                  <input
                    type="date"
                    required
                    value={pubDate}
                    onChange={(e) => setPubDate(e.target.value)}
                    className="w-full rounded-xl border border-ink-200 px-3.5 py-2 text-sm text-ink-900 focus:border-leaf-500 focus:outline-none focus:ring-2 focus:ring-leaf-200"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-ink-900 mb-1">
                  {isTa ? 'சுருக்கம் / விளக்கம்' : 'Summary & Description'}
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={
                    isTa
                      ? 'ஆவணத்தின் முக்கிய விவசாய நோக்கங்கள் மற்றும் பரிந்துரைகள்...'
                      : 'Brief overview of technical agronomic recommendations...'
                  }
                  className="w-full rounded-xl border border-ink-200 p-3 text-sm text-ink-900 focus:border-leaf-500 focus:outline-none focus:ring-2 focus:ring-leaf-200"
                />
              </div>

              {/* Institution, Category & Language */}
              <div className="grid gap-4 sm:grid-cols-3">
                <div>
                  <label className="block text-xs font-bold text-ink-900 mb-1">
                    {isTa ? 'மூல நிறுவனம்' : 'Trusted Source Institution'}
                  </label>
                  <select
                    value={institution}
                    onChange={(e) => setInstitution(e.target.value as TrustedInstitution)}
                    className="w-full rounded-xl border border-ink-200 px-3 py-2 text-xs font-medium text-ink-900 focus:border-leaf-500 focus:outline-none"
                  >
                    {institutions.map((inst) => (
                      <option key={inst} value={inst}>
                        {inst}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-ink-900 mb-1">
                    {isTa ? 'ஆவண வகை' : 'Category'}
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as DocumentCategory)}
                    className="w-full rounded-xl border border-ink-200 px-3 py-2 text-xs font-medium text-ink-900 focus:border-leaf-500 focus:outline-none"
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-ink-900 mb-1">
                    {isTa ? 'மொழி' : 'Language'}
                  </label>
                  <select
                    value={documentLang}
                    onChange={(e) =>
                      setDocumentLang(e.target.value as 'Tamil' | 'English' | 'Bilingual')
                    }
                    className="w-full rounded-xl border border-ink-200 px-3 py-2 text-xs font-medium text-ink-900 focus:border-leaf-500 focus:outline-none"
                  >
                    <option value="Tamil">Tamil (தமிழ்)</option>
                    <option value="English">English</option>
                    <option value="Bilingual">Bilingual (Tamil & English)</option>
                  </select>
                </div>
              </div>

              {/* Crop Multi-Select */}
              <div>
                <label className="block text-xs font-bold text-ink-900 mb-2">
                  {isTa ? 'பொருந்தக்கூடிய பயிர்கள்' : 'Applicable Tamil Nadu Crops'}
                </label>
                <div className="flex flex-wrap gap-2">
                  {availableCrops.map((crop) => {
                    const active = selectedCrops.includes(crop);
                    return (
                      <button
                        key={crop}
                        type="button"
                        onClick={() => toggleCrop(crop)}
                        className={`rounded-full px-3 py-1.5 text-xs font-semibold transition ${
                          active
                            ? 'bg-leaf-500 text-white shadow-sm'
                            : 'border border-ink-200 bg-white text-ink-700 hover:border-ink-300'
                        }`}
                      >
                        {crop}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Chunking Settings Slider */}
              <div className="rounded-xl border border-ink-200 bg-ink-50/70 p-4 space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold text-ink-900">
                  <Sliders className="h-4 w-4 text-leaf-600" />
                  <span>{isTa ? 'துண்டாக்குதல் அமைப்புகள் (Chunking Configuration)' : 'Segmentation & Chunking Parameters'}</span>
                </div>
                <div className="grid gap-4 sm:grid-cols-2 text-xs">
                  <div>
                    <div className="flex justify-between font-semibold text-ink-700 mb-1">
                      <span>{isTa ? 'துண்டு அளவு (Chunk Size)' : 'Target Chunk Size'}</span>
                      <span className="font-mono text-leaf-700">{chunkSize} characters (~{Math.round(chunkSize / 4)} tokens)</span>
                    </div>
                    <input
                      type="range"
                      min={300}
                      max={1200}
                      step={50}
                      value={chunkSize}
                      onChange={(e) => setChunkSize(Number(e.target.value))}
                      className="w-full accent-leaf-500"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between font-semibold text-ink-700 mb-1">
                      <span>{isTa ? 'மேலடுக்கு அளவு (Overlap)' : 'Chunk Overlap'}</span>
                      <span className="font-mono text-leaf-700">{chunkOverlap} characters (~{Math.round(chunkOverlap / 4)} tokens)</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={300}
                      step={20}
                      value={chunkOverlap}
                      onChange={(e) => setChunkOverlap(Number(e.target.value))}
                      className="w-full accent-leaf-500"
                    />
                  </div>
                </div>
              </div>

              {/* Live Ingestion Terminal Output */}
              {logs.length > 0 && (
                <div className="rounded-xl border border-ink-800 bg-ink-900 p-4 font-mono text-xs text-white space-y-1.5 max-h-48 overflow-y-auto">
                  <div className="flex items-center gap-2 text-[11px] text-aqua-400 font-bold border-b border-ink-800 pb-1 mb-2">
                    <Terminal className="h-3.5 w-3.5" />
                    <span>Live Ingestion Pipeline Engine Log</span>
                  </div>
                  {logs.map((l) => (
                    <div key={l.id} className="flex items-start gap-2">
                      <span className="text-ink-400 text-[10px] shrink-0">[{l.timestamp}]</span>
                      <span
                        className={
                          l.tone === 'success'
                            ? 'text-leaf-400'
                            : l.tone === 'warning'
                            ? 'text-sun-400'
                            : l.tone === 'danger'
                            ? 'text-red-400'
                            : 'text-ink-200'
                        }
                      >
                        {l.message}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-ink-200">
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={onClose}
                  className="rounded-xl border border-ink-200 px-4 py-2 text-xs font-semibold text-ink-700 hover:bg-ink-100 transition disabled:opacity-40"
                >
                  {isTa ? 'ரத்து' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isProcessing || !file}
                  className="rounded-xl bg-leaf-500 px-6 py-2.5 text-xs font-bold text-white hover:bg-leaf-600 transition shadow-sm disabled:opacity-40 flex items-center gap-2"
                >
                  {isProcessing ? (
                    <>
                      <div className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white border-t-transparent" />
                      <span>{isTa ? 'செயலாக்குகிறது...' : 'Ingesting Document...'}</span>
                    </>
                  ) : (
                    <>
                      <UploadCloud className="h-4 w-4" />
                      <span>{isTa ? 'ஆவணத்தைச் செயலாக்கு' : 'Ingest & Index Document'}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
