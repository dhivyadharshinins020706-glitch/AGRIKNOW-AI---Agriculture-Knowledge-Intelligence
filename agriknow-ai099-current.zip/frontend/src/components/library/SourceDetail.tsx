import { useState, useEffect } from 'react';
import { Quote, Layers, ShieldCheck, FileText } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { buttonClass } from '@/components/ui/Button';
import type { Source } from '@/types';
import type { IngestedDocument, DocumentChunk } from '@/types/ingestion';
import { fetchIngestedDocuments, fetchDocumentChunks } from '@/services/ingestionService';
import { ChunkTraceabilityModal } from './ChunkTraceabilityModal';
import { useLanguage } from '@/contexts/LanguageContext';

export function SourceDetail({ source }: { source: Source }) {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';

  const [matchingDoc, setMatchingDoc] = useState<IngestedDocument | null>(null);
  const [chunks, setChunks] = useState<DocumentChunk[]>([]);
  const [showTraceModal, setShowTraceModal] = useState(false);

  useEffect(() => {
    let active = true;
    fetchIngestedDocuments().then((docs) => {
      if (!active) return;
      // Match by title keyword or publisher
      const found = docs.find(
        (d) =>
          d.id === source.id ||
          d.title.toLowerCase().includes(source.title.toLowerCase().slice(0, 15)) ||
          source.title.toLowerCase().includes(d.title.toLowerCase().slice(0, 15))
      );
      if (found) {
        setMatchingDoc(found);
        fetchDocumentChunks(found.id).then((ch) => {
          if (active) setChunks(ch);
        });
      }
    });

    return () => {
      active = false;
    };
  }, [source]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone="ai">{source.kind}</Badge>
        <Badge tone="neutral">{source.language}</Badge>
        <Badge tone="info">{source.year}</Badge>
        <span className="inline-flex items-center gap-1 rounded-full bg-leaf-100 px-2.5 py-0.5 text-xs font-bold text-leaf-800">
          <ShieldCheck className="h-3.5 w-3.5 text-leaf-600" />
          {source.reliability}
        </span>
      </div>

      <div>
        <p className="text-sm font-bold text-leaf-800">{source.publisher}</p>
        <p className="mt-2 text-[15px] leading-relaxed text-ink-700">{source.summary}</p>
      </div>

      {/* RAG Ingestion Pipeline Status if matched */}
      {matchingDoc && (
        <div className="rounded-2xl border border-lilac-200 bg-lilac-50/60 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-xs font-bold text-lilac-900">
              <Layers className="h-4 w-4 text-lilac-700" />
              {isTa ? 'RAG வெக்டர் குறியீட்டு நிலை' : 'Indexed in RAG Vector Store'}
            </span>
            <span className="rounded bg-lilac-200 px-2 py-0.5 text-[10px] font-bold text-lilac-800">
              {matchingDoc.status.toUpperCase()}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs text-ink-700">
            <div>
              <span className="text-ink-400 block text-[10px]">
                {isTa ? 'மொத்த பக்கங்கள்' : 'Total Pages'}
              </span>
              <span className="font-bold flex items-center gap-1">
                <FileText className="h-3 w-3" />
                {matchingDoc.totalPages}
              </span>
            </div>
            <div>
              <span className="text-ink-400 block text-[10px]">
                {isTa ? 'வெக்டர் துண்டுகள்' : 'Indexed Chunks'}
              </span>
              <span className="font-bold flex items-center gap-1">
                <Layers className="h-3 w-3 text-lilac-600" />
                {chunks.length || matchingDoc.totalChunks}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowTraceModal(true)}
            className="w-full rounded-xl bg-lilac-600 py-2 text-xs font-bold text-white hover:bg-lilac-700 transition"
          >
            {isTa ? 'அனைத்து துண்டுகளையும் தடமறி' : 'Inspect Semantic Chunks & Vector Values'}
          </button>
        </div>
      )}

      {/* Key points from this document */}
      <div className="space-y-3">
        <h3 className="text-base font-bold text-ink-900">
          {isTa ? 'இந்த ஆவணத்திலிருந்து முக்கிய புள்ளிகள்' : 'Key points from this document'}
        </h3>
        {source.excerpts.map((excerpt) => (
          <blockquote
            key={excerpt.section}
            className="relative rounded-2xl border border-ink-200 bg-ink-50 p-4 pl-5"
          >
            <span className="absolute left-0 top-4 h-[calc(100%-2rem)] w-1 rounded-r-full bg-leaf-500" />
            <p className="mb-1.5 flex items-center gap-1.5 text-xs font-bold uppercase tracking-[0.1em] text-leaf-800">
              <Quote className="h-3.5 w-3.5" aria-hidden />
              {excerpt.section}
            </p>
            <p className="text-[15px] leading-relaxed text-ink-800">{excerpt.text}</p>
          </blockquote>
        ))}
      </div>

      {/* Topics */}
      <div className="flex flex-wrap gap-2">
        {source.topics.map((topic) => (
          <Badge key={topic} tone="neutral">
            {topic}
          </Badge>
        ))}
      </div>

      <a href={`#/evidence?doc=${source.id}`} className={buttonClass('primary', 'lg', 'w-full')}>
        {isTa ? 'இந்த ஆதாரம் எங்கு பயன்படுத்தப்பட்டது என்பதைக் காண்க' : 'See where this is used in AI answers'}
      </a>

      {showTraceModal && matchingDoc && (
        <ChunkTraceabilityModal document={matchingDoc} onClose={() => setShowTraceModal(false)} />
      )}
    </div>
  );
}
