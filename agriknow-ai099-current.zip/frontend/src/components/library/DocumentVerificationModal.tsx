import { useState } from 'react';
import { X, ShieldCheck, AlertTriangle, CheckCircle2, XCircle } from 'lucide-react';
import type { IngestedDocument, VerificationStatus } from '@/types/ingestion';
import { verifyDocument } from '@/services/ingestionService';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';

interface DocumentVerificationModalProps {
  document: IngestedDocument;
  onClose: () => void;
  onUpdated: () => void;
}

export function DocumentVerificationModal({
  document,
  onClose,
  onUpdated,
}: DocumentVerificationModalProps) {
  const { lang } = useLanguage();
  const { user } = useAuth();
  const isTa = lang === 'ta';

  const [status, setStatus] = useState<VerificationStatus>(document.verificationStatus);
  const [notes, setNotes] = useState(document.verificationNotes || '');
  const [reviewer, setReviewer] = useState(
    document.verifiedBy || user?.email?.split('@')[0] || 'Agronomist Lead'
  );
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    await verifyDocument(document.id, status, notes, reviewer);
    setSubmitting(false);
    onUpdated();
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/60 p-4 backdrop-blur-sm animate-fade-in"
    >
      <div className="relative w-full max-w-xl rounded-2xl bg-white shadow-2xl overflow-hidden border border-ink-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-ink-200 bg-ink-50 px-6 py-4">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-sun-100 text-sun-900 font-bold">
              <ShieldCheck className="h-5 w-5 text-sun-600" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-ink-900">
                {isTa ? 'ஆவண சரிபார்ப்பு மற்றும் தணிக்கை' : 'Document Verification & Audit'}
              </h2>
              <p className="text-xs text-ink-600 truncate max-w-sm">{document.title}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-ink-400 hover:bg-ink-200 hover:text-ink-700 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Conflict Alert Banner if flagged */}
          {document.verificationStatus === 'flagged_conflicting' && (
            <div className="rounded-xl border border-sun-300 bg-sun-50 p-3 text-xs text-sun-900 flex items-start gap-2.5">
              <AlertTriangle className="h-4 w-4 text-sun-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">
                  {isTa ? 'எச்சரிக்கை: முரண்பட்ட பரிந்துரைகள் கண்டறியப்பட்டன' : 'Automated Quality Conflict Warning'}
                </p>
                <p className="mt-0.5 text-sun-800">
                  {document.verificationNotes ||
                    'Document text triggered restricted or outdated pesticide triggers during ingestion.'}
                </p>
              </div>
            </div>
          )}

          {/* Verification Status Selector */}
          <div>
            <label className="block text-xs font-bold text-ink-900 mb-2">
              {isTa ? 'சரிபார்ப்பு நிலை (Verification Status)' : 'Verification Status'}
            </label>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {[
                {
                  id: 'verified',
                  label: isTa ? 'சரிபார்க்கப்பட்டது' : 'Verified',
                  icon: CheckCircle2,
                  activeColor: 'border-leaf-500 bg-leaf-50 text-leaf-800',
                },
                {
                  id: 'pending_review',
                  label: isTa ? 'ஆய்வில் உள்ளது' : 'Pending Review',
                  icon: ShieldCheck,
                  activeColor: 'border-sun-500 bg-sun-50 text-sun-800',
                },
                {
                  id: 'flagged_conflicting',
                  label: isTa ? 'முரண்பாடு' : 'Flag Conflicted',
                  icon: AlertTriangle,
                  activeColor: 'border-sun-600 bg-sun-100 text-sun-900',
                },
                {
                  id: 'rejected',
                  label: isTa ? 'நிராகரி' : 'Reject',
                  icon: XCircle,
                  activeColor: 'border-danger-500 bg-danger-50 text-danger-800',
                },
              ].map((opt) => {
                const active = status === opt.id;
                const Icon = opt.icon;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setStatus(opt.id as VerificationStatus)}
                    className={`flex flex-col items-center justify-center p-3 rounded-xl border text-xs font-bold transition text-center gap-1.5 ${
                      active
                        ? opt.activeColor
                        : 'border-ink-200 bg-white text-ink-600 hover:border-ink-300'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{opt.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Reviewer Name */}
          <div>
            <label className="block text-xs font-bold text-ink-900 mb-1">
              {isTa ? 'தணிக்கையாளர் / ஆய்வாளர் பெயர்' : 'Auditor / Reviewer Identity'}
            </label>
            <input
              type="text"
              value={reviewer}
              onChange={(e) => setReviewer(e.target.value)}
              required
              placeholder="e.g. Dr. R. Swaminathan (TNAU Agronomy)"
              className="w-full rounded-xl border border-ink-200 px-3.5 py-2 text-sm text-ink-900 focus:border-leaf-500 focus:outline-none focus:ring-2 focus:ring-leaf-200"
            />
          </div>

          {/* Verification Notes */}
          <div>
            <label className="block text-xs font-bold text-ink-900 mb-1">
              {isTa ? 'தணிக்கைக் குறிப்புகள் & கள ஒப்புதல்' : 'Reviewer Audit Notes & Guidance'}
            </label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={
                isTa
                  ? 'பரிந்துரைக்கப்பட்ட விவசாய சூழல் மற்றும் கள வழிகாட்டுதல் பற்றிய குறிப்புகள்...'
                  : 'Specify agronomic validity, applicable agro-climatic zones, and recommended usage...'
              }
              className="w-full rounded-xl border border-ink-200 p-3 text-sm text-ink-900 focus:border-leaf-500 focus:outline-none focus:ring-2 focus:ring-leaf-200"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-ink-200">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-ink-200 px-4 py-2 text-xs font-semibold text-ink-700 hover:bg-ink-100 transition"
            >
              {isTa ? 'ரத்து' : 'Cancel'}
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="rounded-xl bg-leaf-500 px-5 py-2 text-xs font-bold text-white hover:bg-leaf-600 transition disabled:opacity-50"
            >
              {submitting
                ? isTa
                  ? 'சேமிக்கிறது...'
                  : 'Saving Audit...'
                : isTa
                ? 'சரிபார்ப்பை உறுதிப்படுத்து'
                : 'Confirm Verification'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
