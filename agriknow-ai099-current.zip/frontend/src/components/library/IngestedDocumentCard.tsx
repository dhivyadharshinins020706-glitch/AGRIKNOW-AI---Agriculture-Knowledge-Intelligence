import { useState } from 'react';
import {
  FileText,
  Calendar,
  Layers,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Clock,
  Trash2,
  Building2,
} from 'lucide-react';
import type { IngestedDocument } from '@/types/ingestion';
import { formatBytes } from '@/utils/cryptoUtils';
import { useLanguage } from '@/contexts/LanguageContext';
import { ChunkTraceabilityModal } from './ChunkTraceabilityModal';
import { DocumentVerificationModal } from './DocumentVerificationModal';
import { deleteIngestedDocument } from '@/services/ingestionService';

interface IngestedDocumentCardProps {
  document: IngestedDocument;
  onRefresh: () => void;
}

export function IngestedDocumentCard({ document, onRefresh }: IngestedDocumentCardProps) {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';

  const [showTraceability, setShowTraceability] = useState(false);
  const [showVerification, setShowVerification] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const handleDelete = async () => {
    if (
      window.confirm(
        isTa
          ? `"${document.title}" ஆவணத்தையும் அதன் அனைத்து வெக்டர் துண்டுகளையும் நீக்க விரும்புகிறீர்களா?`
          : `Are you sure you want to delete "${document.title}" and its indexed chunks?`
      )
    ) {
      setDeleting(true);
      await deleteIngestedDocument(document.id);
      setDeleting(false);
      onRefresh();
    }
  };

  const getVerificationBadge = () => {
    switch (document.verificationStatus) {
      case 'verified':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-leaf-100 px-2.5 py-0.5 text-[11px] font-bold text-leaf-800">
            <CheckCircle2 className="h-3 w-3 text-leaf-600" />
            {isTa ? 'சரிபார்க்கப்பட்டது' : 'Verified'}
          </span>
        );
      case 'flagged_conflicting':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-sun-100 px-2.5 py-0.5 text-[11px] font-bold text-sun-900 border border-sun-300">
            <AlertTriangle className="h-3 w-3 text-sun-600" />
            {isTa ? 'முரண்பாடு கண்டறியப்பட்டது' : 'Flagged Conflict'}
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-danger-100 px-2.5 py-0.5 text-[11px] font-bold text-danger-800">
            <XCircle className="h-3 w-3 text-danger-600" />
            {isTa ? 'நிராகரிக்கப்பட்டது' : 'Rejected'}
          </span>
        );
      case 'pending_review':
      default:
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-sun-50 px-2.5 py-0.5 text-[11px] font-bold text-sun-800 border border-sun-200">
            <Clock className="h-3 w-3 text-sun-600" />
            {isTa ? 'ஆய்வில் உள்ளது' : 'Pending Review'}
          </span>
        );
    }
  };

  return (
    <>
      <div className="flex flex-col justify-between rounded-2xl border border-ink-200 bg-white p-5 shadow-sm transition hover:shadow-md">
        <div>
          {/* Top row: Category, Verification Badge & Delete */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="rounded-md bg-lilac-100 px-2 py-0.5 text-[11px] font-bold text-lilac-900">
                {document.category}
              </span>
              {getVerificationBadge()}
            </div>

            <button
              type="button"
              disabled={deleting}
              onClick={handleDelete}
              title={isTa ? 'ஆவணத்தை நீக்கு' : 'Delete document'}
              className="text-ink-400 hover:text-danger-600 p-1 transition disabled:opacity-30"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>

          {/* Title & Description */}
          <h3 className="mt-3 text-base font-bold text-ink-900 leading-snug line-clamp-2">
            {document.title}
          </h3>
          <p className="mt-1 text-xs text-ink-600 line-clamp-2">{document.description}</p>

          {/* Source Institution */}
          <div className="mt-3 flex items-center gap-1.5 text-xs font-semibold text-leaf-800">
            <Building2 className="h-3.5 w-3.5 shrink-0" />
            <span className="truncate">{document.institution}</span>
          </div>

          {/* Crops Tags */}
          <div className="mt-3 flex flex-wrap gap-1.5">
            {(document.crops || []).map((crop) => (
              <span
                key={crop}
                className="rounded-full bg-ink-100 px-2.5 py-0.5 text-[10px] font-medium text-ink-700"
              >
                {crop}
              </span>
            ))}
          </div>
        </div>

        {/* Footer Meta & Actions */}
        <div className="mt-5 border-t border-ink-100 pt-3">
          <div className="flex items-center justify-between text-[11px] text-ink-500 mb-3">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1">
                <FileText className="h-3 w-3" />
                {document.totalPages || 0} {isTa ? 'பக்கங்கள்' : 'pages'}
              </span>
              <span className="flex items-center gap-1">
                <Layers className="h-3 w-3 text-lilac-600" />
                {document.totalChunks || 0} {isTa ? 'துண்டுகள்' : 'chunks'}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              <span>{document.publicationDate || formatBytes(document.fileSizeBytes || 0)}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowTraceability(true)}
              className="flex-1 rounded-xl border border-leaf-300 bg-leaf-50/80 py-2 text-xs font-bold text-leaf-800 hover:bg-leaf-100 transition text-center"
            >
              {isTa ? 'துண்டுகளைக் காண்' : 'Inspect Chunks'}
            </button>
            <button
              type="button"
              onClick={() => setShowVerification(true)}
              className="rounded-xl border border-ink-200 bg-white px-3 py-2 text-xs font-bold text-ink-700 hover:bg-ink-100 transition"
              title={isTa ? 'சரிபார்ப்பு நிலை' : 'Audit Document'}
            >
              <ShieldCheck className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {showTraceability && (
        <ChunkTraceabilityModal document={document} onClose={() => setShowTraceability(false)} />
      )}

      {showVerification && (
        <DocumentVerificationModal
          document={document}
          onClose={() => setShowVerification(false)}
          onUpdated={onRefresh}
        />
      )}
    </>
  );
}
