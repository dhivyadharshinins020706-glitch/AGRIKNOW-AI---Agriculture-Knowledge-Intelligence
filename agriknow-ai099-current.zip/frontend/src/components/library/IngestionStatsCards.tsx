import { BookOpen, Layers, ShieldCheck, Sprout } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import type { IngestionStats } from '@/types/ingestion';
import { useLanguage } from '@/contexts/LanguageContext';

interface IngestionStatsCardsProps {
  stats: IngestionStats;
}

export function IngestionStatsCards({ stats }: IngestionStatsCardsProps) {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';

  const safeTotalDocs = stats?.totalDocuments ?? 0;
  const safeTotalChunks = stats?.totalChunks ?? 0;
  const safeVerifiedDocs = stats?.verifiedDocuments ?? 0;
  const safeFlaggedDocs = stats?.flaggedDocuments ?? 0;
  const safeCropDist = stats?.cropDistribution || {};

  const geminiChunks = stats?.modelDistribution?.['gemini-embedding-2'] ?? 0;
  const hashChunks = stats?.modelDistribution?.['multilingual-dense-hash-128'] ?? safeTotalChunks;
  const chunkModelLabel = geminiChunks > 0
    ? `${geminiChunks} Gemini | ${hashChunks} 128-D`
    : isTa
    ? '128-டி அடர்த்தி உட்பொதிவுகள்'
    : '128-D Multilingual Embeddings';

  const items = [
    {
      label: isTa ? 'மொத்த ஆவணங்கள்' : 'Ingested Documents',
      value: safeTotalDocs,
      subtext: isTa ? 'TNAU, ICAR, KVK மூலங்கள்' : 'TNAU, ICAR & State Manuals',
      icon: BookOpen,
      tone: 'bg-leaf-100 text-leaf-800',
    },
    {
      label: isTa ? 'அட்டவணைப்படுத்தப்பட்ட துண்டுகள்' : 'Indexed Chunks (RAG)',
      value: safeTotalChunks,
      subtext: chunkModelLabel,
      icon: Layers,
      tone: 'bg-lilac-200 text-lilac-900',
    },
    {
      label: isTa ? 'சரிபார்க்கப்பட்ட நிலை' : 'Verified Knowledge',
      value: `${safeVerifiedDocs}/${safeTotalDocs}`,
      subtext: safeFlaggedDocs > 0
        ? isTa
          ? `${safeFlaggedDocs} முரண்பாடுகள் ஆய்வில்`
          : `${safeFlaggedDocs} flagged for review`
        : isTa
        ? 'தணிக்கை நிறைவுற்றது'
        : 'Agronomist Verified',
      icon: ShieldCheck,
      tone: 'bg-sun-100 text-sun-900',
    },
    {
      label: isTa ? 'முக்கிய பயிர்கள் பரப்பு' : 'Tamil Nadu Crops Covered',
      value: Object.keys(safeCropDist).length,
      subtext: isTa ? 'நெல், பருத்தி, கரும்பு, மக்காச்சோளம்...' : 'Paddy, Cotton, Cane, Maize...',
      icon: Sprout,
      tone: 'bg-aqua-100 text-aqua-900',
    },
  ];

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {items.map((item) => {
        const Icon = item.icon;
        return (
          <Card key={item.label} className="flex items-center gap-4 p-5">
            <span
              className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl text-xl font-bold ${item.tone}`}
            >
              <Icon className="h-6 w-6" />
            </span>
            <div className="min-w-0">
              <span className="text-xl font-black text-ink-900">{item.value}</span>
              <p className="text-xs font-semibold text-ink-700 truncate">{item.label}</p>
              <p className="text-[10px] text-ink-500 truncate">{item.subtext}</p>
            </div>
          </Card>
        );
      })}
    </div>
  );
}
