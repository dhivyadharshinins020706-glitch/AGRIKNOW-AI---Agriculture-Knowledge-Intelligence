import { ArrowUpRight, BadgeCheck, Languages } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import type { Source } from '@/types';

const kindTone: Record<Source['kind'], 'success' | 'info' | 'ai' | 'warning'> = {
  'Government advisory': 'success',
  'Research paper': 'ai',
  'Extension guide': 'info',
  'Field manual': 'warning',
};

export function SourceCard({ source, onOpen }: { source: Source; onOpen: () => void }) {
  return (
    <Card hover className="flex h-full flex-col p-5 sm:p-6">
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone={kindTone[source.kind]}>{source.kind}</Badge>
        <span className="inline-flex items-center gap-1 text-xs font-medium text-ink-500">
          <BadgeCheck className="h-4 w-4 text-aqua-700" aria-hidden />
          {source.reliability}
        </span>
      </div>

      <h3 className="mt-4 text-lg font-bold leading-snug text-ink-900">{source.title}</h3>
      <p className="mt-1 text-sm text-ink-500">
        {source.publisher}, {source.year}
      </p>
      <p className="mt-3 flex-1 text-[15px] leading-relaxed text-ink-700">{source.summary}</p>

      <div className="mt-4 flex items-center gap-2 text-xs text-ink-500">
        <Languages className="h-4 w-4" aria-hidden />
        {source.language}
      </div>

      <div className="mt-5 flex flex-wrap gap-2 border-t border-ink-100 pt-5">
        <button
          type="button"
          onClick={onOpen}
          className="inline-flex h-10 flex-1 items-center justify-center rounded-xl border border-ink-200 px-4 text-sm font-medium text-ink-900 transition hover:border-ink-300 hover:bg-ink-50"
        >
          Read key points
        </button>
        <a
          href={`#/evidence?doc=${source.id}`}
          className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-lilac-100 px-4 text-sm font-bold text-lilac-800 transition hover:bg-lilac-200"
        >
          Sources
          <ArrowUpRight className="h-4 w-4" aria-hidden />
        </a>
      </div>
    </Card>
  );
}
