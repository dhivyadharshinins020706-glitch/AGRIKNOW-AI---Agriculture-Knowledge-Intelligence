import { BookOpen, CircleCheck, FlaskConical, Leaf, ShieldCheck, Stethoscope } from 'lucide-react';
import { Badge, severityTone } from '@/components/ui/Badge';
import { findSource } from '@/data/sources';
import type { Disease } from '@/types';
import type { ReactNode } from 'react';

function Section({ icon: Icon, title, children }: { icon: typeof Leaf; title: string; children: ReactNode }) {
  return (
    <section className="space-y-3">
      <h3 className="flex items-center gap-2 text-base font-bold text-ink-900">
        <Icon className="h-5 w-5 text-leaf-700" aria-hidden />
        {title}
      </h3>
      {children}
    </section>
  );
}

function BulletList({ items }: { items: string[] }) {
  return (
    <ul className="space-y-2.5">
      {items.map((item) => (
        <li key={item} className="flex gap-3 text-[15px] leading-relaxed text-ink-700">
          <CircleCheck className="mt-0.5 h-5 w-5 shrink-0 text-leaf-500" aria-hidden />
          {item}
        </li>
      ))}
    </ul>
  );
}

export function DiseaseDetail({ disease }: { disease: Disease }) {
  if (!disease) return null;

  return (
    <div className="space-y-7">
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone={severityTone[disease.severity] || 'warning'}>{disease.severity} risk</Badge>
        <Badge tone="neutral">{disease.type}</Badge>
        <Badge tone="info">{disease.cropName}</Badge>
      </div>

      <Section icon={Stethoscope} title="How to recognise it">
        <BulletList items={disease.symptoms ?? []} />
      </Section>

      <div className="grid gap-7 sm:grid-cols-2">
        <Section icon={Leaf} title="Natural methods">
          <BulletList items={disease.organicTreatment ?? []} />
        </Section>
        <Section icon={FlaskConical} title="Chemical control">
          <BulletList items={disease.chemicalTreatment ?? []} />
          <p className="rounded-xl bg-sun-50 px-3 py-2 text-xs leading-relaxed text-sun-800">
            Always follow the dose on the product label and confirm with your local Krishi Officer.
          </p>
        </Section>
      </div>

      <Section icon={ShieldCheck} title="Prevention">
        <BulletList items={disease.prevention ?? []} />
      </Section>

      <Section icon={BookOpen} title="Sources">
        <ul className="grid gap-2 sm:grid-cols-2">
          {(disease.sourceIds ?? []).map((sourceId) => {
            const source = findSource(sourceId);
            if (!source) return null;
            return (
              <li key={sourceId}>
                <a
                  href={`#/evidence?doc=${sourceId}`}
                  className="block rounded-xl border border-ink-200 p-3 transition hover:border-lilac-400 hover:bg-lilac-50"
                >
                  <span className="block text-sm font-medium text-ink-900">{source.title}</span>
                  <span className="text-xs text-ink-500">
                    {source.publisher}, {source.year}
                  </span>
                </a>
              </li>
            );
          })}
        </ul>
      </Section>
    </div>
  );
}
