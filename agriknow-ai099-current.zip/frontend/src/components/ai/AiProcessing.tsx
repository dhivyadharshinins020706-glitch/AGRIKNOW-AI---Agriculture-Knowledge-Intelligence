import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Check, Loader2 } from 'lucide-react';

interface AiProcessingProps {
  title: string;
  steps: string[];
  stepMs?: number;
  onComplete: () => void;
}

export function AiProcessing({ title, steps, stepMs = 650, onComplete }: AiProcessingProps) {
  const [current, setCurrent] = useState(0);
  const completeRef = useRef(onComplete);
  completeRef.current = onComplete;

  useEffect(() => {
    if (current >= steps.length) {
      const done = window.setTimeout(() => completeRef.current(), 250);
      return () => window.clearTimeout(done);
    }
    const next = window.setTimeout(() => setCurrent((index) => index + 1), stepMs);
    return () => window.clearTimeout(next);
  }, [current, steps.length, stepMs]);

  return (
    <div className="rounded-2xl border border-lilac-300/60 bg-gradient-to-br from-lilac-50 to-aqua-50 p-5" role="status" aria-live="polite">
      <div className="mb-4 flex items-center gap-3">
        <span className="relative flex h-9 w-9 items-center justify-center">
          <span className="absolute inset-0 animate-ping-slow rounded-full bg-aqua-300/60" />
          <span className="relative h-3 w-3 rounded-full bg-aqua-500" />
        </span>
        <p className="text-sm font-medium text-ink-800">{title}</p>
      </div>
      <ul className="space-y-2.5">
        {steps.map((step, index) => {
          const finished = index < current;
          const active = index === current;
          return (
            <motion.li
              key={step}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: index <= current ? 1 : 0.45, x: 0 }}
              className="flex items-center gap-3 text-sm text-ink-700"
            >
              <span
                className={`flex h-6 w-6 items-center justify-center rounded-full ${
                  finished ? 'bg-leaf-400 text-ink-900' : active ? 'bg-aqua-100 text-aqua-800' : 'bg-ink-100 text-ink-400'
                }`}
              >
                {finished ? (
                  <Check className="h-3.5 w-3.5" aria-hidden />
                ) : active ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />
                ) : (
                  <span className="h-1.5 w-1.5 rounded-full bg-ink-300" />
                )}
              </span>
              {step}
            </motion.li>
          );
        })}
      </ul>
    </div>
  );
}
