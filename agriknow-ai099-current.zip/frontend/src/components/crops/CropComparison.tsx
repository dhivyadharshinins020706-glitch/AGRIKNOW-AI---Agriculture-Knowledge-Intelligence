import { Check } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Badge, severityTone } from '@/components/ui/Badge';
import { cropIcons, profitPerAcre } from '@/data/crops';
import type { Crop } from '@/types';
import { motion } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';

interface CropCardProps {
  crop: Crop;
  selected: boolean;
  disabled: boolean;
  onToggle: () => void;
  acres?: number;
}

export function CropSelectCard({ crop, selected, disabled, onToggle, acres = 1 }: CropCardProps) {
  const Icon = cropIcons[crop.id];
  const { lang } = useLanguage();
  const isTa = lang === 'ta';
  const profit = profitPerAcre(crop) * acres;

  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={selected}
      disabled={disabled && !selected}
      onClick={onToggle}
      className={`group relative flex h-full w-full flex-col rounded-2xl border p-5 text-left transition duration-300 disabled:cursor-not-allowed disabled:opacity-50 sm:p-6 ${
        selected
          ? 'border-leaf-400 bg-leaf-50/70 shadow-lift ring-4 ring-leaf-200/60'
          : 'border-ink-200/70 bg-white shadow-card hover:-translate-y-0.5 hover:border-ink-300 hover:shadow-lift'
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <span
          className={`flex h-12 w-12 items-center justify-center rounded-xl transition-colors ${
            selected ? 'bg-leaf-400 text-ink-900' : 'bg-aqua-100 text-aqua-800'
          }`}
        >
          {Icon ? <Icon className="h-6 w-6" aria-hidden /> : null}
        </span>
        <motion.span
          animate={{ scale: selected ? 1 : 0.9, opacity: selected ? 1 : 0.5 }}
          className={`flex h-7 w-7 items-center justify-center rounded-full border-2 ${
            selected ? 'border-leaf-500 bg-leaf-500 text-ink-900' : 'border-ink-300 bg-white text-transparent'
          }`}
        >
          <Check className="h-4 w-4" strokeWidth={3} aria-hidden />
        </motion.span>
      </div>

      <div className="mt-5 min-w-0">
        <p className="truncate text-lg font-bold text-ink-900">
          {isTa && crop.nameTa ? crop.nameTa : crop.name}
        </p>
        <p className="truncate text-sm text-ink-500">{crop.name}</p>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <Badge tone="neutral">{crop.season}</Badge>
        <Badge tone="neutral">{crop.durationDays} {isTa ? 'நாட்கள்' : 'days'}</Badge>
        <Badge tone={severityTone[crop.risk]}>{crop.risk} {isTa ? 'அபாயம்' : 'risk'}</Badge>
      </div>

      <div className="mt-auto border-t border-ink-100 pt-4 mt-5">
        <p className="text-xs text-ink-500">
          {acres > 1
            ? (isTa ? `${acres} ஏக்கருக்கு மொத்த லாபம்` : `Profit for ${acres} acres`)
            : (isTa ? 'ஏக்கருக்கு எதிர்பார்க்கப்படும் லாபம்' : 'Estimated profit per acre')}
        </p>
        <p className="text-2xl font-bold tabular-nums text-ink-900">
          ₹{Math.round(profit).toLocaleString('en-IN')}
        </p>
      </div>
    </button>
  );
}

interface Row {
  label: string;
  values: string[];
  bestIndex?: number;
}

export function ComparisonTable({ crops, acres = 1 }: { crops: Crop[]; acres?: number }) {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';

  const profits = crops.map((c) => profitPerAcre(c) * acres);
  const costs = crops.map((c) => c.costPerAcre * acres);
  const yields = crops.map((c) => c.yieldQuintalPerAcre * acres);

  const riskRank = { Low: 1, Medium: 2, High: 3 };
  const waterRank = { Low: 1, Medium: 2, High: 3 };

  const rows: Row[] = [
    { label: isTa ? 'பருவம்' : 'Season', values: crops.map((crop) => crop.season) },
    {
      label: isTa ? 'கால அளவு' : 'Duration',
      values: crops.map((crop) => `${crop.durationDays} ${isTa ? 'நாட்கள்' : 'days'}`),
      bestIndex: indexOfMin(crops.map((crop) => crop.durationDays)),
    },
    {
      label: isTa ? 'நீர் தேவை' : 'Water need',
      values: crops.map((crop) => crop.waterNeed),
      bestIndex: indexOfMin(crops.map((crop) => waterRank[crop.waterNeed])),
    },
    {
      label: acres > 1 ? (isTa ? `${acres} ஏக்கர் மகசூல்` : `Yield (${acres} acres)`) : (isTa ? 'எதிர்பார்க்கப்படும் மகசூல்' : 'Expected yield'),
      values: yields.map((y) => `${y.toFixed(1)} ${isTa ? 'குவிண்டால்' : 'quintals'}`),
      bestIndex: indexOfMax(yields),
    },
    {
      label: acres > 1 ? (isTa ? `${acres} ஏக்கர் மொத்த செலவு` : `Total cost (${acres} acres)`) : (isTa ? 'ஏக்கர் சாகுபடி செலவு' : 'Cost per acre'),
      values: costs.map((val) => `₹${Math.round(val).toLocaleString('en-IN')}`),
      bestIndex: indexOfMin(costs),
    },
    {
      label: acres > 1 ? (isTa ? `${acres} ஏக்கர் நிகர லாபம்` : `Net profit (${acres} acres)`) : (isTa ? 'நிகர லாபம்' : 'Net profit'),
      values: profits.map((val) => `₹${Math.round(val).toLocaleString('en-IN')}`),
      bestIndex: indexOfMax(profits),
    },
    {
      label: isTa ? 'இடர் அளவு' : 'Risk level',
      values: crops.map((crop) => crop.risk),
      bestIndex: indexOfMin(crops.map((crop) => riskRank[crop.risk])),
    },
    {
      label: isTa ? 'ஏற்ற நிலம்' : 'Best for',
      values: crops.map((crop) => crop.bestFor),
    },
  ];

  return (
    <Card className="overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] border-collapse text-left">
          <thead>
            <tr className="border-b border-ink-200 bg-ink-50">
              <th scope="col" className="sticky left-0 bg-ink-50 p-4 text-sm font-medium text-ink-500">
                {isTa ? 'ஒப்பீடு' : 'Compare'}
              </th>
              {crops.map((crop) => (
                <th key={crop.id} scope="col" className="p-4 text-base font-bold text-ink-900">
                  {isTa && crop.nameTa ? crop.nameTa : crop.name}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.label} className="border-b border-ink-100 last:border-0">
                <th scope="row" className="sticky left-0 bg-white p-4 text-sm font-medium text-ink-600">
                  {row.label}
                </th>
                {row.values.map((value, index) => {
                  const best = row.bestIndex === index;
                  return (
                    <td key={`${row.label}-${index}`} className="p-4 align-top">
                      <span
                        className={`inline-flex items-center gap-1.5 rounded-lg text-[15px] ${
                          best ? 'bg-leaf-100 px-2.5 py-1 font-bold text-leaf-800' : 'text-ink-800'
                        }`}
                      >
                        {best && <Check className="h-4 w-4" aria-hidden />}
                        {value}
                      </span>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function indexOfMin(values: number[]): number {
  return values.indexOf(Math.min(...values));
}

function indexOfMax(values: number[]): number {
  return values.indexOf(Math.max(...values));
}
