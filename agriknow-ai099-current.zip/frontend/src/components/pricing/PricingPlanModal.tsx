import { useState } from 'react';
import { Check, Shield, Sparkles, Building2, GraduationCap, Users, X, Info } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { useLanguage } from '@/contexts/LanguageContext';
import { BUSINESS_PRICING_PLANS, type PricingPlan } from '@/data/businessPricing';

interface PricingPlanModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PricingPlanModal({ isOpen, onClose }: PricingPlanModalProps) {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('annual');

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="pricing-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-ink-950/70 backdrop-blur-sm overflow-y-auto"
    >
      <div className="relative w-full max-w-5xl rounded-3xl bg-white shadow-2xl border border-ink-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-ink-100 bg-ink-50/60 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-leaf-500 text-white shadow-sm">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h2 id="pricing-modal-title" className="text-lg font-bold text-ink-900">
                {isTa ? 'AGRIKNOW AI சந்தா & நிறுவன திட்டங்கள்' : 'AGRIKNOW AI Plans & Institutional Licensing'}
              </h2>
              <p className="text-xs text-ink-500">
                {isTa
                  ? 'விவசாயிகளுக்கு 100% இலவசம் • நிறுவனங்கள் மற்றும் FPO-க்களுக்கான பிரத்யேக சேவைகள்'
                  : '100% Free for Smallholder Farmers • Enterprise & FPO Sustainability Models'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl p-2 text-ink-400 hover:bg-ink-100 hover:text-ink-700 transition"
            aria-label="Close modal"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="overflow-y-auto p-6 space-y-6">
          {/* Ethical Farmer Commitment Alert */}
          <div className="flex items-start gap-3 rounded-2xl border border-leaf-300 bg-leaf-50/70 p-4 text-xs text-leaf-950">
            <Shield className="mt-0.5 h-5 w-5 shrink-0 text-leaf-700" />
            <div className="space-y-1">
              <p className="font-bold text-sm text-leaf-900">
                {isTa ? '🌾 விவசாயிகளுக்கான நமது நெறிமுறை உறுதிமொழி:' : '🌾 Our Uncompromising Farmer Commitment:'}
              </p>
              <p className="leading-relaxed">
                {isTa
                  ? 'பயிர் பாதுகாப்பு எச்சரிக்கைகள், மத்திய அரசால் தடைசெய்யப்பட்ட பூச்சிக்கொல்லி தடுப்பு மற்றும் தமிழ்நாடு வேளாண்மைப் பல்கலைக்கழக (TNAU) ஆதார ஆவணங்கள் எப்போதுமே கட்டணமின்றி 100% இலவசமாகவே இருக்கும். நமது இயங்குதளம் உழவர் உற்பத்தியாளர் நிறுவனங்கள் (FPO) மற்றும் பெருநிறுவன B2B சந்தாக்கள் மூலமாக நிலைநிறுத்தப்படுகிறது.'
                  : 'Agricultural safety warnings, banned pesticide alerts, and university evidence citations will NEVER be locked behind a paywall. AGRIKNOW AI is funded through enterprise B2B licensing, institutional FPO partnerships, and research grants — keeping smallholder access free forever.'}
              </p>
            </div>
          </div>

          {/* Billing Toggle Switch */}
          <div className="flex items-center justify-center gap-3">
            <span
              className={`text-xs font-semibold ${
                billingCycle === 'monthly' ? 'text-ink-900' : 'text-ink-400'
              }`}
            >
              {isTa ? 'மாதாந்திர கட்டணம்' : 'Monthly Billing'}
            </span>
            <button
              type="button"
              role="switch"
              aria-checked={billingCycle === 'annual'}
              aria-label={isTa ? 'ஆண்டு கட்டண முறைக்கு மாற்று' : 'Switch to annual billing'}
              onClick={() => setBillingCycle((prev) => (prev === 'monthly' ? 'annual' : 'monthly'))}
              className="relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent bg-leaf-600 transition-colors duration-200 ease-in-out focus:outline-none"
            >
              <span
                className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition duration-200 ease-in-out ${
                  billingCycle === 'annual' ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
            <div className="flex items-center gap-1.5">
              <span
                className={`text-xs font-semibold ${
                  billingCycle === 'annual' ? 'text-ink-900' : 'text-ink-400'
                }`}
              >
                {isTa ? 'வருடாந்திர கட்டணம்' : 'Annual Billing'}
              </span>
              <span className="rounded-full bg-clay-100 px-2 py-0.5 text-[10px] font-bold text-clay-800">
                {isTa ? '2 மாதங்கள் இலவசம்' : 'Save ~17%'}
              </span>
            </div>
          </div>

          {/* Pricing Cards Grid */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {BUSINESS_PRICING_PLANS.map((plan: PricingPlan) => {
              const isFree = plan.priceMonthlyInr === 0;
              const displayPrice = isFree
                ? '₹0'
                : billingCycle === 'annual'
                ? `₹${Math.round(plan.priceAnnualInr / 12).toLocaleString('en-IN')}`
                : `₹${plan.priceMonthlyInr.toLocaleString('en-IN')}`;

              return (
                <Card
                  key={plan.id}
                  className={`flex flex-col justify-between p-5 transition ${
                    plan.highlighted
                      ? 'border-2 border-leaf-500 bg-white ring-4 ring-leaf-100 shadow-md'
                      : 'border border-ink-200 bg-white hover:border-ink-300'
                  }`}
                >
                  <div className="space-y-4">
                    {/* Header */}
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-ink-400">
                          {plan.id === 'tier-farmer-free'
                            ? isTa
                              ? 'விவசாயி'
                              : 'Smallholder'
                            : plan.id === 'tier-fpo-pro'
                            ? 'FPO / PACS'
                            : plan.id === 'tier-agribusiness-enterprise'
                            ? 'Enterprise'
                            : 'University'}
                        </span>
                        {plan.highlighted && (
                          <Badge tone="success">
                            {isTa ? 'அனைவருக்கும் இலவசம்' : 'Free Forever'}
                          </Badge>
                        )}
                      </div>
                      <h3 className="mt-1 text-base font-bold text-ink-900">
                        {isTa ? plan.nameTa : plan.name}
                      </h3>
                      <p className="mt-1 text-xs text-ink-500 line-clamp-2">
                        {isTa ? plan.targetSegmentTa : plan.targetSegment}
                      </p>
                    </div>

                    {/* Price */}
                    <div className="border-y border-ink-100 py-3">
                      <div className="flex items-baseline gap-1">
                        <span className="text-2xl font-black text-ink-900">{displayPrice}</span>
                        {!isFree && (
                          <span className="text-xs text-ink-500">
                            /{isTa ? 'மாதம்' : 'month'}
                          </span>
                        )}
                      </div>
                      <p className="mt-0.5 text-[11px] text-ink-400">
                        {isFree
                          ? isTa
                            ? 'கட்டணம் எதுவும் இல்லை'
                            : 'No credit card required'
                          : billingCycle === 'annual'
                          ? isTa
                            ? `வருடத்திற்கு ₹${plan.priceAnnualInr.toLocaleString('en-IN')} (ஒருங்கிணைந்த பில்லிங்)`
                            : `Billed annually (₹${plan.priceAnnualInr.toLocaleString('en-IN')}/yr)`
                          : isTa
                          ? 'மாதாந்திர பில்லிங்'
                          : 'Billed monthly'}
                      </p>
                    </div>

                    {/* Features list */}
                    <ul className="space-y-2">
                      {(isTa ? plan.featuresTa : plan.features).map((feat, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-xs text-ink-700">
                          <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-leaf-600" />
                          <span className="leading-tight">{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* CTA Button */}
                  <div className="mt-6 pt-2">
                    {isFree ? (
                      <button
                        type="button"
                        onClick={onClose}
                        className="w-full rounded-xl bg-leaf-600 py-2.5 text-xs font-bold text-white hover:bg-leaf-700 transition shadow-xs"
                      >
                        {isTa ? 'நடப்பு இலவச திட்டம் (செயலில் உள்ளது)' : 'Active Plan (Current)'}
                      </button>
                    ) : (
                      <a
                        href="mailto:partnerships@agriknow.ai?subject=Inquiry for AGRIKNOW AI Institutional Tier"
                        className="inline-flex w-full items-center justify-center gap-1.5 rounded-xl border border-ink-300 bg-white py-2.5 text-xs font-bold text-ink-900 hover:bg-ink-50 transition shadow-xs"
                      >
                        {plan.id === 'tier-fpo-pro' ? (
                          <Users className="h-3.5 w-3.5 text-leaf-700" />
                        ) : plan.id === 'tier-agribusiness-enterprise' ? (
                          <Building2 className="h-3.5 w-3.5 text-clay-700" />
                        ) : (
                          <GraduationCap className="h-3.5 w-3.5 text-lilac-700" />
                        )}
                        <span>{isTa ? 'தொடர்பு கொள்க' : 'Contact Sales / Pilot'}</span>
                      </a>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>

          {/* Compliance & DPDP Act footnote */}
          <div className="flex items-center justify-between rounded-xl bg-ink-50 px-4 py-3 text-[11px] text-ink-500">
            <div className="flex items-center gap-1.5">
              <Info className="h-3.5 w-3.5 text-ink-400" />
              <span>
                {isTa
                  ? 'இந்திய டிஜிட்டல் தனிநபர் தரவுப் பாதுகாப்பு சட்டம் 2023 (DPDP Act) மற்றும் பூச்சிக்கொல்லி சட்டம் 1968-க்கு இணங்க செயல்படுகிறது.'
                  : 'Compliant with Digital Personal Data Protection Act 2023 (DPDP) and Insecticides Act 1968.'}
              </span>
            </div>
            <span className="font-semibold text-ink-700">GST Invoice Ready</span>
          </div>
        </div>
      </div>
    </div>
  );
}
