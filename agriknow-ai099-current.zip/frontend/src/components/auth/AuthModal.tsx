import { useState, type FormEvent } from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, CheckCircle2, KeyRound, Lock, Mail, MapPin, Phone, UserRound, X, Database } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useToast } from '@/contexts/ToastContext';
import { buttonClass } from '@/components/ui/Button';

const tnDistricts = [
  'Thanjavur',
  'Tiruvarur',
  'Nagapattinam',
  'Tiruchirappalli',
  'Madurai',
  'Coimbatore',
  'Erode',
  'Salem',
  'Dharmapuri',
  'Tirunelveli',
  'Villupuram',
  'Cuddalore',
  'Theni',
  'Dindigul',
  'Pudukkottai',
];

export function AuthModal() {
  const {
    isAuthModalOpen,
    closeAuthModal,
    authModalMode,
    openAuthModal,
    signIn,
    signUp,
    resetPassword,
    isLoading,
    isConfigured,
  } = useAuth();
  const { lang } = useLanguage();
  const { show } = useToast();
  const isTa = lang === 'ta';

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [district, setDistrict] = useState('Thanjavur');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isAuthModalOpen) return null;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!isConfigured) {
      setErrorMessage(
        isTa
          ? 'கிளவுட் டேட்டாபேஸ் இன்னும் இணைக்கப்படவில்லை. தயவுசெய்து .env கோப்பில் VITE_SUPABASE_URL மற்றும் VITE_SUPABASE_ANON_KEY ஐ உள்ளிடவும்.'
          : 'Cloud database is not yet configured. Please add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your .env file.'
      );
      return;
    }

    if (authModalMode === 'login') {
      const res = await signIn(email, password);
      if (res.error) {
        setErrorMessage(res.error);
      } else {
        show(isTa ? 'வெற்றிகரமாக உள்நுழைந்துள்ளீர்கள்' : 'Successfully signed in', {
          tone: 'success',
        });
      }
    } else if (authModalMode === 'register') {
      if (!fullName.trim()) {
        setErrorMessage(isTa ? 'உங்கள் பெயரை உள்ளிடவும்' : 'Please enter your full name');
        return;
      }
      const res = await signUp(email, password, fullName, phone, district);
      if (res.error) {
        setErrorMessage(res.error);
      } else {
        show(isTa ? 'பதிவு முடிந்தது! உங்கள் மின்னஞ்சலைச் சரிபார்க்கவும்' : 'Registration complete! Check your email to confirm.', {
          tone: 'success',
        });
      }
    } else if (authModalMode === 'reset') {
      const res = await resetPassword(email);
      if (res.error) {
        setErrorMessage(res.error);
      } else {
        setSuccessMessage(
          isTa
            ? 'கடவுச்சொல் மீட்பு இணைப்பு உங்கள் மின்னஞ்சலுக்கு அனுப்பப்பட்டது.'
            : 'Password reset link has been dispatched to your email address.'
        );
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={closeAuthModal}
        className="fixed inset-0 bg-ink-900/60 backdrop-blur-sm"
      />

      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 16 }}
        className="relative z-10 w-full max-w-md overflow-hidden rounded-3xl border border-ink-200/80 bg-white p-6 shadow-lift sm:p-8"
      >
        <button
          type="button"
          onClick={closeAuthModal}
          className="absolute right-5 top-5 rounded-full p-2 text-ink-400 transition hover:bg-ink-100 hover:text-ink-700"
          aria-label="Close"
        >
          <X className="h-5 w-5" aria-hidden />
        </button>

        <div className="flex items-center gap-3">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-leaf-100 text-leaf-800">
            {authModalMode === 'reset' ? (
              <KeyRound className="h-6 w-6" aria-hidden />
            ) : (
              <UserRound className="h-6 w-6" aria-hidden />
            )}
          </span>
          <div>
            <h2 className="text-xl font-bold text-ink-900">
              {authModalMode === 'login' && (isTa ? 'உழவர் உள்நுழைவு' : 'Farmer Login')}
              {authModalMode === 'register' && (isTa ? 'புதிய உழவர் பதிவு' : 'Farmer Registration')}
              {authModalMode === 'reset' && (isTa ? 'கடவுச்சொல் மீட்பு' : 'Password Recovery')}
            </h2>
            <p className="text-xs text-ink-500">
              {isTa ? 'AGRIKNOW கிளவுட் கணக்கு' : 'AGRIKNOW Cloud Farm Account'}
            </p>
          </div>
        </div>

        {!isConfigured && (
          <div className="mt-4 rounded-xl border border-sun-200 bg-sun-50 p-3.5 text-xs text-sun-900 leading-relaxed">
            <p className="flex items-center gap-1.5 font-bold">
              <Database className="h-4 w-4 text-sun-700 shrink-0" aria-hidden />
              {isTa ? 'கிளவுட் டேட்டாபேஸ் அமைப்பு' : 'Cloud Database Setup Required'}
            </p>
            <p className="mt-1 text-ink-700">
              {isTa
                ? 'நேரடி அங்கீகாரம் மற்றும் டேட்டாபேஸ் இணைப்பிற்கு VITE_SUPABASE_URL மற்றும் VITE_SUPABASE_ANON_KEY ஐ .env கோப்பில் உள்ளிடவும்.'
                : 'To enable cloud authentication and sync across devices, provide VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your .env file.'}
            </p>
          </div>
        )}

        {errorMessage && (
          <div className="mt-4 flex items-start gap-2 rounded-xl bg-danger-50 p-3 text-xs font-medium text-danger-700">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" aria-hidden />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="mt-4 flex items-start gap-2 rounded-xl bg-leaf-50 p-3 text-xs font-medium text-leaf-800">
            <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" aria-hidden />
            <span>{successMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          {authModalMode === 'register' && (
            <div>
              <label className="text-xs font-semibold text-ink-800">
                {isTa ? 'முழு பெயர்' : 'Full Name'}
              </label>
              <div className="relative mt-1">
                <UserRound className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
                <input
                  required
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder={isTa ? 'எ.கா: முருகன் செல்வம்' : 'e.g. Murugan Selvam'}
                  className="h-11 w-full rounded-xl border border-ink-200 pl-10 pr-4 text-sm focus:border-leaf-500 focus:outline-none"
                />
              </div>
            </div>
          )}

          <div>
            <label className="text-xs font-semibold text-ink-800">
              {isTa ? 'மின்னஞ்சல் முகவரி' : 'Email Address'}
            </label>
            <div className="relative mt-1">
              <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
              <input
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="farmer@agriknow.in"
                className="h-11 w-full rounded-xl border border-ink-200 pl-10 pr-4 text-sm focus:border-leaf-500 focus:outline-none"
              />
            </div>
          </div>

          {authModalMode !== 'reset' && (
            <div>
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-ink-800">
                  {isTa ? 'கடவுச்சொல்' : 'Password'}
                </label>
                {authModalMode === 'login' && (
                  <button
                    type="button"
                    onClick={() => openAuthModal('reset')}
                    className="text-xs font-medium text-leaf-700 hover:underline"
                  >
                    {isTa ? 'கடவுச்சொல் மறந்துவிட்டதா?' : 'Forgot password?'}
                  </button>
                )}
              </div>
              <div className="relative mt-1">
                <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
                <input
                  required
                  type="password"
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="h-11 w-full rounded-xl border border-ink-200 pl-10 pr-4 text-sm focus:border-leaf-500 focus:outline-none"
                />
              </div>
            </div>
          )}

          {authModalMode === 'register' && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-ink-800">
                  {isTa ? 'மொபைல்' : 'Mobile'}
                </label>
                <div className="relative mt-1">
                  <Phone className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
                  <input
                    type="tel"
                    maxLength={10}
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                    placeholder="9842012345"
                    className="h-11 w-full rounded-xl border border-ink-200 pl-10 pr-3 text-sm focus:border-leaf-500 focus:outline-none"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold text-ink-800">
                  {isTa ? 'மாவட்டம்' : 'District'}
                </label>
                <div className="relative mt-1">
                  <MapPin className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
                  <select
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    className="h-11 w-full rounded-xl border border-ink-200 bg-white pl-10 pr-3 text-xs focus:border-leaf-500 focus:outline-none"
                  >
                    {tnDistricts.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className={`w-full ${buttonClass('primary', 'lg', 'mt-2')} disabled:opacity-50`}
          >
            {isLoading
              ? (isTa ? 'செயலாக்குகிறது...' : 'Processing...')
              : authModalMode === 'login'
              ? (isTa ? 'உள்நுழை' : 'Sign In')
              : authModalMode === 'register'
              ? (isTa ? 'பதிவு செய்' : 'Register Account')
              : (isTa ? 'மீட்பு இணைப்பு அனுப்பு' : 'Send Recovery Link')}
          </button>
        </form>

        <div className="mt-6 border-t border-ink-100 pt-4 text-center text-xs text-ink-600">
          {authModalMode === 'login' ? (
            <p>
              {isTa ? 'கணக்கு இல்லையா?' : "Don't have an account?"}{' '}
              <button
                type="button"
                onClick={() => openAuthModal('register')}
                className="font-bold text-leaf-700 hover:underline"
              >
                {isTa ? 'இலவசமாக பதிவு செய்' : 'Register now'}
              </button>
            </p>
          ) : (
            <p>
              {isTa ? 'ஏற்கனவே கணக்கு உள்ளதா?' : 'Already have an account?'}{' '}
              <button
                type="button"
                onClick={() => openAuthModal('login')}
                className="font-bold text-leaf-700 hover:underline"
              >
                {isTa ? 'உள்நுழையவும்' : 'Sign in'}
              </button>
            </p>
          )}
        </div>
      </motion.div>
    </div>
  );
}
