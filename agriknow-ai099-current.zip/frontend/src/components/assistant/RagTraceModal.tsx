import { useState } from 'react';
import {
  X,
  Activity,
  Layers,
  Network,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Clock,
  Sparkles,
  Search,
} from 'lucide-react';
import type { RagExecutionTrace } from '@/services/rag/advancedRagEngine';
import { useLanguage } from '@/contexts/LanguageContext';

interface RagTraceModalProps {
  trace: RagExecutionTrace;
  onClose: () => void;
}

export function RagTraceModal({ trace, onClose }: RagTraceModalProps) {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';

  const [activeTab, setActiveTab] = useState<
    'overview' | 'hybrid' | 'graph' | 'rerank' | 'evidence' | 'context'
  >('overview');

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/60 p-4 backdrop-blur-sm animate-fade-in"
    >
      <div className="relative flex max-h-[92vh] w-full max-w-5xl flex-col rounded-2xl bg-white shadow-2xl overflow-hidden border border-ink-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-ink-200 bg-ink-900 px-6 py-4 text-white">
          <div className="flex items-center gap-3 min-w-0">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-leaf-500 text-white font-bold">
              <Activity className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold truncate">
                  {isTa ? 'RAG செயலாக்க கண்காணிப்பு ஆய்வுக்கூடம்' : 'RAG Engine Observability & Execution Trace'}
                </h2>
                <span className="rounded bg-aqua-400/20 px-2 py-0.5 text-[11px] font-mono font-bold text-aqua-300">
                  {trace.latencyMs.total} ms
                </span>
                <span
                  className={`rounded px-2 py-0.5 text-[10px] font-bold uppercase ${
                    trace.cragDecision === 'PASSED'
                      ? 'bg-leaf-500/20 text-leaf-300'
                      : trace.cragDecision === 'REFORMULATED'
                      ? 'bg-sun-500/20 text-sun-300'
                      : 'bg-red-500/20 text-red-300'
                  }`}
                >
                  CRAG: {trace.cragDecision}
                </span>
              </div>
              <p className="truncate text-xs text-ink-300">
                &ldquo;{trace.originalQuery}&rdquo;
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-ink-400 hover:bg-ink-800 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 border-b border-ink-200 bg-ink-50 px-6 py-2 overflow-x-auto no-scrollbar text-xs font-bold text-ink-600">
          {[
            { id: 'overview', label: isTa ? 'கண்ணோட்டம்' : 'Pipeline Overview', icon: Sparkles },
            { id: 'hybrid', label: isTa ? 'கலப்பின தேடல் (RRF)' : 'Hybrid Retrieval & RRF', icon: Search },
            { id: 'graph', label: isTa ? 'அறிவு வரைபடம் (Graph RAG)' : 'Graph RAG Traversal', icon: Network },
            { id: 'rerank', label: isTa ? 'மறுதரவரிசை (Cross-Encoder)' : 'Cross-Encoder Rerank', icon: Layers },
            { id: 'evidence', label: isTa ? 'சான்றுகள் & பக்கங்கள்' : 'Claims & Citations', icon: CheckCircle2 },
            { id: 'context', label: isTa ? 'அனுப்பப்பட்ட சூழல்' : 'LLM Grounded Buffer', icon: FileText },
          ].map((tab) => {
            const active = activeTab === tab.id;
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 transition whitespace-nowrap ${
                  active ? 'bg-white text-ink-900 shadow-sm border border-ink-200' : 'hover:bg-ink-100'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Latency Breakdown Bar */}
              <div className="rounded-xl border border-ink-200 bg-ink-50 p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-ink-900 flex items-center gap-1.5">
                    <Clock className="h-4 w-4 text-leaf-600" />
                    {isTa ? 'செயல்திறன் மற்றும் தாமத விவரம்' : 'Stage Latency Breakdown'}
                  </span>
                  <span className="font-mono text-xs font-bold text-leaf-800">
                    Total: {trace.latencyMs.total} ms
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-5 text-center text-xs">
                  <div className="rounded-lg bg-white p-2 border border-ink-200">
                    <span className="text-[10px] text-ink-500 block">Query Analysis</span>
                    <span className="font-mono font-bold text-ink-900">{trace.latencyMs.queryUnderstanding} ms</span>
                  </div>
                  <div className="rounded-lg bg-white p-2 border border-ink-200">
                    <span className="text-[10px] text-ink-500 block">Hybrid Search</span>
                    <span className="font-mono font-bold text-ink-900">{trace.latencyMs.hybridRetrieval} ms</span>
                  </div>
                  <div className="rounded-lg bg-white p-2 border border-ink-200">
                    <span className="text-[10px] text-ink-500 block">Graph Traversal</span>
                    <span className="font-mono font-bold text-ink-900">{trace.latencyMs.graphTraversal} ms</span>
                  </div>
                  <div className="rounded-lg bg-white p-2 border border-ink-200">
                    <span className="text-[10px] text-ink-500 block">Cross-Encoder</span>
                    <span className="font-mono font-bold text-ink-900">{trace.latencyMs.reranking} ms</span>
                  </div>
                  <div className="rounded-lg bg-white p-2 border border-ink-200">
                    <span className="text-[10px] text-ink-500 block">Synthesis</span>
                    <span className="font-mono font-bold text-ink-900">{trace.latencyMs.generation} ms</span>
                  </div>
                </div>
              </div>

              {/* Query Understanding Card */}
              <div className="rounded-xl border border-ink-200 bg-white p-5 space-y-4">
                <h3 className="text-sm font-bold text-ink-900">
                  {isTa ? '1. வினவல் புரிதல் & உருமாற்றம்' : '1. Query Understanding & Transformation'}
                </h3>
                <div className="grid gap-3 sm:grid-cols-2 text-xs">
                  <div className="rounded-lg bg-ink-50 p-3">
                    <span className="text-ink-500 font-bold block mb-1">Normalized Agronomic Query</span>
                    <p className="font-mono text-ink-800">{trace.normalizedQuery}</p>
                  </div>
                  <div className="rounded-lg bg-ink-50 p-3">
                    <span className="text-ink-500 font-bold block mb-1">Detected Intent & Language</span>
                    <p className="font-semibold text-leaf-800">
                      Intent: {trace.queryAnalysis.intent} ({Math.round(trace.queryAnalysis.confidence * 100)}% conf) • Lang: {trace.detectedLanguage.toUpperCase()}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 text-xs">
                  <span className="font-bold text-ink-600">Extracted Entities:</span>
                  {(trace.queryAnalysis?.extractedEntities?.crops || []).map((c) => (
                    <span key={c} className="rounded-full bg-leaf-100 px-2.5 py-0.5 font-bold text-leaf-800">
                      Crop: {c}
                    </span>
                  ))}
                  {(trace.queryAnalysis?.extractedEntities?.diseases || []).map((d) => (
                    <span key={d} className="rounded-full bg-sun-100 px-2.5 py-0.5 font-bold text-sun-900">
                      Disease: {d}
                    </span>
                  ))}
                  {(trace.queryAnalysis?.extractedEntities?.pests || []).map((p) => (
                    <span key={p} className="rounded-full bg-red-100 px-2.5 py-0.5 font-bold text-red-800">
                      Pest: {p}
                    </span>
                  ))}
                  {(trace.queryAnalysis?.extractedEntities?.nutrients || []).map((n) => (
                    <span key={n} className="rounded-full bg-aqua-100 px-2.5 py-0.5 font-bold text-aqua-900">
                      Nutrient: {n}
                    </span>
                  ))}
                </div>
              </div>

              {/* CRAG Decision Card */}
              <div className="rounded-xl border border-ink-200 bg-white p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-ink-900">
                    {isTa ? '2. சரியான RAG தர மதிப்பீடு (CRAG Guardrail)' : '2. Corrective RAG Evaluation (CRAG)'}
                  </h3>
                  <span className="text-xs font-mono font-bold text-leaf-700">
                    Relevance Score: {trace.cragScore}
                  </span>
                </div>
                <p className="text-xs text-ink-600">
                  Decision: <strong>{trace.cragDecision}</strong> — {trace.reformationNotes || 'Evidence exceeded sufficiency confidence thresholds.'}
                </p>
                {trace.hasContradictions && (
                  <div className="rounded-lg border border-sun-300 bg-sun-50 p-3 text-xs text-sun-900 flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 text-sun-600 shrink-0 mt-0.5" />
                    <span>{trace.contradictionNotes}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: HYBRID RETRIEVAL & RRF */}
          {activeTab === 'hybrid' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-ink-900">
                  {isTa ? 'கலப்பின மீட்டெடுப்பு & மறுநிலை இணைவு (RRF Candidates)' : 'Hybrid Candidates Ranked via Reciprocal Rank Fusion'}
                </h3>
                <span className="text-xs text-ink-500 font-mono">Formula: 1/(60+r_vector) + 1/(60+r_bm25)</span>
              </div>

              <div className="overflow-x-auto rounded-xl border border-ink-200">
                <table className="w-full text-left text-xs">
                  <thead className="bg-ink-50 border-b border-ink-200 font-bold text-ink-700">
                    <tr>
                      <th className="p-3">Rank</th>
                      <th className="p-3">Source & Page</th>
                      <th className="p-3">Vector Score</th>
                      <th className="p-3">BM25 Score</th>
                      <th className="p-3">Combined RRF</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-100">
                    {trace.hybridCandidates.map((c) => (
                      <tr key={c.chunk.id} className="hover:bg-ink-50">
                        <td className="p-3 font-bold font-mono">#{c.combinedRank}</td>
                        <td className="p-3">
                          <p className="font-bold text-ink-900">{c.chunk.documentTitle}</p>
                          <p className="text-[11px] text-ink-500">Page {c.chunk.pageNumber} • {c.chunk.sourceInstitution}</p>
                        </td>
                        <td className="p-3 font-mono">
                          {c.vectorScore} <span className="text-[10px] text-ink-400">(#{c.vectorRank})</span>
                        </td>
                        <td className="p-3 font-mono">
                          {c.bm25Score} <span className="text-[10px] text-ink-400">({c.bm25Rank ? `#${c.bm25Rank}` : 'unranked'})</span>
                        </td>
                        <td className="p-3 font-mono font-bold text-leaf-700">{c.rrfScore}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: GRAPH RAG */}
          {activeTab === 'graph' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-ink-900">
                {isTa ? 'வேளாண் அறிவு வரைபடத்தின் இணைப்புகள் (Graph RAG Traversal)' : 'Agricultural Knowledge Graph Subgraph Traversal'}
              </h3>
              {trace.graphTraversal && trace.graphTraversal.relationalContext.length > 0 ? (
                <div className="space-y-3">
                  <div className="grid gap-2 sm:grid-cols-2">
                    {trace.graphTraversal.edges.map((edge, idx) => (
                      <div key={idx} className="rounded-xl border border-lilac-200 bg-lilac-50/60 p-3 text-xs space-y-1">
                        <div className="flex items-center justify-between font-bold text-lilac-900">
                          <span>{edge.sourceId.replace(/^[a-z]+_/, '')}</span>
                          <span className="rounded bg-lilac-200 px-1.5 py-0.5 text-[10px] text-lilac-800">
                            {edge.relation}
                          </span>
                          <span>{edge.targetId.replace(/^[a-z]+_/, '')}</span>
                        </div>
                        <p className="text-ink-700">{edge.description}</p>
                        <p className="text-[10px] text-ink-500 font-mono">
                          Citation: {edge.sourceDocId}, Page {edge.pageNumber}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-8 text-center text-xs text-ink-500">
                  {isTa ? 'இந்த வினவலுக்கு வரைபட இணைப்புகள் எதுவும் தேவையில்லை.' : 'No relational graph expansion required for this single-hop query.'}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: CROSS-ENCODER RERANK */}
          {activeTab === 'rerank' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-ink-900">
                {isTa ? 'Cross-Encoder மறுதரவரிசை முடிவுகள்' : 'Cross-Encoder Reranker Re-Scoring'}
              </h3>
              <div className="overflow-x-auto rounded-xl border border-ink-200">
                <table className="w-full text-left text-xs">
                  <thead className="bg-ink-50 border-b border-ink-200 font-bold text-ink-700">
                    <tr>
                      <th className="p-3">Final Rank</th>
                      <th className="p-3">Document & Page</th>
                      <th className="p-3">Initial Rank</th>
                      <th className="p-3">Semantic Alignment</th>
                      <th className="p-3">Entity Coverage</th>
                      <th className="p-3">Final Score</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-100">
                    {trace.rerankedResults.map((r) => (
                      <tr key={r.chunk.id} className="hover:bg-ink-50">
                        <td className="p-3 font-bold font-mono text-leaf-800">#{r.rerankedRank}</td>
                        <td className="p-3">
                          <p className="font-bold text-ink-900">{r.chunk.documentTitle}</p>
                          <p className="text-[11px] text-ink-500">Page {r.chunk.pageNumber} • {r.chunk.sourceInstitution}</p>
                        </td>
                        <td className="p-3 font-mono">#{r.initialRank}</td>
                        <td className="p-3 font-mono">{r.semanticAlignment}</td>
                        <td className="p-3 font-mono">{r.entityCoverage}</td>
                        <td className="p-3 font-mono font-bold text-ink-900">{r.crossEncoderScore}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 5: EVIDENCE & CITATIONS */}
          {activeTab === 'evidence' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-ink-900">
                {isTa ? 'உறுதிப்படுத்தப்பட்ட கூற்றுகள் & சான்றுகள்' : 'Claim-to-Evidence Association (100% Traceable)'}
              </h3>
              <div className="space-y-3">
                {trace.evidenceList.map((e, idx) => (
                  <div key={idx} className="rounded-xl border border-ink-200 bg-white p-4 space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold text-ink-800">
                      <span className="flex items-center gap-1.5 text-leaf-700">
                        <CheckCircle2 className="h-4 w-4" />
                        Evidence #{idx + 1}: {e.documentTitle}
                      </span>
                      <span className="rounded bg-ink-100 px-2 py-0.5 text-ink-700">Page {e.pageNumber}</span>
                    </div>
                    <p className="font-mono text-xs text-ink-800 bg-ink-50 p-3 rounded-lg leading-relaxed">
                      {e.excerpt}
                    </p>
                    <div className="flex items-center justify-between text-[10px] text-ink-500">
                      <span>Publisher: {e.sourceInstitution}</span>
                      <span>Cross-Encoder Relevance: {e.relevanceScore}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: CONTEXT BUFFER */}
          {activeTab === 'context' && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-ink-900">
                {isTa ? 'LLM ஜெனரேட்டருக்கு அனுப்பப்பட்ட சரிபார்க்கப்பட்ட சூழல்' : 'Context Buffer Injected into LLM Synthesis'}
              </h3>
              <div className="rounded-xl border border-ink-800 bg-ink-900 p-4 font-mono text-xs text-aqua-300 leading-relaxed max-h-96 overflow-y-auto whitespace-pre-wrap">
                {trace.groundedContextText}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-ink-200 bg-ink-50 px-6 py-3">
          <span className="font-mono text-xs text-ink-500">
            Trace ID: {trace.id}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-ink-900 px-4 py-2 text-xs font-bold text-white hover:bg-ink-800 transition"
          >
            {isTa ? 'மூடு' : 'Close Trace View'}
          </button>
        </div>
      </div>
    </div>
  );
}
