import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, MicOff, Send, X, Volume2, Globe } from 'lucide-react';
import type { Lang } from '@/lib/i18n';

interface VoiceInputModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTranscriptReady: (transcript: string) => void;
  currentLang: Lang;
}

interface SpeechRecognitionEvent {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: {
      isFinal: boolean;
      [index: number]: {
        transcript: string;
      };
    };
  };
}

interface SpeechRecognitionInstance {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onstart: () => void;
  onresult: (event: SpeechRecognitionEvent) => void;
  onerror: (event: { error: string }) => void;
  onend: () => void;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

export function VoiceInputModal({
  isOpen,
  onClose,
  onTranscriptReady,
  currentLang,
}: VoiceInputModalProps) {
  const [selectedLang, setSelectedLang] = useState<'ta' | 'en'>(currentLang === 'ta' ? 'ta' : 'en');
  const [transcript, setTranscript] = useState('');
  const [interimText, setInterimText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const recognitionRef = useRef<SpeechRecognitionInstance | null>(null);

  useEffect(() => {
    setSelectedLang(currentLang === 'ta' ? 'ta' : 'en');
  }, [currentLang]);

  useEffect(() => {
    if (!isOpen) {
      if (recognitionRef.current && isListening) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      setTranscript('');
      setInterimText('');
      setErrorMessage(null);
      return;
    }

    startListening(selectedLang);

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {
          // ignore
        }
      }
    };
  }, [isOpen, selectedLang]);

  const startListening = (langCode: 'ta' | 'en') => {
    setErrorMessage(null);
    setTranscript('');
    setInterimText('');

    type WindowWithSpeech = Window & {
      SpeechRecognition?: new () => SpeechRecognitionInstance;
      webkitSpeechRecognition?: new () => SpeechRecognitionInstance;
    };
    const SpeechRecognition =
      (window as unknown as WindowWithSpeech).SpeechRecognition ||
      (window as unknown as WindowWithSpeech).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setErrorMessage(
        langCode === 'ta'
          ? 'இந்த உலாவியில் குரல் உள்ளீடு ஆதரிக்கப்படவில்லை. தயவுசெய்து Google Chrome பயன்படுத்தவும்.'
          : 'Speech recognition is not supported in this browser. Please use Google Chrome.'
      );
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = langCode === 'ta' ? 'ta-IN' : 'en-IN';
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: SpeechRecognitionEvent) => {
        let finalStr = '';
        let interimStr = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const res = event.results[i];
          if (res.isFinal) {
            finalStr += res[0].transcript + ' ';
          } else {
            interimStr += res[0].transcript;
          }
        }

        if (finalStr) {
          setTranscript((prev) => (prev ? `${prev} ${finalStr}` : finalStr).trim());
        }
        setInterimText(interimStr);
      };

      recognition.onerror = (e: { error: string }) => {
        if (e.error === 'no-speech') {
          // silence, continue
          return;
        }
        if (e.error === 'not-allowed') {
          setErrorMessage(
            langCode === 'ta'
              ? 'மைக்ரோஃபோன் அனுமதி மறுக்கப்பட்டது. பிரவுசர் அமைப்பில் மைக்கை இயக்கவும்.'
              : 'Microphone permission was denied. Please allow microphone access.'
          );
        } else {
          setErrorMessage(
            langCode === 'ta'
              ? 'குரல் உள்ளீட்டில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்.'
              : 'Voice recognition error. Please try speaking again.'
          );
        }
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      setErrorMessage(
        langCode === 'ta'
          ? 'குரல் உள்ளீட்டைத் தொடங்க முடியவில்லை.'
          : 'Could not start voice recognition service.'
      );
      setIsListening(false);
    }
  };

  const toggleMic = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      startListening(selectedLang);
    }
  };

  const handleSend = () => {
    const fullText = (transcript + ' ' + interimText).trim();
    if (!fullText) return;
    onTranscriptReady(fullText);
    onClose();
  };

  if (!isOpen) return null;

  const currentDisplay = (transcript + ' ' + interimText).trim();

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-lg overflow-hidden rounded-3xl border border-leaf-200 bg-white shadow-2xl"
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-ink-100 bg-gradient-to-r from-leaf-50 via-white to-aqua-50 px-6 py-4">
            <div className="flex items-center gap-2.5">
              <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-leaf-500 text-white shadow-md shadow-leaf-500/30">
                <Mic className="h-5 w-5" />
              </span>
              <div>
                <h3 className="text-base font-bold text-ink-900">
                  {selectedLang === 'ta' ? 'குரல் வழி கேள்வி கேட்கவும்' : 'Voice Query Input'}
                </h3>
                <p className="text-xs text-ink-500">
                  {selectedLang === 'ta'
                    ? 'தமிழில் அல்லது ஆங்கிலத்தில் பேசலாம்'
                    : 'Speak in Tamil or English'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="rounded-full p-2 text-ink-400 hover:bg-ink-100 hover:text-ink-700 transition"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="p-6">
            {/* Language Selection Tabs */}
            <div className="mb-6 flex justify-center">
              <div className="inline-flex rounded-xl bg-ink-100 p-1">
                <button
                  type="button"
                  onClick={() => setSelectedLang('ta')}
                  className={`flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-bold transition ${
                    selectedLang === 'ta'
                      ? 'bg-leaf-600 text-white shadow-xs'
                      : 'text-ink-600 hover:text-ink-900'
                  }`}
                >
                  <Globe className="h-3.5 w-3.5" />
                  தமிழ் (Tamil - ta-IN)
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedLang('en')}
                  className={`flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-bold transition ${
                    selectedLang === 'en'
                      ? 'bg-leaf-600 text-white shadow-xs'
                      : 'text-ink-600 hover:text-ink-900'
                  }`}
                >
                  <Globe className="h-3.5 w-3.5" />
                  English (en-IN)
                </button>
              </div>
            </div>

            {/* Central Animated Mic Sphere */}
            <div className="flex flex-col items-center justify-center py-4">
              <div className="relative flex items-center justify-center">
                {isListening && (
                  <>
                    <motion.div
                      animate={{ scale: [1, 1.4, 1], opacity: [0.3, 0.7, 0.3] }}
                      transition={{ repeat: Infinity, duration: 1.8, ease: 'easeInOut' }}
                      className="absolute h-28 w-28 rounded-full bg-leaf-400/30"
                    />
                    <motion.div
                      animate={{ scale: [1, 1.7, 1], opacity: [0.1, 0.4, 0.1] }}
                      transition={{ repeat: Infinity, duration: 2.2, ease: 'easeInOut', delay: 0.3 }}
                      className="absolute h-36 w-36 rounded-full bg-leaf-300/20"
                    />
                  </>
                )}

                <button
                  type="button"
                  onClick={toggleMic}
                  className={`relative z-10 flex h-20 w-20 items-center justify-center rounded-full text-white shadow-xl transition-transform active:scale-95 ${
                    isListening
                      ? 'bg-gradient-to-tr from-leaf-600 to-leaf-400 ring-4 ring-leaf-200'
                      : 'bg-ink-400 hover:bg-ink-500'
                  }`}
                  aria-label={isListening ? 'Stop recording' : 'Start recording'}
                >
                  {isListening ? (
                    <Mic className="h-9 w-9 animate-bounce" />
                  ) : (
                    <MicOff className="h-8 w-8" />
                  )}
                </button>
              </div>

              {/* Status Indicator */}
              <p className="mt-4 text-xs font-bold uppercase tracking-wider text-leaf-700">
                {isListening ? (
                  <span className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-full bg-leaf-500 animate-ping" />
                    {selectedLang === 'ta' ? 'கேட்கிறது... பேசவும்' : 'Listening... Speak now'}
                  </span>
                ) : (
                  <span className="text-ink-400">
                    {selectedLang === 'ta'
                      ? 'தொடங்க மைக்கை அழுத்தவும்'
                      : 'Tap mic to start speaking'}
                  </span>
                )}
              </p>
            </div>

            {/* Transcript Preview Box */}
            <div className="mt-4 min-h-[100px] max-h-36 overflow-y-auto rounded-2xl border border-ink-200 bg-ink-50/70 p-4 text-sm leading-relaxed text-ink-900">
              {currentDisplay ? (
                <p className="font-medium">{currentDisplay}</p>
              ) : (
                <p className="italic text-ink-400">
                  {selectedLang === 'ta'
                    ? 'எடுத்துக்காட்டு: "நெல்லில் குலை நோய் கட்டுப்பாடு என்ன?", "தக்காளி விலை இன்று என்ன?"'
                    : 'Example: "How to control stem borer in paddy?", "What is the tomato price today?"'}
                </p>
              )}
            </div>

            {errorMessage && (
              <p className="mt-2 text-xs font-medium text-danger-600">
                ⚠️ {errorMessage}
              </p>
            )}

            {/* Action Buttons */}
            <div className="mt-6 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => {
                  setTranscript('');
                  setInterimText('');
                }}
                disabled={!currentDisplay}
                className="rounded-xl border border-ink-200 px-4 py-2.5 text-xs font-semibold text-ink-600 transition hover:bg-ink-100 disabled:opacity-40"
              >
                {selectedLang === 'ta' ? 'அழி' : 'Clear'}
              </button>

              <button
                type="button"
                onClick={handleSend}
                disabled={!currentDisplay}
                className="flex items-center gap-2 rounded-xl bg-leaf-600 px-6 py-2.5 text-xs font-bold text-white shadow-md shadow-leaf-600/30 transition hover:bg-leaf-500 disabled:cursor-not-allowed disabled:bg-ink-200 disabled:text-ink-400 disabled:shadow-none"
              >
                <Send className="h-3.5 w-3.5" />
                {selectedLang === 'ta' ? 'கேள்வி கேள் (Ask AI)' : 'Ask AI Now'}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
