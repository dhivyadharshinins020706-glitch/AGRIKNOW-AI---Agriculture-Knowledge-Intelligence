import { FileText, X, Sparkles, ExternalLink } from 'lucide-react';
import type { AnalyzedDocument } from '@/types';
import type { Lang } from '@/lib/i18n';

interface ActiveDocumentCardProps {
  document: AnalyzedDocument;
  onRemove: () => void;
  onAskFollowUp: (question: string) => void;
  lang: Lang;
}

export function ActiveDocumentCard({
  document,
  onRemove,
  onAskFollowUp,
  lang,
}: ActiveDocumentCardProps) {
  const isTa = lang === 'ta';

  return (
    <div className="relative mb-3 overflow-hidden rounded-2xl border border-leaf-300 bg-gradient-to-r from-leaf-50 via-white to-aqua-50/70 p-3.5 shadow-xs">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-2.5 min-w-0">
          <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-leaf-500 text-white shadow-xs">
            <FileText className="h-4 w-4" />
          </span>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center rounded-md bg-leaf-100 px-2 py-0.5 text-[10px] font-bold text-leaf-800">
                {isTa ? document.categoryLabelTa : document.categoryLabelEn}
              </span>
              <span className="text-[11px] font-medium text-ink-500 truncate">
                {document.fileName}
              </span>
            </div>

            <p className="mt-1 text-xs font-bold text-ink-900 truncate">
              {document.crop ? `${document.crop}${document.variety ? ` — ${document.variety}` : ''}` : (isTa ? document.categoryLabelTa : document.categoryLabelEn)}
              {document.lotOrBatchNumber ? ` | Lot: ${document.lotOrBatchNumber}` : ''}
              {document.germinationPercent ? ` | ${isTa ? 'முளைப்பு' : 'Germination'}: ${document.germinationPercent}` : ''}
              {document.expiryDate ? ` | ${isTa ? 'காலாவதி' : 'Exp'}: ${document.expiryDate}` : ''}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onRemove}
          title={isTa ? 'ஆவணத்தை நீக்கு' : 'Remove active document'}
          className="rounded-lg p-1 text-ink-400 hover:bg-ink-100 hover:text-ink-700 transition"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Quick Prompt Chips for the Document */}
      <div className="mt-2.5 flex flex-wrap items-center gap-1.5 pt-1 border-t border-ink-100/70">
        <span className="text-[10px] font-bold uppercase tracking-wider text-ink-500 flex items-center gap-1">
          <Sparkles className="h-3 w-3 text-leaf-600" />
          {isTa ? 'ஆவணக் கேள்விகள்:' : 'Quick Questions:'}
        </span>

        <button
          type="button"
          onClick={() =>
            onAskFollowUp(
              isTa
                ? 'நான் என்ன ஆவணம் பதிவேற்றியுள்ளேன் மற்றும் இதில் என்ன தகவல் உள்ளது?'
                : 'What document did I upload and what is the information inside it?'
            )
          }
          className="rounded-full border border-leaf-200 bg-white px-2.5 py-0.5 text-[11px] font-medium text-leaf-900 transition hover:bg-leaf-100"
        >
          {isTa ? 'ஆவணம் விளக்கம்' : 'Explain Document'}
        </button>

        <button
          type="button"
          onClick={() =>
            onAskFollowUp(
              isTa
                ? 'இந்த விதையின் காலாவதி தேதி மற்றும் முளைப்புத் திறன் என்ன?'
                : 'What is the expiry date and germination capacity of this seed lot?'
            )
          }
          className="rounded-full border border-leaf-200 bg-white px-2.5 py-0.5 text-[11px] font-medium text-leaf-900 transition hover:bg-leaf-100"
        >
          {isTa ? 'முளைப்பு & காலாவதி' : 'Germination & Expiry'}
        </button>

        <button
          type="button"
          onClick={() =>
            onAskFollowUp(
              isTa
                ? 'விதை முளைக்காமல் போனால் விவசாயிக்கு என்ன சட்டப்பூர்வ உரிமைகள் உள்ளன?'
                : 'What are my legal rights if these seeds fail to germinate?'
            )
          }
          className="rounded-full border border-leaf-200 bg-white px-2.5 py-0.5 text-[11px] font-medium text-leaf-900 transition hover:bg-leaf-100"
        >
          {isTa ? 'சட்டப்பூர்வ உரிமைகள்' : 'Legal Rights'}
        </button>
      </div>
    </div>
  );
}
