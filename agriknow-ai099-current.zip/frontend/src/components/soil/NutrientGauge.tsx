import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/Badge';
import type { SoilNutrient } from '@/types';

interface NutrientGaugeProps {
  nutrient: SoilNutrient;
  delay?: number;
}

function status(nutrient: SoilNutrient): { label: string; tone: 'warning' | 'success' | 'info' } {
  if (nutrient.value < nutrient.low) return { label: 'Low, add more', tone: 'warning' };
  if (nutrient.value > nutrient.high) return { label: 'High, reduce', tone: 'info' };
  return { label: 'Balanced', tone: 'success' };
}

export function NutrientGauge({ nutrient, delay = 0 }: NutrientGaugeProps) {
  const toPercent = (value: number) => Math.min(100, (value / nutrient.max) * 100);
  const marker = toPercent(nutrient.value);
  const result = status(nutrient);

  return (
    <div>
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-base font-bold text-ink-900">{nutrient.label}</p>
          <p className="text-sm tabular-nums text-ink-500">
            {nutrient.value} {nutrient.unit}
          </p>
        </div>
        <Badge tone={result.tone}>{result.label}</Badge>
      </div>

      <div className="relative mt-6 pt-3">
        <div className="relative h-3 w-full overflow-hidden rounded-full bg-ink-100">
          <div className="absolute inset-y-0 left-0 bg-sun-300" style={{ width: `${toPercent(nutrient.low)}%` }} />
          <div
            className="absolute inset-y-0 bg-leaf-300"
            style={{ left: `${toPercent(nutrient.low)}%`, width: `${toPercent(nutrient.high) - toPercent(nutrient.low)}%` }}
          />
          <div className="absolute inset-y-0 bg-aqua-300" style={{ left: `${toPercent(nutrient.high)}%`, right: 0 }} />
        </div>
        <motion.div
          initial={{ left: '0%' }}
          animate={{ left: `${marker}%` }}
          transition={{ duration: 1, delay, ease: 'easeOut' }}
          className="absolute top-0 -translate-x-1/2"
        >
          <span className="block h-2 w-2 translate-x-[3px] rounded-full bg-ink-900" />
          <span className="mt-1 block h-5 w-0.5 -translate-x-[3px] rounded-full bg-ink-900" />
        </motion.div>
      </div>

      <div className="mt-2 flex justify-between text-xs text-ink-500">
        <span>0</span>
        <span>
          Target {nutrient.low} to {nutrient.high}
        </span>
        <span>{nutrient.max}</span>
      </div>
    </div>
  );
}
