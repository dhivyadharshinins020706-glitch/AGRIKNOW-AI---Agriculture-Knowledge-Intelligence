import type { ReactNode } from 'react';

export function Card({ children, className = '', hover = false }: { children: ReactNode; className?: string; hover?: boolean }) {
  return (
    <div
      className={`rounded-2xl border border-ink-200/70 bg-white shadow-card ${
        hover ? 'transition duration-300 hover:-translate-y-0.5 hover:border-ink-300 hover:shadow-lift' : ''
      } ${className}`}
    >
      {children}
    </div>
  );
}

export function Skeleton({ className = '' }: { className?: string }) {
  return (
    <div
      aria-hidden
      className={`animate-shimmer rounded-xl bg-[linear-gradient(90deg,#EEF0EC_0%,#F6F7F5_50%,#EEF0EC_100%)] bg-[length:800px_100%] ${className}`}
    />
  );
}
