import { Component, type ErrorInfo, type ReactNode } from 'react';
import { AlertTriangle, Home, RotateCcw, Copy, Check } from 'lucide-react';
import { buttonClass } from './Button';
import { logger } from '@/services/telemetry/logger';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  copied: boolean;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null, copied: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, copied: false };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    logger.error('ErrorBoundary', `Application crashed: ${error.message}`, {
      stack: error.stack,
      componentStack: errorInfo.componentStack,
    });
  }

  handleCopyReport = () => {
    const report = {
      timestamp: new Date().toISOString(),
      url: window.location.href,
      error: this.state.error?.message,
      stack: this.state.error?.stack,
      recentLogs: logger.getRecentLogs().slice(-10),
    };
    navigator.clipboard.writeText(JSON.stringify(report, null, 2)).catch(() => {});
    this.setState({ copied: true });
    setTimeout(() => this.setState({ copied: false }), 2000);
  };

  handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.hash = '#/dashboard';
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex min-h-screen flex-col items-center justify-center bg-ink-50 px-4 text-center">
          <div className="w-full max-w-md rounded-2xl border border-sun-300 bg-white p-8 shadow-lift">
            <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-sun-100 text-sun-800">
              <AlertTriangle className="h-7 w-7" aria-hidden />
            </span>
            <h1 className="mt-5 text-2xl font-bold text-ink-900">Something went wrong</h1>
            <p className="mt-2 text-sm text-ink-600">
              தொழில்நுட்பக் கோளாறு நிகழ்ந்துள்ளது. பக்கத்தை மீண்டும் புதுப்பிக்கவும் அல்லது முகப்புக்குச் செல்லவும்.
            </p>

            {this.state.error && (
              <div className="mt-4 max-h-32 overflow-y-auto rounded-lg bg-ink-100 p-3 text-left font-mono text-xs text-ink-700">
                {this.state.error.message}
              </div>
            )}

            <div className="mt-6 flex flex-col gap-2 sm:flex-row sm:justify-center">
              <button
                type="button"
                onClick={() => window.location.reload()}
                className={buttonClass('primary', 'sm')}
              >
                <RotateCcw className="h-4 w-4" aria-hidden />
                Reload / புதுப்பி
              </button>
              <button
                type="button"
                onClick={this.handleReset}
                className={buttonClass('secondary', 'sm')}
              >
                <Home className="h-4 w-4" aria-hidden />
                Dashboard / முகப்பு
              </button>
              <button
                type="button"
                onClick={this.handleCopyReport}
                className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-ink-200 bg-white px-3 py-1.5 text-xs font-semibold text-ink-700 hover:bg-ink-100"
              >
                {this.state.copied ? <Check className="h-3.5 w-3.5 text-leaf-600" /> : <Copy className="h-3.5 w-3.5" />}
                {this.state.copied ? 'Copied' : 'Copy Report'}
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
