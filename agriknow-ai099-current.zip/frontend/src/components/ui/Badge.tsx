import type { ReactNode } from 'react';

type Tone = 'neutral' | 'success' | 'warning' | 'danger' | 'info' | 'ai';

const toneClass: Record<Tone, string> = {
  neutral: 'bg-ink-100 text-ink-700',
  success: 'bg-leaf-100 text-leaf-800',
  warning: 'bg-sun-100 text-sun-800',
  danger: 'bg-danger-100 text-danger-700',
  info: 'bg-aqua-100 text-aqua-800',
  ai: 'bg-lilac-200 text-lilac-800',
};

export function Badge({ tone = 'neutral', children }: { tone?: Tone; children: ReactNode }) {
  return (
    <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-medium ${toneClass[tone]}`}>
      {children}
    </span>
  );
}

export const severityTone = { Low: 'success', Medium: 'warning', High: 'danger' } as const;
