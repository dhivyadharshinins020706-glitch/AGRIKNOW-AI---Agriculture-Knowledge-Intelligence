import type { LucideIcon } from 'lucide-react';
import { motion } from 'framer-motion';

interface SegmentedOption<T extends string> {
  value: T;
  label: string;
  icon?: LucideIcon;
}

interface SegmentedProps<T extends string> {
  id: string;
  label: string;
  options: SegmentedOption<T>[];
  value: T;
  onChange: (value: T) => void;
  className?: string;
}

export function Segmented<T extends string>({ id, label, options, value, onChange, className = '' }: SegmentedProps<T>) {
  return (
    <div role="radiogroup" aria-label={label} className={`inline-flex rounded-2xl bg-ink-100 p-1 ${className}`}>
      {options.map((option) => {
        const active = option.value === value;
        const Icon = option.icon;
        return (
          <button
            key={option.value}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => onChange(option.value)}
            className={`relative inline-flex h-10 flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-xl px-4 text-sm font-medium transition-colors duration-200 sm:text-base ${
              active ? 'text-ink-900' : 'text-ink-600 hover:text-ink-900'
            }`}
          >
            {active && (
              <motion.span
                layoutId={`segment-${id}`}
                className="absolute inset-0 rounded-xl bg-white shadow-card"
                transition={{ type: 'spring', stiffness: 500, damping: 36 }}
              />
            )}
            <span className="relative inline-flex items-center gap-2">
              {Icon && <Icon className="h-4 w-4" aria-hidden />}
              {option.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}
