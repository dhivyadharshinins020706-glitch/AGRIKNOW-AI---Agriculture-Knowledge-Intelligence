import type { ButtonHTMLAttributes, ReactNode } from 'react';

type Variant = 'primary' | 'secondary' | 'dark' | 'ghost';
type Size = 'sm' | 'md' | 'lg';

const variantClass: Record<Variant, string> = {
  primary:
    'bg-leaf-400 text-ink-900 shadow-[0_10px_24px_-12px_rgba(83,181,79,0.9)] hover:bg-leaf-300 hover:shadow-[0_14px_28px_-12px_rgba(83,181,79,0.9)]',
  secondary: 'bg-white text-ink-900 border border-ink-200 hover:border-ink-300 hover:bg-ink-50',
  dark: 'bg-ink-900 text-white hover:bg-ink-800',
  ghost: 'text-ink-700 hover:bg-ink-100 hover:text-ink-900',
};

const sizeClass: Record<Size, string> = {
  sm: 'h-10 px-4 text-sm',
  md: 'h-11 px-5 text-sm sm:text-base',
  lg: 'h-12 px-6 text-base',
};

export function buttonClass(variant: Variant = 'primary', size: Size = 'md', extra = '') {
  return [
    'inline-flex items-center justify-center gap-2 rounded-xl font-bold transition-all duration-200',
    'disabled:cursor-not-allowed disabled:opacity-50 active:scale-[0.98]',
    variantClass[variant],
    sizeClass[size],
    extra,
  ].join(' ');
}

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  children: ReactNode;
}

export function Button({ variant = 'primary', size = 'md', className = '', type = 'button', children, ...rest }: ButtonProps) {
  return (
    <button type={type} className={buttonClass(variant, size, className)} {...rest}>
      {children}
    </button>
  );
}
