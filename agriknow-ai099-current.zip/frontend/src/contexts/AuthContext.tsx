import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import {
  loginFarmer,
  logoutFarmer,
  registerFarmer,
  requestPasswordReset,
  type AuthResponse,
} from '@/services/authService';
import type { Session, User } from '@supabase/supabase-js';

export type UserRole = 'farmer' | 'officer' | 'scientist' | 'admin';

interface AuthContextValue {
  user: User | null;
  session: Session | null;
  role: UserRole;
  isAdmin: boolean;
  isOfficer: boolean;
  switchRole: (role: UserRole) => void;
  isLoading: boolean;
  isConfigured: boolean;
  signIn: (email: string, pass: string) => Promise<AuthResponse>;
  signUp: (email: string, pass: string, name: string, phone?: string, district?: string) => Promise<AuthResponse>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ error: string | null }>;
  isAuthModalOpen: boolean;
  openAuthModal: (mode?: 'login' | 'register' | 'reset') => void;
  closeAuthModal: () => void;
  authModalMode: 'login' | 'register' | 'reset';
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [role, setRole] = useState<UserRole>(() => {
    try {
      return (localStorage.getItem('agriknow_user_role') as UserRole) || 'farmer';
    } catch {
      return 'farmer';
    }
  });
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | 'reset'>('login');

  const isAdmin = role === 'admin' || role === 'scientist';
  const isOfficer = role === 'officer' || role === 'scientist' || role === 'admin';

  const switchRole = useCallback((newRole: UserRole) => {
    setRole(newRole);
    try {
      localStorage.setItem('agriknow_user_role', newRole);
    } catch {
      // Ignore
    }
    if (supabase && user) {
      supabase.auth.updateUser({ data: { role: newRole } }).catch(() => {});
    }
  }, [user]);

  useEffect(() => {
    if (!isSupabaseConfigured || !supabase) {
      setIsLoading(false);
      return;
    }

    // 1. Check existing session
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setUser(data.session?.user || null);
      setIsLoading(false);
    });

    // 2. Listen to auth state changes
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, currentSession) => {
      setSession(currentSession);
      setUser(currentSession?.user || null);
      setIsLoading(false);
    });

    return () => {
      authListener?.subscription.unsubscribe();
    };
  }, []);

  const signIn = useCallback(async (email: string, pass: string) => {
    setIsLoading(true);
    const res = await loginFarmer(email, pass);
    setIsLoading(false);
    if (!res.error) {
      setIsAuthModalOpen(false);
    }
    return res;
  }, []);

  const signUp = useCallback(
    async (email: string, pass: string, name: string, phone?: string, district?: string) => {
      setIsLoading(true);
      const res = await registerFarmer(email, pass, name, phone, district);
      setIsLoading(false);
      if (!res.error) {
        setIsAuthModalOpen(false);
      }
      return res;
    },
    []
  );

  const signOut = useCallback(async () => {
    setIsLoading(true);
    await logoutFarmer();
    setUser(null);
    setSession(null);
    setIsLoading(false);
  }, []);

  const resetPassword = useCallback(async (email: string) => {
    return requestPasswordReset(email);
  }, []);

  const openAuthModal = useCallback((mode: 'login' | 'register' | 'reset' = 'login') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  }, []);

  const closeAuthModal = useCallback(() => {
    setIsAuthModalOpen(false);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        role,
        isAdmin,
        isOfficer,
        switchRole,
        isLoading,
        isConfigured: isSupabaseConfigured,
        signIn,
        signUp,
        signOut,
        resetPassword,
        isAuthModalOpen,
        openAuthModal,
        closeAuthModal,
        authModalMode,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
