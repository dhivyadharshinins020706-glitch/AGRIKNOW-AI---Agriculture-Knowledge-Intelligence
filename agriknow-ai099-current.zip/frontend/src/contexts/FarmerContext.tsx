import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react';
import type { FarmerPreferences, FarmerProfile, FarmTask, SoilSample } from '@/types';
import { initialTasks } from '@/data/farm';
import { soilSamples } from '@/data/soil';
import { useAuth } from './AuthContext';
import { fetchFarmerProfileFromDb, syncFarmerProfileToDb } from '@/services/farmerService';
import { fetchUserSoilReports, saveSoilReportToDb } from '@/services/soilReportService';
import {
  deleteTaskFromDb,
  fetchUserTasks,
  saveTaskToDb,
  toggleTaskInDb,
} from '@/services/taskService';

interface FarmerContextValue {
  profile: FarmerProfile;
  updateProfile: (profile: Partial<FarmerProfile>) => Promise<void>;
  preferences: FarmerPreferences;
  updatePreferences: (preferences: Partial<FarmerPreferences>) => void;
  tasks: FarmTask[];
  toggleTask: (id: string) => Promise<void>;
  addTask: (title: string, when: string, crop?: string, priority?: 'High' | 'Medium' | 'Low') => Promise<void>;
  deleteTask: (id: string) => Promise<void>;
  fields: SoilSample[];
  addCustomField: (field: Omit<SoilSample, 'id'>) => Promise<string>;
  resetToDefaults: () => void;
  isCloudSyncing: boolean;
}

const defaultProfile: FarmerProfile = {
  name: 'Murugan Selvam',
  village: 'Keelavasal',
  district: 'Thanjavur',
  state: 'Tamil Nadu',
  phone: '9842012345',
  acres: 2.5,
  soilType: 'Alluvial Clay',
  irrigationSource: 'Canal',
  cropIds: ['paddy', 'groundnut'],
};

const defaultPreferences: FarmerPreferences = {
  weatherAlerts: true,
  diseaseAlerts: true,
  priceAlerts: false,
  voiceAutoRead: false,
  offlineMode: true,
};

const STORAGE_KEYS = {
  PROFILE: 'agriknow_farmer_profile',
  PREFERENCES: 'agriknow_farmer_preferences',
  TASKS: 'agriknow_farmer_tasks',
  CUSTOM_FIELDS: 'agriknow_farmer_custom_fields',
};

const FarmerContext = createContext<FarmerContextValue | null>(null);

export function FarmerProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [isCloudSyncing, setIsCloudSyncing] = useState(false);

  const [profile, setProfileState] = useState<FarmerProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return saved ? JSON.parse(saved) : defaultProfile;
    } catch {
      return defaultProfile;
    }
  });

  const [preferences, setPreferencesState] = useState<FarmerPreferences>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PREFERENCES);
      return saved ? JSON.parse(saved) : defaultPreferences;
    } catch {
      return defaultPreferences;
    }
  });

  const [tasks, setTasks] = useState<FarmTask[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.TASKS);
      return saved ? JSON.parse(saved) : initialTasks;
    } catch {
      return initialTasks;
    }
  });

  const [customFields, setCustomFields] = useState<SoilSample[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CUSTOM_FIELDS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Sync with Cloud Database when authenticated user changes
  useEffect(() => {
    if (!user) return;

    let isMounted = true;
    setIsCloudSyncing(true);

    Promise.all([
      fetchFarmerProfileFromDb(user.id),
      fetchUserSoilReports(user.id),
      fetchUserTasks(user.id),
    ])
      .then(([cloudProfile, cloudSoilReports, cloudTasks]) => {
        if (!isMounted) return;

        if (cloudProfile) {
          setProfileState(cloudProfile);
        } else {
          // If no cloud profile exists yet, initialize it with current local profile
          syncFarmerProfileToDb(user.id, profile);
        }

        if (cloudSoilReports && cloudSoilReports.length > 0) {
          setCustomFields(cloudSoilReports);
        }

        if (cloudTasks && cloudTasks.length > 0) {
          setTasks(cloudTasks);
        }
      })
      .finally(() => {
        if (isMounted) setIsCloudSyncing(false);
      });

    return () => {
      isMounted = false;
    };
  }, [user]);

  // Save to localStorage when state changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
    } catch {
      // Ignore
    }
  }, [profile]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PREFERENCES, JSON.stringify(preferences));
    } catch {
      // Ignore
    }
  }, [preferences]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
    } catch {
      // Ignore
    }
  }, [tasks]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CUSTOM_FIELDS, JSON.stringify(customFields));
    } catch {
      // Ignore
    }
  }, [customFields]);

  const updateProfile = useCallback(
    async (partial: Partial<FarmerProfile>) => {
      setProfileState((prev) => ({ ...prev, ...partial }));
      if (user) {
        setIsCloudSyncing(true);
        await syncFarmerProfileToDb(user.id, partial);
        setIsCloudSyncing(false);
      }
    },
    [user]
  );

  const updatePreferences = useCallback((partial: Partial<FarmerPreferences>) => {
    setPreferencesState((prev) => ({ ...prev, ...partial }));
  }, []);

  const toggleTask = useCallback(
    async (id: string) => {
      const task = tasks.find((t) => t.id === id);
      const nextDone = task ? !task.done : true;

      setTasks((prev) =>
        prev.map((t) => (t.id === id ? { ...t, done: nextDone } : t))
      );

      if (user) {
        await toggleTaskInDb(id, nextDone);
      }
    },
    [tasks, user]
  );

  const addTask = useCallback(
    async (
      title: string,
      when: string,
      crop?: string,
      priority: 'High' | 'Medium' | 'Low' = 'Medium'
    ) => {
      let createdId = `t_${Date.now()}`;

      if (user) {
        const dbId = await saveTaskToDb(user.id, {
          title,
          when,
          done: false,
          crop,
          priority,
        });
        if (dbId) createdId = dbId;
      }

      const newTask: FarmTask = {
        id: createdId,
        title,
        when,
        done: false,
        crop,
        priority,
      };

      setTasks((prev) => [newTask, ...prev]);
    },
    [user]
  );

  const deleteTask = useCallback(
    async (id: string) => {
      setTasks((prev) => prev.filter((task) => task.id !== id));
      if (user) {
        await deleteTaskFromDb(id);
      }
    },
    [user]
  );

  const addCustomField = useCallback(
    async (field: Omit<SoilSample, 'id'>) => {
      let createdId = `custom-field-${Date.now()}`;

      if (user) {
        const dbId = await saveSoilReportToDb(user.id, field);
        if (dbId.id) createdId = dbId.id;
      }

      const newField: SoilSample = {
        ...field,
        id: createdId,
        isCustom: true,
      };

      setCustomFields((prev) => [...prev, newField]);
      return createdId;
    },
    [user]
  );

  const resetToDefaults = useCallback(() => {
    setProfileState(defaultProfile);
    setPreferencesState(defaultPreferences);
    setTasks(initialTasks);
    setCustomFields([]);
    try {
      localStorage.removeItem(STORAGE_KEYS.PROFILE);
      localStorage.removeItem(STORAGE_KEYS.PREFERENCES);
      localStorage.removeItem(STORAGE_KEYS.TASKS);
      localStorage.removeItem(STORAGE_KEYS.CUSTOM_FIELDS);
    } catch {
      // Ignore
    }
  }, []);

  const allFields = [...soilSamples, ...customFields];

  return (
    <FarmerContext.Provider
      value={{
        profile,
        updateProfile,
        preferences,
        updatePreferences,
        tasks,
        toggleTask,
        addTask,
        deleteTask,
        fields: allFields,
        addCustomField,
        resetToDefaults,
        isCloudSyncing,
      }}
    >
      {children}
    </FarmerContext.Provider>
  );
}

export function useFarmer(): FarmerContextValue {
  const ctx = useContext(FarmerContext);
  if (!ctx) throw new Error('useFarmer must be used inside FarmerProvider');
  return ctx;
}
