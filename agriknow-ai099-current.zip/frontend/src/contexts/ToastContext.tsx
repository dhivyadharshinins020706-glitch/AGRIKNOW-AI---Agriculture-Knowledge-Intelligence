import { createContext, useCallback, useContext, useMemo, useRef, useState, type ReactNode } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, Info, AlertTriangle, XCircle, X, type LucideIcon } from 'lucide-react';

export type ToastTone = 'success' | 'info' | 'warning' | 'error';

interface ToastItem {
  id: number;
  title: string;
  description?: string;
  tone: ToastTone;
}

interface ToastContextValue {
  show: (title: string, options?: { description?: string; tone?: ToastTone }) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

const toneStyles: Record<ToastTone, { icon: LucideIcon; iconClass: string; bar: string }> = {
  success: { icon: CheckCircle2, iconClass: 'text-leaf-600 bg-leaf-100', bar: 'bg-leaf-400' },
  info: { icon: Info, iconClass: 'text-aqua-800 bg-aqua-100', bar: 'bg-aqua-400' },
  warning: { icon: AlertTriangle, iconClass: 'text-sun-800 bg-sun-100', bar: 'bg-sun-400' },
  error: { icon: XCircle, iconClass: 'text-danger-700 bg-danger-100', bar: 'bg-danger-500' },
};

const DISMISS_MS = 3800;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const nextId = useRef(1);

  const dismiss = useCallback((id: number) => {
    setToasts((items) => items.filter((item) => item.id !== id));
  }, []);

  const show = useCallback<ToastContextValue['show']>(
    (title, options) => {
      const id = nextId.current++;
      setToasts((items) => [
        ...items.slice(-2),
        { id, title, description: options?.description, tone: options?.tone ?? 'success' },
      ]);
      window.setTimeout(() => dismiss(id), DISMISS_MS);
    },
    [dismiss],
  );

  const value = useMemo(() => ({ show }), [show]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div
        aria-live="polite"
        className="pointer-events-none fixed inset-x-0 bottom-24 z-[60] flex flex-col items-center gap-3 px-4 sm:bottom-auto sm:top-6 sm:items-end sm:px-6 lg:top-8"
      >
        <AnimatePresence initial={false}>
          {toasts.map((toast) => {
            const style = toneStyles[toast.tone];
            const Icon = style.icon;
            return (
              <motion.div
                key={toast.id}
                layout
                initial={{ opacity: 0, y: 16, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -8, scale: 0.96, transition: { duration: 0.2 } }}
                transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                className="pointer-events-auto relative flex w-full max-w-sm items-start gap-3 overflow-hidden rounded-2xl border border-ink-200 bg-white p-4 pr-10 shadow-lift"
                role="status"
              >
                <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${style.iconClass}`}>
                  <Icon className="h-5 w-5" aria-hidden />
                </span>
                <div className="min-w-0">
                  <p className="text-sm font-bold text-ink-900">{toast.title}</p>
                  {toast.description && <p className="mt-0.5 text-sm text-ink-600">{toast.description}</p>}
                </div>
                <button
                  type="button"
                  onClick={() => dismiss(toast.id)}
                  aria-label="Dismiss notification"
                  className="absolute right-2 top-2 rounded-lg p-1.5 text-ink-500 transition hover:bg-ink-100 hover:text-ink-900"
                >
                  <X className="h-4 w-4" aria-hidden />
                </button>
                <motion.span
                  className={`absolute bottom-0 left-0 h-1 ${style.bar}`}
                  initial={{ width: '100%' }}
                  animate={{ width: '0%' }}
                  transition={{ duration: DISMISS_MS / 1000, ease: 'linear' }}
                />
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used inside ToastProvider');
  return ctx;
}
