import { FileSearch, GitCompare, Layers, LayoutDashboard, Microscope, BookOpen, MessageCircleQuestion, Settings, Database, type LucideIcon } from 'lucide-react';
import type { TranslationKey } from '@/lib/i18n';

export interface NavItem {
  path: string;
  labelKey: TranslationKey;
  icon: LucideIcon;
}

export const appNav: NavItem[] = [
  { path: '/dashboard', labelKey: 'nav.dashboard', icon: LayoutDashboard },
  { path: '/assistant', labelKey: 'nav.assistant', icon: MessageCircleQuestion },
  { path: '/diseases', labelKey: 'nav.diseases', icon: Microscope },
  { path: '/soil', labelKey: 'nav.soil', icon: Layers },
  { path: '/crops', labelKey: 'nav.crops', icon: GitCompare },
  { path: '/library', labelKey: 'nav.library', icon: BookOpen },
  { path: '/ingestion', labelKey: 'nav.ingestion', icon: Database },
  { path: '/evidence', labelKey: 'nav.evidence', icon: FileSearch },
  { path: '/profile', labelKey: 'nav.profile', icon: Settings },
];

export const mobilePrimaryNav = appNav.slice(0, 4);
export const mobileMoreNav = appNav.slice(4);
