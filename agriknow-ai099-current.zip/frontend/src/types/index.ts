export type Severity = 'Low' | 'Medium' | 'High';

export interface Source {
  id: string;
  title: string;
  publisher: string;
  year: number;
  kind: 'Government advisory' | 'Research paper' | 'Extension guide' | 'Field manual';
  language: 'English' | 'Tamil' | 'English & Tamil';
  reliability: 'Verified' | 'Peer reviewed';
  topics: string[];
  summary: string;
  excerpts: Excerpt[];
}

export interface Excerpt {
  section: string;
  text: string;
  relevance: 'high' | 'medium';
}

export interface Disease {
  id: string;
  name: string;
  cropId: string;
  cropName: string;
  type: 'Disease' | 'Pest';
  severity: Severity;
  symptoms: string[];
  organicTreatment: string[];
  chemicalTreatment: string[];
  prevention: string[];
  sourceIds: string[];
}

export interface Crop {
  id: string;
  name: string;
  nameTa: string;
  season: 'Kharif' | 'Rabi';
  durationDays: number;
  waterNeed: 'Low' | 'Medium' | 'High';
  yieldQuintalPerAcre: number;
  pricePerQuintal: number;
  costPerAcre: number;
  risk: Severity;
  bestFor: string;
}

export interface SoilNutrient {
  key: 'nitrogen' | 'phosphorus' | 'potassium' | 'organicCarbon';
  label: string;
  value: number;
  unit: string;
  low: number;
  high: number;
  max: number;
}

export interface SoilSample {
  id: string;
  label: string;
  location: string;
  crop: string;
  pH: number;
  nutrients: SoilNutrient[];
  plan: { stage: string; product: string; dose: string; timing: string }[];
  isCustom?: boolean;
}

import type { RagExecutionTrace } from '@/services/rag/advancedRagEngine';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  sourceIds?: string[];
  isLiveBackend?: boolean;
  provider?: string;
  confidence?: number;
  timestamp?: number;
  ragTrace?: RagExecutionTrace;
  suggestedFollowUps?: { en: string; ta: string }[];
  documentContext?: AnalyzedDocument;
  imageUrl?: string;
}

export type AgriDocumentCategory =
  | 'seed_certificate'
  | 'purchase_invoice'
  | 'mandi_receipt'
  | 'soil_health_card'
  | 'pesticide_bill'
  | 'nursery_bill'
  | 'insurance_policy'
  | 'general_agri_doc';

export interface DocumentKeyFinding {
  labelEn: string;
  labelTa: string;
  value: string;
  status?: 'verified' | 'warning' | 'info';
}

export interface AnalyzedDocument {
  id: string;
  fileName: string;
  fileType: 'pdf' | 'image' | 'text';
  category: AgriDocumentCategory;
  categoryLabelEn: string;
  categoryLabelTa: string;
  crop?: string;
  variety?: string;
  lotOrBatchNumber?: string;
  issuerOrDealer?: string;
  testingDate?: string;
  expiryDate?: string;
  germinationPercent?: string;
  purityPercent?: string;
  moisturePercent?: string;
  chemicalTreatment?: string;
  quantity?: string;
  pricePaid?: string;
  subsidyDetail?: string;
  summaryEn: string;
  summaryTa: string;
  rawText: string;
  suggestedQuestions: { en: string; ta: string }[];
  keyFindings: DocumentKeyFinding[];
  analyzedAt: string;
}

export interface CannedAnswer {
  keywords: string[];
  en: string;
  ta: string;
  sourceIds: string[];
}

export interface Retrieval {
  sourceId: string;
  score: number;
}

export interface FarmerProfile {
  name: string;
  village: string;
  district: string;
  state: string;
  phone: string;
  acres: number;
  soilType: 'Alluvial Clay' | 'Red Sandy Loam' | 'Black Cotton' | 'Laterite' | 'Coastal Sand';
  irrigationSource: 'Canal' | 'Borewell' | 'Open Well' | 'Rainfed' | 'Drip Irrigation';
  cropIds: string[];
}

export interface FarmerPreferences {
  weatherAlerts: boolean;
  diseaseAlerts: boolean;
  priceAlerts: boolean;
  voiceAutoRead: boolean;
  offlineMode: boolean;
}

export interface FarmTask {
  id: string;
  title: string;
  titleTa?: string;
  when: string;
  done: boolean;
  crop?: string;
  priority?: 'High' | 'Medium' | 'Low';
}

export interface AiAnswerResult {
  text: string;
  sourceIds: string[];
  isLiveBackend: boolean;
  provider: 'Live AI Model' | 'Verified Agricultural Corpus' | string;
  confidence: number;
  ragTrace?: RagExecutionTrace;
  suggestedFollowUps?: { en: string; ta: string }[];
  isError?: boolean;
  retryable?: boolean;
}

export interface MarketPriceItem {
  crop: string;
  cropTa: string;
  mandi: string;
  price: number;
  change: number;
  unit: string;
  updatedAt: string;
}

export interface AgriWeather {
  location: string;
  tempC: number;
  humidity: number;
  windKmh: number;
  rainChance: number;
  condition: string;
  conditionTa: string;
  farmingAdvice: string;
  farmingAdviceTa: string;
}
