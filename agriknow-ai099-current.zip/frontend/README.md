# AGRIKNOW AI — Frontend Module

The frontend for AGRIKNOW AI is built with **React 18**, **TypeScript**, **Tailwind CSS**, and **Framer Motion**. It is designed mobile-first for Indian farmers and agricultural field officers.

## Brand Identity & Colors
Strictly follows the official 5-color palette:
- **Amber / Harvest Gold:** `#F09B04` (`brand-500`)
- **Leaf Green:** `#53B54F` (`leaf-500`)
- **Lavender / Mauve:** `#C6A9D8` (`lavender-400`)
- **Electric Cyan:** `#14F6FA` (`cyan-400`)
- **Soft Lilac / Surface:** `#E4D8F1` (`lilac-100`)

## Structure
- `src/components/`: Modular UI components organized by domain:
  - `assistant/`: Conversational chat bubbles, suggested questions, audio player
  - `crops/`: Crop selector, regional calendar, water & soil requirement badges
  - `dashboard/`: Farmer metrics, live weather widget, mandi prices, quick actions
  - `diseases/`: Disease identification, visual leaf scanner, management guidance
  - `soil/`: Soil test parameter interpretation, nutrient balance gauges
  - `library/`: Ingestion manager, verified research document browser
  - `legal/`: Consent banner, legal disclaimers, system health modal
  - `ui/`: Reusable cards, badges, buttons, error boundaries, page headers
- `src/pages/`: Main application routes (Dashboard, Assistant, Crops, Diseases, Soil, Library, Profile, Ingestion Admin)
- `src/contexts/`: React context providers for Language (`en`/`ta`), Auth, Toast notifications, and Farmer profiles
- `src/data/`: Curated evidence bases, agricultural sources, and Tamil/English prompts
- `src/lib/`: Client utilities, router, i18n localization engine, Supabase client
