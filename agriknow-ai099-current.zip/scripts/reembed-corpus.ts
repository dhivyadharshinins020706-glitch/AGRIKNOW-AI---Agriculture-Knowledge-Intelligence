/**
 * AGRIKNOW AI — Phase C: Safe Document Re-Embedding & Rollback CLI Utility
 * 
 * Usage:
 *   node --experimental-strip-types scripts/reembed-corpus.ts --dry-run
 *   node --experimental-strip-types scripts/reembed-corpus.ts --reembed
 *   node --experimental-strip-types scripts/reembed-corpus.ts --benchmark
 *   node --experimental-strip-types scripts/reembed-corpus.ts --rollback
 */

import {
  fetchIngestedDocuments,
  getIngestionStats,
  reembedDocumentChunks,
  rollbackEmbeddingsToLocalHash,
} from '../src/services/ingestionService.ts';
import { getGeminiApiKey, getGeminiEmbeddingModel } from '../src/services/geminiService.ts';
import { executeAdvancedRag } from '../src/services/rag/advancedRagEngine.ts';

const args = process.argv.slice(2);
const isDryRun = args.includes('--dry-run') || args.length === 0;
const isReembed = args.includes('--reembed');
const isBenchmark = args.includes('--benchmark');
const isRollback = args.includes('--rollback');

async function main() {
  console.log('======================================================================');
  console.log('🌾 AGRIKNOW AI — PHASE C: CORPUS RE-EMBEDDING & ROLLBACK UTILITY');
  console.log('======================================================================\n');

  const stats = await getIngestionStats();
  const docs = await fetchIngestedDocuments();
  const apiKey = getGeminiApiKey();
  const targetModel = getGeminiEmbeddingModel();

  console.log('📊 CURRENT CORPUS OVERVIEW:');
  console.log(`  • Total Documents:        ${stats.totalDocuments}`);
  console.log(`  • Total Indexed Chunks:   ${stats.totalChunks}`);
  console.log(`  • Configured Target Model: ${targetModel}`);
  console.log(`  • Gemini API Key Status:  ${apiKey ? 'CONFIGURED (' + apiKey.slice(0, 8) + '...)' : 'MISSING (Offline mode only)'}`);
  console.log('  • Current Embedding Model Distribution:');
  for (const [m, count] of Object.entries(stats.modelDistribution || {})) {
    console.log(`      - ${m}: ${count} chunks`);
  }
  console.log('');

  if (isRollback) {
    console.log('🔄 EXECUTING ROLLBACK TO MULTILINGUAL-DENSE-HASH-128...');
    const rb = await rollbackEmbeddingsToLocalHash();
    console.log(`✅ Rollback complete. Reverted ${rb.revertedChunks} chunks to local 128-D hash embeddings.\n`);
    const afterStats = await getIngestionStats();
    console.log('  • New Embedding Model Distribution:');
    for (const [m, count] of Object.entries(afterStats.modelDistribution || {})) {
      console.log(`      - ${m}: ${count} chunks`);
    }
    return;
  }

  if (isDryRun && !isReembed && !isBenchmark) {
    console.log('🔍 [DRY-RUN MODE] Scan results:');
    const legacyCount = (stats.modelDistribution || {})['multilingual-dense-hash-128'] || 0;
    const modernCount = (stats.modelDistribution || {})[targetModel] || 0;

    console.log(`  • Chunks in legacy space (128-D): ${legacyCount}`);
    console.log(`  • Chunks in target model (${targetModel}): ${modernCount}`);
    console.log(`  • Chunks eligible for migration: ${legacyCount}`);
    console.log('\n💡 To perform the actual re-embedding, run:');
    console.log('   npm run reembed -- --reembed\n');
    return;
  }

  if (isReembed) {
    if (!apiKey) {
      console.error('❌ Cannot re-embed: GEMINI_API_KEY is not set in environment.');
      console.log('   Please set GEMINI_API_KEY in .env.local and retry.\n');
      process.exit(1);
    }

    console.log(`🚀 Starting re-embedding of corpus using ${targetModel}...`);
    const result = await reembedDocumentChunks();

    if (result.success) {
      console.log(`✅ Re-embedding completed successfully!`);
      console.log(`  • Newly embedded: ${result.newlyEmbedded} chunks (${result.dimensions}-D)`);
      console.log(`  • Skipped (already modern): ${result.skipped} chunks`);
    } else {
      console.warn(`⚠️ Re-embedding finished with errors:`);
      console.log(`  • Newly embedded: ${result.newlyEmbedded}`);
      console.log(`  • Errors (${result.errors.length}):`);
      result.errors.forEach((e) => console.log(`      ! ${e}`));
    }
    console.log('');
  }

  if (isBenchmark || isReembed) {
    console.log('🎯 RUNNING RETRIEVAL ACCURACY BENCHMARK ON PILOT QUESTIONS...');
    const questions = [
      {
        crop: 'Paddy',
        q: 'நெல்லில் குலை நோய் தாக்கினால் என்ன மருந்து தெளிக்க வேண்டும்?',
        lang: 'ta' as const,
        expectedSource: 'doc-tnau-paddy-sri',
      },
      {
        crop: 'Cotton',
        q: 'How to monitor and control cotton bollworm using pheromone traps?',
        lang: 'en' as const,
        expectedSource: 'doc-icar-cotton-ipm',
      },
      {
        crop: 'Groundnut',
        q: 'நிலக்கடலையில் பொக்கு காய் வராமல் இருக்க ஜிப்சம் எப்போது இட வேண்டும்?',
        lang: 'ta' as const,
        expectedSource: 'doc-tnau-groundnut-gypsum',
      },
    ];

    let passedCount = 0;
    for (const test of questions) {
      const res = await executeAdvancedRag(test.q, test.lang);
      const topMatch = res.evidenceList[0]?.sourceId;
      const matched = topMatch === test.expectedSource;
      if (matched) passedCount++;

      console.log(`  [${test.crop}] Top match: ${topMatch || 'none'} | Expected: ${test.expectedSource} | ${matched ? '✓ MATCH' : '✗ MISMATCH'} (Confidence: ${(res.confidence * 100).toFixed(1)}%)`);
    }

    console.log(`\n🏆 Benchmark Score: ${passedCount} / ${questions.length} (${((passedCount / questions.length) * 100).toFixed(0)}%)\n`);
  }

  console.log('======================================================================');
  console.log('✨ PHASE C VERIFICATION FINISHED SUCCESSFULLY.');
  console.log('======================================================================');
}

main().catch((err) => {
  console.error('Fatal error in re-embed utility:', err);
  process.exit(1);
});
