import assert from 'node:assert';
import { askQuestionAboutDocument, setActiveAnalyzedDocument, type StoredUserDocument } from '../src/services/documentAnalyzerService.ts';
import { askAgriAssistant } from '../src/services/aiService.ts';

async function run() {
  console.log('🌾 Testing Document Q&A & Fallback Fixes...');

  const sampleDoc: StoredUserDocument = {
    id: 'doc-test-seed-1',
    fileName: '5aafc00b-6eeb-447e-a99f-3829ef7e856f.pdf',
    originalFileName: '5aafc00b-6eeb-447e-a99f-3829ef7e856f.pdf',
    fileType: 'pdf',
    fileSizeBytes: 10240,
    uploadedAt: new Date().toISOString(),
    processingStatus: 'ready',
    category: 'seed_certificate',
    categoryLabelEn: 'Seed Certification Tag / Certificate',
    categoryLabelTa: 'விதைச் சான்றிதழ் அட்டை',
    crop: 'Paddy (நெல்)',
    variety: 'CO 51',
    lotOrBatchNumber: 'TN-2026-CO51-4921',
    testingDate: '15/03/2026',
    expiryDate: '14/12/2026',
    germinationPercent: '88%',
    purityPercent: '98%',
    summaryEn: 'Certified Paddy Seeds CO 51 produced in Thanjavur. Germination: 88%, Purity: 98%.',
    summaryTa: 'தஞ்சாவூரில் உற்பத்தி செய்யப்பட்ட சான்றளிக்கப்பட்ட நெல் விதைகள் CO 51. முளைப்பு: 88%, தூய்மை: 98%.',
    rawText: 'Certified Paddy Seeds CO 51 Lot No: TN-2026-CO51-4921 Germination: 88% Test: 15/03/2026 Valid: 14/12/2026',
  };

  // Test 1: Compound Question in English
  console.log('\n📌 TEST 1: Compound Document Question (English)');
  const answerEn = await askQuestionAboutDocument(
    sampleDoc,
    'What is the expiry date and germination capacity of this seed lot?',
    'en'
  );
  console.log('Answer:\n', answerEn);
  assert(answerEn.includes('88%'), 'Should contain 88% germination');
  assert(answerEn.includes('14/12/2026'), 'Should contain expiry date 14/12/2026');
  assert(answerEn.includes('TN-2026-CO51-4921'), 'Should contain lot number TN-2026-CO51-4921');
  assert(!answerEn.includes('Information verified.'), 'Must NOT be "Information verified."');
  console.log('✅ TEST 1 PASSED');

  // Test 2: Compound Question in Tamil
  console.log('\n📌 TEST 2: Compound Document Question (Tamil)');
  const answerTa = await askQuestionAboutDocument(
    sampleDoc,
    'இந்த விதைக் குவியல் (Lot No), காலாவதி தேதி மற்றும் முளைப்புத் திறன் என்ன?',
    'ta'
  );
  console.log('Answer:\n', answerTa);
  assert(answerTa.includes('88%'), 'Tamil answer should contain 88%');
  assert(answerTa.includes('14/12/2026'), 'Tamil answer should contain expiry date');
  assert(answerTa.includes('TN-2026-CO51-4921'), 'Tamil answer should contain lot number');
  console.log('✅ TEST 2 PASSED');

  // Test 3: askAgriAssistant with Active Document
  console.log('\n📌 TEST 3: askAgriAssistant with Active Document in Session');
  setActiveAnalyzedDocument(sampleDoc);
  const assistantRes = await askAgriAssistant(
    'What is the expiry date and germination capacity of this seed lot?',
    'en'
  );
  console.log('Assistant Response Text:\n', assistantRes.text);
  assert(assistantRes.text.includes('88%'), 'Assistant should answer 88% from active document');
  assert(assistantRes.text.includes('14/12/2026'), 'Assistant should answer expiry date from active document');
  assert(assistantRes.text !== 'Information verified.', 'Assistant text must NOT be canned "Information verified."');
  console.log('✅ TEST 3 PASSED');

  // Test 4: Document without expiry date provides statutory Seed Act validity
  console.log('\n📌 TEST 4: Document without explicit expiry date provides statutory Seed Act validity');
  const docNoExpiry = { ...sampleDoc, expiryDate: undefined };
  const answerNoExpiry = await askQuestionAboutDocument(
    docNoExpiry,
    'What is the expiry date and germination capacity of this seed lot?',
    'en'
  );
  console.log('Answer without explicit expiry:\n', answerNoExpiry);
  assert(answerNoExpiry.includes('88%'), 'Should contain 88%');
  assert(answerNoExpiry.includes('9 months') || answerNoExpiry.includes('Seed Act'), 'Should explain 9 months Seed Act validity');
  console.log('✅ TEST 4 PASSED');

  console.log('\n🎉 ALL DOCUMENT Q&A TESTS PASSED WITH 100% INTEGRITY!');
  process.exit(0);
}

run().catch((err) => {
  console.error('Test failed:', err);
  process.exit(1);
});
