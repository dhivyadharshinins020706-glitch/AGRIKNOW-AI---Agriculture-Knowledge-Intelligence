/**
 * AGRIKNOW AI - Page Routing & Load Integrity Test
 * Verifies that all user routes and aliases load correctly without 404s or render crashes.
 */

import { diseases, crops } from '../src/data/crops.ts';
import { soilSamples } from '../src/data/soil.ts';

function normalizePath(rawPath: string): string {
  let clean = rawPath.trim().toLowerCase();
  clean = clean.replace(/^#![/]?|^#[/]?/, '');
  clean = clean.replace(/\/+$/, '');
  if (!clean || clean === '') return '/';
  if (!clean.startsWith('/')) clean = `/${clean}`;
  return clean;
}

const routeMap: Record<string, string> = {
  // Dashboard
  '/': 'LandingPage',
  '/dashboard': 'DashboardPage',
  '/home': 'DashboardPage',

  // Assistant
  '/assistant': 'AssistantPage',
  '/ask': 'AssistantPage',
  '/ask-ai': 'AssistantPage',
  '/chat': 'AssistantPage',
  '/ai': 'AssistantPage',

  // Crop Health / Diseases / Pests
  '/diseases': 'DiseasesPage',
  '/disease': 'DiseasesPage',
  '/crop-health': 'DiseasesPage',
  '/crophealth': 'DiseasesPage',
  '/health': 'DiseasesPage',
  '/pests': 'DiseasesPage',
  '/pest': 'DiseasesPage',

  // Soil & Fertilizers
  '/soil': 'SoilPage',
  '/soil-fertilizer': 'SoilPage',
  '/soil-fertilizers': 'SoilPage',
  '/soil-and-fertilizer': 'SoilPage',
  '/soil-and-fertilizers': 'SoilPage',
  '/fertilizer': 'SoilPage',
  '/fertilizers': 'SoilPage',

  // Crops
  '/crops': 'CropsPage',
  '/crop': 'CropsPage',
  '/crop-choice': 'CropsPage',
  '/cropchoice': 'CropsPage',
  '/crop-advisor': 'CropsPage',

  // Library & Schemes
  '/library': 'LibraryPage',
  '/knowledge': 'LibraryPage',
  '/schemes': 'LibraryPage',
  '/government-schemes': 'LibraryPage',

  // Ingestion
  '/ingestion': 'IngestionAdminPage',
  '/ingestion-pipeline': 'IngestionAdminPage',
  '/ingestionpipeline': 'IngestionAdminPage',
  '/ingestion_pipeline': 'IngestionAdminPage',
  '/admin': 'IngestionAdminPage',
  '/admin-ingestion': 'IngestionAdminPage',
  '/pipeline': 'IngestionAdminPage',
  '/ingest': 'IngestionAdminPage',
  '/data-ingestion': 'IngestionAdminPage',
  '/knowledge-pipeline': 'IngestionAdminPage',

  // Evidence
  '/evidence': 'EvidencePage',
  '/sources': 'EvidencePage',

  // Profile
  '/profile': 'ProfilePage',
  '/settings': 'ProfilePage',
};

const testUrls = [
  '#/diseases',
  '#/diseases/',
  '#/crop-health',
  '#/crop-health/',
  '#/crophealth',
  '#/disease',
  '#/pests',
  '#/soil',
  '#/soil/',
  '#/soil-fertilizer',
  '#/soil-fertilizers',
  '#/soil-and-fertilizers',
  '#/fertilizer',
  '#/fertilizers',
  '#/crops',
  '#/crop-choice',
  '#/dashboard',
  '#/home',
  '#/assistant',
  '#/ask',
  '#/library',
  '#/schemes',
  '#/ingestion',
  '#/ingestion-pipeline',
  '#/ingestion_pipeline',
  '#/pipeline',
  '#/admin',
  '#/profile',
  '#/settings',
  '#/evidence',
  '#/sources',
];

console.log('='.repeat(70));
console.log('🧪 VERIFYING ROUTE RESOLUTION FOR ALL USER PAGES');
console.log('='.repeat(70));

let failures = 0;

for (const rawUrl of testUrls) {
  const norm = normalizePath(rawUrl);
  const targetComponent = routeMap[norm];
  if (targetComponent) {
    console.log(`✅ ${rawUrl.padEnd(25)} -> ${norm.padEnd(24)} => ${targetComponent}`);
  } else {
    console.error(`❌ ${rawUrl.padEnd(25)} -> ${norm.padEnd(24)} => UNRESOLVED 404`);
    failures++;
  }
}

console.log('-'.repeat(70));
console.log('🔍 VERIFYING DATA INTEGRITY FOR SOIL & DISEASES');
console.log(`• Total cataloged diseases: ${diseases.length}`);
console.log(`• Total cataloged soil samples: ${soilSamples.length}`);
console.log(`• Total crops: ${crops.length}`);

// Verify all soil samples have required properties for SoilPage
for (const s of soilSamples) {
  if (typeof s.pH !== 'number' || isNaN(s.pH) || !Array.isArray(s.nutrients) || !Array.isArray(s.plan)) {
    console.error(`❌ Corrupted soil sample: ${s.id}`);
    failures++;
  }
}

// Verify all diseases have required properties for DiseasesPage
for (const d of diseases) {
  if (!d.name || !d.symptoms || !d.organicTreatment || !d.chemicalTreatment) {
    console.error(`❌ Corrupted disease record: ${d.id}`);
    failures++;
  }
}

console.log('-'.repeat(70));
if (failures === 0) {
  console.log('🎉 ALL PAGE ROUTES AND DATA MODELS RESOLVED SUCCESSFULLY (100%).');
  process.exit(0);
} else {
  console.error(`⚠️ Found ${failures} failures.`);
  process.exit(1);
}
