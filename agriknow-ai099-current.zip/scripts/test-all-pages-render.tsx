import React from 'react';
import { renderToString } from 'react-dom/server';
import { LanguageProvider } from '../src/contexts/LanguageContext.tsx';
import { AuthProvider } from '../src/contexts/AuthContext.tsx';
import { FarmerProvider } from '../src/contexts/FarmerContext.tsx';
import { ToastProvider } from '../src/contexts/ToastContext.tsx';

import LandingPage from '../src/pages/LandingPage.tsx';
import DashboardPage from '../src/pages/DashboardPage.tsx';
import AssistantPage from '../src/pages/AssistantPage.tsx';
import DiseasesPage from '../src/pages/DiseasesPage.tsx';
import SoilPage from '../src/pages/SoilPage.tsx';
import CropsPage from '../src/pages/CropsPage.tsx';
import LibraryPage from '../src/pages/LibraryPage.tsx';
import IngestionAdminPage from '../src/pages/IngestionAdminPage.tsx';
import EvidencePage from '../src/pages/EvidencePage.tsx';
import ProfilePage from '../src/pages/ProfilePage.tsx';

// Setup minimal browser mocks for Node environment
if (typeof globalThis.window === 'undefined') {
  (globalThis as any).window = {
    location: { hash: '', pathname: '/', search: '', href: 'http://localhost:5173/' },
    addEventListener: () => {},
    removeEventListener: () => {},
    matchMedia: () => ({ matches: false, addEventListener: () => {}, removeEventListener: () => {} }),
    scrollTo: () => {},
    localStorage: {
      getItem: () => null,
      setItem: () => {},
      removeItem: () => {},
      clear: () => {},
    },
  };
  (globalThis as any).localStorage = (globalThis as any).window.localStorage;
  (globalThis as any).document = {
    title: '',
    getElementById: () => null,
    createElement: () => ({}),
  };
  (globalThis as any).navigator = {
    clipboard: { writeText: async () => {} },
    userAgent: 'node',
  };
}

const pages = [
  { name: 'LandingPage', Component: LandingPage },
  { name: 'DashboardPage', Component: DashboardPage },
  { name: 'AssistantPage', Component: AssistantPage },
  { name: 'DiseasesPage', Component: DiseasesPage },
  { name: 'SoilPage', Component: SoilPage },
  { name: 'CropsPage', Component: CropsPage },
  { name: 'LibraryPage', Component: LibraryPage },
  { name: 'IngestionAdminPage', Component: IngestionAdminPage },
  { name: 'EvidencePage', Component: EvidencePage },
  { name: 'ProfilePage', Component: ProfilePage },
];

console.log('Testing render of all application pages:');
let failed = 0;

for (const p of pages) {
  try {
    const html = renderToString(
      React.createElement(
        LanguageProvider,
        null,
        React.createElement(
          AuthProvider,
          null,
          React.createElement(
            FarmerProvider,
            null,
            React.createElement(ToastProvider, null, React.createElement(p.Component, null))
          )
        )
      )
    );
    console.log(`✅ ${p.name}: Rendered successfully (${html.length} chars)`);
  } catch (err: any) {
    console.error(`❌ ${p.name} FAILED to render:`, err.message);
    if (err.stack) console.error(err.stack);
    failed++;
  }
}

if (failed === 0) {
  console.log('\n🎉 ALL 10 PAGES RENDERED CLEANLY WITHOUT ERRORS!');
  process.exit(0);
} else {
  console.error(`\n💥 ${failed} pages failed to render!`);
  process.exit(1);
}
