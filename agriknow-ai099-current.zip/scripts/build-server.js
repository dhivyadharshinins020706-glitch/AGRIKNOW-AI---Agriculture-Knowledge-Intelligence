// Build script for AGRIKNOW AI Serverless Functions
// Uses esbuild to bundle each endpoint into a standalone, self-contained ES module for Vercel.
// Eliminates runtime ESM resolution and missing TypeScript extension issues.

import * as esbuild from 'esbuild';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

const endpoints = [
  { in: 'server/health.ts', out: 'api/health.js' },
  { in: 'server/ai/ask.ts', out: 'api/ai/ask.js' },
  { in: 'server/ai/diagnose.ts', out: 'api/ai/diagnose.js' },
  { in: 'server/ai/analyze-document.ts', out: 'api/ai/analyze-document.js' },
  { in: 'server/ai/document-qa.ts', out: 'api/ai/document-qa.js' },
  { in: 'server/ai/embed.ts', out: 'api/ai/embed.js' },
];

async function buildServerlessFunctions() {
  console.log('⚡ Bundling AGRIKNOW AI Serverless Functions for Vercel deployment...');

  // Ensure api and api/ai exist
  fs.mkdirSync(path.join(rootDir, 'api', 'ai'), { recursive: true });

  for (const ep of endpoints) {
    const inputPath = path.join(rootDir, ep.in);
    const outputPath = path.join(rootDir, ep.out);

    await esbuild.build({
      entryPoints: [inputPath],
      bundle: true,
      platform: 'node',
      target: 'node20',
      format: 'esm',
      packages: 'external',
      outfile: outputPath,
      sourcemap: true,
      minify: false,
      banner: {
        js: '// AGRIKNOW AI Production Serverless Function (Bundled)\n',
      },
    });

    const stat = fs.statSync(outputPath);
    const sizeKb = (stat.size / 1024).toFixed(1);
    console.log(`  ✅ Bundled ${ep.out} (${sizeKb} KB)`);
  }

  // Remove any legacy .ts files from api/ so Vercel only treats the 6 .js files as endpoints
  const cleanLegacyTs = (dir) => {
    if (!fs.existsSync(dir)) return;
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (entry.name.startsWith('_') || entry.name === 'services' || entry.name === 'middleware' || entry.name === 'config') {
          fs.rmSync(fullPath, { recursive: true, force: true });
          console.log(`  🧹 Removed internal directory: ${path.relative(rootDir, fullPath)}`);
        } else {
          cleanLegacyTs(fullPath);
        }
      } else if (entry.name.endsWith('.ts')) {
        fs.unlinkSync(fullPath);
        console.log(`  🧹 Removed legacy source: ${path.relative(rootDir, fullPath)}`);
      }
    }
  };

  cleanLegacyTs(path.join(rootDir, 'api'));
  console.log('🚀 Serverless function build complete! Exactly 6 standalone endpoints ready in api/\n');
}

buildServerlessFunctions().catch((err) => {
  console.error('❌ Serverless build error:', err);
  process.exit(1);
});
