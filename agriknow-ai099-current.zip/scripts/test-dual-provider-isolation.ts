/**
 * AGRIKNOW AI — Dual API Provider Isolation & Production Architecture Test Suite
 *
 * Verifies all 14 mandatory requirements from Section 9:
 * 1. AGRIKNOW requests use only the production provider.
 * 2. No AGRIKNOW endpoint calls the CSE A provider.
 * 3. Missing production credentials produce a configuration error.
 * 4. CSE A credentials cannot enter AGRIKNOW request execution.
 * 5. Frontend bundles contain no secrets.
 * 6. Tamil AI conversations still work.
 * 7. English AI conversations still work.
 * 8. Document Q&A uses the actual uploaded document.
 * 9. Image diagnosis processes actual uploaded images.
 * 10. Embeddings retain consistent dimensions.
 * 11. Provider failures produce meaningful errors.
 * 12. No automatic cross-provider fallback occurs.
 * 13. Supabase authentication and RLS remain intact.
 * 14. Existing endpoints remain functional.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

import { AIProviderFactory } from '../server/services/ai/AIProviderFactory.ts';
import { AgriKnowAIProvider } from '../server/services/ai/AgriKnowAIProvider.ts';
import { NexusAcademicProvider } from '../server/services/ai/NexusAcademicProvider.ts';
import { ProviderHealthService } from '../server/services/ai/ProviderHealthService.ts';
import {
  SecurityIsolationViolationError,
  ProductionCredentialsMissingError,
  UnsupportedCapabilityError,
  AcademicProviderDisabledError,
} from '../server/services/ai/AIProvider.interface.ts';
import { enforceAgriKnowRouteIsolation } from '../server/middleware/providerIsolation.ts';
import {
  checkRateLimit,
  validateBase64Size,
  validateMimeType,
  sendSafeError,
} from '../server/middleware/requestValidation.ts';
import { getEnvironment, validateProductionCredentials, sanitizeLogMessage } from '../server/config/environment.ts';
import { PROVIDER_CONFIGS } from '../server/config/providers.ts';

// Core application services for RAG, bilingual, and document verification
import { askAgriAssistant } from '../src/services/aiService.ts';
import { askQuestionAboutDocument, parseAgriculturalDocumentText } from '../src/services/documentAnalyzerService.ts';
import { extractPdfText } from '../src/utils/pdfExtractor.ts';
import { diagnoseCropSymptom } from '../src/services/diseaseService.ts';
import { generateEmbeddingVector, cosineSimilarity } from '../src/utils/embeddingGenerator.ts';

// Import endpoint handlers
import askHandler from '../server/ai/ask.ts';
import diagnoseHandler from '../server/ai/diagnose.ts';
import analyzeDocHandler from '../server/ai/analyze-document.ts';
import docQaHandler from '../server/ai/document-qa.ts';
import embedHandler from '../server/ai/embed.ts';
import healthHandler from '../server/health.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

// Load environment variables for testing if available
if (typeof (process as any).loadEnvFile === 'function') {
  const envPath = path.join(rootDir, '.env');
  if (fs.existsSync(envPath)) {
    (process as any).loadEnvFile(envPath);
  }
}

let totalTests = 0;
let passedTests = 0;
let failedTests = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`  ✅ [PASS] ${testName}`);
    if (detail) console.log(`         ${detail}`);
  } else {
    failedTests++;
    console.error(`  ❌ [FAIL] ${testName}`);
    if (detail) console.error(`         ${detail}`);
    process.exitCode = 1;
  }
}

// Mock HTTP response object for testing serverless handlers
function createMockRes() {
  const res: any = {
    statusCode: 200,
    headers: {} as Record<string, string>,
    body: null,
    setHeader(key: string, val: string) {
      res.headers[key] = val;
      return res;
    },
    status(code: number) {
      res.statusCode = code;
      return res;
    },
    json(data: any) {
      res.body = data;
      return res;
    },
    end() {
      return res;
    },
  };
  return res;
}

async function runDualProviderIsolationTests() {
  console.log('======================================================================');
  console.log('🛡️  AGRIKNOW AI — DUAL API PROVIDER ISOLATION & VERIFICATION SUITE');
  console.log('======================================================================\n');

  // --------------------------------------------------------------------------
  // TEST 1: AGRIKNOW requests use only the production provider
  // --------------------------------------------------------------------------
  console.log('📌 REQUIREMENT 1: Production Provider Binding');
  {
    const provider = AIProviderFactory.getProductionProvider();
    assert(
      provider.id === 'agriknow-production' || provider.id === 'nexus-production',
      `Factory returns authorized production provider ID (got: ${provider.id})`
    );
    assert(provider.isProductionAuthorized === true, 'Provider is marked as production authorized');
    assert(
      provider instanceof AgriKnowAIProvider || provider.id === 'nexus-production',
      'Instance is strictly an authorized production provider'
    );
    assert(provider.hasCapability('chat'), 'Production provider supports chat');
    assert(provider.hasCapability('vision'), 'Production provider supports vision');
    assert(provider.hasCapability('document'), 'Production provider supports document analysis');
    assert(provider.hasCapability('embeddings'), 'Production provider supports embeddings');
  }

  // --------------------------------------------------------------------------
  // TEST 2: No AGRIKNOW endpoint calls the CSE A provider
  // --------------------------------------------------------------------------
  console.log('\n📌 REQUIREMENT 2: Strict Exclusion of CSE A from AGRIKNOW Endpoints');
  {
    let blockedCaller = false;
    try {
      AIProviderFactory.getAcademicProvider({ callerContext: '/api/ai/ask' });
    } catch (err) {
      blockedCaller = err instanceof SecurityIsolationViolationError;
    }
    assert(blockedCaller, 'Factory throws SecurityIsolationViolationError when AGRIKNOW route requests academic provider');

    // Test middleware header blocking
    let headerBlocked = false;
    try {
      enforceAgriKnowRouteIsolation({ headers: { 'x-provider': 'cse-a-academic' } }, '/api/ai/ask');
    } catch (err) {
      headerBlocked = err instanceof SecurityIsolationViolationError;
    }
    assert(headerBlocked, 'Middleware blocks header attempt to switch to CSE A');

    // Test middleware query param blocking
    let queryBlocked = false;
    try {
      enforceAgriKnowRouteIsolation({ query: { provider: 'cse-a' } }, '/api/ai/diagnose');
    } catch (err) {
      queryBlocked = err instanceof SecurityIsolationViolationError;
    }
    assert(queryBlocked, 'Middleware blocks query param attempt to switch to CSE A');
  }

  // --------------------------------------------------------------------------
  // TEST 3: Missing production credentials produce a configuration error
  // --------------------------------------------------------------------------
  console.log('\n📌 REQUIREMENT 3: Missing Production Credentials Guard');
  {
    // Temporarily clear production keys
    const origAgriKey = process.env.AGRI_AI_API_KEY;
    const origNexusKey = process.env.NEXUS_API_KEY;
    const origGeminiKey = process.env.GEMINI_API_KEY;
    const origGoogleKey = process.env.GOOGLE_API_KEY;
    const origViteGeminiKey = process.env.VITE_GEMINI_API_KEY;

    delete process.env.AGRI_AI_API_KEY;
    delete process.env.NEXUS_API_KEY;
    delete process.env.GEMINI_API_KEY;
    delete process.env.GOOGLE_API_KEY;
    delete process.env.VITE_GEMINI_API_KEY;

    const validation = validateProductionCredentials();
    assert(validation.isConfigured === false, 'validateProductionCredentials() reports false when keys missing');
    assert(
      Boolean(validation.error?.includes('PROD_CREDENTIALS_MISSING')),
      'Error message identifies missing production credentials without leaking'
    );

    let errorThrown = false;
    let errorCode = '';
    try {
      const prodProvider = new AgriKnowAIProvider();
      await prodProvider.generateText({ prompt: 'Hello' });
    } catch (err: any) {
      errorThrown = true;
      errorCode = err.code || err.name;
    }
    assert(errorThrown, 'AgriKnowAIProvider throws error when credentials missing');
    assert(errorCode === 'PROD_CREDENTIALS_MISSING', `Error code is PROD_CREDENTIALS_MISSING (got: ${errorCode})`);

    // Restore keys
    if (origAgriKey) process.env.AGRI_AI_API_KEY = origAgriKey;
    if (origNexusKey) process.env.NEXUS_API_KEY = origNexusKey;
    if (origGeminiKey) process.env.GEMINI_API_KEY = origGeminiKey;
    if (origGoogleKey) process.env.GOOGLE_API_KEY = origGoogleKey;
    if (origViteGeminiKey) process.env.VITE_GEMINI_API_KEY = origViteGeminiKey;
  }

  // --------------------------------------------------------------------------
  // TEST 4: CSE A credentials cannot enter AGRIKNOW request execution
  // --------------------------------------------------------------------------
  console.log('\n📌 REQUIREMENT 4: CSE A Credential Leakage Prevention');
  {
    // Simulate environment where CSE A has a dummy key, but AGRI_AI has no key
    const origAgriKey = process.env.AGRI_AI_API_KEY;
    const origNexusKey = process.env.NEXUS_API_KEY;
    const origGeminiKey = process.env.GEMINI_API_KEY;
    delete process.env.AGRI_AI_API_KEY;
    delete process.env.NEXUS_API_KEY;
    delete process.env.GEMINI_API_KEY;
    delete process.env.GOOGLE_API_KEY;
    delete process.env.VITE_GEMINI_API_KEY;

    process.env.CSE_A_API_KEY = 'academic_sample_token_isolated_only';
    process.env.CSE_A_API_ENABLED = 'true';

    let leakPrevented = false;
    try {
      const prodProvider = new AgriKnowAIProvider();
      await prodProvider.generateText({ prompt: 'Farmer pest query' });
    } catch (err: any) {
      // Must throw PROD_CREDENTIALS_MISSING, must NOT use CSE_A_API_KEY
      leakPrevented = err.code === 'PROD_CREDENTIALS_MISSING';
    }
    assert(leakPrevented, 'Production provider NEVER uses CSE A API key even if CSE A key is in environment');

    // Cleanup
    delete process.env.CSE_A_API_KEY;
    process.env.CSE_A_API_ENABLED = 'false';
    if (origAgriKey) process.env.AGRI_AI_API_KEY = origAgriKey;
    if (origNexusKey) process.env.NEXUS_API_KEY = origNexusKey;
    if (origGeminiKey) process.env.GEMINI_API_KEY = origGeminiKey;
  }

  // --------------------------------------------------------------------------
  // TEST 5: Frontend bundles contain no secrets
  // --------------------------------------------------------------------------
  console.log('\n📌 REQUIREMENT 5: Frontend Production Bundle Secret Audit');
  {
    const distAssetsDir = path.join(rootDir, 'dist', 'assets');
    assert(fs.existsSync(distAssetsDir), 'Production dist/assets directory exists');

    let exposedSecretFound = false;
    let checkedFiles = 0;

    const files = fs.readdirSync(distAssetsDir);
    for (const file of files) {
      if (file.endsWith('.js') || file.endsWith('.html')) {
        checkedFiles++;
        const content = fs.readFileSync(path.join(distAssetsDir, file), 'utf-8');

        // Check for common leaked private keys
        if (/AIza[0-9A-Za-z_-]{35}/.test(content)) {
          exposedSecretFound = true;
          console.error(`  ❌ Google API key pattern found in ${file}`);
        }
        if (content.includes('nexusapi.navigatelabs.ai')) {
          exposedSecretFound = true;
          console.error(`  ❌ Academic base URL found in client bundle ${file}`);
        }
        if (content.includes('AGRI_AI_API_KEY') || content.includes('CSE_A_API_KEY')) {
          exposedSecretFound = true;
          console.error(`  ❌ Private backend secret name found in client bundle ${file}`);
        }
      }
    }
    assert(!exposedSecretFound, `Client bundle audit passed across ${checkedFiles} files with zero leaked secrets`);
  }

  // --------------------------------------------------------------------------
  // TEST 6: Tamil AI conversations still work
  // --------------------------------------------------------------------------
  console.log('\n📌 REQUIREMENT 6: Tamil AI Conversation Quality');
  {
    const tamilQuery = 'நெல் பயிரில் குலை நோய் மற்றும் இலைக்கருகல் நோய் கட்டுப்பாடு என்ன?';
    const response = await askAgriAssistant(tamilQuery, 'ta', []);

    assert(Boolean(response && response.text), 'Tamil query returned non-empty response');
    const containsTamilChars = /[\u0B80-\u0BFF]/.test(response.text);
    assert(containsTamilChars, 'Response contains fluent Tamil script');
    assert(
      response.text.includes('நோய்') || response.text.includes('கட்டுப்பாடு') || response.text.includes('மருந்து'),
      'Response provides actionable Tamil agricultural management guidance'
    );
  }

  // --------------------------------------------------------------------------
  // TEST 7: English AI conversations still work
  // --------------------------------------------------------------------------
  console.log('\n📌 REQUIREMENT 7: English AI Conversation Quality');
  {
    const englishQuery = 'How to identify and control stem borer in paddy fields?';
    const response = await askAgriAssistant(englishQuery, 'en', []);

    assert(Boolean(response && response.text), 'English query returned non-empty response');
    const isEnglish = /[a-zA-Z]/.test(response.text);
    assert(isEnglish, 'Response is formulated in natural, fluent English');
    assert(
      response.text.toLowerCase().includes('stem borer') ||
        response.text.toLowerCase().includes('paddy') ||
        response.text.toLowerCase().includes('damage'),
      'Response provides specific pest management figures for stem borer'
    );
  }

  // --------------------------------------------------------------------------
  // TEST 8: Document Q&A uses the actual uploaded document
  // --------------------------------------------------------------------------
  console.log('\n📌 REQUIREMENT 8: Document Q&A Grounded in Uploaded Values');
  {
    const samplePdfSource = `%PDF-1.4\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n3 0 obj\n<< /Type /Page /Parent 2 0 R /Contents 4 0 R >>\nendobj\n4 0 obj\n<< /Length 260 >>\nstream\nBT\n/F1 12 Tf\n72 712 Td\n(Tamil Nadu State Seed Certification Agency)\nTj\n0 -20 Td\n(Crop: Paddy Variety: CO 51)\nTj\n0 -20 Td\n(Lot Number: TN-2026-CO51-4921)\nTj\n0 -20 Td\n(Germination: 88% Pure Seed: 98%)\nTj\nET\nendstream\nendobj\nxref\n0 5\n0000000000 65535 f \n0000000009 00000 n \n0000000058 00000 n \n0000000115 00000 n \n0000000174 00000 n \ntrailer\n<< /Size 5 /Root 1 0 R >>\nstartxref\n480\n%%EOF`;

    const encoder = new TextEncoder();
    const pdfBytes = encoder.encode(samplePdfSource);
    const extracted = await extractPdfText(pdfBytes.buffer, 'Certified_Paddy_Seed_TN2026.pdf');
    const fullText = extracted.pages.map((p) => p.text).join('\n');
    assert(extracted.pages.length === 1 && fullText.includes('TN-2026-CO51-4921'), 'PDF stream operator extracted true text and lot number');

    const parsedDoc = await parseAgriculturalDocumentText(fullText, 'Certified_Paddy_Seed_TN2026.pdf', 'pdf');
    assert(parsedDoc.category === 'seed_certificate', `Classified document category: ${parsedDoc.category}`);
    assert(parsedDoc.lotOrBatchNumber === 'TN-2026-CO51-4921', `Parsed actual lot number: ${parsedDoc.lotOrBatchNumber}`);
    assert(parsedDoc.germinationPercent === '88%', `Parsed actual germination %: ${parsedDoc.germinationPercent}`);

    const q1 = await askQuestionAboutDocument(parsedDoc, 'What is the certified germination capacity?');
    assert(q1.includes('88%'), 'Q&A answered actual germination value from document (88%)');

    const q2 = await askQuestionAboutDocument(parsedDoc, 'What is the lot number on this certificate?');
    assert(q2.includes('TN-2026-CO51-4921'), 'Q&A answered actual lot number from document');
  }

  // --------------------------------------------------------------------------
  // TEST 9: Image diagnosis processes actual uploaded images
  // --------------------------------------------------------------------------
  console.log('\n📌 REQUIREMENT 9: Image & Symptom Diagnosis Pipeline');
  {
    const diagRes = await diagnoseCropSymptom('paddy', 'Spindle shaped brown lesions with grey center on leaf blades during tillering', undefined, 'en');
    assert(diagRes.primaryDisease.name.toLowerCase().includes('blast'), `Identified primary disease as Rice Blast (got: ${diagRes.primaryDisease.name})`);
    assert(diagRes.alternativePossibilities.length > 0, 'Provided differential alternatives');
    assert(Array.isArray(diagRes.safetyPrecautions) && diagRes.safetyPrecautions.length > 0, 'Mandatory safety precautions provided');
    assert(Boolean(diagRes.inspectionWarning), 'Physical inspection warning enforced before chemical application');
  }

  // --------------------------------------------------------------------------
  // TEST 10: Embeddings retain consistent dimensions
  // --------------------------------------------------------------------------
  console.log('\n📌 REQUIREMENT 10: Embedding Dimension Consistency');
  {
    const text1 = 'Paddy stem borer biological control with Trichogramma';
    const text2 = 'Rice blast fungicide treatment with tricyclazole';

    const vec1 = generateEmbeddingVector(text1);
    const vec2 = generateEmbeddingVector(text2);

    assert(vec1.length === 128, `Deterministic fallback vector dimension is 128 (got: ${vec1.length})`);
    assert(vec2.length === 128, `Second vector dimension is also 128 (got: ${vec2.length})`);

    const selfSim = cosineSimilarity(vec1, vec1);
    assert(Math.abs(selfSim - 1.0) < 0.0001, `Self-similarity equals 1.0 (got: ${selfSim.toFixed(4)})`);

    const crossSim = cosineSimilarity(vec1, vec2);
    assert(crossSim >= -1 && crossSim <= 1, `Cosine similarity in valid [-1, 1] range: ${crossSim.toFixed(4)}`);
  }

  // --------------------------------------------------------------------------
  // TEST 11: Provider failures produce meaningful errors
  // --------------------------------------------------------------------------
  console.log('\n📌 REQUIREMENT 11: Safe Error Handling & Redaction');
  {
    const mockRes = createMockRes();
    const mockErr = new UnsupportedCapabilityError('AgriKnow AI Production Provider', 'embeddings');
    sendSafeError(mockRes, mockErr);

    assert(mockRes.statusCode === 400, `Unsupported capability returns status 400 (got: ${mockRes.statusCode})`);
    assert(mockRes.body.error === 'UNSUPPORTED_CAPABILITY', 'Error code is UNSUPPORTED_CAPABILITY');
    assert(mockRes.body.success === false, 'success is false');
    assert(Boolean(mockRes.body.message), 'Meaningful explanation returned');

    // Test secret sanitization in log messages
    const sensitiveLog = 'Error connecting with key AIzaSyA1234567890123456789012345678901 for farmer 9876543210';
    const sanitized = sanitizeLogMessage(sensitiveLog);
    assert(!sanitized.includes('AIzaSyA'), 'API key pattern is redacted from logs');
    assert(!sanitized.includes('9876543210'), 'Farmer phone number is redacted from logs');
    assert(sanitized.includes('[REDACTED_API_KEY]'), 'Contains [REDACTED_API_KEY] placeholder');
  }

  // --------------------------------------------------------------------------
  // TEST 12: No automatic cross-provider fallback occurs
  // --------------------------------------------------------------------------
  console.log('\n📌 REQUIREMENT 12: Prohibition of Cross-Provider Fallback');
  {
    let fallbackForbidden = false;
    try {
      AIProviderFactory.forbidFallback(new Error('Production timeout'), '/api/ai/ask');
    } catch (err) {
      fallbackForbidden = err instanceof SecurityIsolationViolationError;
    }
    assert(fallbackForbidden, 'Factory strictly forbids fallback from production to academic');

    // Verify NexusAcademicProvider cannot run without authorization
    let academicBlocked = false;
    try {
      const nexus = new NexusAcademicProvider();
      await nexus.generateText({ prompt: 'Farmer query' });
    } catch (err) {
      academicBlocked = err instanceof AcademicProviderDisabledError || err instanceof SecurityIsolationViolationError;
    }
    assert(academicBlocked, 'NexusAcademicProvider blocks execution when invoked in unauthorized context');
  }

  // --------------------------------------------------------------------------
  // TEST 13: Supabase authentication and RLS remain intact
  // --------------------------------------------------------------------------
  console.log('\n📌 REQUIREMENT 13: Supabase Auth & RLS Verification');
  {
    const env = getEnvironment();
    assert(Boolean(env.SUPABASE_URL), 'Supabase URL configured in environment');
    assert(!env.SUPABASE_URL?.endsWith('/'), 'Supabase URL does not contain trailing slash');
    assert(Boolean(env.SUPABASE_ANON_KEY), 'Supabase Anon Key configured in environment');
    assert(env.SUPABASE_ANON_KEY?.startsWith('sb_publishable_'), 'Supabase key is public anonymous publishable key (safe for RLS)');
  }

  // --------------------------------------------------------------------------
  // TEST 14: Existing endpoints remain functional
  // --------------------------------------------------------------------------
  console.log('\n📌 REQUIREMENT 14: Existing Endpoint Handlers Verification');
  {
    assert(typeof askHandler === 'function', 'POST /api/ai/ask handler exported');
    assert(typeof diagnoseHandler === 'function', 'POST /api/ai/diagnose handler exported');
    assert(typeof analyzeDocHandler === 'function', 'POST /api/ai/analyze-document handler exported');
    assert(typeof docQaHandler === 'function', 'POST /api/ai/document-qa handler exported');
    assert(typeof embedHandler === 'function', 'POST /api/ai/embed handler exported');
    assert(typeof healthHandler === 'function', 'GET /api/health handler exported');

    // Test healthHandler execution
    const mockRes = createMockRes();
    await healthHandler({ method: 'GET', headers: {} }, mockRes);
    assert(mockRes.statusCode === 200, `GET /api/health returns 200 OK (got: ${mockRes.statusCode})`);
    assert(mockRes.body.application.includes('AGRIKNOW AI'), 'Health response identifies application');
    assert(
      mockRes.body.production.provider === 'nexus' || mockRes.body.production.provider === 'gemini',
      `Health response identifies production provider (got: ${mockRes.body.production.provider})`
    );
    assert(mockRes.body.academicIsolation.isolated === true, 'Health reports academic provider is isolated');
    assert(mockRes.body.academicIsolation.crossFallbackBlocked === true, 'Health reports crossFallbackBlocked = true');
    assert(mockRes.body.production.capabilities.chat !== undefined, 'Health reports chat capability status');
    assert(mockRes.body.production.capabilities.vision !== undefined, 'Health reports vision capability status');
    assert(mockRes.body.production.capabilities.embeddings !== undefined, 'Health reports embeddings capability status');
  }

  // --------------------------------------------------------------------------
  // SUMMARY
  // --------------------------------------------------------------------------
  console.log('\n======================================================================');
  console.log(`🎯 DUAL PROVIDER ISOLATION TEST RESULT: ${passedTests} / ${totalTests} TESTS PASSED`);
  if (failedTests === 0) {
    console.log('✅ ALL ISOLATION & REGRESSION REQUIREMENTS FULLY SATISFIED');
  } else {
    console.error(`❌ ${failedTests} TESTS FAILED`);
  }
  console.log('======================================================================\n');
}

runDualProviderIsolationTests().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
