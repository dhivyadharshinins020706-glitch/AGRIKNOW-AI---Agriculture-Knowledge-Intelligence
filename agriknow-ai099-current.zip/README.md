# AGRIKNOW AI — Agricultural Knowledge Intelligence Platform

**AGRIKNOW AI** is an evidence-grounded, bilingual (Tamil & English) agricultural intelligence platform engineered for Indian farmers, field officers, and agricultural scientists. It delivers research-backed guidance on crop diagnostics, soil and fertilizer management, and regional crop selection using verified publications from the **Indian Council of Agricultural Research (ICAR)** and **Tamil Nadu Agricultural University (TNAU)**.

---

## 🏛️ Project Architecture

The project is cleanly modularized into four core directories:

```
agriknow-ai/
├── 📁 frontend/             # React 18 + Tailwind CSS + Framer Motion UI
│   ├── src/components/     # Domain components (assistant, crops, diseases, soil, library)
│   ├── src/pages/          # Application views & dashboards
│   ├── src/contexts/       # Auth, language, farmer profile, toast providers
│   ├── src/data/           # Curated evidence bases, agricultural sources
│   ├── src/lib/            # Localization engine, router, Supabase client
│   └── index.html          # HTML entry point with metadata
│
├── 📁 backend/              # API services, security, telemetry & network resilience
│   ├── services/           # Auth, farmer profile, conversations, weather, mandi APIs
│   ├── utils/              # Upload safety, XSS protection, PII masking, rate limiting
│   └── telemetry/          # Structured JSON logger with ring buffer
│
├── 📁 ai/                   # Advanced RAG Intelligence Engine & NLP pipeline
│   ├── rag/                # Multi-stage RAG, query cache, prompt injection shield
│   ├── nlp/                # Chunker, text cleaner, multilingual embedding generator
│   └── services/           # Assistant orchestration, safe chemical guardrails
│
└── 📁 database/             # PostgreSQL / Supabase migrations & recovery suites
    ├── migrations/         # RLS policies, RBAC roles, knowledge vectors
    └── scripts/            # Snapshot generator, restoration & automated test suites
```

---

## 🎨 Official Brand Palette

Strict adherence to the official 5-color palette:
- **Harvest Gold / Brand:** `#F09B04`
- **Leaf Green:** `#53B54F`
- **Mauve / Accent:** `#C6A9D8`
- **Electric Cyan:** `#14F6FA`
- **Soft Lilac / Background:** `#E4D8F1`

---

## 🚀 Live Production Deployment

- **Production URL:** [https://agriknow-ai.vercel.app](https://agriknow-ai.vercel.app)
- **Deployment Platform:** Vercel
- **Environment:** Vite + React + TypeScript + Tailwind CSS

---

## 💻 Local Setup & Execution

1. **Install Dependencies:**
   ```bash
   npm install
   ```

2. **Start Development Server:**
   ```bash
   npm run dev
   ```
   Open [http://localhost:5173](http://localhost:5173) in your browser.

3. **Run Production Build:**
   ```bash
   npm run build
   ```

4. **Execute Verification Suites:**
   ```bash
   # Run Phase 6 Security & Reliability Suite
   node --experimental-strip-types database/scripts/test-phase6-security-reliability.ts

   # Run Database Backup Restoration Suite
   node --experimental-strip-types database/scripts/test-backup-restoration.ts
   ```
