// AGRIKNOW AI Production Serverless Function (Bundled)


// server/services/ai/AIProvider.interface.ts
var AIProviderError = class extends Error {
  code;
  statusCode;
  constructor(message, code, statusCode = 500) {
    super(message);
    this.name = "AIProviderError";
    this.code = code;
    this.statusCode = statusCode;
  }
};
var ProductionCredentialsMissingError = class extends AIProviderError {
  constructor(detail) {
    super(
      detail || "PROD_CREDENTIALS_MISSING: AGRIKNOW production credentials (AGRI_AI_API_KEY) are missing. Cross-provider fallback to academic API is strictly prohibited.",
      "PROD_CREDENTIALS_MISSING",
      503
    );
    this.name = "ProductionCredentialsMissingError";
  }
};
var SecurityIsolationViolationError = class extends AIProviderError {
  constructor(detail) {
    super(
      `SECURITY_ISOLATION_VIOLATION: ${detail}`,
      "SECURITY_ISOLATION_VIOLATION",
      403
    );
    this.name = "SecurityIsolationViolationError";
  }
};
var UnsupportedCapabilityError = class extends AIProviderError {
  constructor(providerName, capability) {
    super(
      `UNSUPPORTED_CAPABILITY: Provider "${providerName}" does not support required capability "${capability}". Fallback to other providers is forbidden.`,
      "UNSUPPORTED_CAPABILITY",
      400
    );
    this.name = "UnsupportedCapabilityError";
  }
};
var AcademicProviderDisabledError = class extends AIProviderError {
  constructor() {
    super(
      "ACADEMIC_PROVIDER_DISABLED: The CSE A academic provider is disabled. It can only be used for explicitly authorized academic experiments.",
      "ACADEMIC_PROVIDER_DISABLED",
      403
    );
    this.name = "AcademicProviderDisabledError";
  }
};

// server/config/providers.ts
var PROVIDER_CONFIGS = {
  "agriknow-production": {
    id: "agriknow-production",
    displayName: "AGRIKNOW AI Production Provider",
    isAcademicOnly: false,
    isProductionAuthorized: true,
    supportedCapabilities: [
      "chat",
      "structuredJson",
      "vision",
      "document",
      "embeddings"
    ],
    defaultModel: "gemini-2.5-flash",
    defaultEmbeddingModel: "gemini-embedding-2",
    isolationNotice: "Authorized for AGRIKNOW AI production services. Serves farmer queries, disease diagnoses, document extraction, and semantic embeddings."
  },
  "nexus-production": {
    id: "nexus-production",
    displayName: "Navigate Labs Nexus Production Engine",
    isAcademicOnly: false,
    isProductionAuthorized: true,
    supportedCapabilities: [
      "chat",
      "structuredJson",
      "vision",
      "document",
      "embeddings"
    ],
    defaultModel: "nova-micro",
    defaultEmbeddingModel: "text-embedding-3-small",
    baseUrl: "https://nexusapi.navigatelabs.ai",
    isolationNotice: "Authorized primary production AI inference provider for AGRIKNOW AI via Navigate Labs Nexus."
  },
  "cse-a-academic": {
    id: "cse-a-academic",
    displayName: "CSE A Academic Experiment Provider (Nexus)",
    isAcademicOnly: true,
    isProductionAuthorized: false,
    supportedCapabilities: ["chat"],
    defaultModel: "nexus-academic-v1",
    baseUrl: "https://nexusapi.navigatelabs.ai",
    isolationNotice: "STRICTLY ISOLATED: Used ONLY for explicitly authorized CSE A academic research experiments. Disabled by default. Forbidden in production AGRIKNOW routes. Never receives farmer queries, documents, or images."
  }
};

// server/config/environment.ts
function sanitizeLogMessage(message) {
  if (!message || typeof message !== "string") return "";
  return message.replace(/AIza[0-9A-Za-z_-]{20,50}/g, "[REDACTED_API_KEY]").replace(/bearer\s+[a-zA-Z0-9_.-]+/gi, "Bearer [REDACTED_TOKEN]").replace(/sb_publishable_[a-zA-Z0-9_-]+/g, "[REDACTED_SUPABASE_KEY]").replace(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g, "[REDACTED_EMAIL]").replace(/\b(?:\+91|91)?[6-9]\d{9}\b/g, "[REDACTED_PHONE]");
}
function getEnvironment() {
  const env = typeof process !== "undefined" ? process.env : {};
  const isNexus = (env.AGRI_AI_PROVIDER || "").toLowerCase() === "nexus";
  const productionApiKey = isNexus ? env.NEXUS_API_KEY || env.AGRI_AI_API_KEY || void 0 : env.AGRI_AI_API_KEY || env.GEMINI_API_KEY || env.GOOGLE_API_KEY || env.VITE_GEMINI_API_KEY || void 0;
  const productionModel = env.AGRI_AI_MODEL || (isNexus ? env.NEXUS_MODEL || "nexus-v1" : env.GEMINI_MODEL || "gemini-2.5-flash");
  const productionEmbeddingModel = env.AGRI_AI_EMBEDDING_MODEL || env.GEMINI_EMBEDDING_MODEL || "gemini-embedding-2";
  const isCseAEnabled = env.CSE_A_API_ENABLED === "true";
  const cseABaseUrl = env.CSE_A_API_BASE_URL || "https://nexusapi.navigatelabs.ai";
  const cseAApiKey = env.CSE_A_API_KEY || void 0;
  return {
    AGRI_AI_PROVIDER: env.AGRI_AI_PROVIDER || "gemini",
    AGRI_AI_BASE_URL: env.AGRI_AI_BASE_URL || (isNexus ? env.NEXUS_BASE_URL || "https://nexusapi.navigatelabs.ai" : void 0),
    AGRI_AI_API_KEY: productionApiKey,
    AGRI_AI_MODEL: productionModel,
    AGRI_AI_EMBEDDING_MODEL: productionEmbeddingModel,
    CSE_A_API_ENABLED: isCseAEnabled,
    CSE_A_API_BASE_URL: cseABaseUrl,
    CSE_A_API_KEY: cseAApiKey,
    SUPABASE_URL: env.VITE_SUPABASE_URL || env.SUPABASE_URL || void 0,
    SUPABASE_ANON_KEY: env.VITE_SUPABASE_ANON_KEY || env.SUPABASE_ANON_KEY || void 0,
    NODE_ENV: env.NODE_ENV || "production",
    APP_VERSION: "3.0.0-dual-isolated"
  };
}
function validateProductionCredentials() {
  const env = getEnvironment();
  if (!env.AGRI_AI_API_KEY || !env.AGRI_AI_API_KEY.trim()) {
    const keyName = env.AGRI_AI_PROVIDER === "nexus" ? "NEXUS_API_KEY" : "AGRI_AI_API_KEY / GEMINI_API_KEY";
    return {
      isConfigured: false,
      provider: env.AGRI_AI_PROVIDER,
      model: env.AGRI_AI_MODEL,
      error: `PROD_CREDENTIALS_MISSING: AGRIKNOW AI production API credentials (${keyName}) are not configured. The academic provider cannot be used as a fallback.`
    };
  }
  return {
    isConfigured: true,
    provider: env.AGRI_AI_PROVIDER,
    model: env.AGRI_AI_MODEL
  };
}

// backend/services/geminiService.ts
import { GoogleGenAI } from "@google/genai";
var usageStats = {
  totalRequests: 0,
  successfulRequests: 0,
  failedRequests: 0,
  totalTokensUsed: 0,
  activeModel: process.env.GEMINI_MODEL || "gemini-2.5-flash-lite",
  embeddingModel: process.env.GEMINI_EMBEDDING_MODEL || "gemini-embedding-2",
  lastRequestTime: null
};
function getGeminiApiKey() {
  const key = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || process.env.VITE_GEMINI_API_KEY || null;
  if (key && key.trim().length > 5 && !key.includes("YOUR_")) {
    return key.trim();
  }
  return null;
}
function getGeminiModel(override) {
  if (override) return override;
  return process.env.GEMINI_MODEL || "gemini-2.5-flash-lite";
}
function getGeminiEmbeddingModel(override) {
  if (override) return override;
  return process.env.GEMINI_EMBEDDING_MODEL || "gemini-embedding-2";
}
var cachedGenAiClient = null;
var cachedApiKey = null;
function getGenAiClient() {
  const apiKey = getGeminiApiKey();
  if (!apiKey) return null;
  if (!cachedGenAiClient || cachedApiKey !== apiKey) {
    cachedGenAiClient = new GoogleGenAI({ apiKey });
    cachedApiKey = apiKey;
  }
  return cachedGenAiClient;
}
async function withRetry(operation, retries = 3, delayMs = 1e3, operationName = "Gemini Operation") {
  let attempt = 0;
  while (attempt < retries) {
    try {
      return await operation();
    } catch (err) {
      attempt++;
      const errMsg = err instanceof Error ? err.message : String(err);
      const isTransient = errMsg.includes("429") || errMsg.includes("503") || errMsg.includes("RESOURCE_EXHAUSTED") || errMsg.includes("UNAVAILABLE") || errMsg.includes("fetch failed") || errMsg.includes("ECONNRESET");
      if (attempt >= retries || !isTransient) {
        throw err;
      }
      const backoff = delayMs * Math.pow(2, attempt - 1);
      console.warn(`[Gemini Retry] ${operationName} failed (attempt ${attempt}/${retries}): ${errMsg}. Retrying in ${backoff}ms...`);
      await new Promise((resolve) => setTimeout(resolve, backoff));
    }
  }
  throw new Error(`${operationName} failed after ${retries} attempts.`);
}
async function callGeminiText(options) {
  usageStats.totalRequests++;
  usageStats.lastRequestTime = (/* @__PURE__ */ new Date()).toISOString();
  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    usageStats.failedRequests++;
    throw new Error(
      "GEMINI_KEY_NOT_CONFIGURED: Google Gemini API key is not configured on the server. Please set GEMINI_API_KEY in your environment variables."
    );
  }
  const modelsToTry = [
    options.model,
    process.env.GEMINI_MODEL,
    "gemini-flash-lite-latest",
    "gemini-3.5-flash-lite",
    "gemini-3.5-flash",
    "gemini-2.5-flash",
    "gemini-flash-latest",
    "gemini-3.8-flash",
    "gemini-pro-latest"
  ].filter(Boolean);
  const uniqueModels = Array.from(new Set(modelsToTry));
  let lastError = null;
  for (const model of uniqueModels) {
    try {
      usageStats.activeModel = model;
      const client = getGenAiClient();
      if (client && client.models) {
        try {
          const contents2 = [];
          if (options.history && options.history.length > 0) {
            for (const turn of options.history) {
              if (!turn.text || turn.text.trim().length === 0) continue;
              contents2.push({
                role: turn.role === "assistant" ? "model" : "user",
                parts: [{ text: turn.text }]
              });
            }
          }
          contents2.push({
            role: "user",
            parts: [{ text: options.prompt }]
          });
          const response = await client.models.generateContent({
            model,
            contents: contents2,
            config: {
              temperature: options.temperature ?? 0.2,
              maxOutputTokens: options.maxOutputTokens ?? 2500,
              systemInstruction: options.systemInstruction ? options.systemInstruction : void 0
            }
          });
          const candidate = response.candidates?.[0];
          const text = response.text || candidate?.content?.parts?.map((p) => p.text).join("") || "";
          if (text.trim()) {
            usageStats.successfulRequests++;
            const tokens = response.usageMetadata?.totalTokenCount || 0;
            usageStats.totalTokensUsed += tokens;
            return {
              text,
              modelUsed: model,
              tokensUsed: tokens,
              finishReason: candidate?.finishReason || "STOP"
            };
          }
        } catch (sdkErr) {
          console.warn(`[Gemini SDK Warning] SDK call for ${model} encountered error, trying REST:`, sdkErr?.message || sdkErr);
        }
      }
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
      const contents = [];
      if (options.history && options.history.length > 0) {
        for (const turn of options.history) {
          if (!turn.text || turn.text.trim().length === 0) continue;
          contents.push({
            role: turn.role === "assistant" ? "model" : "user",
            parts: [{ text: turn.text }]
          });
        }
      }
      contents.push({
        role: "user",
        parts: [{ text: options.prompt }]
      });
      const bodyPayload = {
        contents,
        generationConfig: {
          temperature: options.temperature ?? 0.2,
          topP: 0.95,
          maxOutputTokens: options.maxOutputTokens ?? 2500
        }
      };
      if (options.systemInstruction) {
        bodyPayload.systemInstruction = {
          parts: [{ text: options.systemInstruction }]
        };
      }
      const controller = new AbortController();
      const timeoutMs = options.timeoutMs ?? 2e4;
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
      try {
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(bodyPayload),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (!res.ok) {
          const errJson = await res.json().catch(() => ({}));
          const errMsg = errJson?.error?.message || `HTTP ${res.status} (${res.statusText})`;
          throw new Error(`GEMINI_API_ERROR: ${errMsg}`);
        }
        const data = await res.json();
        const candidate = data.candidates?.[0];
        const text = candidate?.content?.parts?.map((p) => p.text).join("") || "";
        if (!text.trim()) {
          throw new Error("GEMINI_EMPTY_RESPONSE: Gemini returned an empty response.");
        }
        usageStats.successfulRequests++;
        const tokens = data.usageMetadata?.totalTokenCount || 0;
        usageStats.totalTokensUsed += tokens;
        return {
          text,
          modelUsed: model,
          tokensUsed: tokens,
          finishReason: candidate?.finishReason || "STOP"
        };
      } catch (restErr) {
        clearTimeout(timeoutId);
        throw restErr;
      }
    } catch (modelErr) {
      lastError = modelErr;
      const errMsg = modelErr instanceof Error ? modelErr.message : String(modelErr);
      console.warn(`[Gemini Failover] Model "${model}" failed (${errMsg}). Switching to next candidate model...`);
    }
  }
  usageStats.failedRequests++;
  throw new Error(`GEMINI_INFERENCE_ERROR: All candidate models failed. Last error: ${lastError instanceof Error ? lastError.message : String(lastError)}`);
}
async function callGeminiEmbeddings(text) {
  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    throw new Error("GEMINI_KEY_NOT_CONFIGURED: Set GEMINI_API_KEY in environment variables.");
  }
  const model = getGeminiEmbeddingModel();
  usageStats.embeddingModel = model;
  const client = getGenAiClient();
  return withRetry(
    async () => {
      if (client && client.models) {
        try {
          const res2 = await client.models.embedContent({
            model,
            contents: text
          });
          const values2 = res2?.embedding?.values;
          if (Array.isArray(values2) && values2.length > 0) {
            return values2;
          }
        } catch (sdkErr) {
          console.warn("[Gemini SDK Embed] SDK fallback to REST:", sdkErr?.message);
        }
      }
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:embedContent?key=${apiKey}`;
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          content: { parts: [{ text }] }
        })
      });
      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(`GEMINI_EMBEDDING_ERROR: ${errJson?.error?.message || res.statusText}`);
      }
      const data = await res.json();
      const values = data?.embedding?.values;
      if (!Array.isArray(values)) {
        throw new Error("GEMINI_EMBEDDING_ERROR: Invalid embedding response format.");
      }
      return values;
    },
    3,
    1e3,
    "Gemini Embedding Generation"
  );
}
async function callGeminiVision(base64Data, mimeType, userNotes, lang = "en") {
  usageStats.totalRequests++;
  usageStats.lastRequestTime = (/* @__PURE__ */ new Date()).toISOString();
  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    usageStats.failedRequests++;
    throw new Error(
      "GEMINI_KEY_NOT_CONFIGURED: Google Gemini API key is not configured on the server. Please set GEMINI_API_KEY in your environment variables."
    );
  }
  const model = getGeminiModel();
  usageStats.activeModel = model;
  const cleanBase64 = (base64Data || "").replace(/^data:[^;]+;base64,/, "").trim();
  const hasImage = cleanBase64.length > 20;
  const systemInstruction = `You are a Senior Plant Pathologist, Agricultural Entomologist, and Agronomist at Tamil Nadu Agricultural University (TNAU) and ICAR.
Your task is to examine an uploaded leaf/crop photograph or clinical symptom description of an agricultural crop, leaf, stem, fruit, or pest.
Perform an objective, scientifically rigorous diagnostic visual and pathological inspection.

CRITICAL DIAGNOSTIC RULES:
1. Objectively describe what is visibly seen or reported (lesions, chlorosis, fungal mycelia, insect holes, leaf margins, necrotic spots, fruit damage).
2. Identify the most probable crop and primary condition accurately.
3. NEVER claim 100% certainty from a single photograph or brief description. Give realistic confidence (65-92%).
4. Always provide 2-3 alternative differential diagnoses that share similar symptoms (e.g. bacterial blight vs fungal blast, potassium deficiency vs brown spot, mite damage vs thrips).
5. Explain clearly WHY each possibility is considered based on visual clues and pathogen biology.
6. List what MISSING information or field checks would confirm the diagnosis (e.g. underside sporulation, stem ooze, soil moisture, age of crop).
7. Recommend verified, legal, CIBRC/TNAU-compliant management steps:
   - IPM & cultural practices
   - Biological bio-agents (Trichoderma viride, Pseudomonas fluorescens, Neem oil, Beauveria bassiana) with exact dosages
   - Certified chemical interventions with EXACT dosages per litre of water (e.g. Tricyclazole 75% WP @ 0.6 g/L, Chlorantraniliprole 18.5% SC @ 0.3 ml/L, Mancozeb 75% WP @ 2 g/L)
   - NEVER invent or recommend banned chemicals (e.g. Monocrotophos, Endosulfan, Methyl Parathion).
8. Provide key environmental triggers (humidity %, cloudy days, leaf wetness hours) and crucial safety precautions (PPE, Pre-Harvest Intervals).
9. If the image is blurry, dark, not a crop, or healthy, state this transparently in 'conditionType' ('healthy', 'unclear', 'environmental').
10. The language requested is: ${lang === "ta" ? "Tamil (\u0BA4\u0BAE\u0BBF\u0BB4\u0BCD) with technical and chemical names in parentheses" : "English"}. All observations, diagnoses, explanations, and instructions must strictly be in this language.
11. Return ONLY valid JSON matching the requested structure without any markdown backticks.`;
  const promptText = hasImage ? `Analyze this crop leaf / agricultural photograph carefully.
${userNotes ? `Farmer's observations: "${userNotes}"` : "No additional symptoms reported by farmer."}

Return JSON with this exact schema:
{
  "visualObservations": "Detailed description of visible leaf/tissue symptoms (lesion geometry, margins, color, halo, frass, or damage)",
  "cropIdentified": "Crop name and variety/type if recognizable",
  "primaryDiagnosis": "Primary disease, pest, or deficiency name",
  "confidence": 85,
  "conditionType": "fungal" | "bacterial" | "viral" | "pest" | "nutrient_deficiency" | "environmental" | "healthy" | "unclear",
  "differentialDiagnoses": [
    {
      "condition": "Alternative Condition Name",
      "probability": 25,
      "differentiatingClue": "Visual or pathological feature that distinguishes this from the primary condition"
    }
  ],
  "whySuggested": "Agronomic and pathological reasoning explaining why the primary diagnosis was chosen",
  "missingInformation": "What additional field signs, photos, or tests would confirm diagnosis",
  "environmentalTriggers": ["Key weather or soil conditions that favor this pathogen/pest"],
  "safetyPrecautions": ["Crucial personal protective gear (PPE), wind direction, and Pre-Harvest Interval (PHI) rules"],
  "managementPlan": {
    "ipmAndCultural": ["Cultural step 1", "Sanitation step 2"],
    "biologicalControls": ["Bio-agent 1 with dosage (e.g. Trichoderma viride @ 5g/L or Pseudomonas @ 10g/L)", "Neem formulation with dosage (e.g. Neem oil 3% @ 3ml/L)"],
    "certifiedChemicals": [
      {
        "name": "Chemical Fungicide/Insecticide Name & Formulation",
        "dosage": "Exact dose per litre of water (e.g. 0.6 g/L, 2 ml/L)",
        "safetyNotes": "Pre-harvest interval and precautions"
      }
    ]
  },
  "expertEscalationNotice": "Guidance on consulting local Assistant Agricultural Officer (AAO) or KVK"
}` : `Perform a comprehensive clinical plant pathology diagnosis based on the reported crop and symptoms:
${userNotes ? `Reported observations & symptoms: "${userNotes}"` : "General crop health inspection requested."}

Return JSON with this exact schema:
{
  "visualObservations": "Clinical summary of characteristic symptoms for this condition",
  "cropIdentified": "Crop name identified from notes",
  "primaryDiagnosis": "Primary disease, pest, or deficiency name",
  "confidence": 84,
  "conditionType": "fungal" | "bacterial" | "viral" | "pest" | "nutrient_deficiency" | "environmental" | "healthy" | "unclear",
  "differentialDiagnoses": [
    {
      "condition": "Alternative Condition Name",
      "probability": 25,
      "differentiatingClue": "Diagnostic feature that distinguishes this from the primary condition"
    }
  ],
  "whySuggested": "Agronomic reasoning explaining why these symptoms indicate this primary diagnosis",
  "missingInformation": "What field symptoms or checks are needed to definitively verify",
  "environmentalTriggers": ["Key weather or soil conditions that favor this pathogen/pest"],
  "safetyPrecautions": ["Crucial personal protective gear (PPE), wind direction, and Pre-Harvest Interval (PHI) rules"],
  "managementPlan": {
    "ipmAndCultural": ["Cultural step 1", "Sanitation step 2"],
    "biologicalControls": ["Bio-agent 1 with dosage (e.g. Trichoderma @ 5g/L or Pseudomonas @ 10g/L)", "Neem formulation with dosage"],
    "certifiedChemicals": [
      {
        "name": "Chemical Fungicide/Insecticide Name & Formulation",
        "dosage": "Exact dose per litre of water",
        "safetyNotes": "Pre-harvest interval and precautions"
      }
    ]
  },
  "expertEscalationNotice": "Guidance on consulting local Assistant Agricultural Officer (AAO) or KVK"
}`;
  const modelsToTry = [
    "gemini-flash-lite-latest",
    "gemini-3.5-flash-lite",
    "gemini-3.5-flash",
    "gemini-2.5-flash",
    "gemini-flash-latest",
    "gemini-3.8-flash",
    "gemini-pro-latest"
  ];
  let lastVisionError = null;
  for (const model2 of modelsToTry) {
    try {
      usageStats.activeModel = model2;
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model2}:generateContent?key=${apiKey}`;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 35e3);
      const parts = [{ text: promptText }];
      if (hasImage) {
        parts.push({
          inlineData: {
            mimeType,
            data: cleanBase64
          }
        });
      }
      try {
        const response = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [
              {
                role: "user",
                parts
              }
            ],
            systemInstruction: {
              parts: [{ text: systemInstruction }]
            },
            generationConfig: {
              temperature: 0.1,
              maxOutputTokens: 2500,
              responseMimeType: "application/json"
            }
          }),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (!response.ok) {
          const errJson = await response.json().catch(() => ({}));
          throw new Error(`GEMINI_VISION_ERROR: ${errJson?.error?.message || response.statusText}`);
        }
        const data = await response.json();
        const rawText = data.candidates?.[0]?.content?.parts?.map((p) => p.text).join("") || "";
        let cleanJson = rawText.trim();
        const jsonMatch = cleanJson.match(/```(?:json)?\s*([\s\S]*?)\s*```/) || cleanJson.match(/(\{[\s\S]*\})/);
        if (jsonMatch) {
          cleanJson = jsonMatch[1].trim();
        }
        cleanJson = cleanJson.replace(/,\s*([\]}])/g, "$1");
        const parsed = JSON.parse(cleanJson);
        usageStats.successfulRequests++;
        return parsed;
      } catch (callErr) {
        clearTimeout(timeoutId);
        throw callErr;
      }
    } catch (modelErr) {
      lastVisionError = modelErr;
      console.warn(`[Gemini Vision Failover] Model "${model2}" failed (${modelErr?.message || modelErr}). Trying next candidate...`);
    }
  }
  usageStats.failedRequests++;
  throw new Error(`GEMINI_VISION_ERROR: All candidate models failed. Last error: ${lastVisionError instanceof Error ? lastVisionError.message : String(lastVisionError)}`);
}
async function callGeminiDocumentAnalysis(documentText, base64Data, mimeType, fileName = "document.pdf", lang = "en") {
  usageStats.totalRequests++;
  usageStats.lastRequestTime = (/* @__PURE__ */ new Date()).toISOString();
  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    usageStats.failedRequests++;
    throw new Error(
      "GEMINI_KEY_NOT_CONFIGURED: Google Gemini API key is not configured on the server. Please set GEMINI_API_KEY in your environment variables."
    );
  }
  const model = getGeminiModel();
  usageStats.activeModel = model;
  const systemInstruction = `You are AGRIKNOW AI - Senior Agricultural Document Intelligence Specialist.
You specialize in Indian agricultural documents: Soil Health Cards (SHC), Certified Seed Tags (IMSCS/TNSDOC), Mandi APMC J-Forms, Fertilizer Cash Memos & Labels (IFFCO, Coromandel, KRIBHCO), Pesticide Labels (CIBRC regulations), Water Quality Reports, and Subsidy/KCC/PM-Kisan records.

EXTRACT REAL DATA ONLY:
1. Extract actual text, numbers, dates, units, and tables directly from the document.
2. NEVER guess, fabricate, or hallucinate lot numbers, test dates, crop varieties, pH, NPK, or prices. If a parameter is absent, set it to null.
3. For Soil Health Cards: Identify pH, EC, Organic Carbon (OC), Nitrogen (N), Phosphorus (P), Potassium (K), Zinc (Zn), Iron (Fe), Sulphur (S).
4. For Fertilizer documents: Identify grade (e.g. 18-46-0, 46% N), net weight, brand, active nutrients.
5. For Pesticide labels: Identify active ingredients, dilution rate, waiting period / PHI (days), target pests.
6. For Seed tags: Identify certified class (Breeder/Foundation/Certified), germination %, purity %, lot no, validity.
7. Return clean, valid JSON matching the exact schema without backticks or markdown fences.`;
  const promptText = `Perform full-spectrum agricultural intelligence extraction on this document (${fileName}):

Document Content:
---
${documentText.slice(0, 1e4)}
---

JSON Output Schema:
{
  "title": "Precise title of the document",
  "category": "soil_health_card" | "water_quality_report" | "fertilizer_bill" | "fertilizer_label" | "pesticide_bill" | "pesticide_label" | "seed_certificate" | "mandi_receipt" | "nursery_bill" | "crop_insurance_doc" | "government_scheme_doc" | "farm_expense_record" | "research_paper" | "general_agri_doc",
  "categoryLabelEn": "English category name",
  "categoryLabelTa": "Tamil category name",
  "crop": "Crop name if mentioned or null",
  "variety": "Variety name if mentioned or null",
  "lotOrBatchNumber": "Lot/Batch/Tag/Sample number or null",
  "issuerOrDealer": "Issuing agency, laboratory, or dealer name or null",
  "testingDate": "Testing / invoice date or null",
  "expiryDate": "Expiry / validity date or null",
  "germinationPercent": "Germination % if mentioned or null",
  "purityPercent": "Physical purity % if mentioned or null",
  "moisturePercent": "Moisture % if mentioned or null",
  "chemicalTreatment": "Fungicide / seed dressing warning or null",
  "quantity": "Quantity / weight with units or null",
  "pricePaid": "Price / total amount or null",
  "subsidyDetail": "Government subsidy details or null",
  "summaryEn": "Detailed factual English summary of all data points and obligations in this document",
  "summaryTa": "\u0BB5\u0BBF\u0BB0\u0BBF\u0BB5\u0BBE\u0BA9 \u0BA4\u0BAE\u0BBF\u0BB4\u0BCD \u0BB5\u0BBF\u0BB3\u0B95\u0BCD\u0B95\u0BAE\u0BCD - \u0BB5\u0BBF\u0BB5\u0B9A\u0BBE\u0BAF\u0BBF\u0B95\u0BCD\u0B95\u0BBE\u0BA9 \u0BAE\u0BC1\u0B95\u0BCD\u0B95\u0BBF\u0BAF \u0BA4\u0B95\u0BB5\u0BB2\u0BCD\u0B95\u0BB3\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BAA\u0BBE\u0BA4\u0BC1\u0B95\u0BBE\u0BAA\u0BCD\u0BAA\u0BC1 \u0B8E\u0B9A\u0BCD\u0B9A\u0BB0\u0BBF\u0B95\u0BCD\u0B95\u0BC8\u0B95\u0BB3\u0BCD",
  "keyFindings": [
    {
      "labelEn": "Parameter Name (e.g. Soil pH, Germination Rate)",
      "labelTa": "\u0B85\u0BB3\u0BB5\u0BC1\u0BB0\u0BC1\u0BB5\u0BBF\u0BA9\u0BCD \u0BAA\u0BC6\u0BAF\u0BB0\u0BCD (\u0BAE\u0BA3\u0BCD \u0B95\u0BBE\u0BB0 \u0B85\u0BAE\u0BBF\u0BB2 \u0BA8\u0BBF\u0BB2\u0BC8, \u0BAE\u0BC1\u0BB3\u0BC8\u0BAA\u0BCD\u0BAA\u0BC1\u0BA4\u0BCD \u0BA4\u0BBF\u0BB1\u0BA9\u0BCD)",
      "value": "Exact value with unit (e.g. 7.4 pH, 88%)",
      "status": "verified" | "warning" | "info"
    }
  ],
  "extractedFields": [
    {
      "key": "field_key (e.g. pH, available_n, lot_no, price)",
      "labelEn": "Field Name En",
      "labelTa": "Field Name Ta",
      "originalValue": "Raw text value as seen in document",
      "normalizedValue": "Clean numerical or text value",
      "unit": "Measurement unit (e.g. %, kg/ha, dS/m, \u20B9)",
      "confidence": 0.95,
      "exactSupportingText": "Exact quote from document"
    }
  ],
  "tables": [
    {
      "title": "Table title if present",
      "headers": ["Header1", "Header2"],
      "rows": [["Cell1", "Cell2"]]
    }
  ],
  "soilParameters": {
    "pH": 7.2,
    "ec": 0.35,
    "organicCarbon": 0.58,
    "availableN": 120,
    "availableP": 6.8,
    "availableK": 95,
    "zinc": 0.9,
    "iron": 5.2,
    "sulphur": 11.5,
    "soilType": "Alluvial Clay Loam"
  },
  "fertilizerParameters": {
    "brandName": "IFFCO DAP",
    "grade": "18-46-0",
    "bagWeightKg": 50,
    "nitrogenWeightKg": 9.0,
    "phosphorusWeightKg": 23.0
  },
  "pesticideParameters": {
    "productName": "Tricyclazole 75% WP",
    "activeIngredient": "Tricyclazole",
    "recommendedDosage": "120 g/acre",
    "waitingPeriodDays": 30,
    "cibrcRegNumber": "CIR-11029"
  },
  "seedParameters": {
    "seedClass": "Certified Class 1",
    "germinationPercent": 88,
    "physicalPurityPercent": 98.5,
    "lotNumber": "TN-2024-CR1009"
  },
  "warnings": ["Any warnings, expired dates, or toxic alerts in document"],
  "actionableGuidanceEn": "Concrete next steps for the farmer",
  "actionableGuidanceTa": "\u0BB5\u0BBF\u0BB5\u0B9A\u0BBE\u0BAF\u0BBF\u0B95\u0BCD\u0B95\u0BBE\u0BA9 \u0B85\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4 \u0B95\u0B9F\u0BCD\u0B9F \u0B95\u0BB3 \u0BA8\u0B9F\u0BB5\u0B9F\u0BBF\u0B95\u0BCD\u0B95\u0BC8\u0B95\u0BB3\u0BCD",
  "suggestedQuestions": [
    {
      "en": "Specific question the farmer can ask about this document?",
      "ta": "\u0B87\u0BA8\u0BCD\u0BA4 \u0B86\u0BB5\u0BA3\u0BAE\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BA4\u0BCD\u0BA4\u0BC1 \u0BB5\u0BBF\u0BB5\u0B9A\u0BBE\u0BAF\u0BBF \u0B95\u0BC7\u0B9F\u0BCD\u0B95\u0B95\u0BCD\u0B95\u0BC2\u0B9F\u0BBF\u0BAF \u0B95\u0BC7\u0BB3\u0BCD\u0BB5\u0BBF?"
    }
  ]
}`;
  const parts = [{ text: promptText }];
  if (base64Data && mimeType) {
    const cleanBase64 = base64Data.replace(/^data:[^;]+;base64,/, "");
    parts.push({
      inlineData: {
        mimeType,
        data: cleanBase64
      }
    });
  }
  const modelsToTry = [
    "gemini-flash-lite-latest",
    "gemini-3.5-flash-lite",
    "gemini-3.5-flash",
    "gemini-2.5-flash",
    "gemini-flash-latest",
    "gemini-3.8-flash",
    "gemini-pro-latest"
  ];
  let lastDocError = null;
  for (const model2 of modelsToTry) {
    try {
      usageStats.activeModel = model2;
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model2}:generateContent?key=${apiKey}`;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 35e3);
      try {
        const response = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ role: "user", parts }],
            systemInstruction: { parts: [{ text: systemInstruction }] },
            generationConfig: {
              temperature: 0.1,
              maxOutputTokens: 2500,
              responseMimeType: "application/json"
            }
          }),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (!response.ok) {
          const errJson = await response.json().catch(() => ({}));
          throw new Error(`GEMINI_DOC_ERROR: ${errJson?.error?.message || response.statusText}`);
        }
        const data = await response.json();
        const rawText = data.candidates?.[0]?.content?.parts?.map((p) => p.text).join("") || "";
        let cleanJson = rawText.trim();
        const jsonMatch = cleanJson.match(/```(?:json)?\s*([\s\S]*?)\s*```/) || cleanJson.match(/(\{[\s\S]*\})/);
        if (jsonMatch) {
          cleanJson = jsonMatch[1].trim();
        }
        const parsed = JSON.parse(cleanJson);
        usageStats.successfulRequests++;
        return parsed;
      } catch (callErr) {
        clearTimeout(timeoutId);
        throw callErr;
      }
    } catch (modelErr) {
      lastDocError = modelErr;
      console.warn(`[Gemini Document Analysis Failover] Model "${model2}" failed (${modelErr?.message || modelErr}). Trying next candidate...`);
    }
  }
  usageStats.failedRequests++;
  throw new Error(`GEMINI_DOC_ERROR: All candidate models failed. Last error: ${lastDocError instanceof Error ? lastDocError.message : String(lastDocError)}`);
}
async function callGeminiDocumentQa(documentText, question, fileName = "document", lang = "en") {
  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    throw new Error(
      "GEMINI_KEY_NOT_CONFIGURED: Google Gemini API key is not configured on the server. Please set GEMINI_API_KEY in your environment variables."
    );
  }
  const isTa = lang === "ta";
  const systemInstruction = `You are AgriKnow AI - Senior Agricultural Document Intelligence Specialist.
The farmer has uploaded an agricultural document named "${fileName}".
You are an intelligent, warm, conversational agricultural expert (like ChatGPT / Gemini).

HOW TO ANSWER:
1. Natural & Direct:
   - Answer the farmer's question in a natural, fluid, and helpful tone.
   - Do NOT output rigid robotic category labels like "MODE A" or "MODE B" or "DOCUMENT-ONLY ANSWERING".
2. Document Precision:
   - When the farmer asks about specific facts, numbers, crop variety, lot number, germination %, expiry date, purity, or prices from the uploaded document, state the exact facts clearly and accurately.
   - If a specific piece of information is NOT present in the document, state honestly that this detail is not mentioned in the uploaded file, without inventing data.
3. Beyond the Document (Actionable Agronomic Guidance):
   - When the farmer asks questions that go beyond the document (e.g. sowing methods, precautions, fertilizer schedules, soil suitability, seed treatment, storage, or legal protections), provide deep, expert, university-backed agricultural guidance (TNAU & ICAR standards) tailored to the crop and variety in the document.
4. Language:
   - Answer 100% in ${isTa ? "Tamil (\u0BA4\u0BAE\u0BBF\u0BB4\u0BCD)" : "English"}. Match the farmer's language fluently.`;
  const promptText = `Uploaded Document Content (${fileName}):
---
${documentText.slice(0, 12e3)}
---

Farmer's Question: "${question}"`;
  const result = await callGeminiText({
    prompt: promptText,
    systemInstruction,
    temperature: 0.1,
    maxOutputTokens: 2e3
  });
  return result.text;
}

// src/utils/embeddingGenerator.ts
var VECTOR_DIM = 128;
function hashString(str, seed = 0) {
  let h1 = 3735928559 ^ seed;
  let h2 = 1103547991 ^ seed;
  for (let i = 0; i < str.length; i++) {
    const ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ h1 >>> 16, 2246822507) ^ Math.imul(h2 ^ h2 >>> 13, 3266489909);
  h2 = Math.imul(h2 ^ h2 >>> 16, 2246822507) ^ Math.imul(h1 ^ h1 >>> 13, 3266489909);
  return 4294967296 * (2097151 & h2) + (h1 >>> 0);
}
function extractFeatures(text) {
  const normalized = text.toLowerCase().trim();
  const words = normalized.split(/[\s,.;:!?()[\]"'/\\-]+/).filter((w) => w.length > 1);
  const features = [...words];
  words.forEach((w) => {
    if (w.length >= 3) {
      for (let i = 0; i <= w.length - 3; i++) {
        features.push(w.slice(i, i + 3));
      }
    }
  });
  return features;
}
function generateEmbeddingVector(text) {
  const vector = new Float32Array(VECTOR_DIM);
  const features = extractFeatures(text);
  if (features.length === 0) {
    return Array.from(vector);
  }
  features.forEach((feat) => {
    const h = hashString(feat);
    const index = Math.abs(h) % VECTOR_DIM;
    const sign = (h & 2147483648) === 0 ? 1 : -1;
    vector[index] += sign * 1;
  });
  let sumSq = 0;
  for (let i = 0; i < VECTOR_DIM; i++) {
    sumSq += vector[i] * vector[i];
  }
  const norm = Math.sqrt(sumSq) || 1;
  const normalizedVector = [];
  for (let i = 0; i < VECTOR_DIM; i++) {
    normalizedVector.push(parseFloat((vector[i] / norm).toFixed(6)));
  }
  return normalizedVector;
}

// server/services/ai/AgriKnowAIProvider.ts
var AgriKnowAIProvider = class {
  id = "agriknow-production";
  name = PROVIDER_CONFIGS["agriknow-production"].displayName;
  isProductionAuthorized = true;
  capabilities = /* @__PURE__ */ new Set([
    "chat",
    "structuredJson",
    "vision",
    "document",
    "embeddings"
  ]);
  ensureConfigured() {
    const validation = validateProductionCredentials();
    if (!validation.isConfigured) {
      throw new ProductionCredentialsMissingError(validation.error);
    }
  }
  hasCapability(capability) {
    return this.capabilities.has(capability);
  }
  assertCapability(capability) {
    if (!this.hasCapability(capability)) {
      throw new UnsupportedCapabilityError(this.name, capability);
    }
  }
  async generateText(options) {
    this.assertCapability("chat");
    this.ensureConfigured();
    const result = await callGeminiText({
      prompt: options.prompt,
      systemInstruction: options.systemInstruction,
      history: options.history,
      temperature: options.temperature ?? 0.15,
      maxOutputTokens: options.maxOutputTokens ?? 2500
    });
    return {
      text: result.text,
      modelUsed: result.modelUsed,
      tokensUsed: result.tokensUsed,
      provider: `AgriKnow (${result.modelUsed})`
    };
  }
  async diagnoseVision(options) {
    this.assertCapability("vision");
    this.ensureConfigured();
    return await callGeminiVision(
      options.imageBase64,
      options.mimeType,
      options.userNotes || "",
      options.language || "en"
    );
  }
  async analyzeDocument(options) {
    this.assertCapability("document");
    this.ensureConfigured();
    return await callGeminiDocumentAnalysis(
      options.documentText || "",
      options.base64Data,
      options.mimeType,
      options.fileName || "document.pdf",
      options.language || "en"
    );
  }
  async documentQa(options) {
    this.assertCapability("document");
    this.ensureConfigured();
    return await callGeminiDocumentQa(
      options.documentText,
      options.question,
      options.fileName || "document",
      options.language || "en"
    );
  }
  async generateEmbeddings(text) {
    this.assertCapability("embeddings");
    const env = getEnvironment();
    if (env.AGRI_AI_API_KEY) {
      try {
        const vector = await callGeminiEmbeddings(text);
        return {
          embedding: vector,
          dimensions: vector.length,
          model: getGeminiEmbeddingModel(),
          isLive: true
        };
      } catch {
        const fallback2 = generateEmbeddingVector(text);
        return {
          embedding: fallback2,
          dimensions: 128,
          model: "multilingual-dense-hash-128",
          isLive: false
        };
      }
    }
    const fallback = generateEmbeddingVector(text);
    return {
      embedding: fallback,
      dimensions: 128,
      model: "multilingual-dense-hash-128",
      isLive: false
    };
  }
  async checkHealth() {
    const env = getEnvironment();
    const isConfigured = Boolean(env.AGRI_AI_API_KEY && env.AGRI_AI_API_KEY.trim());
    return {
      providerId: this.id,
      providerName: this.name,
      isProductionAuthorized: true,
      configured: isConfigured,
      model: getGeminiModel(),
      embeddingModel: getGeminiEmbeddingModel(),
      capabilities: {
        chat: isConfigured,
        structuredJson: isConfigured,
        vision: isConfigured,
        document: isConfigured,
        embeddings: true
        // live or fallback dense vector always available
      },
      message: isConfigured ? "Production AI provider configured and operational" : "Production API credentials not configured"
    };
  }
};

// server/services/ai/NexusAcademicProvider.ts
var NexusAcademicProvider = class {
  id = "cse-a-academic";
  name = PROVIDER_CONFIGS["cse-a-academic"].displayName;
  isProductionAuthorized = false;
  // Strictly unauthorized for production
  capabilities = /* @__PURE__ */ new Set(["chat"]);
  isAuthorizedExperiment;
  constructor(options) {
    this.isAuthorizedExperiment = Boolean(options?.isAuthorizedExperiment);
  }
  assertIsolatedExecution(capability) {
    const env = getEnvironment();
    if (!env.CSE_A_API_ENABLED) {
      throw new AcademicProviderDisabledError();
    }
    if (!this.isAuthorizedExperiment) {
      throw new SecurityIsolationViolationError(
        "CSE A Academic API cannot be invoked without explicit experiment authorization. AGRIKNOW production routes cannot access this provider."
      );
    }
    if (!this.capabilities.has(capability)) {
      throw new UnsupportedCapabilityError(this.name, capability);
    }
  }
  hasCapability(capability) {
    return this.capabilities.has(capability);
  }
  assertCapability(capability) {
    if (!this.hasCapability(capability)) {
      throw new UnsupportedCapabilityError(this.name, capability);
    }
  }
  async generateText(options) {
    this.assertIsolatedExecution("chat");
    const env = getEnvironment();
    if (!env.CSE_A_API_KEY) {
      throw new SecurityIsolationViolationError(
        "No valid academic API key provided. Compromised keys cannot be reused."
      );
    }
    const response = await fetch(`${env.CSE_A_API_BASE_URL}/v1/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${env.CSE_A_API_KEY}`
      },
      body: JSON.stringify({
        model: "nexus-academic-v1",
        messages: [
          ...options.systemInstruction ? [{ role: "system", content: options.systemInstruction }] : [],
          { role: "user", content: options.prompt }
        ],
        temperature: options.temperature ?? 0.2
      })
    });
    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Nexus Academic API error (${response.status}): ${errText}`);
    }
    const data = await response.json();
    return {
      text: data.choices?.[0]?.message?.content || "",
      modelUsed: "nexus-academic-v1",
      tokensUsed: data.usage?.total_tokens || 0,
      provider: "CSE A Academic Nexus"
    };
  }
  async diagnoseVision(_options) {
    this.assertIsolatedExecution("vision");
  }
  async analyzeDocument(_options) {
    this.assertIsolatedExecution("document");
    throw new UnsupportedCapabilityError(this.name, "document");
  }
  async documentQa(_options) {
    this.assertIsolatedExecution("document");
    throw new UnsupportedCapabilityError(this.name, "document");
  }
  async generateEmbeddings(_text) {
    this.assertIsolatedExecution("embeddings");
    throw new UnsupportedCapabilityError(this.name, "embeddings");
  }
  async checkHealth() {
    const env = getEnvironment();
    return {
      providerId: this.id,
      providerName: this.name,
      isProductionAuthorized: false,
      configured: Boolean(env.CSE_A_API_ENABLED && env.CSE_A_API_KEY),
      model: "nexus-academic-v1",
      capabilities: {
        chat: Boolean(env.CSE_A_API_ENABLED && env.CSE_A_API_KEY),
        structuredJson: false,
        vision: false,
        document: false,
        embeddings: false
      },
      message: env.CSE_A_API_ENABLED ? "CSE A Academic Provider enabled for research" : "CSE A Academic Provider disabled for AGRIKNOW AI production isolation"
    };
  }
};

// server/services/ai/NexusProductionProvider.ts
var NexusProductionProvider = class {
  id = "nexus-production";
  name = PROVIDER_CONFIGS["nexus-production"].displayName;
  isProductionAuthorized = true;
  capabilities = /* @__PURE__ */ new Set([
    "chat",
    "structuredJson",
    "vision",
    "document",
    "embeddings"
  ]);
  ensureConfigured() {
    const validation = validateProductionCredentials();
    if (!validation.isConfigured) {
      throw new ProductionCredentialsMissingError(validation.error);
    }
  }
  hasCapability(capability) {
    return this.capabilities.has(capability);
  }
  assertCapability(capability) {
    if (!this.hasCapability(capability)) {
      throw new UnsupportedCapabilityError(this.name, capability);
    }
  }
  async generateText(options) {
    this.assertCapability("chat");
    this.ensureConfigured();
    const env = getEnvironment();
    const baseUrl = env.AGRI_AI_BASE_URL || "https://nexusapi.navigatelabs.ai";
    const model = env.AGRI_AI_MODEL || "nova-micro";
    const messages = [];
    if (options.systemInstruction) {
      messages.push({ role: "system", content: options.systemInstruction });
    }
    if (options.history && Array.isArray(options.history)) {
      for (const h of options.history) {
        messages.push({
          role: h.role === "model" || h.role === "assistant" ? "assistant" : "user",
          content: h.content
        });
      }
    }
    messages.push({ role: "user", content: options.prompt });
    const payload = {
      model,
      messages,
      temperature: options.temperature ?? 0.15,
      max_tokens: options.maxOutputTokens ?? 2500
    };
    if (options.responseMimeType === "application/json") {
      payload.response_format = { type: "json_object" };
    }
    const response = await fetch(`${baseUrl.replace(/\/+$/, "")}/v1/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${env.AGRI_AI_API_KEY}`
      },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(3e4)
    });
    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Nexus Production API error (${response.status}): ${errText}`);
    }
    const data = await response.json();
    const answer = data.choices?.[0]?.message?.content || data.text || data.output || "";
    return {
      text: answer,
      modelUsed: model,
      tokensUsed: data.usage?.total_tokens || 0,
      provider: `AgriKnow (Nexus: ${model})`,
      finishReason: data.choices?.[0]?.finish_reason
    };
  }
  async diagnoseVision(options) {
    this.assertCapability("vision");
    this.ensureConfigured();
    const prompt = `Perform a comprehensive clinical plant pathology diagnosis based on the reported crop symptoms:
Farmer's observed symptoms: "${options.userNotes || "Crop leaf discoloration and lesions observed in field."}"
Language requested: ${options.language === "ta" ? "Tamil (\u0BA4\u0BAE\u0BBF\u0BB4\u0BCD)" : "English"}.

Return JSON with this exact schema:
{
  "visualObservations": "Description of characteristic symptoms",
  "cropIdentified": "Identified crop name",
  "primaryDiagnosis": "Primary disease or pest name",
  "confidence": 80,
  "conditionType": "fungal",
  "differentialDiagnoses": [{"condition": "Alternative Condition", "probability": 20, "differentiatingClue": "Clue"}],
  "whySuggested": "Agronomic reasoning",
  "missingInformation": "Field checks needed to verify",
  "environmentalTriggers": ["Favorable weather condition"],
  "safetyPrecautions": ["PPE gear and safety measures"],
  "managementPlan": {
    "ipmAndCultural": ["Cultural practice 1"],
    "biologicalControls": ["Bio-agent with dosage"],
    "certifiedChemicals": [{"name": "Chemical fungicide/insecticide", "dosage": "Dose per litre", "safetyNotes": "Pre-harvest interval"}]
  },
  "expertEscalationNotice": "Notice to consult local AAO or KVK"
}`;
    const res = await this.generateText({
      prompt,
      systemInstruction: "You are a Senior Plant Pathologist at TNAU & ICAR. Return valid JSON only.",
      temperature: 0.1,
      responseMimeType: "application/json"
    });
    try {
      return JSON.parse(res.text.replace(/```json/g, "").replace(/```/g, "").trim());
    } catch {
      return {
        visualObservations: options.userNotes || "Field symptoms reported by farmer",
        cropIdentified: "Paddy",
        primaryDiagnosis: "Crop Health Inspection",
        confidence: 75,
        conditionType: "fungal",
        differentialDiagnoses: [],
        whySuggested: "Based on reported foliar symptoms",
        missingInformation: "Microscopic inspection of sporulation",
        environmentalTriggers: ["High humidity"],
        safetyPrecautions: ["Wear gloves and mask during spray"],
        managementPlan: {
          ipmAndCultural: ["Ensure proper field sanitation and drainage"],
          biologicalControls: ["Apply Pseudomonas fluorescens @ 10g/L"],
          certifiedChemicals: []
        },
        expertEscalationNotice: "Consult local Assistant Agricultural Officer for physical field inspection."
      };
    }
  }
  async analyzeDocument(options) {
    this.assertCapability("document");
    this.ensureConfigured();
    const prompt = `Analyze this agricultural document and extract verified parameters:
Document content:
"""
${options.documentText?.slice(0, 8e3) || "Uploaded Document"}
"""
File Name: ${options.fileName || "document.pdf"}
Language: ${options.language || "en"}

Return JSON:
{
  "title": "${options.fileName || "Uploaded Document"}",
  "category": "seed_certificate",
  "summaryEn": "Summary of document",
  "keyFindings": [{"labelEn": "Parameter", "value": "Extracted Value"}]
}`;
    const res = await this.generateText({
      prompt,
      systemInstruction: "You are AgriKnow Document Extraction Engine. Return JSON only.",
      temperature: 0.1,
      responseMimeType: "application/json"
    });
    try {
      return JSON.parse(res.text.replace(/```json/g, "").replace(/```/g, "").trim());
    } catch {
      return {
        title: options.fileName || "Uploaded Document",
        category: "seed_certificate",
        summaryEn: "Extracted agricultural document",
        keyFindings: []
      };
    }
  }
  async documentQa(options) {
    this.assertCapability("chat");
    this.ensureConfigured();
    const systemInstruction = `You are AgriKnow AI Document Intelligence Assistant. Answer the farmer's question strictly grounded in the document excerpt provided. If the information is not present in the document, state that clearly in ${options.language === "ta" ? "Tamil" : "English"}.`;
    const prompt = `DOCUMENT CONTEXT (${options.fileName || "Document"}):
---
${options.documentText}
---

QUESTION: ${options.question}`;
    const res = await this.generateText({
      prompt,
      systemInstruction,
      temperature: 0.1
    });
    return res.text;
  }
  async generateEmbeddings(text) {
    this.assertCapability("embeddings");
    const env = getEnvironment();
    if (env.AGRI_AI_API_KEY) {
      try {
        const baseUrl = env.AGRI_AI_BASE_URL || "https://nexusapi.navigatelabs.ai";
        const response = await fetch(`${baseUrl.replace(/\/+$/, "")}/v1/embeddings`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${env.AGRI_AI_API_KEY}`
          },
          body: JSON.stringify({
            model: "text-embedding-3-small",
            input: text
          }),
          signal: AbortSignal.timeout(1e4)
        });
        if (response.ok) {
          const data = await response.json();
          const vector = data.data?.[0]?.embedding;
          if (Array.isArray(vector)) {
            return {
              embedding: vector,
              dimensions: vector.length,
              model: "text-embedding-3-small",
              isLive: true
            };
          }
        }
      } catch {
      }
    }
    const fallback = generateEmbeddingVector(text);
    return {
      embedding: fallback,
      dimensions: 128,
      model: "multilingual-dense-hash-128",
      isLive: false
    };
  }
  async checkHealth() {
    const env = getEnvironment();
    const isConfigured = Boolean(env.AGRI_AI_API_KEY && env.AGRI_AI_API_KEY.trim());
    return {
      providerId: this.id,
      providerName: this.name,
      isProductionAuthorized: true,
      configured: isConfigured,
      model: env.AGRI_AI_MODEL || "nova-micro",
      embeddingModel: "text-embedding-3-small",
      capabilities: {
        chat: isConfigured,
        structuredJson: isConfigured,
        vision: isConfigured,
        document: isConfigured,
        embeddings: true
      },
      message: isConfigured ? "Nexus Production AI provider configured (nova-micro)" : "Nexus API credentials not configured (set NEXUS_API_KEY)"
    };
  }
};

// server/services/ai/AIProviderFactory.ts
var AIProviderFactory = class {
  static productionInstance = null;
  /**
   * Returns the authorized AGRIKNOW AI production provider.
   * Dynamically resolves to NexusProductionProvider if AGRI_AI_PROVIDER='nexus',
   * or AgriKnowAIProvider (Gemini) by default.
   * AGRIKNOW AI routes (/api/ai/*) MUST exclusively call this method.
   */
  static getProductionProvider() {
    const env = getEnvironment();
    const isNexus = (env.AGRI_AI_PROVIDER || "").toLowerCase() === "nexus";
    if (!this.productionInstance || isNexus && this.productionInstance.id !== "nexus-production" || !isNexus && this.productionInstance.id !== "agriknow-production") {
      if (isNexus) {
        this.productionInstance = new NexusProductionProvider();
      } else {
        this.productionInstance = new AgriKnowAIProvider();
      }
    }
    return this.productionInstance;
  }
  /**
   * Returns the isolated CSE A academic experiment provider.
   * STRICTLY RESTRICTED: Requires explicit authorization flag and enabled environment.
   * Will throw SecurityIsolationViolationError if called from AGRIKNOW production routes.
   */
  static getAcademicProvider(options) {
    const callerContext = options?.callerContext || "unknown";
    if (callerContext.includes("/api/ai/") || callerContext.includes("agriknow")) {
      throw new SecurityIsolationViolationError(
        `AGRIKNOW production context "${callerContext}" cannot request the academic provider.`
      );
    }
    const env = getEnvironment();
    if (!env.CSE_A_API_ENABLED) {
      throw new AcademicProviderDisabledError();
    }
    if (!options?.isAuthorizedExperiment) {
      throw new SecurityIsolationViolationError(
        "Academic provider access requires explicit authorized experiment consent."
      );
    }
    return new NexusAcademicProvider({ isAuthorizedExperiment: true });
  }
  /**
   * Guard function ensuring that under NO circumstances does an AGRIKNOW route
   * fall back from production to the academic provider.
   */
  static forbidFallback(primaryError, callerRoute) {
    const msg = `Cross-provider fallback is forbidden. AGRIKNOW route "${callerRoute}" failed: ${primaryError.message}`;
    throw new SecurityIsolationViolationError(msg);
  }
};

// server/middleware/providerIsolation.ts
function enforceAgriKnowRouteIsolation(req, routeName) {
  const query = req.query || {};
  const headers = req.headers || {};
  const body = typeof req.body === "string" ? safeJsonParse(req.body) : req.body || {};
  const requestedProviderQuery = query.provider || query.ai_provider;
  if (requestedProviderQuery && typeof requestedProviderQuery === "string" && requestedProviderQuery.toLowerCase().includes("cse")) {
    const msg = `Forbidden provider override attempt on route ${routeName}: "${requestedProviderQuery}"`;
    console.warn(`[SECURITY ISOLATION] ${sanitizeLogMessage(msg)}`);
    throw new SecurityIsolationViolationError("Provider override to academic environment is strictly forbidden.");
  }
  const headerProvider = headers["x-ai-provider"] || headers["x-provider"];
  if (headerProvider && typeof headerProvider === "string" && headerProvider.toLowerCase().includes("cse")) {
    const msg = `Forbidden provider header override on route ${routeName}: "${headerProvider}"`;
    console.warn(`[SECURITY ISOLATION] ${sanitizeLogMessage(msg)}`);
    throw new SecurityIsolationViolationError("Academic provider headers cannot be used on AGRIKNOW routes.");
  }
  const bodyProvider = body.provider || body.aiProvider;
  if (bodyProvider && typeof bodyProvider === "string" && bodyProvider.toLowerCase().includes("cse")) {
    const msg = `Forbidden body provider override on route ${routeName}: "${bodyProvider}"`;
    console.warn(`[SECURITY ISOLATION] ${sanitizeLogMessage(msg)}`);
    throw new SecurityIsolationViolationError("Academic provider selection in request body is strictly forbidden.");
  }
}
function safeJsonParse(str) {
  try {
    return JSON.parse(str);
  } catch {
    return {};
  }
}

// server/middleware/requestValidation.ts
var rateLimitMap = /* @__PURE__ */ new Map();
var RATE_LIMIT_WINDOW_MS = 60 * 1e3;
var MAX_REQUESTS_PER_WINDOW = 60;
function checkRateLimit(clientIp = "global") {
  const now = Date.now();
  const record = rateLimitMap.get(clientIp);
  if (!record || now - record.windowStart > RATE_LIMIT_WINDOW_MS) {
    rateLimitMap.set(clientIp, { count: 1, windowStart: now });
    return { allowed: true, remaining: MAX_REQUESTS_PER_WINDOW - 1 };
  }
  if (record.count >= MAX_REQUESTS_PER_WINDOW) {
    return { allowed: false, remaining: 0 };
  }
  record.count++;
  return { allowed: true, remaining: MAX_REQUESTS_PER_WINDOW - record.count };
}
function sendSafeError(res, error, defaultMessage = "An unexpected error occurred.") {
  const errorObj = error instanceof Error ? error : new Error(String(error));
  const rawMessage = errorObj.message || defaultMessage;
  const sanitizedMessage = sanitizeLogMessage(rawMessage);
  let statusCode = 500;
  let errorCode = "INTERNAL_ERROR";
  if (errorObj.statusCode) {
    statusCode = errorObj.statusCode;
  }
  if (errorObj.code) {
    errorCode = errorObj.code;
  } else if (sanitizedMessage.includes("PROD_CREDENTIALS_MISSING") || sanitizedMessage.includes("GEMINI_KEY_NOT_CONFIGURED")) {
    statusCode = 503;
    errorCode = "PROD_CREDENTIALS_MISSING";
  } else if (sanitizedMessage.includes("SECURITY_ISOLATION_VIOLATION")) {
    statusCode = 403;
    errorCode = "SECURITY_ISOLATION_VIOLATION";
  } else if (sanitizedMessage.includes("UNSUPPORTED_CAPABILITY")) {
    statusCode = 400;
    errorCode = "UNSUPPORTED_CAPABILITY";
  } else if (sanitizedMessage.includes("RATE_LIMIT_EXCEEDED")) {
    statusCode = 429;
    errorCode = "RATE_LIMIT_EXCEEDED";
  }
  return res.status(statusCode).json({
    success: false,
    error: errorCode,
    message: sanitizedMessage,
    retryable: statusCode !== 400 && statusCode !== 403,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
}

// server/ai/ask.ts
async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed. Use POST." });
  }
  try {
    enforceAgriKnowRouteIsolation(req, "/api/ai/ask");
    const clientIp = req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "global";
    const rateCheck = checkRateLimit(String(clientIp));
    if (!rateCheck.allowed) {
      return res.status(429).json({
        success: false,
        error: "RATE_LIMIT_EXCEEDED",
        message: "Too many requests. Please slow down and try again shortly."
      });
    }
    const body = typeof req.body === "string" ? JSON.parse(req.body) : req.body || {};
    const {
      question,
      language = "en",
      history = [],
      context = "",
      documentContext = null,
      evidenceMetadata: _evidenceMetadata = []
    } = body;
    if (!question || typeof question !== "string" || !question.trim()) {
      return res.status(400).json({ error: 'Missing or empty "question" parameter.' });
    }
    const trimmedQuestion = question.trim();
    const hasTamilScript = /[\u0B80-\u0BFF]/.test(trimmedQuestion);
    const hasEnglishLetters = /[a-zA-Z]/.test(trimmedQuestion);
    let targetLang = "en";
    if (hasTamilScript) {
      targetLang = "ta";
    } else if (hasEnglishLetters) {
      targetLang = "en";
    } else {
      targetLang = language === "ta" ? "ta" : "en";
    }
    const isTa = targetLang === "ta";
    const systemInstruction = `You are AgriKnow AI, a brilliant, warm, and highly capable AI assistant (with specialized expertise in agriculture, farming science, plant pathology, and agronomy from TNAU & ICAR, along with universal intelligence to answer any general knowledge, personal, technical, or conversational question).

CORE BEHAVIOR & PERSONALITY (LIKE CHATGPT / GEMINI):
1. Universal Capability:
   - You can answer ANY question the user asks: general conversation, greetings, personal advice, stress support, science, everyday questions, general knowledge, or agricultural inquiries.
   - NEVER refuse a question. NEVER say "I am only an agricultural assistant" or "I only answer farming questions".
   - If the user shares personal struggles, fatigue, stress, or worries, respond with genuine human warmth, empathy, kindness, and practical supportive advice.
   - If the user asks about crops, farming, pests, diseases, fertilizers, seed tags, soil, or irrigation, provide authoritative, scientifically sound, university-grounded advice (backed by TNAU, ICAR, and CIBRC standards).
2. Natural Conversational Flow:
   - Do NOT repeat rigid canned introductions or repetitive disclaimers on every single turn.
   - If the user asks a direct question (e.g. "When should I apply urea to paddy?" or "What is photosynthesis?"), jump straight into the helpful, accurate answer without repetitive robotic greetings.
   - Only offer greetings when the user is explicitly greeting you (like "hi", "hello", "\u0BB5\u0BA3\u0B95\u0BCD\u0B95\u0BAE\u0BCD").
3. Strict Language Matching:
   - User Question Language Detected: ${isTa ? "TAMIL (\u0BA4\u0BAE\u0BBF\u0BB4\u0BCD)" : "ENGLISH"}.
   - You MUST answer entirely in ${isTa ? "TAMIL (\u0BA4\u0BAE\u0BBF\u0BB4\u0BCD). Use natural, fluent Tamil" : "ENGLISH. Use natural, clear English. Do NOT output Tamil text when the user asks in English"}.
   - Always match the language the user is speaking.
4. Agricultural Scientific Rigor (When discussing crops & farming):
   - Provide exact, actionable agronomic figures (e.g. spray volume per acre, split urea dosages, AWD irrigation water depths, seed germination standards).
   - Never recommend banned chemicals (e.g. Monocrotophos, Endosulfan, Phorate); always promote IPM, biological controls, and approved alternatives.
   - If an active document context is provided and the user asks about it, extract and verify the figures (lot numbers, germination %, expiry dates).`;
    let promptWithContext = `Farmer's Question: "${trimmedQuestion}"

`;
    if (documentContext) {
      promptWithContext += `======================================================
`;
      promptWithContext += `\u{1F4C4} ACTIVE UPLOADED FARMER DOCUMENT INTELLIGENCE:
`;
      promptWithContext += `Title: ${documentContext.title || documentContext.fileName || "Uploaded Document"}
`;
      if (documentContext.category) promptWithContext += `Category: ${documentContext.categoryLabelEn || documentContext.category}
`;
      if (documentContext.crop) promptWithContext += `Crop / Variety: ${documentContext.crop} ${documentContext.variety ? `\u2014 ${documentContext.variety}` : ""}
`;
      if (documentContext.lotOrBatchNumber) promptWithContext += `Lot / Batch / Tag Number: ${documentContext.lotOrBatchNumber}
`;
      if (documentContext.germinationPercent) promptWithContext += `Germination Rate: ${documentContext.germinationPercent}
`;
      if (documentContext.purityPercent) promptWithContext += `Physical Purity: ${documentContext.purityPercent}
`;
      if (documentContext.moisturePercent) promptWithContext += `Moisture: ${documentContext.moisturePercent}
`;
      if (documentContext.expiryDate) promptWithContext += `Expiry / Validity Date: ${documentContext.expiryDate}
`;
      if (documentContext.testingDate) promptWithContext += `Testing / Issue Date: ${documentContext.testingDate}
`;
      if (documentContext.issuerOrDealer) promptWithContext += `Issuing Authority / Dealer: ${documentContext.issuerOrDealer}
`;
      if (documentContext.pricePaid) promptWithContext += `Price / Amount: ${documentContext.pricePaid}
`;
      if (documentContext.quantity) promptWithContext += `Quantity / Weight: ${documentContext.quantity}
`;
      if (documentContext.chemicalTreatment) promptWithContext += `Chemical Seed Treatment: ${documentContext.chemicalTreatment}
`;
      if (documentContext.summaryEn) promptWithContext += `Document Verified Summary:
${documentContext.summaryEn}
`;
      if (documentContext.keyFindings && Array.isArray(documentContext.keyFindings) && documentContext.keyFindings.length > 0) {
        promptWithContext += `Extracted Parameters & Metrics:
`;
        for (const kf of documentContext.keyFindings) {
          promptWithContext += `  * ${kf.labelEn || kf.labelTa}: ${kf.value}
`;
        }
      }
      if (documentContext.rawText) {
        promptWithContext += `
Raw Document Text Excerpt:
---
${documentContext.rawText.slice(0, 1e4)}
---
`;
      }
      promptWithContext += `======================================================

`;
      promptWithContext += `DOCUMENT QUESTION GUIDANCE:
`;
      promptWithContext += `1. If the farmer asks directly about this document (e.g. germination %, lot number, validity date, price, purity, testing agency), cite the exact verified parameters from the document above.
`;
      promptWithContext += `2. If the farmer asks questions BEYOND the document (e.g. "How should I sow this?", "What fertilizer to use?", "Is this certified seed good for clay soil?", "What if it fails to germinate?", "What are my legal rights?"), combine the document's verified parameters with authoritative agronomic science (TNAU & ICAR standards) to give a thorough, accurate, and deeply helpful response.
`;
      promptWithContext += `3. If the farmer asks an unrelated or general question, answer it warmly and intelligently without forcing document references.

`;
    }
    if (context && context.trim()) {
      promptWithContext += `Verified University Knowledge Base Evidence (TNAU & ICAR):
${context}

`;
    }
    promptWithContext += `Language Directive: You MUST answer strictly in ${isTa ? "Tamil (\u0BA4\u0BAE\u0BBF\u0BB4\u0BCD)" : "English"}.

Please provide a clear, accurate, and helpful response:`;
    const provider = AIProviderFactory.getProductionProvider();
    const result = await provider.generateText({
      prompt: promptWithContext,
      systemInstruction,
      history,
      temperature: 0.15,
      maxOutputTokens: 2500
    });
    return res.status(200).json({
      success: true,
      answer: result.text,
      model: result.modelUsed,
      tokensUsed: result.tokensUsed,
      provider: result.provider,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  } catch (err) {
    return sendSafeError(res, err, "AI Assistant query processing failed.");
  }
}
export {
  handler as default
};
//# sourceMappingURL=ask.js.map
