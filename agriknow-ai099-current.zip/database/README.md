# AGRIKNOW AI — Database & Migrations Module

This module houses the PostgreSQL / Supabase database architecture, Row Level Security (RLS) policies, disaster recovery snapshots, and verification suites.

## Structure
- `migrations/`:
  - `20261103000000_init_agriknow_schema.sql`: Core tables for farmer profiles, conversations, messages, soil reports, and saved answers
  - `20261103000001_knowledge_ingestion_rag.sql`: Vector embeddings, agricultural knowledge documents, document chunks, and verification statuses
  - `20261103000002_production_security_roles.sql`: Role-Based Access Control (RBAC: `farmer`, `officer`, `scientist`, `admin`), audit logging table, and strict RLS write policies
- `scripts/`:
  - `backup-database.ts`: Automated snapshot generation with SHA-256 integrity checksums
  - `test-backup-restoration.ts`: Disaster recovery restoration verification & tamper-detection benchmark
  - `test-phase3-pipeline.ts`: Ingestion & chunking pipeline test suite
  - `test-phase4-rag-engine.ts`: Advanced RAG retrieval & hybrid ranking test suite
  - `test-phase5-assistant.ts`: End-to-end bilingual AI assistant test suite
  - `test-phase6-security-reliability.ts`: 10-point production security, rate limiting, and cache verification suite
