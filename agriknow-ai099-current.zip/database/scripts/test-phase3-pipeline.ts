import { computeFileSha256 } from '../src/utils/cryptoUtils.ts';
import { extractPdfText } from '../src/utils/pdfExtractor.ts';
import { cleanAgriculturalText } from '../src/utils/textCleaner.ts';
import { chunkDocumentText } from '../src/utils/chunker.ts';
import { generateEmbeddingVector, cosineSimilarity } from '../src/utils/embeddingGenerator.ts';

async function runPipelineTests() {
  console.log('--- STARTING PHASE 3 INGESTION PIPELINE VERIFICATION ---');

  // Test 1: SHA-256 Hashing & Duplicate Detection
  const samplePdfContent = `%PDF-1.4\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n3 0 obj\n<< /Type /Page /Parent 2 0 R /Contents 4 0 R >>\nendobj\n4 0 obj\n<< /Length 260 >>\nstream\nBT\n/F1 12 Tf\n72 712 Td\n(Tamil Nadu Agricultural University - Cauvery Delta Special Advisory) Tj\n0 -20 Td\n(Paddy Blast Disease Control Protocol for Thanjavur and Tiruvarur:) Tj\n0 -20 Td\n(Apply Tricyclazole 75% WP at 120 g per acre during humid weather.) Tj\n0 -20 Td\n(Split nitrogen application into basal, tillering, and panicle initiation.) Tj\nET\nendstream\nendobj\nxref\n0 5\n0000000000 65535 f \n0000000009 00000 n \n0000000058 00000 n \n0000000115 00000 n \n0000000174 00000 n \ntrailer\n<< /Size 5 /Root 1 0 R >>\nstartxref\n520\n%%EOF`;

  const encoder = new TextEncoder();
  const buffer = encoder.encode(samplePdfContent).buffer;

  const hash1 = await computeFileSha256(buffer);
  const hash2 = await computeFileSha256(buffer);
  console.log(`[TEST 1] SHA-256 Hash Generated: ${hash1}`);
  if (hash1 !== hash2 || hash1.length !== 64) {
    throw new Error('SHA-256 hash calculation failed or inconsistent');
  }
  console.log('✓ TEST 1 PASSED: Cryptographic SHA-256 verification & duplicate detection reliable.');

  // Test 2: PDF Stream Extraction
  const extractionResult = await extractPdfText(buffer, 'test_advisory.pdf');
  console.log(`[TEST 2] Extraction format: ${extractionResult.format}, pages: ${extractionResult.totalPages}, chars: ${extractionResult.totalChars}`);
  if (extractionResult.totalPages < 1 || extractionResult.totalChars === 0) {
    throw new Error('PDF Stream extraction failed');
  }
  console.log('✓ TEST 2 PASSED: PDF stream operator extraction succeeded.');

  // Test 3: Agricultural Text Cleaning & Conflict Detection
  const rawSampleText = `Page 1 of 5\nTNAU Agritech Portal\nInsec-\nticide recommendations for paddy blast.\nApply Monocrotophos 36% SL at 500 ml/acre.`;
  const cleanReport = cleanAgriculturalText(rawSampleText, 1);
  console.log(`[TEST 3] Cleaned Text:\n"${cleanReport.cleanedText}"`);
  console.log(`Has conflicts: ${cleanReport.hasConflicts}, Notes: ${cleanReport.conflictNotes}`);
  if (!cleanReport.hasConflicts || !cleanReport.cleanedText.includes('Insecticide')) {
    throw new Error('Text cleaner failed to detect restricted chemical or fix hyphenation');
  }
  console.log('✓ TEST 3 PASSED: Text cleaning and restricted chemical conflict detection working.');

  // Test 4: Semantic Chunking with Traceability
  const pages = [
    { pageNumber: 1, cleanedText: 'First section on nursery management. Mat nursery preparation with 100 sq meters per hectare.' },
    { pageNumber: 2, cleanedText: 'Second section on transplanting. Square planting with 25x25 cm spacing for single 14-day seedling.' },
  ];
  const chunks = chunkDocumentText('doc-test-1', 'Test Manual', pages, {
    chunkSize: 200,
    chunkOverlap: 40,
    targetCrops: ['Paddy (நெல்)'],
    institution: 'Tamil Nadu Agricultural University (TNAU)',
    category: 'Crop Manual',
    language: 'Tamil',
  });
  console.log(`[TEST 4] Generated ${chunks.length} chunks.`);
  chunks.forEach((c) => {
    console.log(`  - Chunk #${c.chunkIndex + 1} | Page ${c.pageNumber} | Tokens: ${c.tokenCount} | Chars: ${c.content.length}`);
  });
  if (chunks.length < 2 || chunks[0].pageNumber !== 1 || chunks[1].pageNumber !== 2) {
    throw new Error('Chunking failed or page traceability lost');
  }
  console.log('✓ TEST 4 PASSED: Semantic chunking with page-level traceability verified.');

  // Test 5: Dense Multilingual Embedding Generation & Cosine Similarity
  const tamilTextA = 'செம்மை நெல் சாகுபடி பாய் நாற்றங்கால் தயாரிப்பு';
  const tamilTextB = 'நெல் நாற்றங்கால் முறை மற்றும் விதை அளவு';
  const unrelatedText = 'பருத்தி பூச்சி கட்டுப்பாடு வேப்ப எண்ணெய்';

  const vecA = generateEmbeddingVector(tamilTextA);
  const vecB = generateEmbeddingVector(tamilTextB);
  const vecUnrelated = generateEmbeddingVector(unrelatedText);

  console.log(`[TEST 5] Vector Dimensions: ${vecA.length}`);
  if (vecA.length !== 128) {
    throw new Error(`Expected 128 dimensions, got ${vecA.length}`);
  }

  const simRelated = cosineSimilarity(vecA, vecB);
  const simUnrelated = cosineSimilarity(vecA, vecUnrelated);
  console.log(`Cosine Similarity (Related Paddy Nursery texts): ${simRelated.toFixed(4)}`);
  console.log(`Cosine Similarity (Unrelated Cotton text): ${simUnrelated.toFixed(4)}`);

  if (simRelated <= simUnrelated) {
    throw new Error('Embedding similarity ranking failed');
  }
  console.log('✓ TEST 5 PASSED: Dense 128-D vector embeddings & cosine similarity mathematically sound.');

  console.log('\nALL PHASE 3 INGESTION PIPELINE TESTS COMPLETED SUCCESSFULLY!');
}

runPipelineTests().catch((err) => {
  console.error('TEST SUITE FAILED:', err);
  process.exit(1);
});
