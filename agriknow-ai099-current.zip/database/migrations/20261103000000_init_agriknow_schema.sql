-- ==============================================================================
-- AGRIKNOW AI - Database Schema Migration
-- Migration: 20261103000000_init_agriknow_schema.sql
-- Description: Core tables, RLS policies, indexes, and triggers for full-stack AGRIKNOW AI
-- ==============================================================================

-- 1. Enable UUID Extension
create extension if not exists "uuid-ossp";

-- 2. Farmer Profiles Table
create table if not exists public.farmer_profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  full_name text not null,
  phone text,
  village text,
  district text not null default 'Thanjavur',
  state text not null default 'Tamil Nadu',
  acres numeric default 2.5 check (acres > 0),
  soil_type text default 'Alluvial Clay',
  irrigation_source text default 'Canal',
  crop_ids text[] default array['paddy', 'groundnut'],
  preferred_language text default 'ta' check (preferred_language in ('en', 'ta')),
  weather_alerts boolean default true,
  disease_alerts boolean default true,
  price_alerts boolean default false,
  voice_auto_read boolean default false,
  created_at timestamptz default now() not null,
  updated_at timestamptz default now() not null
);

-- 3. Agricultural Conversations Table
create table if not exists public.conversations (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  title text not null,
  language text default 'ta' check (language in ('en', 'ta')),
  is_pinned boolean default false,
  created_at timestamptz default now() not null,
  updated_at timestamptz default now() not null
);

-- 4. Chat Messages Table
create table if not exists public.chat_messages (
  id uuid default gen_random_uuid() primary key,
  conversation_id uuid references public.conversations(id) on delete cascade not null,
  user_id uuid references auth.users(id) on delete cascade not null,
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  source_ids text[] default '{}',
  provider text default 'Verified Agricultural Corpus',
  is_live_backend boolean default false,
  confidence numeric,
  created_at timestamptz default now() not null
);

-- 5. Soil Reports Table (Soil Health Cards)
create table if not exists public.soil_reports (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  field_name text not null,
  location text,
  planned_crop text not null,
  ph numeric not null check (ph >= 0 and ph <= 14),
  nitrogen_val numeric,
  phosphorus_val numeric,
  potassium_val numeric,
  organic_carbon_val numeric,
  fertilizer_plan jsonb default '[]'::jsonb not null,
  created_at timestamptz default now() not null,
  updated_at timestamptz default now() not null
);

-- 6. Saved Knowledge & Advisories (Bookmarks)
create table if not exists public.saved_advisories (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  title text not null,
  content text not null,
  crop_name text,
  source_id text,
  created_at timestamptz default now() not null
);

-- 7. Farm Tasks Table
create table if not exists public.farm_tasks (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  title text not null,
  deadline text not null,
  is_done boolean default false,
  crop text,
  priority text default 'Medium' check (priority in ('High', 'Medium', 'Low')),
  created_at timestamptz default now() not null,
  updated_at timestamptz default now() not null
);

-- 8. Verified Knowledge Documents & Corpus
create table if not exists public.knowledge_sources (
  id text primary key,
  title text not null,
  publisher text not null,
  year integer not null,
  kind text not null,
  language text not null,
  reliability text not null,
  topics text[] default '{}',
  summary text not null,
  excerpts jsonb default '[]'::jsonb not null,
  created_at timestamptz default now() not null
);

-- ==============================================================================
-- INDEXES FOR HIGH-PERFORMANCE QUERYING
-- ==============================================================================
create index if not exists idx_farmer_profiles_district on public.farmer_profiles(district);
create index if not exists idx_conversations_user_id on public.conversations(user_id);
create index if not exists idx_conversations_updated_at on public.conversations(updated_at desc);
create index if not exists idx_chat_messages_conversation_id on public.chat_messages(conversation_id);
create index if not exists idx_chat_messages_user_id on public.chat_messages(user_id);
create index if not exists idx_soil_reports_user_id on public.soil_reports(user_id);
create index if not exists idx_saved_advisories_user_id on public.saved_advisories(user_id);
create index if not exists idx_farm_tasks_user_id on public.farm_tasks(user_id);
create index if not exists idx_knowledge_sources_topics on public.knowledge_sources using gin(topics);

-- ==============================================================================
-- AUTOMATED UPDATED_AT TRIGGER FUNCTION
-- ==============================================================================
create or replace function public.handle_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create or replace trigger set_farmer_profiles_updated_at
before update on public.farmer_profiles
for each row execute function public.handle_updated_at();

create or replace trigger set_conversations_updated_at
before update on public.conversations
for each row execute function public.handle_updated_at();

create or replace trigger set_soil_reports_updated_at
before update on public.soil_reports
for each row execute function public.handle_updated_at();

create or replace trigger set_farm_tasks_updated_at
before update on public.farm_tasks
for each row execute function public.handle_updated_at();

-- ==============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ==============================================================================

-- Enable RLS on all tables
alter table public.farmer_profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.chat_messages enable row level security;
alter table public.soil_reports enable row level security;
alter table public.saved_advisories enable row level security;
alter table public.farm_tasks enable row level security;
alter table public.knowledge_sources enable row level security;

-- 1. Farmer Profiles RLS
create policy "Farmers can view their own profile"
  on public.farmer_profiles for select
  using (auth.uid() = id);

create policy "Farmers can insert their own profile"
  on public.farmer_profiles for insert
  with check (auth.uid() = id);

create policy "Farmers can update their own profile"
  on public.farmer_profiles for update
  using (auth.uid() = id);

-- 2. Conversations RLS
create policy "Farmers can view their own conversations"
  on public.conversations for select
  using (auth.uid() = user_id);

create policy "Farmers can create their own conversations"
  on public.conversations for insert
  with check (auth.uid() = user_id);

create policy "Farmers can update their own conversations"
  on public.conversations for update
  using (auth.uid() = user_id);

create policy "Farmers can delete their own conversations"
  on public.conversations for delete
  using (auth.uid() = user_id);

-- 3. Chat Messages RLS
create policy "Farmers can view messages from their conversations"
  on public.chat_messages for select
  using (auth.uid() = user_id);

create policy "Farmers can insert messages into their conversations"
  on public.chat_messages for insert
  with check (auth.uid() = user_id);

-- 4. Soil Reports RLS
create policy "Farmers can view their own soil reports"
  on public.soil_reports for select
  using (auth.uid() = user_id);

create policy "Farmers can create their own soil reports"
  on public.soil_reports for insert
  with check (auth.uid() = user_id);

create policy "Farmers can update their own soil reports"
  on public.soil_reports for update
  using (auth.uid() = user_id);

create policy "Farmers can delete their own soil reports"
  on public.soil_reports for delete
  using (auth.uid() = user_id);

-- 5. Saved Advisories RLS
create policy "Farmers can view their own saved advisories"
  on public.saved_advisories for select
  using (auth.uid() = user_id);

create policy "Farmers can save advisories"
  on public.saved_advisories for insert
  with check (auth.uid() = user_id);

create policy "Farmers can delete their saved advisories"
  on public.saved_advisories for delete
  using (auth.uid() = user_id);

-- 6. Farm Tasks RLS
create policy "Farmers can view their own tasks"
  on public.farm_tasks for select
  using (auth.uid() = user_id);

create policy "Farmers can insert their own tasks"
  on public.farm_tasks for insert
  with check (auth.uid() = user_id);

create policy "Farmers can update their own tasks"
  on public.farm_tasks for update
  using (auth.uid() = user_id);

create policy "Farmers can delete their own tasks"
  on public.farm_tasks for delete
  using (auth.uid() = user_id);

-- 7. Knowledge Sources RLS (Public read for all farmers)
create policy "Public read access for verified agricultural knowledge"
  on public.knowledge_sources for select
  using (true);

-- ==============================================================================
-- AUTOMATIC PROFILE CREATION TRIGGER ON SIGNUP
-- ==============================================================================
create or replace function public.handle_new_farmer()
returns trigger as $$
begin
  insert into public.farmer_profiles (id, full_name, phone, district, state)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', 'Farmer'),
    new.raw_user_meta_data->>'phone',
    coalesce(new.raw_user_meta_data->>'district', 'Thanjavur'),
    'Tamil Nadu'
  );
  return new;
end;
$$ language plpgsql security definer;

create or replace trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_farmer();
