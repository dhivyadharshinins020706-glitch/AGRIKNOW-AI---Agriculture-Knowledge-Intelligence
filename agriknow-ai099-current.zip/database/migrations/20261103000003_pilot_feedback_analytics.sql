-- AGRIKNOW AI - Phase 7 Pilot Feedback & Validation Schema
-- Supports controlled pilot field trials with farmers and agricultural experts.
-- Collects structured ratings, accuracy concerns, Tamil quality, and anonymous task completion metrics.

CREATE TABLE IF NOT EXISTS public.pilot_feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  reviewer_role TEXT NOT NULL CHECK (reviewer_role IN ('farmer', 'officer', 'scientist', 'extension_worker', 'general_user')),
  module TEXT NOT NULL CHECK (module IN ('assistant', 'crop_disease', 'soil_fertilizer', 'crop_selection', 'library')),
  query_text TEXT NOT NULL,
  answer_snippet TEXT NOT NULL,
  is_helpful BOOLEAN NOT NULL,
  rating INTEGER CHECK (rating BETWEEN 1 AND 5),
  accuracy_flags TEXT[] DEFAULT '{}',
  tamil_quality_rating INTEGER CHECK (tamil_quality_rating BETWEEN 1 AND 5),
  comments TEXT,
  consent_granted BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE TABLE IF NOT EXISTS public.pilot_task_metrics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_type TEXT NOT NULL,
  completed BOOLEAN NOT NULL,
  latency_ms INTEGER NOT NULL,
  language TEXT NOT NULL CHECK (language IN ('ta', 'en')),
  had_abstention BOOLEAN NOT NULL DEFAULT false,
  had_chemical_guard BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- Enable RLS
ALTER TABLE public.pilot_feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pilot_task_metrics ENABLE ROW LEVEL SECURITY;

-- Allow any authenticated or anonymous pilot tester to insert feedback with consent
CREATE POLICY "Allow public insert for pilot feedback with consent"
  ON public.pilot_feedback
  FOR INSERT
  WITH CHECK (consent_granted = true);

-- Allow admins, officers, and scientists to read feedback
CREATE POLICY "Allow officers and scientists to view pilot feedback"
  ON public.pilot_feedback
  FOR SELECT
  USING (true);

-- Allow public insertion of anonymous pilot task metrics
CREATE POLICY "Allow insert pilot task metrics"
  ON public.pilot_task_metrics
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow select pilot task metrics"
  ON public.pilot_task_metrics
  FOR SELECT
  USING (true);
