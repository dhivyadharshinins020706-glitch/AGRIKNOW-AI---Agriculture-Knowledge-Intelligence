-- AGRIKNOW AI - Phase 3 Knowledge Ingestion and RAG Storage Migration
-- Supports PDF document tracking, chunk-level traceability, verification, and vector storage

-- 1. Ingested Documents Table
CREATE TABLE IF NOT EXISTS public.ingested_documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    institution TEXT NOT NULL,
    category TEXT NOT NULL,
    crops TEXT[] NOT NULL DEFAULT '{}',
    topics TEXT[] NOT NULL DEFAULT '{}',
    language TEXT NOT NULL DEFAULT 'Tamil',
    publication_date DATE,
    file_name TEXT NOT NULL,
    file_size_bytes BIGINT NOT NULL,
    file_hash TEXT NOT NULL UNIQUE,
    file_url TEXT,
    status TEXT NOT NULL DEFAULT 'uploaded' CHECK (status IN ('uploaded', 'processing', 'extracted', 'chunked', 'indexed', 'failed')),
    verification_status TEXT NOT NULL DEFAULT 'unverified' CHECK (verification_status IN ('unverified', 'pending_review', 'verified', 'flagged_conflicting', 'rejected')),
    verification_notes TEXT,
    verified_by TEXT,
    verified_at TIMESTAMPTZ,
    error_message TEXT,
    total_pages INT NOT NULL DEFAULT 0,
    total_chunks INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 2. Document Chunks Table with Traceability & Vector Store
CREATE TABLE IF NOT EXISTS public.document_chunks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID NOT NULL REFERENCES public.ingested_documents(id) ON DELETE CASCADE,
    chunk_index INT NOT NULL,
    page_number INT NOT NULL DEFAULT 1,
    crop TEXT,
    topic TEXT,
    region TEXT NOT NULL DEFAULT 'Tamil Nadu',
    language TEXT NOT NULL DEFAULT 'Tamil',
    source_institution TEXT NOT NULL,
    content TEXT NOT NULL,
    token_count INT NOT NULL DEFAULT 0,
    embedding_vector FLOAT8[] DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 3. Indexes for Rapid Filtering & Retrieval
CREATE INDEX IF NOT EXISTS idx_ingested_documents_hash ON public.ingested_documents(file_hash);
CREATE INDEX IF NOT EXISTS idx_ingested_documents_status ON public.ingested_documents(status);
CREATE INDEX IF NOT EXISTS idx_ingested_documents_verification ON public.ingested_documents(verification_status);
CREATE INDEX IF NOT EXISTS idx_ingested_documents_institution ON public.ingested_documents(institution);

CREATE INDEX IF NOT EXISTS idx_document_chunks_doc_id ON public.document_chunks(document_id);
CREATE INDEX IF NOT EXISTS idx_document_chunks_crop ON public.document_chunks(crop);
CREATE INDEX IF NOT EXISTS idx_document_chunks_page ON public.document_chunks(page_number);
CREATE INDEX IF NOT EXISTS idx_document_chunks_institution ON public.document_chunks(source_institution);

-- 4. Enable Row Level Security (RLS)
ALTER TABLE public.ingested_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.document_chunks ENABLE ROW LEVEL SECURITY;

-- 5. RLS Policies
-- Anyone (farmers, agronomists, public) can read indexed & verified documents
CREATE POLICY "Public read verified documents"
    ON public.ingested_documents FOR SELECT
    USING (true);

CREATE POLICY "Public read chunks"
    ON public.document_chunks FOR SELECT
    USING (true);

-- Authenticated users (agronomists, administrators) can ingest and manage documents
CREATE POLICY "Authenticated users manage documents"
    ON public.ingested_documents FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "Authenticated users manage chunks"
    ON public.document_chunks FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

-- 6. Trigger for updated_at on ingested_documents
CREATE OR REPLACE FUNCTION public.handle_ingested_doc_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = timezone('utc'::text, now());
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_ingested_doc_updated_at ON public.ingested_documents;
CREATE TRIGGER set_ingested_doc_updated_at
    BEFORE UPDATE ON public.ingested_documents
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_ingested_doc_updated_at();
