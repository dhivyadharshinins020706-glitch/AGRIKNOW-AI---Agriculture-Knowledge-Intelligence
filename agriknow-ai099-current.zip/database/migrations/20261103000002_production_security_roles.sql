-- ==============================================================================
-- AGRIKNOW AI - Production Security & Role-Based Access Control (RBAC) Migration
-- Migration: 20261103000002_production_security_roles.sql
-- Description: Adds user roles, granular RLS policies, and security audit log table
-- ==============================================================================

-- 1. Add Role Column to Farmer Profiles
ALTER TABLE public.farmer_profiles
  ADD COLUMN IF NOT EXISTS role TEXT DEFAULT 'farmer'
  CHECK (role IN ('farmer', 'officer', 'scientist', 'admin'));

CREATE INDEX IF NOT EXISTS idx_farmer_profiles_role ON public.farmer_profiles(role);

-- 2. Helper Security Definer Function to Check Administrative / Officer Role
CREATE OR REPLACE FUNCTION public.is_admin_or_officer(check_user_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
  user_role TEXT;
BEGIN
  SELECT role INTO user_role
  FROM public.farmer_profiles
  WHERE id = check_user_id;

  RETURN user_role IN ('officer', 'scientist', 'admin');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 3. Security Audit Logs Table for Compliance & Anomaly Tracking
CREATE TABLE IF NOT EXISTS public.security_audit_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  target_table TEXT,
  record_id TEXT,
  ip_address TEXT,
  user_agent TEXT,
  details JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON public.security_audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON public.security_audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON public.security_audit_logs(created_at DESC);

-- Enable RLS on audit logs (Only admins can view, system inserts)
ALTER TABLE public.security_audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view security audit logs"
  ON public.security_audit_logs FOR SELECT
  USING (public.is_admin_or_officer(auth.uid()));

CREATE POLICY "System can insert audit logs"
  ON public.security_audit_logs FOR INSERT
  WITH CHECK (true);

-- 4. Tighten Ingestion RLS Policies (Restrict Ingestion/Verification to Officers & Scientists)
DROP POLICY IF EXISTS "Authenticated users manage documents" ON public.ingested_documents;
DROP POLICY IF EXISTS "Authenticated users manage chunks" ON public.document_chunks;

CREATE POLICY "Officers and Scientists can manage documents"
  ON public.ingested_documents FOR ALL
  TO authenticated
  USING (public.is_admin_or_officer(auth.uid()))
  WITH CHECK (public.is_admin_or_officer(auth.uid()));

CREATE POLICY "Officers and Scientists can manage chunks"
  ON public.document_chunks FOR ALL
  TO authenticated
  USING (public.is_admin_or_officer(auth.uid()))
  WITH CHECK (public.is_admin_or_officer(auth.uid()));
