import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'node:url';

function apiDevServerPlugin(): Plugin {
  return {
    name: 'api-dev-server',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        const url = req.url?.split('?')[0];
        if (!url || !url.startsWith('/api/')) {
          return next();
        }

        // Parse JSON body if present
        let body: any = {};
        if (req.method === 'POST') {
          try {
            const buffers: Buffer[] = [];
            for await (const chunk of req) {
              buffers.push(Buffer.from(chunk));
            }
            const rawBody = Buffer.concat(buffers).toString('utf-8');
            if (rawBody.trim()) {
              body = JSON.parse(rawBody);
            }
          } catch {
            body = {};
          }
        }

        // Mock express/vercel res methods for Node http.ServerResponse
        const jsonRes = (status: number, data: any) => {
          res.statusCode = status;
          res.setHeader('Content-Type', 'application/json');
          res.setHeader('Access-Control-Allow-Origin', '*');
          res.end(JSON.stringify(data));
        };

        const mockRes = {
          statusCode: 200,
          setHeader: (name: string, val: string) => res.setHeader(name, val),
          status: (code: number) => ({
            json: (data: any) => jsonRes(code, data),
            end: () => {
              res.statusCode = code;
              res.end();
            },
          }),
          json: (data: any) => jsonRes(200, data),
          end: () => res.end(),
        };

        const mockReq = {
          method: req.method,
          headers: req.headers,
          url: req.url,
          body,
        };

        try {
          const hasLocalKey = Boolean(
            process.env.GEMINI_API_KEY ||
            process.env.GOOGLE_API_KEY ||
            process.env.VITE_GEMINI_API_KEY
          );

          if (url.startsWith('/api/ai/') && !hasLocalKey) {
            try {
              const proxyRes = await fetch(`https://agriknow-ai.vercel.app${url}`, {
                method: req.method || 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: req.method === 'POST' ? JSON.stringify(body) : undefined,
              });
              const proxyData = await proxyRes.json();
              return jsonRes(proxyRes.status, proxyData);
            } catch (proxyErr) {
              console.warn(`[Vite Dev Proxy] Live fallback proxy failed for ${url}:`, proxyErr);
            }
          }

          if (url === '/api/ai/ask') {
            const mod = await import('./api/ai/ask.ts');
            return mod.default(mockReq, mockRes);
          } else if (url === '/api/ai/diagnose') {
            const mod = await import('./api/ai/diagnose.ts');
            return mod.default(mockReq, mockRes);
          } else if (url === '/api/ai/analyze-document') {
            const mod = await import('./api/ai/analyze-document.ts');
            return mod.default(mockReq, mockRes);
          } else if (url === '/api/ai/document-qa') {
            const mod = await import('./api/ai/document-qa.ts');
            return mod.default(mockReq, mockRes);
          } else if (url === '/api/ai/embed') {
            const mod = await import('./api/ai/embed.ts');
            return mod.default(mockReq, mockRes);
          } else if (url === '/api/health') {
            const mod = await import('./api/health.ts');
            return mod.default(mockReq, mockRes);
          }
        } catch (err: any) {
          return jsonRes(500, { error: 'Internal server error in dev api middleware', message: err?.message });
        }

        next();
      });
    },
  };
}

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react(), apiDevServerPlugin()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
      '@frontend': fileURLToPath(new URL('./frontend/src', import.meta.url)),
      '@backend': fileURLToPath(new URL('./backend', import.meta.url)),
      '@ai': fileURLToPath(new URL('./ai', import.meta.url)),
      '@database': fileURLToPath(new URL('./database', import.meta.url)),
    },
  },
  server: {
    host: true,
    port: 5173,
  },
  preview: {
    host: true,
    port: 4173,
  },
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
});
