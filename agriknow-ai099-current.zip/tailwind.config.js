/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', '"Noto Sans Tamil"', 'system-ui', 'sans-serif'],
      },
      colors: {
        // Wiener Schnitzel - warnings, attention, harvest
        sun: {
          50: '#FEF6E7',
          100: '#FDEBC4',
          200: '#FBD98D',
          300: '#F7C25A',
          400: '#F09B04',
          500: '#D08203',
          600: '#A86703',
          700: '#7F4E02',
          800: '#563501',
          900: '#2E1C00',
        },
        // Medium Green - healthy crops, success, primary actions
        leaf: {
          50: '#EEF8EE',
          100: '#D5EFD3',
          200: '#AEE0AA',
          300: '#7FCD78',
          400: '#53B54F',
          500: '#439C40',
          600: '#2F7A2C',
          700: '#245E22',
          800: '#1A4619',
          900: '#112E11',
        },
        // Perfume + Pale Lavender Grey - AI assistant and knowledge surfaces
        lilac: {
          50: '#FAF7FD',
          100: '#F3EEF9',
          200: '#E4D8F1',
          300: '#D2BEE6',
          400: '#C6A9D8',
          500: '#AE87C6',
          600: '#8E63AB',
          700: '#6E4A87',
          800: '#4E3262',
          900: '#301E40',
        },
        // Frozen State - live data, processing, highlights
        aqua: {
          50: '#E9FEFF',
          100: '#C8FDFE',
          200: '#9CFBFD',
          300: '#5FF9FC',
          400: '#14F6FA',
          500: '#0BCBD0',
          600: '#079CA0',
          700: '#06777A',
          800: '#045254',
          900: '#022F30',
        },
        // Neutral ink - text, borders, surfaces
        ink: {
          50: '#F6F7F5',
          100: '#EEF0EC',
          200: '#DCE0D8',
          300: '#B9C0B4',
          400: '#8A9386',
          500: '#646E61',
          600: '#4A5448',
          700: '#343D31',
          800: '#222A20',
          900: '#141A13',
        },
        danger: {
          50: '#FDF2F2',
          100: '#FADADA',
          500: '#D64545',
          700: '#9B2424',
        },
      },
      boxShadow: {
        card: '0 1px 2px rgba(20,26,19,0.04), 0 8px 24px -12px rgba(20,26,19,0.10)',
        lift: '0 2px 4px rgba(20,26,19,0.05), 0 20px 40px -16px rgba(20,26,19,0.18)',
        glow: '0 0 0 4px rgba(20,246,250,0.18)',
      },
      keyframes: {
        shimmer: {
          '0%': { backgroundPosition: '-400px 0' },
          '100%': { backgroundPosition: '400px 0' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-8px)' },
        },
        ping: {
          '0%': { transform: 'scale(1)', opacity: '0.6' },
          '100%': { transform: 'scale(2.4)', opacity: '0' },
        },
      },
      animation: {
        shimmer: 'shimmer 1.6s linear infinite',
        float: 'float 6s ease-in-out infinite',
        'ping-slow': 'ping 2.4s cubic-bezier(0,0,0.2,1) infinite',
      },
    },
  },
  plugins: [],
};
