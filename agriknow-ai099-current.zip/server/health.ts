// AGRIKNOW AI — Production Health Check Endpoint
// Upgraded to report provider isolation, models, capabilities, and database status with zero secret exposure.

import { ProviderHealthService } from './services/ai/ProviderHealthService.ts';
import { sendSafeError } from './middleware/requestValidation.ts';

export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed. Use GET.' });
  }

  try {
    const report = await ProviderHealthService.getHealthReport();
    return res.status(200).json(report);
  } catch (err: unknown) {
    return sendSafeError(res, err, 'Health check inspection failed.');
  }
}
