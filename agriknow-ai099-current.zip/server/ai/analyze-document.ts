// AGRIKNOW AI — Document Intelligence & Verification Handler
// Exclusively uses the AGRIKNOW AI Production Provider with complete CSE A isolation.

import { AIProviderFactory } from '../services/ai/AIProviderFactory.ts';
import { enforceAgriKnowRouteIsolation } from '../middleware/providerIsolation.ts';
import {
  checkRateLimit,
  validateBase64Size,
  validateMimeType,
  sendSafeError,
} from '../middleware/requestValidation.ts';

export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed. Use POST.' });
  }

  try {
    // 1. Enforce route isolation against academic override attempts
    enforceAgriKnowRouteIsolation(req, '/api/ai/analyze-document');

    // 2. Rate limiting
    const clientIp = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'global';
    const rateCheck = checkRateLimit(String(clientIp));
    if (!rateCheck.allowed) {
      return res.status(429).json({
        success: false,
        error: 'RATE_LIMIT_EXCEEDED',
        message: 'Too many requests. Please slow down and try again shortly.',
      });
    }

    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {};
    const { documentText = '', base64Data, mimeType, fileName = 'document.pdf', language = 'en' } = body;

    if (!documentText && !base64Data) {
      return res.status(400).json({ error: 'Must provide either "documentText" or "base64Data".' });
    }

    // 3. Security validation
    if (base64Data) {
      validateBase64Size(base64Data, 15 * 1024 * 1024); // 15MB limit
      if (mimeType) {
        validateMimeType(mimeType, [
          'application/pdf',
          'image/jpeg',
          'image/png',
          'image/webp',
          'text/plain',
        ]);
      }
    }

    // 4. Exclusively invoke the production AI provider
    const provider = AIProviderFactory.getProductionProvider();
    const analyzed = await provider.analyzeDocument({
      documentText,
      base64Data,
      mimeType,
      fileName,
      language: language as 'ta' | 'en',
    });

    return res.status(200).json({
      success: true,
      analyzedDocument: analyzed,
      provider: 'AgriKnow Document Analyzer',
      timestamp: new Date().toISOString(),
    });
  } catch (err: unknown) {
    return sendSafeError(res, err, 'Document extraction and analysis failed.');
  }
}
