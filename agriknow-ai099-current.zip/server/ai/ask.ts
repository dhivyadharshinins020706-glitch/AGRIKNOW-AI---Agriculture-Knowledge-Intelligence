// AGRIKNOW AI — Production Assistant Query Handler
// Exclusively uses the AGRIKNOW AI Production Provider with complete CSE A isolation.

import { AIProviderFactory } from '../services/ai/AIProviderFactory.ts';
import { enforceAgriKnowRouteIsolation } from '../middleware/providerIsolation.ts';
import { checkRateLimit, sendSafeError } from '../middleware/requestValidation.ts';

export default async function handler(req: any, res: any) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed. Use POST.' });
  }

  try {
    // 1. Enforce route isolation against academic override attempts
    enforceAgriKnowRouteIsolation(req, '/api/ai/ask');

    // 2. Rate limiting
    const clientIp = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'global';
    const rateCheck = checkRateLimit(String(clientIp));
    if (!rateCheck.allowed) {
      return res.status(429).json({
        success: false,
        error: 'RATE_LIMIT_EXCEEDED',
        message: 'Too many requests. Please slow down and try again shortly.',
      });
    }

    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {};
    const {
      question,
      language = 'en',
      history = [],
      context = '',
      documentContext = null,
      evidenceMetadata: _evidenceMetadata = [],
    } = body;

    if (!question || typeof question !== 'string' || !question.trim()) {
      return res.status(400).json({ error: 'Missing or empty "question" parameter.' });
    }

    const trimmedQuestion = question.trim();

    // Intelligent language resolution:
    // 1. If the question contains Tamil characters ([\u0B80-\u0BFF]), target language is strictly Tamil ('ta')
    // 2. If the question contains English/Latin letters without Tamil script, target language is strictly English ('en')
    // 3. Otherwise, respect the explicit language parameter
    const hasTamilScript = /[\u0B80-\u0BFF]/.test(trimmedQuestion);
    const hasEnglishLetters = /[a-zA-Z]/.test(trimmedQuestion);

    let targetLang: 'ta' | 'en' = 'en';
    if (hasTamilScript) {
      targetLang = 'ta';
    } else if (hasEnglishLetters) {
      targetLang = 'en';
    } else {
      targetLang = language === 'ta' ? 'ta' : 'en';
    }

    const isTa = targetLang === 'ta';

    const systemInstruction = `You are AgriKnow AI, a brilliant, warm, and highly capable AI assistant (with specialized expertise in agriculture, farming science, plant pathology, and agronomy from TNAU & ICAR, along with universal intelligence to answer any general knowledge, personal, technical, or conversational question).

CORE BEHAVIOR & PERSONALITY (LIKE CHATGPT / GEMINI):
1. Universal Capability:
   - You can answer ANY question the user asks: general conversation, greetings, personal advice, stress support, science, everyday questions, general knowledge, or agricultural inquiries.
   - NEVER refuse a question. NEVER say "I am only an agricultural assistant" or "I only answer farming questions".
   - If the user shares personal struggles, fatigue, stress, or worries, respond with genuine human warmth, empathy, kindness, and practical supportive advice.
   - If the user asks about crops, farming, pests, diseases, fertilizers, seed tags, soil, or irrigation, provide authoritative, scientifically sound, university-grounded advice (backed by TNAU, ICAR, and CIBRC standards).
2. Natural Conversational Flow:
   - Do NOT repeat rigid canned introductions or repetitive disclaimers on every single turn.
   - If the user asks a direct question (e.g. "When should I apply urea to paddy?" or "What is photosynthesis?"), jump straight into the helpful, accurate answer without repetitive robotic greetings.
   - Only offer greetings when the user is explicitly greeting you (like "hi", "hello", "வணக்கம்").
3. Strict Language Matching:
   - User Question Language Detected: ${isTa ? 'TAMIL (தமிழ்)' : 'ENGLISH'}.
   - You MUST answer entirely in ${isTa ? 'TAMIL (தமிழ்). Use natural, fluent Tamil' : 'ENGLISH. Use natural, clear English. Do NOT output Tamil text when the user asks in English'}.
   - Always match the language the user is speaking.
4. Agricultural Scientific Rigor (When discussing crops & farming):
   - Provide exact, actionable agronomic figures (e.g. spray volume per acre, split urea dosages, AWD irrigation water depths, seed germination standards).
   - Never recommend banned chemicals (e.g. Monocrotophos, Endosulfan, Phorate); always promote IPM, biological controls, and approved alternatives.
   - If an active document context is provided and the user asks about it, extract and verify the figures (lot numbers, germination %, expiry dates).`;

    let promptWithContext = `Farmer's Question: "${trimmedQuestion}"\n\n`;

    if (documentContext) {
      promptWithContext += `======================================================\n`;
      promptWithContext += `📄 ACTIVE UPLOADED FARMER DOCUMENT INTELLIGENCE:\n`;
      promptWithContext += `Title: ${documentContext.title || documentContext.fileName || 'Uploaded Document'}\n`;
      if (documentContext.category) promptWithContext += `Category: ${documentContext.categoryLabelEn || documentContext.category}\n`;
      if (documentContext.crop) promptWithContext += `Crop / Variety: ${documentContext.crop} ${documentContext.variety ? `— ${documentContext.variety}` : ''}\n`;
      if (documentContext.lotOrBatchNumber) promptWithContext += `Lot / Batch / Tag Number: ${documentContext.lotOrBatchNumber}\n`;
      if (documentContext.germinationPercent) promptWithContext += `Germination Rate: ${documentContext.germinationPercent}\n`;
      if (documentContext.purityPercent) promptWithContext += `Physical Purity: ${documentContext.purityPercent}\n`;
      if (documentContext.moisturePercent) promptWithContext += `Moisture: ${documentContext.moisturePercent}\n`;
      if (documentContext.expiryDate) promptWithContext += `Expiry / Validity Date: ${documentContext.expiryDate}\n`;
      if (documentContext.testingDate) promptWithContext += `Testing / Issue Date: ${documentContext.testingDate}\n`;
      if (documentContext.issuerOrDealer) promptWithContext += `Issuing Authority / Dealer: ${documentContext.issuerOrDealer}\n`;
      if (documentContext.pricePaid) promptWithContext += `Price / Amount: ${documentContext.pricePaid}\n`;
      if (documentContext.quantity) promptWithContext += `Quantity / Weight: ${documentContext.quantity}\n`;
      if (documentContext.chemicalTreatment) promptWithContext += `Chemical Seed Treatment: ${documentContext.chemicalTreatment}\n`;
      if (documentContext.summaryEn) promptWithContext += `Document Verified Summary:\n${documentContext.summaryEn}\n`;

      if (documentContext.keyFindings && Array.isArray(documentContext.keyFindings) && documentContext.keyFindings.length > 0) {
        promptWithContext += `Extracted Parameters & Metrics:\n`;
        for (const kf of documentContext.keyFindings) {
          promptWithContext += `  * ${kf.labelEn || kf.labelTa}: ${kf.value}\n`;
        }
      }

      if (documentContext.rawText) {
        promptWithContext += `\nRaw Document Text Excerpt:\n---\n${documentContext.rawText.slice(0, 10000)}\n---\n`;
      }
      promptWithContext += `======================================================\n\n`;
      promptWithContext += `DOCUMENT QUESTION GUIDANCE:\n`;
      promptWithContext += `1. If the farmer asks directly about this document (e.g. germination %, lot number, validity date, price, purity, testing agency), cite the exact verified parameters from the document above.\n`;
      promptWithContext += `2. If the farmer asks questions BEYOND the document (e.g. "How should I sow this?", "What fertilizer to use?", "Is this certified seed good for clay soil?", "What if it fails to germinate?", "What are my legal rights?"), combine the document's verified parameters with authoritative agronomic science (TNAU & ICAR standards) to give a thorough, accurate, and deeply helpful response.\n`;
      promptWithContext += `3. If the farmer asks an unrelated or general question, answer it warmly and intelligently without forcing document references.\n\n`;
    }

    if (context && context.trim()) {
      promptWithContext += `Verified University Knowledge Base Evidence (TNAU & ICAR):\n${context}\n\n`;
    }

    promptWithContext += `Language Directive: You MUST answer strictly in ${isTa ? 'Tamil (தமிழ்)' : 'English'}.\n\nPlease provide a clear, accurate, and helpful response:`;

    // 3. Exclusively invoke the production AI provider
    const provider = AIProviderFactory.getProductionProvider();
    const result = await provider.generateText({
      prompt: promptWithContext,
      systemInstruction,
      history,
      temperature: 0.15,
      maxOutputTokens: 2500,
    });

    return res.status(200).json({
      success: true,
      answer: result.text,
      model: result.modelUsed,
      tokensUsed: result.tokensUsed,
      provider: result.provider,
      timestamp: new Date().toISOString(),
    });
  } catch (err: unknown) {
    return sendSafeError(res, err, 'AI Assistant query processing failed.');
  }
}
