// AGRIKNOW AI — Multimodal Crop Disease & Pest Diagnosis Handler
// Exclusively uses the AGRIKNOW AI Production Provider with complete CSE A isolation.

import { AIProviderFactory } from '../services/ai/AIProviderFactory.ts';
import { enforceAgriKnowRouteIsolation } from '../middleware/providerIsolation.ts';
import {
  checkRateLimit,
  validateBase64Size,
  validateMimeType,
  sendSafeError,
} from '../middleware/requestValidation.ts';

export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed. Use POST.' });
  }

  try {
    // 1. Enforce route isolation against academic override attempts
    enforceAgriKnowRouteIsolation(req, '/api/ai/diagnose');

    // 2. Rate limiting
    const clientIp = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'global';
    const rateCheck = checkRateLimit(String(clientIp));
    if (!rateCheck.allowed) {
      return res.status(429).json({
        success: false,
        error: 'RATE_LIMIT_EXCEEDED',
        message: 'Too many requests. Please slow down and try again shortly.',
      });
    }

    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {};
    const { imageBase64 = '', mimeType = 'image/jpeg', userNotes = '', language = 'en' } = body;

    if (!imageBase64 && !userNotes) {
      return res.status(400).json({
        error: 'Please provide either a crop leaf image or observed symptom notes in the request body.',
      });
    }

    // 3. Security validation: file size & MIME type
    if (imageBase64) {
      validateBase64Size(imageBase64, 10 * 1024 * 1024); // 10MB limit
      validateMimeType(mimeType, ['image/jpeg', 'image/png', 'image/webp', 'image/jpg']);
    }

    // 4. Exclusively invoke the production AI provider
    const provider = AIProviderFactory.getProductionProvider();
    const diagnosis = await provider.diagnoseVision({
      imageBase64,
      mimeType,
      userNotes,
      language: language as 'ta' | 'en',
    });

    return res.status(200).json({
      success: true,
      diagnosis,
      provider: 'AgriKnow Vision Diagnosis',
      timestamp: new Date().toISOString(),
    });
  } catch (err: unknown) {
    return sendSafeError(res, err, 'Crop disease diagnosis failed.');
  }
}
