// AGRIKNOW AI — Semantic Vector Embedding Handler
// Exclusively uses the AGRIKNOW AI Production Provider with consistent dimensions and offline resilience.

import { AIProviderFactory } from '../services/ai/AIProviderFactory.ts';
import { enforceAgriKnowRouteIsolation } from '../middleware/providerIsolation.ts';
import { checkRateLimit, sendSafeError } from '../middleware/requestValidation.ts';

export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed. Use POST.' });
  }

  try {
    // 1. Enforce route isolation against academic override attempts
    enforceAgriKnowRouteIsolation(req, '/api/ai/embed');

    // 2. Rate limiting
    const clientIp = req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'global';
    const rateCheck = checkRateLimit(String(clientIp));
    if (!rateCheck.allowed) {
      return res.status(429).json({
        success: false,
        error: 'RATE_LIMIT_EXCEEDED',
        message: 'Too many requests. Please slow down and try again shortly.',
      });
    }

    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {};
    const { text } = body;

    if (!text || (typeof text !== 'string' && !Array.isArray(text))) {
      return res.status(400).json({ error: 'Missing "text" string or array in request body.' });
    }

    const provider = AIProviderFactory.getProductionProvider();

    if (Array.isArray(text)) {
      const results = [];
      for (const t of text) {
        const itemResult = await provider.generateEmbeddings(String(t));
        results.push(itemResult);
      }
      return res.status(200).json({
        success: true,
        embeddings: results.map((r) => r.embedding),
        model: results[0]?.model || 'gemini-embedding-2',
        version: '1.0',
        dimensions: results[0]?.dimensions || 0,
        isLive: results[0]?.isLive ?? false,
      });
    }

    const result = await provider.generateEmbeddings(text);
    return res.status(200).json({
      success: true,
      embedding: result.embedding,
      model: result.model,
      version: '1.0',
      dimensions: result.dimensions,
      isLive: result.isLive,
    });
  } catch (err: unknown) {
    return sendSafeError(res, err, 'Semantic embedding generation failed.');
  }
}
