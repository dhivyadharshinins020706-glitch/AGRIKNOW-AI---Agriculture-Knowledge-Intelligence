// AGRIKNOW AI — Provider Isolation & Route Security Middleware
// Blocks any client attempts to switch providers, inject academic credentials, or bypass isolation.

import { SecurityIsolationViolationError } from '../services/ai/AIProvider.interface.ts';
import { sanitizeLogMessage } from '../config/environment.ts';

export function enforceAgriKnowRouteIsolation(req: any, routeName: string): void {
  const query = req.query || {};
  const headers = req.headers || {};
  const body = typeof req.body === 'string' ? safeJsonParse(req.body) : req.body || {};

  // Check query parameters
  const requestedProviderQuery = query.provider || query.ai_provider;
  if (
    requestedProviderQuery &&
    typeof requestedProviderQuery === 'string' &&
    requestedProviderQuery.toLowerCase().includes('cse')
  ) {
    const msg = `Forbidden provider override attempt on route ${routeName}: "${requestedProviderQuery}"`;
    console.warn(`[SECURITY ISOLATION] ${sanitizeLogMessage(msg)}`);
    throw new SecurityIsolationViolationError('Provider override to academic environment is strictly forbidden.');
  }

  // Check headers
  const headerProvider = headers['x-ai-provider'] || headers['x-provider'];
  if (
    headerProvider &&
    typeof headerProvider === 'string' &&
    headerProvider.toLowerCase().includes('cse')
  ) {
    const msg = `Forbidden provider header override on route ${routeName}: "${headerProvider}"`;
    console.warn(`[SECURITY ISOLATION] ${sanitizeLogMessage(msg)}`);
    throw new SecurityIsolationViolationError('Academic provider headers cannot be used on AGRIKNOW routes.');
  }

  // Check body
  const bodyProvider = body.provider || body.aiProvider;
  if (
    bodyProvider &&
    typeof bodyProvider === 'string' &&
    bodyProvider.toLowerCase().includes('cse')
  ) {
    const msg = `Forbidden body provider override on route ${routeName}: "${bodyProvider}"`;
    console.warn(`[SECURITY ISOLATION] ${sanitizeLogMessage(msg)}`);
    throw new SecurityIsolationViolationError('Academic provider selection in request body is strictly forbidden.');
  }
}

function safeJsonParse(str: string): any {
  try {
    return JSON.parse(str);
  } catch {
    return {};
  }
}
