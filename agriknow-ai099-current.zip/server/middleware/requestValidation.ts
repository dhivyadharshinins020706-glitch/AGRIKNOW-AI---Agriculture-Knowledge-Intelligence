// AGRIKNOW AI — Request Validation, Rate Limiting & Safe Error Handler Middleware

import { sanitizeLogMessage } from '../config/environment.ts';

// Simple in-memory sliding window rate limiter
const rateLimitMap = new Map<string, { count: number; windowStart: number }>();
const RATE_LIMIT_WINDOW_MS = 60 * 1000; // 1 minute
const MAX_REQUESTS_PER_WINDOW = 60; // 60 requests per minute

/**
 * Validates in-memory rate limits. Returns true if request is within rate limit.
 */
export function checkRateLimit(clientIp: string = 'global'): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const record = rateLimitMap.get(clientIp);

  if (!record || now - record.windowStart > RATE_LIMIT_WINDOW_MS) {
    rateLimitMap.set(clientIp, { count: 1, windowStart: now });
    return { allowed: true, remaining: MAX_REQUESTS_PER_WINDOW - 1 };
  }

  if (record.count >= MAX_REQUESTS_PER_WINDOW) {
    return { allowed: false, remaining: 0 };
  }

  record.count++;
  return { allowed: true, remaining: MAX_REQUESTS_PER_WINDOW - record.count };
}

/**
 * Validates file size limits for base64 encoded payloads.
 * Base64 is approx 1.33x raw size. 10MB binary is ~13.3MB base64.
 */
export function validateBase64Size(base64Str: string, maxBytes: number = 10 * 1024 * 1024): void {
  if (!base64Str) return;
  const approxSizeBytes = Math.round((base64Str.length * 3) / 4);
  if (approxSizeBytes > maxBytes) {
    throw new Error(
      `Payload size exceeds limit. Maximum allowed is ${Math.round(maxBytes / (1024 * 1024))}MB.`
    );
  }
}

/**
 * Validates allowed MIME types.
 */
export function validateMimeType(mimeType: string, allowedTypes: string[]): void {
  if (!mimeType) return;
  const normalized = mimeType.toLowerCase().trim();
  const isAllowed = allowedTypes.some((allowed) => normalized === allowed || normalized.startsWith(allowed));
  if (!isAllowed) {
    throw new Error(
      `Unsupported MIME type: "${mimeType}". Allowed types: ${allowedTypes.join(', ')}.`
    );
  }
}

/**
 * Safe error response sender that never reveals internal stack traces, API keys, or database secrets.
 */
export function sendSafeError(res: any, error: unknown, defaultMessage = 'An unexpected error occurred.') {
  const errorObj = error instanceof Error ? error : new Error(String(error));
  const rawMessage = errorObj.message || defaultMessage;
  const sanitizedMessage = sanitizeLogMessage(rawMessage);

  let statusCode = 500;
  let errorCode = 'INTERNAL_ERROR';

  if ((errorObj as any).statusCode) {
    statusCode = (errorObj as any).statusCode;
  }
  if ((errorObj as any).code) {
    errorCode = (errorObj as any).code;
  } else if (sanitizedMessage.includes('PROD_CREDENTIALS_MISSING') || sanitizedMessage.includes('GEMINI_KEY_NOT_CONFIGURED')) {
    statusCode = 503;
    errorCode = 'PROD_CREDENTIALS_MISSING';
  } else if (sanitizedMessage.includes('SECURITY_ISOLATION_VIOLATION')) {
    statusCode = 403;
    errorCode = 'SECURITY_ISOLATION_VIOLATION';
  } else if (sanitizedMessage.includes('UNSUPPORTED_CAPABILITY')) {
    statusCode = 400;
    errorCode = 'UNSUPPORTED_CAPABILITY';
  } else if (sanitizedMessage.includes('RATE_LIMIT_EXCEEDED')) {
    statusCode = 429;
    errorCode = 'RATE_LIMIT_EXCEEDED';
  }

  return res.status(statusCode).json({
    success: false,
    error: errorCode,
    message: sanitizedMessage,
    retryable: statusCode !== 400 && statusCode !== 403,
    timestamp: new Date().toISOString(),
  });
}
