// AGRIKNOW AI — Server-side Environment Configuration & Security Layer
// Reads and validates credentials with complete secret redaction and dual-provider isolation.

export interface AgriEnvironment {
  // Production AI Provider
  AGRI_AI_PROVIDER: string;
  AGRI_AI_BASE_URL?: string;
  AGRI_AI_API_KEY?: string;
  AGRI_AI_MODEL: string;
  AGRI_AI_EMBEDDING_MODEL: string;

  // CSE A Academic Environment (Strictly Disabled by default)
  CSE_A_API_ENABLED: boolean;
  CSE_A_API_BASE_URL: string;
  CSE_A_API_KEY?: string;

  // Database & App Services
  SUPABASE_URL?: string;
  SUPABASE_ANON_KEY?: string;
  NODE_ENV: string;
  APP_VERSION: string;
}

/**
 * Safely redacts sensitive strings such as API keys, authorization tokens, or passwords.
 * Leaves the first 4 and last 4 characters visible if sufficiently long, otherwise fully redacts.
 */
export function redactSecret(secret?: string | null): string {
  if (!secret) return '[NOT_SET]';
  const clean = String(secret).trim();
  if (clean.length <= 8) return '[REDACTED]';
  return `${clean.substring(0, 4)}...${clean.substring(clean.length - 4)}`;
}

/**
 * Redacts any potential secrets, phone numbers, or email addresses from log messages.
 */
export function sanitizeLogMessage(message: string): string {
  if (!message || typeof message !== 'string') return '';
  return message
    .replace(/AIza[0-9A-Za-z_-]{20,50}/g, '[REDACTED_API_KEY]')
    .replace(/bearer\s+[a-zA-Z0-9_.-]+/gi, 'Bearer [REDACTED_TOKEN]')
    .replace(/sb_publishable_[a-zA-Z0-9_-]+/g, '[REDACTED_SUPABASE_KEY]')
    .replace(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g, '[REDACTED_EMAIL]')
    .replace(/\b(?:\+91|91)?[6-9]\d{9}\b/g, '[REDACTED_PHONE]');
}

/**
 * Reads process environment variables with backward-compatible fallbacks for existing production setup.
 */
export function getEnvironment(): AgriEnvironment {
  const env = (typeof process !== 'undefined' ? process.env : {}) as Record<string, string | undefined>;

  const isNexus = (env.AGRI_AI_PROVIDER || '').toLowerCase() === 'nexus';

  // Resolve Production Key (prioritize provider-specific key, then AGRI_AI_API_KEY, then legacy keys)
  const productionApiKey = isNexus
    ? env.NEXUS_API_KEY || env.AGRI_AI_API_KEY || undefined
    : env.AGRI_AI_API_KEY ||
      env.GEMINI_API_KEY ||
      env.GOOGLE_API_KEY ||
      env.VITE_GEMINI_API_KEY ||
      undefined;

  // Resolve Model configuration
  const productionModel =
    env.AGRI_AI_MODEL ||
    (isNexus ? env.NEXUS_MODEL || 'nexus-v1' : env.GEMINI_MODEL || 'gemini-2.5-flash');

  const productionEmbeddingModel =
    env.AGRI_AI_EMBEDDING_MODEL ||
    env.GEMINI_EMBEDDING_MODEL ||
    'gemini-embedding-2';

  // CSE A Academic Environment — strictly false unless explicitly set to 'true'
  const isCseAEnabled = env.CSE_A_API_ENABLED === 'true';
  const cseABaseUrl = env.CSE_A_API_BASE_URL || 'https://nexusapi.navigatelabs.ai';
  const cseAApiKey = env.CSE_A_API_KEY || undefined;

  return {
    AGRI_AI_PROVIDER: env.AGRI_AI_PROVIDER || 'gemini',
    AGRI_AI_BASE_URL:
      env.AGRI_AI_BASE_URL ||
      (isNexus ? env.NEXUS_BASE_URL || 'https://nexusapi.navigatelabs.ai' : undefined),
    AGRI_AI_API_KEY: productionApiKey,
    AGRI_AI_MODEL: productionModel,
    AGRI_AI_EMBEDDING_MODEL: productionEmbeddingModel,

    CSE_A_API_ENABLED: isCseAEnabled,
    CSE_A_API_BASE_URL: cseABaseUrl,
    CSE_A_API_KEY: cseAApiKey,

    SUPABASE_URL: env.VITE_SUPABASE_URL || env.SUPABASE_URL || undefined,
    SUPABASE_ANON_KEY: env.VITE_SUPABASE_ANON_KEY || env.SUPABASE_ANON_KEY || undefined,
    NODE_ENV: env.NODE_ENV || 'production',
    APP_VERSION: '3.0.0-dual-isolated',
  };
}

/**
 * Validates that production credentials exist for AGRIKNOW operations.
 */
export function validateProductionCredentials(): {
  isConfigured: boolean;
  provider: string;
  model: string;
  error?: string;
} {
  const env = getEnvironment();
  if (!env.AGRI_AI_API_KEY || !env.AGRI_AI_API_KEY.trim()) {
    const keyName = env.AGRI_AI_PROVIDER === 'nexus' ? 'NEXUS_API_KEY' : 'AGRI_AI_API_KEY / GEMINI_API_KEY';
    return {
      isConfigured: false,
      provider: env.AGRI_AI_PROVIDER,
      model: env.AGRI_AI_MODEL,
      error: `PROD_CREDENTIALS_MISSING: AGRIKNOW AI production API credentials (${keyName}) are not configured. The academic provider cannot be used as a fallback.`,
    };
  }

  return {
    isConfigured: true,
    provider: env.AGRI_AI_PROVIDER,
    model: env.AGRI_AI_MODEL,
  };
}
