// AGRIKNOW AI — Multi-Provider Configuration & Isolation Definitions
// Strict isolation between AGRIKNOW AI production and CSE A academic environments.

export type ProviderType = 'agriknow-production' | 'nexus-production' | 'cse-a-academic';

export type AICapability =
  | 'chat'
  | 'structuredJson'
  | 'vision'
  | 'document'
  | 'embeddings';

export interface ProviderMetadata {
  id: ProviderType;
  displayName: string;
  isAcademicOnly: boolean;
  isProductionAuthorized: boolean;
  supportedCapabilities: readonly AICapability[];
  defaultModel: string;
  defaultEmbeddingModel?: string;
  baseUrl?: string;
  isolationNotice: string;
}

export const PROVIDER_CONFIGS: Record<ProviderType, ProviderMetadata> = {
  'agriknow-production': {
    id: 'agriknow-production',
    displayName: 'AGRIKNOW AI Production Provider',
    isAcademicOnly: false,
    isProductionAuthorized: true,
    supportedCapabilities: [
      'chat',
      'structuredJson',
      'vision',
      'document',
      'embeddings',
    ] as const,
    defaultModel: 'gemini-2.5-flash',
    defaultEmbeddingModel: 'gemini-embedding-2',
    isolationNotice:
      'Authorized for AGRIKNOW AI production services. Serves farmer queries, disease diagnoses, document extraction, and semantic embeddings.',
  },
  'nexus-production': {
    id: 'nexus-production',
    displayName: 'Navigate Labs Nexus Production Engine',
    isAcademicOnly: false,
    isProductionAuthorized: true,
    supportedCapabilities: [
      'chat',
      'structuredJson',
      'vision',
      'document',
      'embeddings',
    ] as const,
    defaultModel: 'nova-micro',
    defaultEmbeddingModel: 'text-embedding-3-small',
    baseUrl: 'https://nexusapi.navigatelabs.ai',
    isolationNotice:
      'Authorized primary production AI inference provider for AGRIKNOW AI via Navigate Labs Nexus.',
  },
  'cse-a-academic': {
    id: 'cse-a-academic',
    displayName: 'CSE A Academic Experiment Provider (Nexus)',
    isAcademicOnly: true,
    isProductionAuthorized: false,
    supportedCapabilities: ['chat'] as const,
    defaultModel: 'nexus-academic-v1',
    baseUrl: 'https://nexusapi.navigatelabs.ai',
    isolationNotice:
      'STRICTLY ISOLATED: Used ONLY for explicitly authorized CSE A academic research experiments. Disabled by default. Forbidden in production AGRIKNOW routes. Never receives farmer queries, documents, or images.',
  },
};
