// AGRIKNOW AI — Provider Factory with Strict Isolation Boundaries
// Enforces that AGRIKNOW AI endpoints can ONLY access the production provider.
// Prevents automatic provider switching and cross-provider fallbacks.

import type { IAIProvider } from './AIProvider.interface.ts';
import { AgriKnowAIProvider } from './AgriKnowAIProvider.ts';
import { NexusAcademicProvider } from './NexusAcademicProvider.ts';
import { NexusProductionProvider } from './NexusProductionProvider.ts';
import { SecurityIsolationViolationError, AcademicProviderDisabledError } from './AIProvider.interface.ts';
import { getEnvironment } from '../../config/environment.ts';

export class AIProviderFactory {
  private static productionInstance: IAIProvider | null = null;

  /**
   * Returns the authorized AGRIKNOW AI production provider.
   * Dynamically resolves to NexusProductionProvider if AGRI_AI_PROVIDER='nexus',
   * or AgriKnowAIProvider (Gemini) by default.
   * AGRIKNOW AI routes (/api/ai/*) MUST exclusively call this method.
   */
  public static getProductionProvider(): IAIProvider {
    const env = getEnvironment();
    const isNexus = (env.AGRI_AI_PROVIDER || '').toLowerCase() === 'nexus';

    if (
      !this.productionInstance ||
      (isNexus && this.productionInstance.id !== 'nexus-production') ||
      (!isNexus && this.productionInstance.id !== 'agriknow-production')
    ) {
      if (isNexus) {
        this.productionInstance = new NexusProductionProvider();
      } else {
        this.productionInstance = new AgriKnowAIProvider();
      }
    }
    return this.productionInstance;
  }

  /**
   * Returns the isolated CSE A academic experiment provider.
   * STRICTLY RESTRICTED: Requires explicit authorization flag and enabled environment.
   * Will throw SecurityIsolationViolationError if called from AGRIKNOW production routes.
   */
  public static getAcademicProvider(options?: {
    isAuthorizedExperiment?: boolean;
    callerContext?: string;
  }): IAIProvider {
    const callerContext = options?.callerContext || 'unknown';

    // Disallow if caller is an AGRIKNOW route
    if (callerContext.includes('/api/ai/') || callerContext.includes('agriknow')) {
      throw new SecurityIsolationViolationError(
        `AGRIKNOW production context "${callerContext}" cannot request the academic provider.`
      );
    }

    const env = getEnvironment();
    if (!env.CSE_A_API_ENABLED) {
      throw new AcademicProviderDisabledError();
    }

    if (!options?.isAuthorizedExperiment) {
      throw new SecurityIsolationViolationError(
        'Academic provider access requires explicit authorized experiment consent.'
      );
    }

    return new NexusAcademicProvider({ isAuthorizedExperiment: true });
  }

  /**
   * Guard function ensuring that under NO circumstances does an AGRIKNOW route
   * fall back from production to the academic provider.
   */
  public static forbidFallback(primaryError: Error, callerRoute: string): never {
    const msg = `Cross-provider fallback is forbidden. AGRIKNOW route "${callerRoute}" failed: ${primaryError.message}`;
    throw new SecurityIsolationViolationError(msg);
  }
}
