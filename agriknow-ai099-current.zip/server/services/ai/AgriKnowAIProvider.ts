// AGRIKNOW AI — Production AI Provider Implementation
// Directly serves farmers with university-grounded intelligence using authorized production credentials.

import {
  type IAIProvider,
  type AITextOptions,
  type AITextResult,
  type AIVisionOptions,
  type AIDocumentAnalysisOptions,
  type AIDocumentQaOptions,
  type AIEmbedResult,
  type AIProviderHealth,
  ProductionCredentialsMissingError,
  UnsupportedCapabilityError,
} from './AIProvider.interface.ts';
import { type AICapability, PROVIDER_CONFIGS } from '../../config/providers.ts';
import { getEnvironment, validateProductionCredentials } from '../../config/environment.ts';
import {
  callGeminiText,
  callGeminiVision,
  callGeminiDocumentAnalysis,
  callGeminiDocumentQa,
  callGeminiEmbeddings,
  getGeminiModel,
  getGeminiEmbeddingModel,
} from '../../../backend/services/geminiService.ts';
import { generateEmbeddingVector } from '../../../src/utils/embeddingGenerator.ts';

export class AgriKnowAIProvider implements IAIProvider {
  readonly id = 'agriknow-production' as const;
  readonly name = PROVIDER_CONFIGS['agriknow-production'].displayName;
  readonly isProductionAuthorized = true;
  readonly capabilities: ReadonlySet<AICapability> = new Set<AICapability>([
    'chat',
    'structuredJson',
    'vision',
    'document',
    'embeddings',
  ]);

  private ensureConfigured(): void {
    const validation = validateProductionCredentials();
    if (!validation.isConfigured) {
      throw new ProductionCredentialsMissingError(validation.error);
    }
  }

  hasCapability(capability: AICapability): boolean {
    return this.capabilities.has(capability);
  }

  assertCapability(capability: AICapability): void {
    if (!this.hasCapability(capability)) {
      throw new UnsupportedCapabilityError(this.name, capability);
    }
  }

  async generateText(options: AITextOptions): Promise<AITextResult> {
    this.assertCapability('chat');
    this.ensureConfigured();

    const result = await callGeminiText({
      prompt: options.prompt,
      systemInstruction: options.systemInstruction,
      history: options.history as any,
      temperature: options.temperature ?? 0.15,
      maxOutputTokens: options.maxOutputTokens ?? 2500,
    });

    return {
      text: result.text,
      modelUsed: result.modelUsed,
      tokensUsed: result.tokensUsed,
      provider: `AgriKnow (${result.modelUsed})`,
    };
  }

  async diagnoseVision(options: AIVisionOptions): Promise<any> {
    this.assertCapability('vision');
    this.ensureConfigured();

    return await callGeminiVision(
      options.imageBase64,
      options.mimeType,
      options.userNotes || '',
      options.language || 'en'
    );
  }

  async analyzeDocument(options: AIDocumentAnalysisOptions): Promise<any> {
    this.assertCapability('document');
    this.ensureConfigured();

    return await callGeminiDocumentAnalysis(
      options.documentText || '',
      options.base64Data,
      options.mimeType,
      options.fileName || 'document.pdf',
      options.language || 'en'
    );
  }

  async documentQa(options: AIDocumentQaOptions): Promise<string> {
    this.assertCapability('document');
    this.ensureConfigured();

    return await callGeminiDocumentQa(
      options.documentText,
      options.question,
      options.fileName || 'document',
      options.language || 'en'
    );
  }

  async generateEmbeddings(text: string): Promise<AIEmbedResult> {
    this.assertCapability('embeddings');

    const env = getEnvironment();
    if (env.AGRI_AI_API_KEY) {
      try {
        const vector = await callGeminiEmbeddings(text);
        return {
          embedding: vector,
          dimensions: vector.length,
          model: getGeminiEmbeddingModel(),
          isLive: true,
        };
      } catch {
        // Fallback to offline dense hash vector if network/quota is exceeded
        const fallback = generateEmbeddingVector(text);
        return {
          embedding: fallback,
          dimensions: 128,
          model: 'multilingual-dense-hash-128',
          isLive: false,
        };
      }
    }

    // Offline deterministic vector fallback
    const fallback = generateEmbeddingVector(text);
    return {
      embedding: fallback,
      dimensions: 128,
      model: 'multilingual-dense-hash-128',
      isLive: false,
    };
  }

  async checkHealth(): Promise<AIProviderHealth> {
    const env = getEnvironment();
    const isConfigured = Boolean(env.AGRI_AI_API_KEY && env.AGRI_AI_API_KEY.trim());

    return {
      providerId: this.id,
      providerName: this.name,
      isProductionAuthorized: true,
      configured: isConfigured,
      model: getGeminiModel(),
      embeddingModel: getGeminiEmbeddingModel(),
      capabilities: {
        chat: isConfigured,
        structuredJson: isConfigured,
        vision: isConfigured,
        document: isConfigured,
        embeddings: true, // live or fallback dense vector always available
      },
      message: isConfigured
        ? 'Production AI provider configured and operational'
        : 'Production API credentials not configured',
    };
  }
}
