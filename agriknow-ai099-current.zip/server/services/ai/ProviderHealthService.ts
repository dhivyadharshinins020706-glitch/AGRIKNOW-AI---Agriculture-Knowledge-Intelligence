// AGRIKNOW AI — Comprehensive Health & Isolation Monitoring Service
// Reports provider status, model configuration, capability availability, and DB health without leaking secrets.

import { getEnvironment } from '../../config/environment.ts';
import { AIProviderFactory } from './AIProviderFactory.ts';
import { getGeminiUsageStats } from '../../../backend/services/geminiService.ts';

export interface ComprehensiveHealthReport {
  status: 'healthy' | 'degraded' | 'unhealthy';
  application: string;
  version: string;
  timestamp: string;
  production: {
    provider: string;
    model: string;
    embeddingModel: string;
    configured: boolean;
    capabilities: {
      chat: boolean;
      structuredJson: boolean;
      vision: boolean;
      document: boolean;
      embeddings: boolean;
    };
    usage: {
      totalRequests: number;
      totalTokensUsed: number;
    };
    availableModels?: string[];
  };
  academicIsolation: {
    cseAEnabled: boolean;
    isolated: boolean;
    crossFallbackBlocked: boolean;
    policy: string;
  };
  database: {
    configured: boolean;
    status: 'connected' | 'notconfigured' | 'unreachable' | 'checking';
    type: 'supabase';
  };
}

export class ProviderHealthService {
  /**
   * Generates a complete health inspection report while strictly protecting secrets.
   */
  public static async getHealthReport(): Promise<ComprehensiveHealthReport> {
    const env = getEnvironment();
    const productionProvider = AIProviderFactory.getProductionProvider();
    const prodHealth = await productionProvider.checkHealth();
    const stats = getGeminiUsageStats();

    // 1. Safe Supabase connectivity check
    let dbStatus: 'connected' | 'notconfigured' | 'unreachable' = 'notconfigured';
    const isDbConfigured = Boolean(env.SUPABASE_URL && env.SUPABASE_ANON_KEY);

    if (isDbConfigured && env.SUPABASE_URL) {
      try {
        const pingUrl = `${env.SUPABASE_URL.replace(/\/+$/, '')}/rest/v1/`;
        const res = await fetch(pingUrl, {
          method: 'GET',
          headers: {
            apikey: env.SUPABASE_ANON_KEY || '',
            Authorization: `Bearer ${env.SUPABASE_ANON_KEY || ''}`,
          },
          signal: AbortSignal.timeout(3500),
        });
        // 200 or 401/404 from Supabase confirms the server is reachable and responsive
        dbStatus = (res.status === 200 || res.status === 404 || res.status === 401) ? 'connected' : 'unreachable';
      } catch {
        dbStatus = 'unreachable';
      }
    }

    // 2. Safe Google Gemini Model List check (only if Gemini provider is active and key exists)
    let availableModels: string[] | undefined = undefined;
    if (env.AGRI_AI_PROVIDER === 'gemini' && env.AGRI_AI_API_KEY) {
      try {
        const listRes = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models?key=${env.AGRI_AI_API_KEY}`,
          { signal: AbortSignal.timeout(3000) }
        );
        if (listRes.ok) {
          const listData = await listRes.json();
          availableModels = (listData.models || [])
            .filter((m: any) => m.supportedGenerationMethods?.includes('generateContent'))
            .map((m: any) => m.name.replace('models/', ''));
        }
      } catch {
        // Safe silence if rate limited or network timeout
      }
    }

    // 3. Overall status calculation
    let status: 'healthy' | 'degraded' | 'unhealthy' = 'healthy';
    if (!prodHealth.configured) {
      status = 'degraded';
    }
    if (isDbConfigured && dbStatus === 'unreachable') {
      status = 'degraded';
    }

    return {
      status,
      application: 'AGRIKNOW AI Backend & Intelligence Engine',
      version: env.APP_VERSION,
      timestamp: new Date().toISOString(),
      production: {
        provider: env.AGRI_AI_PROVIDER,
        model: prodHealth.model,
        embeddingModel: prodHealth.embeddingModel || 'gemini-embedding-2',
        configured: prodHealth.configured,
        capabilities: {
          chat: prodHealth.capabilities.chat,
          structuredJson: prodHealth.capabilities.structuredJson,
          vision: prodHealth.capabilities.vision,
          document: prodHealth.capabilities.document,
          embeddings: prodHealth.capabilities.embeddings,
        },
        usage: {
          totalRequests: stats.totalRequests,
          totalTokensUsed: stats.totalTokensUsed,
        },
        availableModels,
      },
      academicIsolation: {
        cseAEnabled: env.CSE_A_API_ENABLED,
        isolated: true,
        crossFallbackBlocked: true,
        policy:
          'CSE A Academic Nexus is strictly isolated. AGRIKNOW production routes exclusively query production AI.',
      },
      database: {
        configured: isDbConfigured,
        status: dbStatus,
        type: 'supabase',
      },
    };
  }
}
