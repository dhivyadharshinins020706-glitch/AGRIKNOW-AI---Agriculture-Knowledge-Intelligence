// AGRIKNOW AI — CSE A Academic Nexus Provider (Strictly Isolated)
// BASE URL: https://nexusapi.navigatelabs.ai
//
// STRICT ISOLATION POLICY:
// 1. Used ONLY for explicitly authorized CSE A academic experiments.
// 2. Must NEVER be used by AGRIKNOW AI.
// 3. Must NEVER receive AGRIKNOW farmer data, documents, images, embeddings, prompts, or requests.
// 4. No compromised keys are stored or reused here.
// 5. Throws SecurityIsolationViolationError if accessed from AGRIKNOW production routes.

import {
  type IAIProvider,
  type AITextOptions,
  type AITextResult,
  type AIVisionOptions,
  type AIDocumentAnalysisOptions,
  type AIDocumentQaOptions,
  type AIEmbedResult,
  type AIProviderHealth,
  SecurityIsolationViolationError,
  AcademicProviderDisabledError,
  UnsupportedCapabilityError,
} from './AIProvider.interface.ts';
import { type AICapability, PROVIDER_CONFIGS } from '../../config/providers.ts';
import { getEnvironment } from '../../config/environment.ts';

export class NexusAcademicProvider implements IAIProvider {
  readonly id = 'cse-a-academic' as const;
  readonly name = PROVIDER_CONFIGS['cse-a-academic'].displayName;
  readonly isProductionAuthorized = false; // Strictly unauthorized for production
  readonly capabilities: ReadonlySet<AICapability> = new Set<AICapability>(['chat']);

  private readonly isAuthorizedExperiment: boolean;

  constructor(options?: { isAuthorizedExperiment?: boolean }) {
    this.isAuthorizedExperiment = Boolean(options?.isAuthorizedExperiment);
  }

  private assertIsolatedExecution(capability: AICapability): void {
    const env = getEnvironment();

    // 1. Check if CSE A Academic API is enabled
    if (!env.CSE_A_API_ENABLED) {
      throw new AcademicProviderDisabledError();
    }

    // 2. Check if explicitly marked as an authorized academic experiment
    if (!this.isAuthorizedExperiment) {
      throw new SecurityIsolationViolationError(
        'CSE A Academic API cannot be invoked without explicit experiment authorization. AGRIKNOW production routes cannot access this provider.'
      );
    }

    // 3. Check capability support
    if (!this.capabilities.has(capability)) {
      throw new UnsupportedCapabilityError(this.name, capability);
    }
  }

  hasCapability(capability: AICapability): boolean {
    return this.capabilities.has(capability);
  }

  assertCapability(capability: AICapability): void {
    if (!this.hasCapability(capability)) {
      throw new UnsupportedCapabilityError(this.name, capability);
    }
  }

  async generateText(options: AITextOptions): Promise<AITextResult> {
    this.assertIsolatedExecution('chat');

    const env = getEnvironment();
    if (!env.CSE_A_API_KEY) {
      throw new SecurityIsolationViolationError(
        'No valid academic API key provided. Compromised keys cannot be reused.'
      );
    }

    // Isolated academic experiment call to Nexus
    const response = await fetch(`${env.CSE_A_API_BASE_URL}/v1/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${env.CSE_A_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'nexus-academic-v1',
        messages: [
          ...(options.systemInstruction
            ? [{ role: 'system', content: options.systemInstruction }]
            : []),
          { role: 'user', content: options.prompt },
        ],
        temperature: options.temperature ?? 0.2,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Nexus Academic API error (${response.status}): ${errText}`);
    }

    const data = await response.json();
    return {
      text: data.choices?.[0]?.message?.content || '',
      modelUsed: 'nexus-academic-v1',
      tokensUsed: data.usage?.total_tokens || 0,
      provider: 'CSE A Academic Nexus',
    };
  }

  async diagnoseVision(_options: AIVisionOptions): Promise<any> {
    this.assertIsolatedExecution('vision'); // Will throw UnsupportedCapabilityError
  }

  async analyzeDocument(_options: AIDocumentAnalysisOptions): Promise<any> {
    this.assertIsolatedExecution('document');
    throw new UnsupportedCapabilityError(this.name, 'document');
  }

  async documentQa(_options: AIDocumentQaOptions): Promise<string> {
    this.assertIsolatedExecution('document');
    throw new UnsupportedCapabilityError(this.name, 'document');
  }

  async generateEmbeddings(_text: string): Promise<AIEmbedResult> {
    this.assertIsolatedExecution('embeddings');
    throw new UnsupportedCapabilityError(this.name, 'embeddings');
  }

  async checkHealth(): Promise<AIProviderHealth> {
    const env = getEnvironment();
    return {
      providerId: this.id,
      providerName: this.name,
      isProductionAuthorized: false,
      configured: Boolean(env.CSE_A_API_ENABLED && env.CSE_A_API_KEY),
      model: 'nexus-academic-v1',
      capabilities: {
        chat: Boolean(env.CSE_A_API_ENABLED && env.CSE_A_API_KEY),
        structuredJson: false,
        vision: false,
        document: false,
        embeddings: false,
      },
      message: env.CSE_A_API_ENABLED
        ? 'CSE A Academic Provider enabled for research'
        : 'CSE A Academic Provider disabled for AGRIKNOW AI production isolation',
    };
  }
}
