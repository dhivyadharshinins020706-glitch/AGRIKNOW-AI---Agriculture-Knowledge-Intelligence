// AGRIKNOW AI — AI Provider Abstraction Interface & Security Error Hierarchy

import type { AICapability, ProviderType } from '../../config/providers.ts';

// ============================================================================
// CUSTOM ERROR HIERARCHY
// ============================================================================

export class AIProviderError extends Error {
  readonly code: string;
  readonly statusCode: number;

  constructor(message: string, code: string, statusCode: number = 500) {
    super(message);
    this.name = 'AIProviderError';
    this.code = code;
    this.statusCode = statusCode;
  }
}

export class ProductionCredentialsMissingError extends AIProviderError {
  constructor(detail?: string) {
    super(
      detail ||
        'PROD_CREDENTIALS_MISSING: AGRIKNOW production credentials (AGRI_AI_API_KEY) are missing. Cross-provider fallback to academic API is strictly prohibited.',
      'PROD_CREDENTIALS_MISSING',
      503
    );
    this.name = 'ProductionCredentialsMissingError';
  }
}

export class SecurityIsolationViolationError extends AIProviderError {
  constructor(detail: string) {
    super(
      `SECURITY_ISOLATION_VIOLATION: ${detail}`,
      'SECURITY_ISOLATION_VIOLATION',
      403
    );
    this.name = 'SecurityIsolationViolationError';
  }
}

export class UnsupportedCapabilityError extends AIProviderError {
  constructor(providerName: string, capability: AICapability) {
    super(
      `UNSUPPORTED_CAPABILITY: Provider "${providerName}" does not support required capability "${capability}". Fallback to other providers is forbidden.`,
      'UNSUPPORTED_CAPABILITY',
      400
    );
    this.name = 'UnsupportedCapabilityError';
  }
}

export class AcademicProviderDisabledError extends AIProviderError {
  constructor() {
    super(
      'ACADEMIC_PROVIDER_DISABLED: The CSE A academic provider is disabled. It can only be used for explicitly authorized academic experiments.',
      'ACADEMIC_PROVIDER_DISABLED',
      403
    );
    this.name = 'AcademicProviderDisabledError';
  }
}

// ============================================================================
// REQUEST & RESPONSE INTERFACES
// ============================================================================

export interface AIHistoryMessage {
  role: 'user' | 'assistant' | 'model';
  content: string;
}

export interface AITextOptions {
  prompt: string;
  systemInstruction?: string;
  history?: AIHistoryMessage[];
  temperature?: number;
  maxOutputTokens?: number;
  responseMimeType?: string;
}

export interface AITextResult {
  text: string;
  modelUsed: string;
  tokensUsed: number;
  provider: string;
  finishReason?: string;
}

export interface AIVisionOptions {
  imageBase64: string;
  mimeType: string;
  userNotes?: string;
  language?: 'ta' | 'en';
}

export interface AIDocumentAnalysisOptions {
  documentText?: string;
  base64Data?: string;
  mimeType?: string;
  fileName?: string;
  language?: 'ta' | 'en';
}

export interface AIDocumentQaOptions {
  documentText: string;
  question: string;
  fileName?: string;
  language?: 'ta' | 'en';
}

export interface AIEmbedResult {
  embedding: number[];
  dimensions: number;
  model: string;
  isLive: boolean;
}

export interface AIProviderHealth {
  providerId: ProviderType;
  providerName: string;
  isProductionAuthorized: boolean;
  configured: boolean;
  model: string;
  embeddingModel?: string;
  capabilities: Record<AICapability, boolean>;
  message?: string;
}

// ============================================================================
// PROVIDER INTERFACE
// ============================================================================

export interface IAIProvider {
  readonly id: ProviderType;
  readonly name: string;
  readonly isProductionAuthorized: boolean;
  readonly capabilities: ReadonlySet<AICapability>;

  hasCapability(capability: AICapability): boolean;
  assertCapability(capability: AICapability): void;

  generateText(options: AITextOptions): Promise<AITextResult>;
  diagnoseVision(options: AIVisionOptions): Promise<any>;
  analyzeDocument(options: AIDocumentAnalysisOptions): Promise<any>;
  documentQa(options: AIDocumentQaOptions): Promise<string>;
  generateEmbeddings(text: string): Promise<AIEmbedResult>;
  checkHealth(): Promise<AIProviderHealth>;
}
