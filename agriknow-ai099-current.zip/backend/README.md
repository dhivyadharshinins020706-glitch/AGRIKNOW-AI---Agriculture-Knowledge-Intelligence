# AGRIKNOW AI — Backend & Services Module

The backend layer coordinates data persistence, authentication, authorization, external agricultural APIs, telemetry, and security validation.

## Structure
- `services/`:
  - `authService.ts`: Session management, registration, login, password recovery, secure logout
  - `farmerService.ts`: Farmer profile data, land holdings, preferred crops & language settings
  - `conversationService.ts`: Persistent bilingual chat history & conversation state
  - `diseaseService.ts`: Symptoms matching, verified ICAR/TNAU disease diagnostics
  - `soilReportService.ts`: Soil parameter analysis, pH/EC/NPK assessment
  - `weatherService.ts`: Hyperlocal agricultural weather forecast & alerts
  - `mandiService.ts`: Live commodity market prices (Agmarknet integration)
  - `ingestionService.ts`: Verification pipeline for agricultural research documents
  - `healthCheckService.ts`: Live system diagnostics for database, RAG corpus, and storage
  - `apiConfig.ts`: Centralized API endpoint configuration & environment variables
- `utils/`:
  - `security.ts`: XSS prevention, PII masking, Indian phone & email validators, path traversal defense
  - `uploadValidator.ts`: Magic byte checking for PDF, JPEG, PNG, WebP & size enforcement
  - `rateLimiter.ts`: In-memory sliding window rate limiter (DDoS protection)
  - `networkUtils.ts`: Exponential backoff retries with full jitter and timeout guards
  - `cryptoUtils.ts`: SHA-256 integrity checksums for backups and audit verification
- `telemetry/`:
  - `logger.ts`: Structured JSON logger with log levels, timestamps, context tagging, and automatic PII redaction
