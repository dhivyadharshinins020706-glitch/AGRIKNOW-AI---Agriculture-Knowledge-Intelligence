/**
 * AGRIKNOW AI - Phase 10 Business Packaging, Pricing & Unit Economics
 * Transparent INR Pricing Tiers grounded in real operational cost ($0.00035/query ≈ ₹0.03/query).
 * Strict Ethical Commitment: Critical safety, banned chemical warnings, and university citations
 * are NEVER locked behind a paywall.
 */

export interface PricingPlan {
  id: string;
  name: string;
  nameTa: string;
  targetSegment: string;
  targetSegmentTa: string;
  priceMonthlyInr: number;
  priceAnnualInr: number;
  billingPeriod: 'Free Forever' | 'Monthly' | 'Annual';
  highlighted: boolean;
  features: string[];
  featuresTa: string[];
  limits: {
    maxQueriesPerMonth: number | 'Unlimited';
    maxMembersOrSeats: number | 'Individual';
    customKnowledgeIngestion: boolean;
    dedicatedApiAccess: boolean;
    outbreakAnalytics: boolean;
    prioritySla: boolean;
  };
}

export const BUSINESS_PRICING_PLANS: PricingPlan[] = [
  {
    id: 'tier-farmer-free',
    name: 'Kisan Free (விவசாயி இலவசம்)',
    nameTa: 'கிசான் இலவச திட்டம்',
    targetSegment: 'Individual smallholder & marginal farmers (< 5 acres)',
    targetSegmentTa: 'சிறு மற்றும் குறு விவசாயிகள் (5 ஏக்கருக்கும் குறைவான நிலம்)',
    priceMonthlyInr: 0,
    priceAnnualInr: 0,
    billingPeriod: 'Free Forever',
    highlighted: true,
    features: [
      '100% Free natural language agricultural AI in Tamil & English',
      'Instant crop disease differential diagnosis & causes',
      'Soil Health Card 12-parameter dosage interpretation',
      'Indian Insecticides Act 1968 chemical safety warnings & bio-alternatives',
      'Unrestricted university source citations (TNAU & ICAR)',
      'Government welfare schemes & subsidy guides (PM-KISAN, PMFBY, Drip)',
      'Offline-capable PWA with local farm memory & consent controls',
    ],
    featuresTa: [
      'தமிழ் மற்றும் ஆங்கிலத்தில் 100% இலவச வேளாண் AI உதவியாளர்',
      'பயிர் நோய் அறிகுறிகள் & காரணங்கள் உடனடி ஒப்பீடு',
      'மண் வள அட்டை 12 சத்துக்கள் அடிப்படையிலான சமச்சீர் உர பரிந்துரை',
      'மத்திய அரசு தடைசெய்த நச்சு மருந்துகள் எச்சரிக்கை & மாற்று முறைகள்',
      'பல்கலைக்கழக ஆவண ஆதாரங்கள் (TNAU & ICAR) முழுமையான அணுகல்',
      'அரசு நலத்திட்டங்கள் & மானிய வழிகாட்டி (PM-KISAN, PMFBY, சொட்டு நீர்)',
      'இணையமில்லா ஆஃப்லைன் பயன்பாடு & விவசாயி தரவு பாதுகாப்பு',
    ],
    limits: {
      maxQueriesPerMonth: 'Unlimited',
      maxMembersOrSeats: 'Individual',
      customKnowledgeIngestion: false,
      dedicatedApiAccess: false,
      outbreakAnalytics: false,
      prioritySla: false,
    },
  },
  {
    id: 'tier-fpo-pro',
    name: 'FPO & Cooperative Pro',
    nameTa: 'உழவர் உற்பத்தியாளர் நிறுவனம் (FPO)',
    targetSegment: 'Farmer Producer Organizations, PACS, and local agri societies (100–1,000 members)',
    targetSegmentTa: 'உழவர் உற்பத்தியாளர் நிறுவனங்கள் & தொடக்க வேளாண் கூட்டுறவு சங்கங்கள்',
    priceMonthlyInr: 2499,
    priceAnnualInr: 24990, // 2 months free on annual
    billingPeriod: 'Monthly',
    highlighted: false,
    features: [
      'Everything in Kisan Free for all enrolled farmer members',
      'Aggregated District & Block Level Outbreak Dashboard',
      'Bulk Soil Health Card CSV upload & automated batch interpretation',
      'Custom Seasonal Advisory Broadcasts to members via SMS / WhatsApp',
      'Member crop acreage & harvest calendar tracking',
      'Dedicated Extension Officer multi-user access (up to 5 staff accounts)',
      'Email & priority telephone support with 4-hour response SLA',
    ],
    featuresTa: [
      'கிசான் இலவச திட்டத்தின் அனைத்து நன்மைகளும் FPO உறுப்பினர்களுக்கு',
      'வட்டார அளவிலான பூச்சி & நோய் பரவல் கண்காணிப்பு மேடை',
      'ஒரே நேரத்தில் பல விவசாயிகளின் மண் அட்டைகளை பதிவேற்றும் வசதி',
      'பருவகால விவசாய ஆலோசனைகளை விவசாயிகளுக்கு அனுப்பும் வசதி',
      'உறுப்பினர்களின் சாகுபடி பரப்பளவு & அறுவடை திட்ட மேலாண்மை',
      '5 கள அலுவலர்களுக்கான பிரத்யேக உள்நுழைவு வசதி',
      '4 மணி நேர முன்னுரிமை வாடிக்கையாளர் உதவி சேவை',
    ],
    limits: {
      maxQueriesPerMonth: 50000,
      maxMembersOrSeats: 500,
      customKnowledgeIngestion: false,
      dedicatedApiAccess: false,
      outbreakAnalytics: true,
      prioritySla: true,
    },
  },
  {
    id: 'tier-agribusiness-enterprise',
    name: 'Agri-Enterprise & Seed Corp',
    nameTa: 'வேளாண் பெருநிறுவனங்கள் & விதை நிறுவனங்கள்',
    targetSegment: 'Input manufacturers, seed companies, commercial mills & contract farming corporates',
    targetSegmentTa: 'விதை, உரம் தயாரிப்பாளர்கள் & ஒப்பந்த சாகுபடி நிறுவனங்கள்',
    priceMonthlyInr: 14999,
    priceAnnualInr: 149990,
    billingPeriod: 'Monthly',
    highlighted: false,
    features: [
      'Custom Ingestion Pipeline for proprietary agronomic research & seed catalogs',
      'Secure Isolated Multi-Tenant Database & vector namespaces',
      'Dedicated REST / GraphQL API endpoints with 99.9% uptime SLA',
      'Comprehensive Farmer Query Analytics & regional sentiment dashboards',
      'Field officer mobile SDK integration',
      'Enterprise Role-Based Access Control (RBAC) with audit logs',
      'Dedicated Agronomy Solutions Architect & technical account manager',
    ],
    featuresTa: [
      'நிறுவனத்தின் பிரத்யேக ஆய்வு அறிக்கைகள் மற்றும் விதை கையேடுகள் பதிவேற்றம்',
      'தனித்தனி பாதுகாப்பான தரவுத்தளம் மற்றும் வெக்டார் சேமிப்பகம்',
      '99.9% நேர உறுதிமொழியுடன் கூடிய நேரடி API அணுகல்',
      'வட்டார அளவிலான விவசாய தேவைகள் மற்றும் வினவல் பகுப்பாய்வு',
      'கள அலுவலர்களுக்கான தனிப்பயன் செயலி இணைப்பு',
      'நிறுவன பாதுகாப்பு தணிக்கை பதிவுகள் & அனுமதிகள் கட்டுப்பாடு',
      'பிரத்யேக தொழில்நுட்ப வேளாண் ஆலோசகர் உதவி',
    ],
    limits: {
      maxQueriesPerMonth: 'Unlimited',
      maxMembersOrSeats: 50,
      customKnowledgeIngestion: true,
      dedicatedApiAccess: true,
      outbreakAnalytics: true,
      prioritySla: true,
    },
  },
  {
    id: 'tier-institutional-university',
    name: 'University & KVK Research Tier',
    nameTa: 'பல்கலைக்கழகம் & வேளாண் அறிவியல் மையம் (KVK)',
    targetSegment: 'State Agricultural Universities (SAUs), ICAR institutes, and Krishi Vigyan Kendras',
    targetSegmentTa: 'தமிழ்நாடு வேளாண்மைப் பல்கலைக்கழகம் & ICAR வேளாண் அறிவியல் மையங்கள்',
    priceMonthlyInr: 4999,
    priceAnnualInr: 49990, // Subsidized for public agricultural education
    billingPeriod: 'Annual',
    highlighted: false,
    features: [
      'Full Admin Ingestion Pipeline access for publishing extension bulletins',
      'Real-world Knowledge Gap Telemetry export (unanswered farmer queries)',
      'Student & extension researcher annotation portal',
      'Differential symptom evaluation validation workbench',
      'Joint publication attributions on platform citation cards',
      'Compliance with National Agricultural Research System (NARS) guidelines',
    ],
    featuresTa: [
      'பல்கலைக்கழக கையேடுகளை நேரடியாக பதிவேற்றி வெளியிடும் வசதி',
      'விவசாயிகள் கேட்கும் விடையளிக்கப்படாத கேள்விகள் ஆய்வு தரவுத்தளம்',
      'மாணவர்கள் & விரிவுரை ஆராய்ச்சியாளர்கள் சரிபார்ப்பு மையம்',
      'கள நோய் அறிகுறிகள் ஒப்பீட்டு ஆய்வு மேடை',
      'ஆராய்ச்சி வெளியீடுகளுக்கான கூட்டு அங்கீகார அட்டை',
      'ICAR மற்றும் தேசிய வேளாண் தரநிலைகளுக்கு முழு இணக்கம்',
    ],
    limits: {
      maxQueriesPerMonth: 100000,
      maxMembersOrSeats: 20,
      customKnowledgeIngestion: true,
      dedicatedApiAccess: true,
      outbreakAnalytics: true,
      prioritySla: true,
    },
  },
];

/**
 * 12-Month Financial Projections (3 Scenarios)
 * Assumptions:
 * - Query unit cost: $0.00035 (₹0.03)
 * - Cloud Hosting & Base Infrastructure: ₹8,000/month
 * - Customer Acquisition Cost (CAC) for FPO: ₹4,500 (field workshops via KVK)
 * - FPO Churn Rate: < 5% annually due to high sticky member value
 */
export interface FinancialScenario {
  name: 'Conservative' | 'Moderate' | 'Optimistic';
  activeFarmers: number;
  paidFpos: number;
  paidEnterprises: number;
  paidUniversities: number;
  annualRecurringRevenueInr: number;
  annualCostOfGoodsSoldInr: number;
  annualOperatingExpensesInr: number;
  netProfitLossInr: number;
  breakEvenMonth: number | 'Not yet';
}

export const FINANCIAL_PROJECTIONS_YEAR_1: Record<string, FinancialScenario> = {
  conservative: {
    name: 'Conservative',
    activeFarmers: 15000,
    paidFpos: 12,
    paidEnterprises: 2,
    paidUniversities: 3,
    annualRecurringRevenueInr: 809640, // (12*24990) + (2*149990) + (3*49990) - discounts
    annualCostOfGoodsSoldInr: 126000, // LLM + Embeddings + Cloud Infra (₹10.5k/mo)
    annualOperatingExpensesInr: 540000, // 1 Field Agronomist + CAC events + legal
    netProfitLossInr: 143640,
    breakEvenMonth: 9,
  },
  moderate: {
    name: 'Moderate',
    activeFarmers: 50000,
    paidFpos: 45,
    paidEnterprises: 6,
    paidUniversities: 8,
    annualRecurringRevenueInr: 2424410, // (45*24990) + (6*149990) + (8*49990)
    annualCostOfGoodsSoldInr: 228000, // ₹19k/mo
    annualOperatingExpensesInr: 1120000, // 2 Agronomists + Field Demos + Support
    netProfitLossInr: 1076410,
    breakEvenMonth: 6,
  },
  optimistic: {
    name: 'Optimistic',
    activeFarmers: 150000,
    paidFpos: 120,
    paidEnterprises: 15,
    paidUniversities: 18,
    annualRecurringRevenueInr: 6148350, // (120*24990) + (15*149990) + (18*49990)
    annualCostOfGoodsSoldInr: 495000, // ₹41.2k/mo
    annualOperatingExpensesInr: 2450000, // Full Tech + Agronomy team + State-wide marketing
    netProfitLossInr: 3203350,
    breakEvenMonth: 4,
  },
};
