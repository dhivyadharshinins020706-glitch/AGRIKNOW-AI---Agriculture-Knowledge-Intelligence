/**
 * AGRIKNOW AI - Verified Indian & Tamil Nadu Government Agricultural Schemes
 * Source Grounding: Ministry of Agriculture & Farmers Welfare (Govt of India)
 * & Department of Agriculture, Government of Tamil Nadu.
 */

export interface GovernmentScheme {
  id: string;
  code: string;
  name: string;
  nameTa: string;
  category: 'direct_benefit' | 'insurance' | 'subsidy' | 'credit' | 'soil_health';
  sponsor: 'Central' | 'State' | 'Shared';
  targetAudience: string;
  targetAudienceTa: string;
  financialBenefit: string;
  financialBenefitTa: string;
  eligibility: string[];
  eligibilityTa: string[];
  documentsRequired: string[];
  documentsRequiredTa: string[];
  officialPortalUrl: string;
  helpline: string;
  verifiedSource: string;
}

export const VERIFIED_GOVERNMENT_SCHEMES: GovernmentScheme[] = [
  {
    id: 'scheme-pm-kisan',
    code: 'PM-KISAN',
    name: 'Pradhan Mantri Kisan Samman Nidhi (PM-KISAN)',
    nameTa: 'பிரதமர் கிசான் சம்மான் நிதி திட்டம்',
    category: 'direct_benefit',
    sponsor: 'Central',
    targetAudience: 'All landholding farmer families across India',
    targetAudienceTa: 'இந்தியாவில் உள்ள அனைத்து நில உரிமையுள்ள விவசாயக் குடும்பங்கள்',
    financialBenefit: '₹6,000 per year paid in three equal four-monthly installments of ₹2,000 directly to Aadhaar-linked bank accounts.',
    financialBenefitTa: 'ஆண்டுக்கு ₹6,000, 4 மாதங்களுக்கு ஒருமுறை ₹2,000 வீதம் 3 தவணைகளில் நேரடியாக ஆதார் இணைக்கப்பட்ட வங்கிக் கணக்கில் வரவு வைக்கப்படுகிறது.',
    eligibility: [
      'Farmer families who own cultivable land parcel in their name',
      'e-KYC verification mandatory via OTP or biometric face authentication',
      'Institutional landholders and income-tax payers are excluded',
    ],
    eligibilityTa: [
      'தங்கள் பெயரில் சாகுபடி செய்யக்கூடிய நிலம் வைத்துள்ள விவசாயிகள்',
      'ஆதார் எண் மற்றும் வங்கிக் கணக்குடன் e-KYC சரிபார்ப்பு கட்டாயம்',
      'நிறுவன நில உரிமையாளர்கள் மற்றும் வருமான வரி செலுத்துபவர்கள் தவிர்த்து',
    ],
    documentsRequired: ['Aadhaar Card', 'Land Patta / Chitta ownership proof', 'Aadhaar-seeded Bank Account details'],
    documentsRequiredTa: ['ஆதார் அட்டை', 'நிலப் பட்டா / சிட்டா நகல்', 'ஆதாருடன் இணைக்கப்பட்ட வங்கிக் கணக்கு புத்தகம்'],
    officialPortalUrl: 'https://pmkisan.gov.in',
    helpline: '155261 / 011-24300606',
    verifiedSource: 'Ministry of Agriculture & Farmers Welfare, Govt of India (Operational Guidelines 2024)',
  },
  {
    id: 'scheme-pmfby',
    code: 'PMFBY',
    name: 'Pradhan Mantri Fasal Bima Yojana (Crop Insurance)',
    nameTa: 'பிரதம மந்திரி பயிர் காப்பீட்டுத் திட்டம்',
    category: 'insurance',
    sponsor: 'Shared',
    targetAudience: 'Farmers cultivating notified crops in notified areas (Paddy, Cotton, Maize, Groundnut, Sugarcane)',
    targetAudienceTa: 'அறிவிக்கப்பட்ட பயிர்களை பயிரிடும் விவசாயிகள் (நெல், பருத்தி, மக்காச்சோளம், நிலக்கடலை, கரும்பு)',
    financialBenefit: 'Subsidized premium: Only 2% for Kharif crops, 1.5% for Rabi food/oilseed crops, and 5% for horticultural/commercial crops. Complete coverage for localized disasters, drought, unseasonal floods, and post-harvest losses.',
    financialBenefitTa: 'குறைந்த காப்பீட்டுக் கட்டணம்: குறுவை/காரிஃப் பயிர்களுக்கு 2%, சம்பா/ரபி பயிர்களுக்கு 1.5%, பணப்பயிர்களுக்கு 5%. வறட்சி, புயல், மழை வெள்ளம் மற்றும் அறுவடைக்கு பிந்தைய இழப்புகளுக்கு இழப்பீடு.',
    eligibility: [
      'All farmers growing notified crops including sharecroppers and tenant farmers',
      'Enrollment within notified cut-off date per crop season via CSC or Agri portal',
    ],
    eligibilityTa: [
      'குத்தகை விவசாயிகள் உட்பட அறிவிக்கப்பட்ட பயிர்களை சாகுபடி செய்யும் அனைத்து விவசாயிகள்',
      'பயிர் பருவத்திற்கு அறிவிக்கப்பட்ட கடைசி தேதிக்குள் பதிவு செய்ய வேண்டும்',
    ],
    documentsRequired: ['Aadhaar Card', 'Sowing Certificate from Village Administrative Officer (VAO)', 'Land Patta', 'Bank Passbook'],
    documentsRequiredTa: ['ஆதார் அட்டை', 'கிராம நிர்வாக அலுவலர் (VAO) விதைப்புச் சான்றிதழ்', 'பட்டா/சிட்டா', 'வங்கி கணக்குப் புத்தகம்'],
    officialPortalUrl: 'https://pmfby.gov.in',
    helpline: '1800-180-1551 (Kisan Call Centre)',
    verifiedSource: 'Pradhan Mantri Fasal Bima Yojana Revised Guidelines, Dept of Agriculture & Farmers Welfare',
  },
  {
    id: 'scheme-tn-micro-irrigation',
    code: 'PMKSY-PDMC-TN',
    name: 'Tamil Nadu Micro Irrigation Scheme (Per Drop More Crop - Drip & Sprinkler)',
    nameTa: 'தமிழ்நாடு முதலமைச்சரின் நுண்ணீர் பாசனத் திட்டம் (சொட்டு நீர் & தெளிப்பு நீர் பாசனம்)',
    category: 'subsidy',
    sponsor: 'Shared',
    targetAudience: 'Small and marginal farmers of Tamil Nadu cultivating horticultural and agricultural crops',
    targetAudienceTa: 'தமிழ்நாடு சிறு மற்றும் குறு விவசாயிகள் மற்றும் ஏனைய விவசாய பெருமக்கள்',
    financialBenefit: '100% full subsidy for Small & Marginal farmers (up to 5 acres); 75% subsidy for Big farmers (up to 12.5 acres) for drip and sprinkler irrigation setup.',
    financialBenefitTa: 'சிறு மற்றும் குறு விவசாயிகளுக்கு (5 ஏக்கர் வரை) 100% முழு மானியம்; பெரு விவசாயிகளுக்கு 75% மானியத்தில் சொட்டுநீர் பாசன அமைப்புகள்.',
    eligibility: [
      'Farmer must own farm land with an operational irrigation well / borewell / water source',
      'Small/Marginal farmer certificate issued by Tahsildar / Revenue department',
      'Valid electricity connection or solar agricultural pump',
    ],
    eligibilityTa: [
      'பாசன வசதியுள்ள கிணறு அல்லது ஆழ்துளை கிணறு கொண்ட நிலம் இருத்தல் வேண்டும்',
      'வருவாய்த் துறை வழங்கிய சிறு/குறு விவசாயி சான்றிதழ்',
      'மின் இணைப்பு அல்லது சூரியசக்தி பம்புசெட் வசதி',
    ],
    documentsRequired: ['Patta/Chitta/FMB sketch', 'Small/Marginal Farmer Certificate', 'Aadhaar Card', 'Field Photo with Well', 'Soil & Water Test Report'],
    documentsRequiredTa: ['பட்டா/சிட்டா/FMB வரைபடம்', 'சிறு/குறு விவசாயி சான்றிதழ்', 'ஆதார் அட்டை', 'கிணறுடன் கூடிய கள புகைப்படம்', 'மண் & நீர் பரிசோதனை அறிக்கை'],
    officialPortalUrl: 'https://tnhorticulture.tn.gov.in',
    helpline: '044-28524894 / Local Horticulture Officer',
    verifiedSource: 'Department of Horticulture and Plantation Crops, Government of Tamil Nadu (G.O. Ms No. 2024)',
  },
  {
    id: 'scheme-cmddm',
    code: 'CMDDM-TN',
    name: "Chief Minister's Dryland Development Mission (CMDDM - Tamil Nadu)",
    nameTa: 'முதலமைச்சரின் மானாவாரி நில மேம்பாட்டு இயக்கம் (CMDDM)',
    category: 'subsidy',
    sponsor: 'State',
    targetAudience: 'Dryland and rainfed farmers in rainfed districts of Tamil Nadu (Virudhunagar, Tuticorin, Ramanathapuram, Dharmapuri, etc.)',
    targetAudienceTa: 'தமிழ்நாட்டின் மானாவாரி மாவட்ட விவசாய பெருமக்கள் (விருதுநகர், தூத்துக்குடி, ராமநாதபுரம், தருமபுரி போன்றவை)',
    financialBenefit: '₹1,250/ha subsidy for summer ploughing, 50% subsidy on certified pulses and millet seeds, 100% free distribution of Bio-fertilizers (Azospirillum, Phosphobacteria) and micro-nutrient mixtures.',
    financialBenefitTa: 'கோடை உழவுக்கு ஹெக்டேருக்கு ₹1,250 மானியம், சான்று பெற்ற பயறு மற்றும் சிறுதானிய விதைகளுக்கு 50% மானியம், மற்றும் இலவச உயிர் உரங்கள் வழங்கல்.',
    eligibility: [
      'Farmers possessing rainfed/dryland cultivation plots',
      'Enrollment in Uzhavan App or via local Assistant Agricultural Officer (AAO)',
    ],
    eligibilityTa: [
      'மானாவாரி சாகுபடி நிலம் வைத்துள்ள விவசாயிகள்',
      'உழவன் செயலி அல்லது வட்டார வேளாண் விரிவாக்க மையத்தில் பதிவு செய்தல்',
    ],
    documentsRequired: ['Aadhaar Card', 'Chitta Copy', 'Bank Passbook'],
    documentsRequiredTa: ['ஆதார் அட்டை', 'சிட்டா நகல்', 'வங்கி கணக்குப் புத்தகம்'],
    officialPortalUrl: 'https://agrisnet.tn.gov.in',
    helpline: 'Uzhavan App Helpdesk / 1800-180-1551',
    verifiedSource: 'Tamil Nadu Agriculture-Farmers Welfare Department Policy Note 2024-25',
  },
  {
    id: 'scheme-kcc',
    code: 'KCC',
    name: 'Kisan Credit Card (Concessional Crop Loan)',
    nameTa: 'கிசான் கடன் அட்டை (குறைந்த வட்டி பயிர்க்கடன் திட்டம்)',
    category: 'credit',
    sponsor: 'Central',
    targetAudience: 'All farmers, tenant farmers, dairy and poultry rearers, and fishery entrepreneurs',
    targetAudienceTa: 'அனைத்து விவசாயிகள், குத்தகைதாரர்கள், கால்நடை மற்றும் மீன் வளர்ப்போர்',
    financialBenefit: 'Collateral-free institutional loan up to ₹1.60 lakh (and up to ₹3.00 lakh with basic hypothecation) at an effective interest rate of just 4% per annum upon prompt repayment (3% Prompt Repayment Incentive).',
    financialBenefitTa: '₹1.60 லட்சம் வரை அடமானம் இல்லாமல், உடனடி திருப்பிச் செலுத்தலில் 4% மிகக் குறைந்த வட்டியில் பயிர்க்கடன் வசதி (ரூ.3 லட்சம் வரை 7% வட்டியில் 3% மானியம்).',
    eligibility: [
      'Individual/joint borrower farmers or owner cultivators',
      'Tenant farmers, oral lessees & sharecroppers with cultivation proof',
      'SHGs or Joint Liability Groups of farmers',
    ],
    eligibilityTa: [
      'சொந்த நிலம் வைத்திருக்கும் விவசாயிகள் அல்லது கூட்டு விவசாயிகள்',
      'சாகுபடி ஆதாரத்துடன் கூடிய குத்தகை விவசாயிகள்',
      'சுய உதவி குழுக்கள் மற்றும் உழவர் உற்பத்தியாளர் குழுக்கள்',
    ],
    documentsRequired: ['Duly filled KCC application', 'Aadhaar Card & PAN', 'Land Record / Chitta / Tenancy Deed', 'No-Dues Certificate from local banks'],
    documentsRequiredTa: ['பூர்த்தி செய்யப்பட்ட KCC விண்ணப்பம்', 'ஆதார் அட்டை & பான் அட்டை', 'பட்டா/சிட்டா நகல்', 'நிலுவை இல்லா சான்று'],
    officialPortalUrl: 'https://myscheme.gov.in/schemes/kcc',
    helpline: '1800-11-5526 (National Banking Helpline)',
    verifiedSource: 'Reserve Bank of India (RBI) Master Circular on Kisan Credit Card Scheme 2024',
  },
  {
    id: 'scheme-soil-health-card',
    code: 'SHC',
    name: 'Soil Health Card Scheme',
    nameTa: 'மண் வள அட்டை திட்டம்',
    category: 'soil_health',
    sponsor: 'Central',
    targetAudience: 'All agricultural landowners in India',
    targetAudienceTa: 'இந்தியாவில் உள்ள அனைத்து விவசாய நில உரிமையாளர்கள்',
    financialBenefit: 'Free comprehensive chemical and physical testing of 12 soil parameters (N, P, K, S, Zn, Fe, Cu, Mn, Bo, pH, EC, OC) with crop-specific dosage charts for balanced fertilization, reducing input cost by 20-30%.',
    financialBenefitTa: '12 வகையான மண் சத்துக்கள் இலவசமாக பரிசோதிக்கப்பட்டு, பயிர் வாரியான சமச்சீர் உர பரிந்துரை அட்டை இலவசமாக வழங்கப்படுகிறது. உரச்செலவு 20-30% குறைகிறது.',
    eligibility: ['All farmers having active agricultural lands sampled through GPS-tagged soil collection grid'],
    eligibilityTa: ['ஜிபிஎஸ் முறையில் மண் மாதிரி சேகரிக்கப்படும் அனைத்து விவசாய பெருமக்கள்'],
    documentsRequired: ['Aadhaar Card', 'Land Survey Number / Patta'],
    documentsRequiredTa: ['ஆதார் அட்டை', 'நில சர்வே எண் / பட்டா நகல்'],
    officialPortalUrl: 'https://soilhealth.dac.gov.in',
    helpline: '011-23381012',
    verifiedSource: 'Department of Agriculture, Cooperation & Farmers Welfare, Ministry of Agriculture',
  },
];
