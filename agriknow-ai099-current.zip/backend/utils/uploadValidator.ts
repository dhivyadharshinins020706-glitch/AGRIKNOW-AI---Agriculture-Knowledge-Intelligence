/**
 * AGRIKNOW AI - Upload Safety & Magic Bytes Validator
 * Protects against Malicious File Upload (CWE-434), extension spoofing, and oversized files.
 */

import { sanitizeFilename } from './security';

export const MAX_DOCUMENT_SIZE_BYTES = 15 * 1024 * 1024; // 15 MB
export const MAX_IMAGE_SIZE_BYTES = 8 * 1024 * 1024; // 8 MB

export interface UploadValidationResult {
  isValid: boolean;
  cleanFilename: string;
  detectedMime: string;
  error?: string;
  errorTa?: string;
}

/**
 * Checks magic byte signatures from the header of an ArrayBuffer.
 */
export function detectMagicBytes(buffer: Uint8Array): string | null {
  if (buffer.length < 4) return null;

  // PDF signature: %PDF (0x25, 0x50, 0x44, 0x46)
  if (
    buffer[0] === 0x25 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x44 &&
    buffer[3] === 0x46
  ) {
    return 'application/pdf';
  }

  // JPEG signature: 0xFF, 0xD8, 0xFF
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return 'image/jpeg';
  }

  // PNG signature: 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A
  if (
    buffer.length >= 8 &&
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47 &&
    buffer[4] === 0x0d &&
    buffer[5] === 0x0a &&
    buffer[6] === 0x1a &&
    buffer[7] === 0x0a
  ) {
    return 'image/png';
  }

  // WebP signature: RIFF....WEBP (0x52 0x49 0x46 0x46 .... 0x57 0x45 0x42 0x50)
  if (
    buffer.length >= 12 &&
    buffer[0] === 0x52 &&
    buffer[1] === 0x49 &&
    buffer[2] === 0x46 &&
    buffer[3] === 0x46 &&
    buffer[8] === 0x57 &&
    buffer[9] === 0x45 &&
    buffer[10] === 0x42 &&
    buffer[11] === 0x50
  ) {
    return 'image/webp';
  }

  // Plain text (UTF-8 / ASCII)
  let isText = true;
  for (let i = 0; i < Math.min(buffer.length, 64); i++) {
    if (buffer[i] === 0x00) {
      isText = false;
      break;
    }
  }
  if (isText) {
    return 'text/plain';
  }

  return null;
}

/**
 * Validates a document file (e.g. PDF crop manual) for safety, size, and authenticity.
 */
export async function validateDocumentUpload(file: File): Promise<UploadValidationResult> {
  const cleanFilename = sanitizeFilename(file.name);

  // 1. Size Check
  if (file.size <= 0) {
    return {
      isValid: false,
      cleanFilename,
      detectedMime: '',
      error: 'File is empty (0 bytes).',
      errorTa: 'கோப்பு காலியாக உள்ளது (0 bytes).',
    };
  }

  if (file.size > MAX_DOCUMENT_SIZE_BYTES) {
    return {
      isValid: false,
      cleanFilename,
      detectedMime: file.type,
      error: `File size exceeds the 15 MB limit (Current: ${(file.size / (1024 * 1024)).toFixed(1)} MB).`,
      errorTa: `கோப்பின் அளவு 15 MB வரம்பை விட அதிகமாக உள்ளது (${(file.size / (1024 * 1024)).toFixed(1)} MB).`,
    };
  }

  // 2. Read first bytes for magic numbers
  try {
    const slice = file.slice(0, 32);
    const buffer = new Uint8Array(await slice.arrayBuffer());
    const detectedMime = detectMagicBytes(buffer);

    const allowedMimes = ['application/pdf', 'text/plain'];
    const isExtensionPdf = cleanFilename.toLowerCase().endsWith('.pdf');
    const isExtensionTxt = cleanFilename.toLowerCase().endsWith('.txt') || cleanFilename.toLowerCase().endsWith('.csv');

    if (!detectedMime || !allowedMimes.includes(detectedMime)) {
      // If extension is PDF but magic bytes mismatch -> spoofing attempt
      if (isExtensionPdf && detectedMime !== 'application/pdf') {
        return {
          isValid: false,
          cleanFilename,
          detectedMime: detectedMime || 'unknown',
          error: 'Security Warning: File extension is .pdf but binary magic bytes mismatch. Upload rejected.',
          errorTa: 'பாதுகாப்பு எச்சரிக்கை: கோப்பு .pdf ஆக உள்ளது, ஆனால் உள் உள்ளடக்கம் வேறுபட்டது. நிராகரிக்கப்பட்டது.',
        };
      }
      return {
        isValid: false,
        cleanFilename,
        detectedMime: detectedMime || 'unknown',
        error: 'Only verified PDF manuals and text documents are permitted.',
        errorTa: 'சரிபார்க்கப்பட்ட PDF கையேடுகள் மற்றும் உரை ஆவணங்கள் மட்டுமே அனுமதிக்கப்படுகின்றன.',
      };
    }

    if (detectedMime === 'text/plain' && !isExtensionTxt) {
      return {
        isValid: false,
        cleanFilename,
        detectedMime,
        error: 'Plain text files must have .txt or .csv extension.',
        errorTa: 'உரை ஆவணங்கள் .txt அல்லது .csv பின்னொட்டு கொண்டிருக்க வேண்டும்.',
      };
    }

    return {
      isValid: true,
      cleanFilename,
      detectedMime,
    };
  } catch (err: unknown) {
    return {
      isValid: false,
      cleanFilename,
      detectedMime: '',
      error: `Failed to inspect file safety: ${err instanceof Error ? err.message : String(err)}`,
      errorTa: 'கோப்பின் பாதுகாப்பை சரிபார்க்க முடியவில்லை.',
    };
  }
}

/**
 * Validates an image upload (e.g. crop leaf photo for disease diagnosis).
 */
export async function validateImageUpload(file: File): Promise<UploadValidationResult> {
  const cleanFilename = sanitizeFilename(file.name);

  // 1. Size Check
  if (file.size <= 0) {
    return {
      isValid: false,
      cleanFilename,
      detectedMime: '',
      error: 'Image file is empty.',
      errorTa: 'படக் கோப்பு காலியாக உள்ளது.',
    };
  }

  if (file.size > MAX_IMAGE_SIZE_BYTES) {
    return {
      isValid: false,
      cleanFilename,
      detectedMime: file.type,
      error: `Image size exceeds the 8 MB limit (Current: ${(file.size / (1024 * 1024)).toFixed(1)} MB).`,
      errorTa: `படத்தின் அளவு 8 MB வரம்பை விட அதிகமாக உள்ளது.`,
    };
  }

  // 2. Read first bytes for image magic numbers
  try {
    const slice = file.slice(0, 32);
    const buffer = new Uint8Array(await slice.arrayBuffer());
    const detectedMime = detectMagicBytes(buffer);

    const allowedImageMimes = ['image/jpeg', 'image/png', 'image/webp'];

    if (!detectedMime || !allowedImageMimes.includes(detectedMime)) {
      return {
        isValid: false,
        cleanFilename,
        detectedMime: detectedMime || 'unknown',
        error: 'Security Warning: Only valid JPEG, PNG, or WebP leaf photos are accepted.',
        errorTa: 'பாதுகாப்பு எச்சரிக்கை: JPEG, PNG, அல்லது WebP இலை படங்கள் மட்டுமே ஏற்கப்படும்.',
      };
    }

    return {
      isValid: true,
      cleanFilename,
      detectedMime,
    };
  } catch (err: unknown) {
    return {
      isValid: false,
      cleanFilename,
      detectedMime: '',
      error: `Image safety verification failed: ${err instanceof Error ? err.message : String(err)}`,
      errorTa: 'படத்தின் பாதுகாப்பை சரிபார்க்க முடியவில்லை.',
    };
  }
}
