/**
 * AGRIKNOW AI - Client-Side Rate Limiter
 * Implements sliding window rate limiting to protect services against abusive spam.
 */

export interface RateLimitResult {
  allowed: boolean;
  remainingTokens: number;
  retryAfterSeconds: number;
}

export class SlidingWindowRateLimiter {
  private timestamps: number[] = [];
  private maxRequests: number;
  private windowMs: number;

  constructor(maxRequests = 15, windowSeconds = 60) {
    this.maxRequests = maxRequests;
    this.windowMs = windowSeconds * 1000;
  }

  /**
   * Attempts to consume 1 token. Returns whether allowed and remaining tokens.
   */
  public checkLimit(): RateLimitResult {
    const now = Date.now();
    const windowStart = now - this.windowMs;

    // Filter out timestamps older than current window
    this.timestamps = this.timestamps.filter((t) => t > windowStart);

    if (this.timestamps.length >= this.maxRequests) {
      const oldestInWindow = this.timestamps[0];
      const retryAfterSeconds = Math.max(1, Math.ceil((oldestInWindow + this.windowMs - now) / 1000));
      return {
        allowed: false,
        remainingTokens: 0,
        retryAfterSeconds,
      };
    }

    this.timestamps.push(now);
    return {
      allowed: true,
      remainingTokens: this.maxRequests - this.timestamps.length,
      retryAfterSeconds: 0,
    };
  }

  /**
   * Resets limiter state.
   */
  public reset(): void {
    this.timestamps = [];
  }
}

// Global default rate limiter for farmer AI assistant queries (max 15 queries per minute)
export const assistantRateLimiter = new SlidingWindowRateLimiter(15, 60);

// Global rate limiter for file ingestion / verification (max 10 operations per minute)
export const ingestionRateLimiter = new SlidingWindowRateLimiter(10, 60);
