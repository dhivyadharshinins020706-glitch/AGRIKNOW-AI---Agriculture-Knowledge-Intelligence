/**
 * AGRIKNOW AI - Network Reliability Utilities
 * Implements fetch timeouts, exponential backoff retries with jitter, and offline detection.
 */

import { logger } from '../services/telemetry/logger.ts';

export interface RetryOptions {
  maxRetries?: number;
  baseDelayMs?: number;
  maxDelayMs?: number;
  timeoutMs?: number;
  retryableStatuses?: number[];
}

export const DEFAULT_RETRYABLE_STATUSES = [408, 429, 500, 502, 503, 504];

/**
 * Executes a fetch request with a strict AbortController timeout.
 */
export async function fetchWithTimeout(
  input: RequestInfo | URL,
  init?: RequestInit,
  timeoutMs = 8000
): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(input, {
      ...init,
      signal: controller.signal,
    });
    return response;
  } catch (err: unknown) {
    if (err instanceof Error && err.name === 'AbortError') {
      logger.warn('Network', `Request timed out after ${timeoutMs}ms: ${String(input)}`);
      throw new Error(`Network timeout: request exceeded ${timeoutMs}ms limit.`);
    }
    throw err;
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Wraps an async operation with controlled retries and exponential backoff with full jitter.
 */
export async function executeWithRetry<T>(
  operation: (attempt: number) => Promise<T>,
  contextName = 'Operation',
  options: RetryOptions = {}
): Promise<T> {
  const maxRetries = options.maxRetries ?? 3;
  const baseDelayMs = options.baseDelayMs ?? 400;
  const maxDelayMs = options.maxDelayMs ?? 4000;

  let lastError: Error | unknown;

  for (let attempt = 1; attempt <= maxRetries + 1; attempt++) {
    try {
      return await operation(attempt);
    } catch (err: unknown) {
      lastError = err;

      if (attempt > maxRetries) {
        logger.error('Reliability', `${contextName} failed after ${maxRetries} retries: ${String(err)}`);
        break;
      }

      // Exponential backoff with jitter: delay = min(maxDelay, base * 2^(attempt-1) * (0.5 + random * 0.5))
      const backoff = Math.min(maxDelayMs, baseDelayMs * Math.pow(2, attempt - 1));
      const jitter = 0.5 + Math.random() * 0.5;
      const delay = Math.round(backoff * jitter);

      logger.warn('Reliability', `${contextName} attempt ${attempt} failed. Retrying in ${delay}ms...`, {
        error: String(err),
      });

      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }

  throw lastError;
}

/**
 * Checks if the current browser client has active internet connectivity.
 */
export function isClientOnline(): boolean {
  return typeof navigator !== 'undefined' ? navigator.onLine : true;
}
