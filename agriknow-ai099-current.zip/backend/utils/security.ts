/* eslint-disable no-control-regex */
/**
 * AGRIKNOW AI - Production Security & Input Sanitization
 * Enforces XSS prevention, input validation, safe filename handling, and PII masking.
 */

/**
 * Strips dangerous HTML control characters, script tags, and null bytes.
 */
export function sanitizeInputText(input: string, maxLength = 1000): string {
  if (typeof input !== 'string') return '';
  
  // 1. Strip null bytes and control chars (except normal whitespace/newlines)
  let clean = input.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
  
  // 2. Strip script tags and HTML markup
  clean = clean.replace(/<[^>]*>/g, '');
  
  // 3. Trim and enforce maximum length
  return clean.trim().slice(0, maxLength);
}

/**
 * Escapes characters that could be interpreted as HTML entities in rendered text.
 */
export function escapeHtml(unsafe: string): string {
  if (typeof unsafe !== 'string') return '';
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Sanitizes uploaded filenames to prevent Directory Traversal (CWE-22) and shell injection.
 */
export function sanitizeFilename(filename: string): string {
  if (!filename) return 'unnamed_file';
  
  // Strip path separators and directory traversal sequences
  let clean = filename
    .replace(/[/\\]/g, '_')
    .replace(/\.\.+/g, '.')
    .replace(/[\x00-\x1F\x7F]/g, '');
  
  // Allow only alphanumeric, underscores, hyphens, and single dot for extension
  clean = clean.replace(/[^a-zA-Z0-9_.\- ]/g, '_');
  
  // Limit length
  if (clean.length > 120) {
    const ext = clean.substring(clean.lastIndexOf('.'));
    clean = clean.slice(0, 110) + ext;
  }
  
  return clean || 'document.pdf';
}

/**
 * Validates standard email format.
 */
export function isValidEmail(email: string): boolean {
  if (!email || email.length > 254) return false;
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
  return emailRegex.test(email);
}

/**
 * Validates Indian 10-digit mobile number format (with optional +91 prefix).
 */
export function isValidIndianPhone(phone: string): boolean {
  if (!phone) return true; // Optional field in some forms
  const cleanPhone = phone.replace(/[\s\-()]/g, '');
  const phoneRegex = /^(?:(?:\+|00)91|0)?[6-9]\d{9}$/;
  return phoneRegex.test(cleanPhone);
}

/**
 * Masks Personally Identifiable Information (PII) like phone numbers and emails in logs and telemetry.
 */
export function maskPii(text: string): string {
  if (!text) return '';
  
  // Mask Indian phone numbers: +91 98765 43210 -> +91 ******3210
  const phoneMasked = text.replace(
    /((?:\+91|0)?[6-9]\d{5})(\d{4})/g,
    '******$2'
  );
  
  // Mask emails: farmer@village.org -> f***r@village.org
  return phoneMasked.replace(
    /([a-zA-Z0-9._%+-])[a-zA-Z0-9._%+-]+([a-zA-Z0-9._%+-])@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/g,
    '$1***$2@$3'
  );
}
