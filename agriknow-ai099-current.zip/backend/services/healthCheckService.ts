/**
 * AGRIKNOW AI - Production Health Check & Diagnostic Service
 * Performs verifiable probes on database connectivity, RAG knowledge corpus,
 * speech synthesis, and client persistence.
 */

import { supabase, isSupabaseConfigured } from '../lib/supabase.ts';
import { fetchIngestedDocuments, fetchDocumentChunks } from './ingestionService.ts';
import { globalRagCache } from './rag/queryCache.ts';

export interface ServiceHealthStatus {
  service: string;
  status: 'healthy' | 'degraded' | 'unreachable';
  latencyMs: number;
  details: string;
  detailsTa: string;
}

export interface SystemHealthReport {
  timestamp: string;
  overallStatus: 'healthy' | 'degraded' | 'critical';
  services: ServiceHealthStatus[];
}

export async function runComprehensiveHealthCheck(): Promise<SystemHealthReport> {
  const services: ServiceHealthStatus[] = [];

  // 1. Supabase Database Probe
  const tDbStart = performance.now();
  if (isSupabaseConfigured && supabase) {
    try {
      const { error } = await supabase.from('knowledge_sources').select('id').limit(1);
      const dbLatency = Math.round(performance.now() - tDbStart);
      if (error) {
        services.push({
          service: 'Supabase Cloud Database',
          status: 'degraded',
          latencyMs: dbLatency,
          details: `Connected with query error: ${error.message}`,
          detailsTa: 'கிளவுட் தரவுத்தள இணைப்பு உள்ளது, ஆனால் வினவல் பிழை ஏற்பட்டது.',
        });
      } else {
        services.push({
          service: 'Supabase Cloud Database',
          status: 'healthy',
          latencyMs: dbLatency,
          details: 'Connected with Row Level Security active.',
          detailsTa: 'பாதுகாப்பான RLS உடன் கிளவுட் தரவுத்தளம் சீராக இயங்குகிறது.',
        });
      }
    } catch (err: unknown) {
      services.push({
        service: 'Supabase Cloud Database',
        status: 'unreachable',
        latencyMs: Math.round(performance.now() - tDbStart),
        details: `Connection failed: ${err instanceof Error ? err.message : String(err)}`,
        detailsTa: 'கிளவுட் தரவுத்தளத்துடன் இணைக்க முடியவில்லை.',
      });
    }
  } else {
    services.push({
      service: 'Supabase Cloud Database',
      status: 'healthy',
      latencyMs: 0,
      details: 'Offline mode active. All agricultural intelligence served from local verified corpus.',
      detailsTa: 'ஆஃப்லைன் முறை செயலில் உள்ளது. அனைத்து தகவல்களும் உள்ளூர் ஆவணங்களிலிருந்து பெறப்படுகின்றன.',
    });
  }

  // 2. Verified Knowledge Corpus & RAG Probe
  const tRagStart = performance.now();
  try {
    const docs = await fetchIngestedDocuments();
    let totalChunks = 0;
    if (docs.length > 0) {
      const chunks = await fetchDocumentChunks(docs[0].id);
      totalChunks = chunks.length;
    }
    const ragLatency = Math.round(performance.now() - tRagStart);
    services.push({
      service: 'Knowledge Corpus & Advanced RAG',
      status: docs.length > 0 ? 'healthy' : 'degraded',
      latencyMs: ragLatency,
      details: `${docs.length} university documents verified; ${totalChunks} traceable chunks indexed in memory.`,
      detailsTa: `${docs.length} பல்கலைக்கழக ஆவணங்கள் சரிபார்க்கப்பட்டுள்ளன; ${totalChunks} தகவல்கள் குறியிடப்பட்டுள்ளன.`,
    });
  } catch (err: unknown) {
    services.push({
      service: 'Knowledge Corpus & Advanced RAG',
      status: 'degraded',
      latencyMs: Math.round(performance.now() - tRagStart),
      details: `Corpus check failed: ${err instanceof Error ? err.message : String(err)}`,
      detailsTa: 'அறிவு களஞ்சியத்தை சரிபார்க்க முடியவில்லை.',
    });
  }

  // 3. Browser Speech & Voice Synthesis Probe
  const tVoiceStart = performance.now();
  const hasSpeechSynthesis = typeof window !== 'undefined' && 'speechSynthesis' in window;
  const voiceLatency = Math.round(performance.now() - tVoiceStart);
  services.push({
    service: 'Speech Audio Engine (Tamil & English)',
    status: hasSpeechSynthesis ? 'healthy' : 'degraded',
    latencyMs: voiceLatency,
    details: hasSpeechSynthesis ? 'SpeechSynthesis API available for illiterate-friendly voice read-aloud.' : 'SpeechSynthesis not supported on this browser.',
    detailsTa: hasSpeechSynthesis ? 'குரல் வாசிப்பு வசதி (SpeechSynthesis) முழுமையாக செயல்படுகிறது.' : 'இந்த உலாவியில் குரல் வாசிப்பு வசதி இல்லை.',
  });

  // 4. Client Storage & In-Memory Cache Probe
  const tStorageStart = performance.now();
  let storageHealthy = false;
  try {
    const testKey = '__agriknow_probe__';
    localStorage.setItem(testKey, '1');
    storageHealthy = localStorage.getItem(testKey) === '1';
    localStorage.removeItem(testKey);
  } catch {
    storageHealthy = false;
  }
  const storageLatency = Math.round(performance.now() - tStorageStart);
  services.push({
    service: 'Client Persistence & RAG Cache',
    status: storageHealthy ? 'healthy' : 'degraded',
    latencyMs: storageLatency,
    details: `LocalStorage verified. RAG Cache active with ${globalRagCache.size()} cached queries.`,
    detailsTa: `உள்ளூர் சேமிப்பு சரிபார்க்கப்பட்டது. ${globalRagCache.size()} வினவல்கள் தற்காலிக சேமிப்பில் உள்ளன.`,
  });

  // Overall status evaluation
  const hasUnreachable = services.some((s) => s.status === 'unreachable');
  const hasDegraded = services.some((s) => s.status === 'degraded');
  const overallStatus = hasUnreachable ? 'critical' : hasDegraded ? 'degraded' : 'healthy';

  return {
    timestamp: new Date().toISOString(),
    overallStatus,
    services,
  };
}
