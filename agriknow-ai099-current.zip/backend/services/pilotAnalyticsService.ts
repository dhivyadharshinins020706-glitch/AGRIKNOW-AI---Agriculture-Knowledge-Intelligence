/**
 * AGRIKNOW AI - Phase 7 Pilot Analytics & Metric Aggregator
 * Tracks task completion, answer helpfulness, response latencies, and abstention
 * without capturing unneeded personal identifying information.
 */

import { supabase, isSupabaseConfigured } from '../lib/supabase.ts';
import { getLocalPilotFeedback } from './feedbackService.ts';

export interface PilotTaskEvent {
  taskType: 'crop_disease_diagnostic' | 'soil_card_interpretation' | 'crop_selection_guide' | 'ai_chat_query' | 'document_retrieval';
  completed: boolean;
  latencyMs: number;
  language: 'ta' | 'en';
  hadAbstention?: boolean;
  hadChemicalGuard?: boolean;
  timestamp: string;
}

export interface PilotAggregatedMetrics {
  totalTasks: number;
  successfulTasks: number;
  taskCompletionRate: number; // percentage
  averageLatencyMs: number;
  totalFeedbackCount: number;
  helpfulCount: number;
  helpfulnessRatio: number; // percentage
  averageRating: number;
  averageTamilQuality: number;
  safeAbstentionCount: number;
  chemicalGuardCount: number;
  languageDistribution: {
    ta: number;
    en: number;
  };
  accuracyFlagsSummary: Record<string, number>;
}

const LOCAL_PILOT_EVENTS_KEY = 'agriknow_pilot_events_v1';
const inMemoryEventsBuffer: PilotTaskEvent[] = [];

export function getLocalPilotEvents(): PilotTaskEvent[] {
  if (typeof localStorage === 'undefined') {
    return [...inMemoryEventsBuffer];
  }
  try {
    const raw = localStorage.getItem(LOCAL_PILOT_EVENTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [...inMemoryEventsBuffer];
  }
}

export function recordPilotTaskEvent(event: Omit<PilotTaskEvent, 'timestamp'>): void {
  const fullEvent: PilotTaskEvent = {
    ...event,
    timestamp: new Date().toISOString(),
  };

  if (typeof localStorage === 'undefined') {
    inMemoryEventsBuffer.unshift(fullEvent);
  } else {
    try {
      const list = getLocalPilotEvents();
      list.unshift(fullEvent);
      localStorage.setItem(LOCAL_PILOT_EVENTS_KEY, JSON.stringify(list.slice(0, 1000)));
    } catch {
      inMemoryEventsBuffer.unshift(fullEvent);
    }
  }

  if (isSupabaseConfigured && supabase) {
    Promise.resolve(
      supabase.from('pilot_task_metrics').insert({
        task_type: fullEvent.taskType,
        completed: fullEvent.completed,
        latency_ms: fullEvent.latencyMs,
        language: fullEvent.language,
        had_abstention: fullEvent.hadAbstention || false,
        had_chemical_guard: fullEvent.hadChemicalGuard || false,
      })
    ).catch(() => {});
  }
}

export function getPilotAggregatedMetrics(): PilotAggregatedMetrics {
  const events = getLocalPilotEvents();
  const feedbacks = getLocalPilotFeedback();

  const totalTasks = events.length;
  const successfulTasks = events.filter((e) => e.completed).length;
  const taskCompletionRate = totalTasks > 0 ? (successfulTasks / totalTasks) * 100 : 100;

  const totalLatency = events.reduce((sum, e) => sum + e.latencyMs, 0);
  const averageLatencyMs = totalTasks > 0 ? Math.round(totalLatency / totalTasks) : 0;

  const safeAbstentionCount = events.filter((e) => e.hadAbstention).length;
  const chemicalGuardCount = events.filter((e) => e.hadChemicalGuard).length;

  const taCount = events.filter((e) => e.language === 'ta').length;
  const enCount = events.filter((e) => e.language === 'en').length;

  const totalFeedbackCount = feedbacks.length;
  const helpfulCount = feedbacks.filter((f) => f.isHelpful).length;
  const helpfulnessRatio = totalFeedbackCount > 0 ? (helpfulCount / totalFeedbackCount) * 100 : 100;

  const ratedFeedbacks = feedbacks.filter((f) => typeof f.rating === 'number' && f.rating > 0);
  const totalRating = ratedFeedbacks.reduce((sum, f) => sum + (f.rating || 0), 0);
  const averageRating = ratedFeedbacks.length > 0 ? Number((totalRating / ratedFeedbacks.length).toFixed(1)) : 5.0;

  const tamilRated = feedbacks.filter((f) => typeof f.tamilQualityRating === 'number' && f.tamilQualityRating > 0);
  const totalTamilRating = tamilRated.reduce((sum, f) => sum + (f.tamilQualityRating || 0), 0);
  const averageTamilQuality = tamilRated.length > 0 ? Number((totalTamilRating / tamilRated.length).toFixed(1)) : 4.8;

  const accuracyFlagsSummary: Record<string, number> = {};
  for (const f of feedbacks) {
    for (const flag of f.accuracyFlags) {
      accuracyFlagsSummary[flag] = (accuracyFlagsSummary[flag] || 0) + 1;
    }
  }

  return {
    totalTasks,
    successfulTasks,
    taskCompletionRate,
    averageLatencyMs,
    totalFeedbackCount,
    helpfulCount,
    helpfulnessRatio,
    averageRating,
    averageTamilQuality,
    safeAbstentionCount,
    chemicalGuardCount,
    languageDistribution: {
      ta: taCount,
      en: enCount,
    },
    accuracyFlagsSummary,
  };
}
