import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { Session, User } from '@supabase/supabase-js';

export interface AuthResponse {
  user: User | null;
  session: Session | null;
  error: string | null;
}

export async function registerFarmer(
  email: string,
  password: string,
  fullName: string,
  phone?: string,
  district?: string
): Promise<AuthResponse> {
  if (!isSupabaseConfigured || !supabase) {
    return {
      user: null,
      session: null,
      error: 'Supabase is not configured. Please add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your .env file.',
    };
  }

  try {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName,
          phone: phone || '',
          district: district || 'Thanjavur',
        },
      },
    });

    if (error) {
      return { user: null, session: null, error: error.message };
    }

    return { user: data.user, session: data.session, error: null };
  } catch (err: unknown) {
    return {
      user: null,
      session: null,
      error: err instanceof Error ? err.message : 'Registration failed unexpectedly',
    };
  }
}

export async function loginFarmer(email: string, password: string): Promise<AuthResponse> {
  if (!isSupabaseConfigured || !supabase) {
    return {
      user: null,
      session: null,
      error: 'Supabase is not configured. Please add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your .env file.',
    };
  }

  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      return { user: null, session: null, error: error.message };
    }

    return { user: data.user, session: data.session, error: null };
  } catch (err: unknown) {
    return {
      user: null,
      session: null,
      error: err instanceof Error ? err.message : 'Sign in failed unexpectedly',
    };
  }
}

export async function logoutFarmer(): Promise<{ error: string | null }> {
  if (!isSupabaseConfigured || !supabase) {
    return { error: null };
  }

  try {
    const { error } = await supabase.auth.signOut();
    return { error: error ? error.message : null };
  } catch (err: unknown) {
    return { error: err instanceof Error ? err.message : 'Logout failed' };
  }
}

export async function requestPasswordReset(email: string): Promise<{ error: string | null }> {
  if (!isSupabaseConfigured || !supabase) {
    return {
      error: 'Supabase is not configured. Please add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your .env file.',
    };
  }

  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/#/profile`,
    });
    return { error: error ? error.message : null };
  } catch (err: unknown) {
    return { error: err instanceof Error ? err.message : 'Password reset failed' };
  }
}

export async function getActiveSession(): Promise<{ session: Session | null; user: User | null }> {
  if (!isSupabaseConfigured || !supabase) {
    return { session: null, user: null };
  }

  try {
    const { data } = await supabase.auth.getSession();
    return { session: data.session, user: data.session?.user || null };
  } catch {
    return { session: null, user: null };
  }
}
