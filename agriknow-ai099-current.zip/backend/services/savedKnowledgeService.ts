import { supabase, isSupabaseConfigured } from '@/lib/supabase';

export interface SavedAdvisory {
  id: string;
  user_id: string;
  title: string;
  content: string;
  crop_name?: string;
  source_id?: string;
  created_at: string;
}

export async function fetchUserSavedAdvisories(userId: string): Promise<SavedAdvisory[]> {
  if (!isSupabaseConfigured || !supabase) return [];

  try {
    const { data, error } = await supabase
      .from('saved_advisories')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error || !data) return [];
    return data;
  } catch {
    return [];
  }
}

export async function saveAdvisoryToDb(
  userId: string,
  title: string,
  content: string,
  cropName?: string,
  sourceId?: string
): Promise<string | null> {
  if (!isSupabaseConfigured || !supabase) return null;

  try {
    const { data, error } = await supabase
      .from('saved_advisories')
      .insert({
        user_id: userId,
        title,
        content,
        crop_name: cropName || null,
        source_id: sourceId || null,
      })
      .select('id')
      .single();

    if (error || !data) return null;
    return data.id;
  } catch {
    return null;
  }
}

export async function deleteSavedAdvisoryFromDb(id: string): Promise<boolean> {
  if (!isSupabaseConfigured || !supabase) return false;

  try {
    const { error } = await supabase.from('saved_advisories').delete().eq('id', id);
    return !error;
  } catch {
    return false;
  }
}
