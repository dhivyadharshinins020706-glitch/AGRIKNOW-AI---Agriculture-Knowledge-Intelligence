import { supabase, isSupabaseConfigured } from '../lib/supabase.ts';
import type {
  IngestedDocument,
  DocumentChunk,
  IngestionOptions,
  IngestionStepLog,
  IngestionStats,
  VerificationStatus,
  EmbeddingMetadata,
} from '../types/ingestion.ts';
import { isEmbeddingCompatible } from '../types/ingestion.ts';
import { computeFileSha256 } from '../utils/cryptoUtils.ts';
import { extractPdfText } from '../utils/pdfExtractor.ts';
import { cleanAgriculturalText } from '../utils/textCleaner.ts';
import { chunkDocumentText } from '../utils/chunker.ts';
import { generateEmbeddingVector, cosineSimilarity } from '../utils/embeddingGenerator.ts';
import { verifiedStarterDocuments, verifiedStarterChunks } from '../data/starterKnowledge.ts';
import { callGeminiEmbeddings, getGeminiApiKey, getGeminiEmbeddingModel } from './geminiService.ts';

const LOCAL_DOCS_KEY = 'agriknow_ingested_documents_v1';
const LOCAL_CHUNKS_KEY = 'agriknow_document_chunks_v1';

export function normalizeIngestedDocument(d: any): IngestedDocument {
  if (!d) return d;
  return {
    ...d,
    crops: Array.isArray(d?.crops)
      ? d.crops.filter(Boolean)
      : typeof d?.crops === 'string'
      ? d.crops.split(',').map((s: string) => s.trim()).filter(Boolean)
      : [],
    topics: Array.isArray(d?.topics)
      ? d.topics.filter(Boolean)
      : typeof d?.topics === 'string'
      ? d.topics.split(',').map((s: string) => s.trim()).filter(Boolean)
      : [],
    verificationStatus: d?.verificationStatus || 'verified',
    fileSizeBytes: Number(d?.fileSizeBytes) || 0,
    totalPages: Number(d?.totalPages) || 1,
    totalChunks: Number(d?.totalChunks) || 1,
  };
}

/**
 * Load documents from local storage or starter defaults
 */
function getLocalDocuments(): IngestedDocument[] {
  try {
    const raw = localStorage.getItem(LOCAL_DOCS_KEY);
    if (!raw) {
      localStorage.setItem(LOCAL_DOCS_KEY, JSON.stringify(verifiedStarterDocuments));
      return verifiedStarterDocuments.map(normalizeIngestedDocument);
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.map(normalizeIngestedDocument) : verifiedStarterDocuments.map(normalizeIngestedDocument);
  } catch {
    return verifiedStarterDocuments.map(normalizeIngestedDocument);
  }
}

function saveLocalDocuments(docs: IngestedDocument[]) {
  try {
    localStorage.setItem(LOCAL_DOCS_KEY, JSON.stringify(docs));
  } catch {
    // quota exceeded fallback
  }
}

const VERIFIED_STARTER_DOC_IDS = new Set([
  'doc-tnau-paddy-sri',
  'doc-icar-cotton-ipm',
  'doc-tnau-groundnut-gypsum',
  'doc-tnau-sugarcane-fertigation',
  'doc-icar-banana-sigatoka',
  'doc-tnau-maize-faw',
]);

function isVerifiedStarterChunk(c: any): boolean {
  if (!Array.isArray(c?.embeddingVector || c?.embedding_vector)) return false;
  const vec = c.embeddingVector || c.embedding_vector;
  if (vec.length !== 128) return false;
  const id = String(c.id || '');
  const docId = String(c.documentId || c.document_id || '');
  return id.startsWith('chunk-tnau-') || id.startsWith('chunk-icar-') || VERIFIED_STARTER_DOC_IDS.has(docId);
}

function getLocalChunks(): DocumentChunk[] {
  try {
    const raw = localStorage.getItem(LOCAL_CHUNKS_KEY);
    if (!raw) {
      localStorage.setItem(LOCAL_CHUNKS_KEY, JSON.stringify(verifiedStarterChunks));
      return verifiedStarterChunks;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return verifiedStarterChunks;
    return parsed.map((c: DocumentChunk) => ({
      ...c,
      embeddingModel:
        c.embeddingModel ||
        (isVerifiedStarterChunk(c) ? 'multilingual-dense-hash-128' : undefined),
      embeddingVersion:
        c.embeddingVersion ||
        (isVerifiedStarterChunk(c) ? '1.0' : undefined),
      embeddingDimensions:
        c.embeddingDimensions ||
        (isVerifiedStarterChunk(c) ? 128 : (Array.isArray(c.embeddingVector) && c.embeddingVector.length > 0 ? c.embeddingVector.length : undefined)),
    }));
  } catch {
    return verifiedStarterChunks;
  }
}

function saveLocalChunks(chunks: DocumentChunk[]) {
  try {
    localStorage.setItem(LOCAL_CHUNKS_KEY, JSON.stringify(chunks));
  } catch {
    // quota exceeded fallback
  }
}

/**
 * Fetch all ingested documents (from Supabase if configured, otherwise local storage)
 */
export async function fetchIngestedDocuments(): Promise<IngestedDocument[]> {
  if (isSupabaseConfigured && supabase) {
    try {
      const queryPromise = supabase
        .from('ingested_documents')
        .select('*')
        .order('created_at', { ascending: false });

      const timeoutPromise = new Promise<{ data: any[] | null; error: any }>((resolve) =>
        setTimeout(() => resolve({ data: null, error: new Error('Supabase query timeout') }), 2500)
      );

      const { data, error } = await Promise.race([queryPromise, timeoutPromise]);

      if (!error && data && data.length > 0) {
        return data.map((d) =>
          normalizeIngestedDocument({
            id: d.id,
            title: d.title,
            description: d.description || '',
            institution: d.institution,
            category: d.category,
            crops: d.crops || [],
            topics: d.topics || [],
            language: d.language,
            publicationDate: d.publication_date || '',
            fileName: d.file_name,
            fileSizeBytes: Number(d.file_size_bytes) || 0,
            fileHash: d.file_hash,
            fileUrl: d.file_url,
            status: d.status,
            verificationStatus: d.verification_status,
            verificationNotes: d.verification_notes,
            verifiedBy: d.verified_by,
            verifiedAt: d.verified_at,
            errorMessage: d.error_message,
            totalPages: d.total_pages || 0,
            totalChunks: d.total_chunks || 0,
            createdAt: d.created_at,
            updatedAt: d.updated_at,
          })
        );
      }
    } catch {
      // Fallback to local documents
    }
  }

  return getLocalDocuments();
}

/**
 * Fetch chunks for a given document with full page traceability
 */
export async function fetchDocumentChunks(documentId: string): Promise<DocumentChunk[]> {
  if (isSupabaseConfigured && supabase) {
    try {
      const { data, error } = await supabase
        .from('document_chunks')
        .select('*')
        .eq('document_id', documentId)
        .order('chunk_index', { ascending: true });

      if (!error && data && data.length > 0) {
        return data.map((c) => ({
          id: c.id,
          documentId: c.document_id,
          documentTitle: '',
          chunkIndex: c.chunk_index,
          pageNumber: c.page_number,
          crop: c.crop,
          topic: c.topic,
          region: c.region,
          language: c.language,
          sourceInstitution: c.source_institution,
          content: c.content,
          tokenCount: c.token_count,
          embeddingVector: c.embedding_vector || [],
          embeddingModel:
            c.embedding_model ||
            (isVerifiedStarterChunk(c) ? 'multilingual-dense-hash-128' : undefined),
          embeddingVersion:
            c.embedding_version ||
            (isVerifiedStarterChunk(c) ? '1.0' : undefined),
          embeddingDimensions:
            c.embedding_dimensions ||
            (isVerifiedStarterChunk(c)
              ? 128
              : Array.isArray(c.embedding_vector) && c.embedding_vector.length > 0
              ? c.embedding_vector.length
              : undefined),
          createdAt: c.created_at,
        }));
      }
    } catch {
      // fallback
    }
  }

  const allChunks = getLocalChunks();
  return allChunks.filter((c) => c.documentId === documentId);
}

/**
 * Executes the complete real Ingestion Pipeline:
 * 1. Binary validation & Size check
 * 2. Cryptographic SHA-256 calculation & Duplicate Detection
 * 3. Stream text extraction & Scanned raster/OCR check
 * 4. Agricultural text cleaning & Conflict detection
 * 5. Semantic chunking with configurable overlap & traceability
 * 6. Multilingual 128-dim dense embedding generation
 * 7. Database & chunk index persistence
 */
export async function uploadAndIngestDocument(
  file: File,
  metadata: {
    title: string;
    description: string;
    institution: IngestionOptions['institution'];
    category: IngestionOptions['category'];
    crops: string[];
    topics: string[];
    language: IngestionOptions['language'];
    publicationDate: string;
  },
  options: {
    chunkSize?: number;
    chunkOverlap?: number;
  },
  onLog?: (log: IngestionStepLog) => void
): Promise<{ document: IngestedDocument; chunks: DocumentChunk[] }> {
  const addLog = (
    step: IngestionStepLog['step'],
    message: string,
    tone: IngestionStepLog['tone'] = 'info'
  ) => {
    if (onLog) {
      onLog({
        id: `log-${Date.now()}-${Math.random()}`,
        timestamp: new Date().toLocaleTimeString(),
        step,
        message,
        tone,
      });
    }
  };

  // STEP 1: Validation
  addLog('validation', `Validating ${file.name} (${(file.size / 1024).toFixed(1)} KB)...`, 'info');
  if (file.size > 25 * 1024 * 1024) {
    const errorMsg = 'File size exceeds maximum permitted limit (25 MB).';
    addLog('error', errorMsg, 'danger');
    throw new Error(errorMsg);
  }

  const arrayBuffer = await file.arrayBuffer();

  // STEP 2: Duplicate Detection with SHA-256
  addLog('hash', 'Computing cryptographic SHA-256 checksum...', 'info');
  const fileHash = await computeFileSha256(arrayBuffer);
  addLog('hash', `File SHA-256: ${fileHash.slice(0, 16)}...`, 'info');

  const existingDocs = await fetchIngestedDocuments();
  const duplicate = existingDocs.find((d) => d.fileHash === fileHash);
  if (duplicate) {
    const dupMsg = `Duplicate detected: This file exactly matches existing document "${duplicate.title}" (ID: ${duplicate.id}). Ingestion rejected to prevent index poisoning.`;
    addLog('error', dupMsg, 'danger');
    throw new Error(dupMsg);
  }

  // STEP 3: Stream Text Extraction & OCR
  addLog('extraction', 'Parsing PDF streams and checking text layer...', 'info');
  const extractionResult = await extractPdfText(arrayBuffer, file.name);

  if (extractionResult.isScannedDocument) {
    addLog(
      'extraction',
      'Scanned document detected: Bitmap raster present without searchable text stream. Flagged for OCR processing.',
      'warning'
    );
  } else {
    addLog(
      'extraction',
      `Extracted ${extractionResult.totalChars} characters across ${extractionResult.totalPages} pages.`,
      'success'
    );
  }

  // STEP 4: Cleaning & Conflict Detection
  addLog('cleaning', 'Cleaning agricultural text and scanning for contradictory or banned recommendations...', 'info');
  let hasBannedConflicts = false;
  const conflictNotesList: string[] = [];

  const cleanedPages = extractionResult.pages.map((p) => {
    const report = cleanAgriculturalText(p.text, p.pageNumber);
    if (report.hasConflicts && report.conflictNotes) {
      hasBannedConflicts = true;
      conflictNotesList.push(report.conflictNotes);
    }
    return {
      pageNumber: p.pageNumber,
      cleanedText: report.cleanedText,
    };
  });

  if (hasBannedConflicts) {
    addLog(
      'cleaning',
      `Conflict Alert: Outdated/restricted chemical recommendations detected. Document will be automatically flagged for agronomist review.`,
      'warning'
    );
  } else {
    addLog('cleaning', 'Text normalization complete. Zero restricted chemicals identified.', 'success');
  }

  // STEP 5: Semantic Chunking with Traceability
  const docId = `doc-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  addLog(
    'chunking',
    `Chunking text with target size ${options.chunkSize || 650} chars and overlap ${options.chunkOverlap || 120} chars...`,
    'info'
  );

  const rawChunks = chunkDocumentText(docId, metadata.title, cleanedPages, {
    chunkSize: options.chunkSize || 650,
    chunkOverlap: options.chunkOverlap || 120,
    targetCrops: metadata.crops,
    institution: metadata.institution,
    category: metadata.category,
    language: metadata.language,
  });

  addLog('chunking', `Generated ${rawChunks.length} semantic chunks with full page traceability.`, 'success');

  // STEP 6: Dense Embedding Generation (Phase B Multi-Model Support)
  let finalChunks: DocumentChunk[] = [];
  const apiKey = getGeminiApiKey();
  const embeddingModelName = getGeminiEmbeddingModel();
  let usedGemini = false;

  if (apiKey) {
    try {
      addLog('embedding', `Generating semantic embeddings via Google ${embeddingModelName} for ${rawChunks.length} chunks...`, 'info');
      const geminiChunks: DocumentChunk[] = [];
      for (const chunk of rawChunks) {
        const vector = await callGeminiEmbeddings(chunk.content);
        geminiChunks.push({
          ...chunk,
          embeddingVector: vector,
          embeddingModel: embeddingModelName,
          embeddingVersion: '1.0',
          embeddingDimensions: vector.length,
        });
      }
      finalChunks = geminiChunks;
      usedGemini = true;
      addLog('embedding', `Successfully generated ${finalChunks[0]?.embeddingDimensions || 768}-D embeddings using ${embeddingModelName}.`, 'success');
    } catch (embedErr: any) {
      addLog('embedding', `Gemini embedding API deferred (${embedErr?.message || 'offline'}). Falling back to resilient multilingual 128-D hash embeddings.`, 'warning');
    }
  }

  if (!usedGemini) {
    addLog('embedding', `Generating multilingual 128-dimensional dense vector embeddings for ${rawChunks.length} chunks...`, 'info');
    finalChunks = rawChunks.map((chunk) => {
      const vector = generateEmbeddingVector(chunk.content);
      return {
        ...chunk,
        embeddingVector: vector,
        embeddingModel: 'multilingual-dense-hash-128',
        embeddingVersion: '1.0',
        embeddingDimensions: 128,
      };
    });
    addLog('embedding', 'Vector generation complete. L2 norm normalized to 1.0 for cosine similarity matching.', 'success');
  }

  // STEP 7: Storage & Document Model Creation
  const initialVerification: VerificationStatus = hasBannedConflicts
    ? 'flagged_conflicting'
    : 'pending_review';

  const newDoc: IngestedDocument = {
    id: docId,
    title: metadata.title,
    description: metadata.description,
    institution: metadata.institution,
    category: metadata.category,
    crops: metadata.crops,
    topics: metadata.topics,
    language: metadata.language,
    publicationDate: metadata.publicationDate || new Date().toISOString().split('T')[0],
    fileName: file.name,
    fileSizeBytes: file.size,
    fileHash,
    status: 'indexed',
    verificationStatus: initialVerification,
    verificationNotes: hasBannedConflicts ? conflictNotesList.join(' | ') : 'Awaiting agronomist review.',
    totalPages: extractionResult.totalPages,
    totalChunks: finalChunks.length,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  // Attempt Supabase persistence if online
  if (isSupabaseConfigured && supabase) {
    try {
      addLog('storage', 'Persisting document and chunks to Supabase PostgreSQL...', 'info');
      await supabase.from('ingested_documents').insert({
        id: newDoc.id,
        title: newDoc.title,
        description: newDoc.description,
        institution: newDoc.institution,
        category: newDoc.category,
        crops: newDoc.crops,
        topics: newDoc.topics,
        language: newDoc.language,
        publication_date: newDoc.publicationDate,
        file_name: newDoc.fileName,
        file_size_bytes: newDoc.fileSizeBytes,
        file_hash: newDoc.fileHash,
        status: newDoc.status,
        verification_status: newDoc.verificationStatus,
        verification_notes: newDoc.verificationNotes,
        total_pages: newDoc.totalPages,
        total_chunks: newDoc.totalChunks,
      });

      const chunkRows = finalChunks.map((c) => ({
        id: c.id,
        document_id: c.documentId,
        chunk_index: c.chunkIndex,
        page_number: c.pageNumber,
        crop: c.crop,
        topic: c.topic,
        region: c.region,
        language: c.language,
        source_institution: c.sourceInstitution,
        content: c.content,
        token_count: c.tokenCount,
        embedding_vector: c.embeddingVector,
        embedding_model: c.embeddingModel,
        embedding_version: c.embeddingVersion,
        embedding_dimensions: c.embeddingDimensions,
      }));

      await supabase.from('document_chunks').insert(chunkRows);
      addLog('storage', 'Supabase database tables successfully synchronized.', 'success');
    } catch {
      addLog('storage', 'Remote database sync deferred. Caching in local resilient repository.', 'warning');
    }
  }

  // Update local storage
  const currentDocs = getLocalDocuments();
  saveLocalDocuments([newDoc, ...currentDocs]);

  const currentChunks = getLocalChunks();
  saveLocalChunks([...finalChunks, ...currentChunks]);

  addLog('storage', `Document "${newDoc.title}" successfully ingested and indexed!`, 'success');

  return {
    document: newDoc,
    chunks: finalChunks,
  };
}

/**
 * Real Hybrid Vector + Keyword Search across indexed chunks
 */
export async function searchKnowledgeChunks(
  query: string,
  filters?: {
    crop?: string;
    institution?: string;
    language?: string;
  }
): Promise<DocumentChunk[]> {
  const trimmed = query.trim();
  const allChunks = isSupabaseConfigured && supabase ? await fetchAllChunksFromDb() : getLocalChunks();

  // If no query, return filtered set
  if (!trimmed) {
    return allChunks.slice(0, 10);
  }

  const localQueryVector = generateEmbeddingVector(trimmed);
  const localQueryMeta: EmbeddingMetadata = {
    embeddingModel: 'multilingual-dense-hash-128',
    embeddingVersion: '1.0',
    embeddingDimensions: 128,
  };

  const queryEmbeddings: { vector: number[]; metadata: EmbeddingMetadata }[] = [
    { vector: localQueryVector, metadata: localQueryMeta },
  ];

  const apiKey = getGeminiApiKey();
  const geminiModel = getGeminiEmbeddingModel();
  if (apiKey) {
    try {
      const geminiVec = await callGeminiEmbeddings(trimmed);
      if (Array.isArray(geminiVec) && geminiVec.length > 0) {
        queryEmbeddings.push({
          vector: geminiVec,
          metadata: {
            embeddingModel: geminiModel,
            embeddingVersion: '1.0',
            embeddingDimensions: geminiVec.length,
          },
        });
      }
    } catch {
      // Graceful fallback to local query vector
    }
  }

  const lowerQuery = trimmed.toLowerCase();

  const scored = allChunks
    .filter((c) => {
      if (filters?.crop && filters.crop !== 'all' && c.crop !== filters.crop) return false;
      if (filters?.institution && filters.institution !== 'all' && c.sourceInstitution !== filters.institution)
        return false;
      if (filters?.language && filters.language !== 'all' && c.language !== filters.language) return false;
      return true;
    })
    .map((chunk) => {
      // Calculate gated semantic vector similarity across compatible spaces ONLY
      let vectorScore = 0;
      if (Array.isArray(chunk.embeddingVector) && chunk.embeddingVector.length > 0) {
        const chunkMeta: EmbeddingMetadata = {
          embeddingModel:
            chunk.embeddingModel ||
            (chunk.embeddingVector.length === 128 ? 'multilingual-dense-hash-128' : 'unknown'),
          embeddingVersion: chunk.embeddingVersion || '1.0',
          embeddingDimensions: chunk.embeddingDimensions || chunk.embeddingVector.length,
        };

        for (const qEmb of queryEmbeddings) {
          const compat = isEmbeddingCompatible(qEmb.metadata, chunkMeta);
          if (compat.compatible) {
            const sim = cosineSimilarity(qEmb.vector, chunk.embeddingVector);
            if (sim > vectorScore) {
              vectorScore = sim;
            }
          }
        }
      }

      // Keyword token overlap bonus
      const contentLower = chunk.content.toLowerCase();
      const keywordHit = contentLower.includes(lowerQuery) ? 0.35 : 0;

      const finalScore = Math.max(0, vectorScore * 0.65 + keywordHit);

      return {
        ...chunk,
        similarityScore: parseFloat(finalScore.toFixed(4)),
      };
    })
    .filter((c) => (c.similarityScore || 0) > 0.05)
    .sort((a, b) => (b.similarityScore || 0) - (a.similarityScore || 0));

  return scored.slice(0, 12);
}

async function fetchAllChunksFromDb(): Promise<DocumentChunk[]> {
  if (!isSupabaseConfigured || !supabase) return getLocalChunks();
  try {
    const queryPromise = supabase.from('document_chunks').select('*').limit(300);
    const timeoutPromise = new Promise<{ data: any[] | null; error: any }>((resolve) =>
      setTimeout(() => resolve({ data: null, error: new Error('Supabase chunks timeout') }), 2500)
    );
    const { data, error } = await Promise.race([queryPromise, timeoutPromise]);
    if (error || !data) return getLocalChunks();
    return data.map((c) => ({
      id: c.id,
      documentId: c.document_id,
      documentTitle: '',
      chunkIndex: c.chunk_index,
      pageNumber: c.page_number,
      crop: c.crop,
      topic: c.topic,
      region: c.region,
      language: c.language,
      sourceInstitution: c.source_institution,
      content: c.content,
      tokenCount: c.token_count,
      embeddingVector: c.embedding_vector || [],
      embeddingModel:
        c.embedding_model ||
        (isVerifiedStarterChunk(c) ? 'multilingual-dense-hash-128' : undefined),
      embeddingVersion:
        c.embedding_version ||
        (isVerifiedStarterChunk(c) ? '1.0' : undefined),
      embeddingDimensions:
        c.embedding_dimensions ||
        (isVerifiedStarterChunk(c)
          ? 128
          : Array.isArray(c.embedding_vector) && c.embedding_vector.length > 0
          ? c.embedding_vector.length
          : undefined),
      createdAt: c.created_at,
    }));
  } catch {
    return getLocalChunks();
  }
}

/**
 * Admin Workflow: Verify or Flag a document
 */
export async function verifyDocument(
  documentId: string,
  verificationStatus: VerificationStatus,
  notes: string,
  verifiedBy: string
): Promise<boolean> {
  const now = new Date().toISOString();

  if (isSupabaseConfigured && supabase) {
    try {
      await supabase
        .from('ingested_documents')
        .update({
          verification_status: verificationStatus,
          verification_notes: notes,
          verified_by: verifiedBy,
          verified_at: now,
        })
        .eq('id', documentId);
    } catch {
      // fallback
    }
  }

  // Update local storage
  const docs = getLocalDocuments();
  const updated = docs.map((d) =>
    d.id === documentId
      ? {
          ...d,
          verificationStatus,
          verificationNotes: notes,
          verifiedBy,
          verifiedAt: now,
          updatedAt: now,
        }
      : d
  );
  saveLocalDocuments(updated);
  return true;
}

/**
 * Delete a document and its cascading chunks
 */
export async function deleteIngestedDocument(documentId: string): Promise<boolean> {
  if (isSupabaseConfigured && supabase) {
    try {
      await supabase.from('ingested_documents').delete().eq('id', documentId);
    } catch {
      // fallback
    }
  }

  const docs = getLocalDocuments().filter((d) => d.id !== documentId);
  saveLocalDocuments(docs);

  const chunks = getLocalChunks().filter((c) => c.documentId !== documentId);
  saveLocalChunks(chunks);

  return true;
}

/**
 * Get aggregate ingestion statistics
 */
export async function getIngestionStats(): Promise<IngestionStats> {
  const docs = await fetchIngestedDocuments();
  const chunks = isSupabaseConfigured && supabase ? await fetchAllChunksFromDb() : getLocalChunks();

  const cropDistribution: Record<string, number> = {};
  (docs || []).forEach((d) => {
    (d.crops || []).forEach((crop) => {
      if (crop) {
        cropDistribution[crop] = (cropDistribution[crop] || 0) + 1;
      }
    });
  });

  const modelDistribution: Record<string, number> = {};
  chunks.forEach((c) => {
    const model =
      c.embeddingModel ||
      (c.embeddingVector?.length === 128 ? 'multilingual-dense-hash-128' : 'unknown');
    modelDistribution[model] = (modelDistribution[model] || 0) + 1;
  });

  return {
    totalDocuments: docs.length,
    totalChunks: chunks.length,
    verifiedDocuments: docs.filter((d) => d.verificationStatus === 'verified').length,
    pendingReviewDocuments: docs.filter(
      (d) => d.verificationStatus === 'pending_review' || d.verificationStatus === 'unverified'
    ).length,
    flaggedDocuments: docs.filter((d) => d.verificationStatus === 'flagged_conflicting').length,
    cropDistribution,
    modelDistribution,
    totalStorageBytes: docs.reduce((acc, d) => acc + (Number(d.fileSizeBytes) || 0), 0),
  };
}

export interface ReembedResult {
  success: boolean;
  totalChunks: number;
  newlyEmbedded: number;
  skipped: number;
  model: string;
  dimensions: number;
  errors: string[];
}

/**
 * Re-embeds document chunks using the active Gemini embedding model (e.g. gemini-embedding-2).
 * Non-destructive: keeps existing vectors intact if the API is offline or an error occurs.
 */
export async function reembedDocumentChunks(
  options: {
    targetDocumentId?: string;
    forceReembed?: boolean;
  } = {}
): Promise<ReembedResult> {
  const apiKey = getGeminiApiKey();
  const targetModel = getGeminiEmbeddingModel();
  if (!apiKey) {
    return {
      success: false,
      totalChunks: 0,
      newlyEmbedded: 0,
      skipped: 0,
      model: targetModel,
      dimensions: 0,
      errors: ['GEMINI_KEY_NOT_CONFIGURED: Set GEMINI_API_KEY in environment variables to re-embed.'],
    };
  }

  const allChunks = isSupabaseConfigured && supabase ? await fetchAllChunksFromDb() : getLocalChunks();
  const targetChunks = options.targetDocumentId
    ? allChunks.filter((c) => c.documentId === options.targetDocumentId)
    : allChunks;

  let newlyEmbedded = 0;
  let skipped = 0;
  const errors: string[] = [];
  const updatedChunks: DocumentChunk[] = [];
  let dimensions = 0;

  for (const chunk of targetChunks) {
    if (
      !options.forceReembed &&
      chunk.embeddingModel === targetModel &&
      Array.isArray(chunk.embeddingVector) &&
      chunk.embeddingVector.length > 128
    ) {
      skipped++;
      updatedChunks.push(chunk);
      continue;
    }

    try {
      const vector = await callGeminiEmbeddings(chunk.content);
      dimensions = vector.length;
      const updatedChunk: DocumentChunk = {
        ...chunk,
        embeddingVector: vector,
        embeddingModel: targetModel,
        embeddingVersion: '1.0',
        embeddingDimensions: vector.length,
      };
      updatedChunks.push(updatedChunk);
      newlyEmbedded++;

      if (isSupabaseConfigured && supabase) {
        await supabase
          .from('document_chunks')
          .update({
            embedding_vector: vector,
            embedding_model: targetModel,
            embedding_version: '1.0',
            embedding_dimensions: vector.length,
          })
          .eq('id', chunk.id);
      }
    } catch (err: any) {
      errors.push(`Failed to embed chunk ${chunk.id}: ${err?.message || 'API error'}`);
      updatedChunks.push(chunk);
    }
  }

  const currentLocal = getLocalChunks();
  const updatedMap = new Map(updatedChunks.map((c) => [c.id, c]));
  saveLocalChunks(currentLocal.map((c) => updatedMap.get(c.id) || c));

  return {
    success: errors.length === 0,
    totalChunks: targetChunks.length,
    newlyEmbedded,
    skipped,
    model: targetModel,
    dimensions,
    errors,
  };
}

/**
 * Reversibly rolls back chunk embeddings to the local unit-normalized 128-D hash space.
 */
export async function rollbackEmbeddingsToLocalHash(
  options: { targetDocumentId?: string } = {}
): Promise<{ success: boolean; revertedChunks: number }> {
  const currentChunks = isSupabaseConfigured && supabase ? await fetchAllChunksFromDb() : getLocalChunks();
  const targetChunks = options.targetDocumentId
    ? currentChunks.filter((c) => c.documentId === options.targetDocumentId)
    : currentChunks;

  let reverted = 0;
  const updatedChunks: DocumentChunk[] = [];

  for (const chunk of targetChunks) {
    if (chunk.embeddingModel !== 'multilingual-dense-hash-128') {
      const vector = generateEmbeddingVector(chunk.content);
      const revertedChunk: DocumentChunk = {
        ...chunk,
        embeddingVector: vector,
        embeddingModel: 'multilingual-dense-hash-128',
        embeddingVersion: '1.0',
        embeddingDimensions: 128,
      };
      updatedChunks.push(revertedChunk);
      reverted++;

      if (isSupabaseConfigured && supabase) {
        await supabase
          .from('document_chunks')
          .update({
            embedding_vector: vector,
            embedding_model: 'multilingual-dense-hash-128',
            embedding_version: '1.0',
            embedding_dimensions: 128,
          })
          .eq('id', chunk.id);
      }
    } else {
      updatedChunks.push(chunk);
    }
  }

  const currentLocal = getLocalChunks();
  const updatedMap = new Map(updatedChunks.map((c) => [c.id, c]));
  saveLocalChunks(currentLocal.map((c) => updatedMap.get(c.id) || c));

  return { success: true, revertedChunks: reverted };
}
