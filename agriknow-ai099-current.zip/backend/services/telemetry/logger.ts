/**
 * AGRIKNOW AI - Production Structured Telemetry & Logger
 * Features log levels, ISO timestamps, context tags, and automatic PII masking.
 * Never logs raw passwords, tokens, API keys, or unmasked mobile numbers.
 */

import { maskPii } from '../../utils/security.ts';

export type LogLevel = 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';

export interface LogEntry {
  timestamp: string;
  level: LogLevel;
  context: string;
  message: string;
  metadata?: Record<string, unknown>;
}

// In-memory ring buffer for client-side telemetry inspection & error reporting
const LOG_BUFFER_SIZE = 150;
const logBuffer: LogEntry[] = [];

/**
 * Sanitizes metadata objects by redacting sensitive keys and masking PII.
 */
function sanitizeMetadata(data?: Record<string, unknown>): Record<string, unknown> | undefined {
  if (!data) return undefined;

  const sensitiveKeys = ['password', 'token', 'secret', 'key', 'apikey', 'anonkey', 'authorization', 'bearer'];
  const sanitized: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(data)) {
    const lowerKey = key.toLowerCase();
    if (sensitiveKeys.some((s) => lowerKey.includes(s))) {
      sanitized[key] = '[REDACTED]';
    } else if (typeof value === 'string') {
      sanitized[key] = maskPii(value);
    } else if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
      sanitized[key] = sanitizeMetadata(value as Record<string, unknown>);
    } else {
      sanitized[key] = value;
    }
  }

  return sanitized;
}

function normalizeMetadata(data?: unknown): Record<string, unknown> | undefined {
  if (!data) return undefined;
  if (data instanceof Error) {
    return { name: data.name, message: data.message, stack: data.stack };
  }
  if (typeof data === 'object' && !Array.isArray(data)) {
    return sanitizeMetadata(data as Record<string, unknown>);
  }
  return { details: String(data) };
}

function writeLog(level: LogLevel, context: string, message: string, metadata?: unknown) {
  const safeMessage = maskPii(message);
  const safeMetadata = normalizeMetadata(metadata);

  const entry: LogEntry = {
    timestamp: new Date().toISOString(),
    level,
    context,
    message: safeMessage,
    metadata: safeMetadata,
  };

  // Keep in circular buffer
  logBuffer.push(entry);
  if (logBuffer.length > LOG_BUFFER_SIZE) {
    logBuffer.shift();
  }

  const formattedMsg = `[${entry.timestamp}] [${level}] [${context}] ${safeMessage}`;

  switch (level) {
    case 'DEBUG':
      if (typeof import.meta !== 'undefined' && import.meta.env?.DEV) {
        console.debug(formattedMsg, safeMetadata || '');
      }
      break;
    case 'INFO':
      console.info(formattedMsg, safeMetadata || '');
      break;
    case 'WARN':
      console.warn(formattedMsg, safeMetadata || '');
      break;
    case 'ERROR':
      console.error(formattedMsg, safeMetadata || '');
      break;
  }
}

export const logger = {
  debug: (context: string, message: string, metadata?: unknown) =>
    writeLog('DEBUG', context, message, metadata),
  info: (context: string, message: string, metadata?: unknown) =>
    writeLog('INFO', context, message, metadata),
  warn: (context: string, message: string, metadata?: unknown) =>
    writeLog('WARN', context, message, metadata),
  error: (context: string, message: string, metadata?: unknown) =>
    writeLog('ERROR', context, message, metadata),

  /**
   * Returns recent log entries (for error reporting and diagnostics).
   */
  getRecentLogs: (): LogEntry[] => [...logBuffer],

  /**
   * Clears in-memory log buffer.
   */
  clearLogs: () => {
    logBuffer.length = 0;
  },
};
