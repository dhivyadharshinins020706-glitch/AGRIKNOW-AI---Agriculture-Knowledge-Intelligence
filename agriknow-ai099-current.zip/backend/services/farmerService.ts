import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { FarmerProfile } from '@/types';

export async function fetchFarmerProfileFromDb(userId: string): Promise<FarmerProfile | null> {
  if (!isSupabaseConfigured || !supabase) return null;

  try {
    const { data, error } = await supabase
      .from('farmer_profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (error || !data) return null;

    return {
      name: data.full_name || 'Farmer',
      village: data.village || '',
      district: data.district || 'Thanjavur',
      state: data.state || 'Tamil Nadu',
      phone: data.phone || '',
      acres: Number(data.acres) || 2.5,
      soilType: data.soil_type || 'Alluvial Clay',
      irrigationSource: data.irrigation_source || 'Canal',
      cropIds: Array.isArray(data.crop_ids) ? data.crop_ids : ['paddy', 'groundnut'],
    };
  } catch (err) {
    console.warn('Could not fetch cloud farmer profile:', err);
    return null;
  }
}

export async function syncFarmerProfileToDb(
  userId: string,
  profile: Partial<FarmerProfile>
): Promise<{ success: boolean; error: string | null }> {
  if (!isSupabaseConfigured || !supabase) {
    return { success: false, error: 'Supabase not configured' };
  }

  try {
    const payload: Record<string, unknown> = {
      id: userId,
      updated_at: new Date().toISOString(),
    };

    if (profile.name !== undefined) payload.full_name = profile.name;
    if (profile.village !== undefined) payload.village = profile.village;
    if (profile.district !== undefined) payload.district = profile.district;
    if (profile.state !== undefined) payload.state = profile.state;
    if (profile.phone !== undefined) payload.phone = profile.phone;
    if (profile.acres !== undefined) payload.acres = profile.acres;
    if (profile.soilType !== undefined) payload.soil_type = profile.soilType;
    if (profile.irrigationSource !== undefined) payload.irrigation_source = profile.irrigationSource;
    if (profile.cropIds !== undefined) payload.crop_ids = profile.cropIds;

    const { error } = await supabase.from('farmer_profiles').upsert(payload);

    if (error) {
      return { success: false, error: error.message };
    }

    return { success: true, error: null };
  } catch (err: unknown) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Database sync error',
    };
  }
}
