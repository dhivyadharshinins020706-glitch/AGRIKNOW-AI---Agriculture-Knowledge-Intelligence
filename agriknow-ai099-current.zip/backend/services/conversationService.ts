import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { ChatMessage } from '@/types';

export interface DbConversation {
  id: string;
  user_id: string;
  title: string;
  language: string;
  created_at: string;
}

export async function fetchUserConversations(userId: string): Promise<DbConversation[]> {
  if (!isSupabaseConfigured || !supabase) return [];

  try {
    const { data, error } = await supabase
      .from('conversations')
      .select('*')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false });

    if (error || !data) return [];
    return data;
  } catch {
    return [];
  }
}

export async function fetchConversationMessages(conversationId: string): Promise<ChatMessage[]> {
  if (!isSupabaseConfigured || !supabase) return [];

  try {
    const { data, error } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true });

    if (error || !data) return [];

    return data.map((row) => ({
      id: row.id,
      role: row.role as 'user' | 'assistant',
      text: row.content,
      sourceIds: Array.isArray(row.source_ids) ? row.source_ids : [],
      isLiveBackend: row.is_live_backend,
      provider: row.provider,
      timestamp: new Date(row.created_at).getTime(),
    }));
  } catch {
    return [];
  }
}

export async function createConversation(
  userId: string,
  title: string,
  language = 'ta'
): Promise<string | null> {
  if (!isSupabaseConfigured || !supabase) return null;

  try {
    const { data, error } = await supabase
      .from('conversations')
      .insert({
        user_id: userId,
        title,
        language,
      })
      .select('id')
      .single();

    if (error || !data) return null;
    return data.id;
  } catch {
    return null;
  }
}

export async function persistChatMessage(
  conversationId: string,
  userId: string,
  message: ChatMessage
): Promise<boolean> {
  if (!isSupabaseConfigured || !supabase) return false;

  try {
    const { error } = await supabase.from('chat_messages').insert({
      conversation_id: conversationId,
      user_id: userId,
      role: message.role,
      content: message.text,
      source_ids: message.sourceIds || [],
      provider: message.provider || 'Verified Agricultural Corpus',
      is_live_backend: message.isLiveBackend || false,
    });

    if (error) return false;

    // Bump updated_at of conversation
    await supabase
      .from('conversations')
      .update({ updated_at: new Date().toISOString() })
      .eq('id', conversationId);

    return true;
  } catch {
    return false;
  }
}

export async function deleteConversation(conversationId: string): Promise<boolean> {
  if (!isSupabaseConfigured || !supabase) return false;

  try {
    const { error } = await supabase
      .from('conversations')
      .delete()
      .eq('id', conversationId);

    return !error;
  } catch {
    return false;
  }
}
