/**
 * AGRIKNOW AI - Personalized Farmer Assistance Service (Phase 9)
 * Strict Privacy & User Consent Control:
 * Enables storage of regional and farm context (crop, season, soil) ONLY with
 * explicit farmer consent. Provides transparent review and instant right-to-erasure.
 */

export interface FarmerPersonalizationContext {
  consentGranted: boolean;
  consentTimestamp?: string;
  region?: string;
  district?: string;
  primaryCrop?: string;
  currentCropStage?: 'land_preparation' | 'sowing' | 'vegetative' | 'tillering' | 'flowering' | 'grain_filling' | 'harvesting';
  soilType?: string;
  waterSource?: 'borewell' | 'canal' | 'well' | 'rainfed';
  landAreaAcres?: number;
  lastUpdated?: string;
}

const PERSONALIZATION_STORAGE_KEY = 'agriknow_farmer_personalization_v1';

const DEFAULT_CONTEXT: FarmerPersonalizationContext = {
  consentGranted: false,
};

/**
 * Checks if user has explicitly granted consent for personalized context
 */
export function hasPersonalizationConsent(): boolean {
  try {
    if (typeof localStorage === 'undefined') return false;
    const raw = localStorage.getItem(PERSONALIZATION_STORAGE_KEY);
    if (!raw) return false;
    const parsed: FarmerPersonalizationContext = JSON.parse(raw);
    return parsed.consentGranted === true;
  } catch {
    return false;
  }
}

/**
 * Updates user consent status. If revoked, immediately purges all saved context.
 */
export function setPersonalizationConsent(consentGranted: boolean): void {
  try {
    if (typeof localStorage === 'undefined') return;
    if (!consentGranted) {
      // Immediate right to erasure upon consent revocation
      purgePersonalizationContext();
      return;
    }
    const current = getPersonalizationContext();
    const updated: FarmerPersonalizationContext = {
      ...current,
      consentGranted: true,
      consentTimestamp: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
    };
    localStorage.setItem(PERSONALIZATION_STORAGE_KEY, JSON.stringify(updated));
  } catch {
    // Non-blocking
  }
}

/**
 * Retrieves the current personalization context if consent is active.
 */
export function getPersonalizationContext(): FarmerPersonalizationContext {
  try {
    if (typeof localStorage === 'undefined') return { ...DEFAULT_CONTEXT };
    const raw = localStorage.getItem(PERSONALIZATION_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_CONTEXT };
    const parsed: FarmerPersonalizationContext = JSON.parse(raw);
    return parsed;
  } catch {
    return { ...DEFAULT_CONTEXT };
  }
}

/**
 * Updates context fields only if user has granted consent.
 */
export function updatePersonalizationContext(
  updates: Partial<Omit<FarmerPersonalizationContext, 'consentGranted' | 'consentTimestamp'>>
): boolean {
  try {
    if (typeof localStorage === 'undefined') return false;
    const current = getPersonalizationContext();
    if (!current.consentGranted) {
      return false; // Refuse write without consent
    }

    const updated: FarmerPersonalizationContext = {
      ...current,
      ...updates,
      lastUpdated: new Date().toISOString(),
    };

    localStorage.setItem(PERSONALIZATION_STORAGE_KEY, JSON.stringify(updated));
    return true;
  } catch {
    return false;
  }
}

/**
 * Completely erases all stored personalization context and resets consent.
 */
export function purgePersonalizationContext(): void {
  try {
    if (typeof localStorage === 'undefined') return;
    localStorage.removeItem(PERSONALIZATION_STORAGE_KEY);
  } catch {
    // Non-blocking
  }
}

/**
 * Generates contextual agronomic context for the RAG engine or Assistant
 * if and only if consent is active.
 */
export function buildPersonalizedContextPrompt(lang: 'ta' | 'en' = 'en'): string | null {
  const ctx = getPersonalizationContext();
  if (!ctx.consentGranted) {
    return null;
  }

  const parts: string[] = [];
  if (lang === 'ta') {
    if (ctx.district) parts.push(`மாவட்டம்: ${ctx.district}`);
    if (ctx.primaryCrop) parts.push(`பயிர்: ${ctx.primaryCrop}`);
    if (ctx.currentCropStage) parts.push(`பயிர் வளர்ச்சி நிலை: ${ctx.currentCropStage}`);
    if (ctx.soilType) parts.push(`மண் வகை: ${ctx.soilType}`);
    if (ctx.waterSource) parts.push(`பாசன வசதி: ${ctx.waterSource}`);
    if (ctx.landAreaAcres) parts.push(`பரப்பளவு: ${ctx.landAreaAcres} ஏக்கர்`);

    return parts.length > 0 ? `[விவசாயியின் பண்ணை சூழல் (ஒப்புதலுடன்): ${parts.join(', ')}]` : null;
  } else {
    if (ctx.district) parts.push(`District: ${ctx.district}`);
    if (ctx.primaryCrop) parts.push(`Crop: ${ctx.primaryCrop}`);
    if (ctx.currentCropStage) parts.push(`Growth Stage: ${ctx.currentCropStage}`);
    if (ctx.soilType) parts.push(`Soil: ${ctx.soilType}`);
    if (ctx.waterSource) parts.push(`Irrigation: ${ctx.waterSource}`);
    if (ctx.landAreaAcres) parts.push(`Area: ${ctx.landAreaAcres} acres`);

    return parts.length > 0 ? `[Farmer Farm Context (With Explicit Consent): ${parts.join(', ')}]` : null;
  }
}
