import { apiConfig } from './apiConfig';
import type { MarketPriceItem } from '@/types';

export const benchmarkMandiPrices: MarketPriceItem[] = [
  {
    crop: 'Paddy (Samba / CR1009)',
    cropTa: 'நெல் (சம்பா / சி.ஆர் 1009)',
    mandi: 'Thanjavur APMC',
    price: 2320,
    change: 2.1,
    unit: 'Quintal',
    updatedAt: 'Today, 10:30 AM',
  },
  {
    crop: 'Groundnut Pods',
    cropTa: 'நிலக்கடலை காய்',
    mandi: 'Tiruvannamalai Market',
    price: 6150,
    change: -0.8,
    unit: 'Quintal',
    updatedAt: 'Today, 09:45 AM',
  },
  {
    crop: 'Finger Millet (Ragi)',
    cropTa: 'கேழ்வரகு (ராகி)',
    mandi: 'Dharmapuri Regulated Market',
    price: 3950,
    change: 1.4,
    unit: 'Quintal',
    updatedAt: 'Today, 11:00 AM',
  },
  {
    crop: 'Bt Cotton (Kapas)',
    cropTa: 'பருத்தி',
    mandi: 'Theni Cotton Market',
    price: 7200,
    change: 3.2,
    unit: 'Quintal',
    updatedAt: 'Today, 10:15 AM',
  },
  {
    crop: 'Maize (Hybrid)',
    cropTa: 'மக்காச்சோளம்',
    mandi: 'Udumalpet Regulated Market',
    price: 2280,
    change: 0.5,
    unit: 'Quintal',
    updatedAt: 'Today, 08:30 AM',
  },
  {
    crop: 'Black Gram (Urad)',
    cropTa: 'உளுந்து',
    mandi: 'Villupuram Market',
    price: 7550,
    change: -1.2,
    unit: 'Quintal',
    updatedAt: 'Today, 11:15 AM',
  },
];

export async function fetchMandiPrices(): Promise<{ prices: MarketPriceItem[]; isLive: boolean }> {
  if (apiConfig.mandiApiUrl) {
    try {
      const response = await fetch(apiConfig.mandiApiUrl);
      if (response.ok) {
        const livePrices = await response.json();
        return { prices: livePrices, isLive: true };
      }
    } catch {
      // Fall through to benchmark rates
    }
  }

  return { prices: benchmarkMandiPrices, isLive: false };
}
