import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { SoilNutrient, SoilSample } from '@/types';

export async function fetchUserSoilReports(userId: string): Promise<SoilSample[]> {
  if (!isSupabaseConfigured || !supabase) return [];

  try {
    const { data, error } = await supabase
      .from('soil_reports')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error || !data) return [];

    return data.map((row) => {
      const nutrients: SoilNutrient[] = [
        {
          key: 'nitrogen',
          label: 'Nitrogen',
          value: Number(row.nitrogen_val) || 200,
          unit: 'kg/ha',
          low: 280,
          high: 560,
          max: 600,
        },
        {
          key: 'phosphorus',
          label: 'Phosphorus',
          value: Number(row.phosphorus_val) || 15,
          unit: 'kg/ha',
          low: 11,
          high: 22,
          max: 40,
        },
        {
          key: 'potassium',
          label: 'Potassium',
          value: Number(row.potassium_val) || 150,
          unit: 'kg/ha',
          low: 115,
          high: 280,
          max: 400,
        },
        {
          key: 'organicCarbon',
          label: 'Organic carbon',
          value: Number(row.organic_carbon_val) || 0.5,
          unit: '%',
          low: 0.5,
          high: 0.75,
          max: 1,
        },
      ];

      return {
        id: row.id,
        label: row.field_name,
        location: row.location || 'Farm',
        crop: row.planned_crop,
        pH: Number(row.ph),
        nutrients,
        plan: Array.isArray(row.fertilizer_plan) ? row.fertilizer_plan : [],
        isCustom: true,
      };
    });
  } catch (err) {
    console.warn('Could not fetch cloud soil reports:', err);
    return [];
  }
}

export async function saveSoilReportToDb(
  userId: string,
  sample: Omit<SoilSample, 'id'>
): Promise<{ id: string | null; error: string | null }> {
  if (!isSupabaseConfigured || !supabase) {
    return { id: null, error: 'Database not configured' };
  }

  try {
    const n = sample.nutrients.find((x) => x.key === 'nitrogen')?.value || 200;
    const p = sample.nutrients.find((x) => x.key === 'phosphorus')?.value || 15;
    const k = sample.nutrients.find((x) => x.key === 'potassium')?.value || 150;
    const oc = sample.nutrients.find((x) => x.key === 'organicCarbon')?.value || 0.5;

    const { data, error } = await supabase
      .from('soil_reports')
      .insert({
        user_id: userId,
        field_name: sample.label,
        location: sample.location,
        planned_crop: sample.crop,
        ph: sample.pH,
        nitrogen_val: n,
        phosphorus_val: p,
        potassium_val: k,
        organic_carbon_val: oc,
        fertilizer_plan: sample.plan,
      })
      .select('id')
      .single();

    if (error) {
      return { id: null, error: error.message };
    }

    return { id: data.id, error: null };
  } catch (err: unknown) {
    return {
      id: null,
      error: err instanceof Error ? err.message : 'Failed to save soil report',
    };
  }
}
