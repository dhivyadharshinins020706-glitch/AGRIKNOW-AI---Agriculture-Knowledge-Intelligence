/**
 * AGRIKNOW AI - Government Schemes Intelligence Service
 * Provides search, eligibility checking, and bilingual query answering for
 * Indian and Tamil Nadu Government agricultural welfare programs.
 */

import { VERIFIED_GOVERNMENT_SCHEMES, type GovernmentScheme } from '../data/governmentSchemes.ts';

export interface SchemeFilterOptions {
  category?: 'direct_benefit' | 'insurance' | 'subsidy' | 'credit' | 'soil_health' | 'all';
  searchQuery?: string;
  sponsor?: 'Central' | 'State' | 'Shared' | 'all';
}

export function getAllGovernmentSchemes(): GovernmentScheme[] {
  return [...VERIFIED_GOVERNMENT_SCHEMES];
}

export function searchGovernmentSchemes(options: SchemeFilterOptions = {}): GovernmentScheme[] {
  let results = [...VERIFIED_GOVERNMENT_SCHEMES];

  if (options.category && options.category !== 'all') {
    results = results.filter((s) => s.category === options.category);
  }

  if (options.sponsor && options.sponsor !== 'all') {
    results = results.filter((s) => s.sponsor === options.sponsor);
  }

  if (options.searchQuery && options.searchQuery.trim().length > 0) {
    const q = options.searchQuery.toLowerCase().trim();
    results = results.filter((s) => {
      const matchEn =
        s.name.toLowerCase().includes(q) ||
        s.code.toLowerCase().includes(q) ||
        s.financialBenefit.toLowerCase().includes(q) ||
        s.targetAudience.toLowerCase().includes(q);
      const matchTa =
        s.nameTa.toLowerCase().includes(q) ||
        s.financialBenefitTa.toLowerCase().includes(q) ||
        s.targetAudienceTa.toLowerCase().includes(q);
      return matchEn || matchTa;
    });
  }

  return results;
}

export function matchSchemeForQuery(query: string, lang: 'ta' | 'en' = 'en'): {
  found: boolean;
  scheme?: GovernmentScheme;
  summary?: string;
  portalUrl?: string;
} {
  const lower = query.toLowerCase();

  // Keyword mappings
  const scheme = VERIFIED_GOVERNMENT_SCHEMES.find((s) => {
    if (lower.includes('pm kisan') || lower.includes('pm-kisan') || lower.includes('கிசான் சம்மான்') || lower.includes('6000')) {
      return s.code === 'PM-KISAN';
    }
    if (lower.includes('insurance') || lower.includes('fasal bima') || lower.includes('pmfby') || lower.includes('காப்பீடு')) {
      return s.code === 'PMFBY';
    }
    if (lower.includes('drip') || lower.includes('sprinkler') || lower.includes('micro irrigation') || lower.includes('சொட்டு நீர்') || lower.includes('நுண்ணீர் பாசனம்')) {
      return s.code === 'PMKSY-PDMC-TN';
    }
    if (lower.includes('kcc') || lower.includes('kisan credit') || lower.includes('பயிர்க்கடன்') || lower.includes('loan')) {
      return s.code === 'KCC';
    }
    if (lower.includes('soil health card') || lower.includes('மண் அட்டை') || lower.includes('மண் வள அட்டை')) {
      return s.code === 'SHC';
    }
    if (lower.includes('dryland') || lower.includes('cmddm') || lower.includes('மானாவாரி')) {
      return s.code === 'CMDDM-TN';
    }
    return false;
  });

  if (!scheme) {
    return { found: false };
  }

  const summary = lang === 'ta'
    ? `🏛️ **${scheme.nameTa} (${scheme.code})**\n\n💰 **நிதிப் பலன்:** ${scheme.financialBenefitTa}\n\n📋 **தகுதி:**\n${scheme.eligibilityTa.map((e) => `• ${e}`).join('\n')}\n\n📄 **தேவையான ஆவணங்கள்:** ${scheme.documentsRequiredTa.join(', ')}\n\n🌐 **அதிகாரப்பூர்வ தளம்:** [${scheme.officialPortalUrl}](${scheme.officialPortalUrl})\n📞 **உதவி எண்:** ${scheme.helpline}\n📌 **சான்று:** ${scheme.verifiedSource}`
    : `🏛️ **${scheme.name} (${scheme.code})**\n\n💰 **Financial Benefit:** ${scheme.financialBenefit}\n\n📋 **Eligibility:**\n${scheme.eligibility.map((e) => `• ${e}`).join('\n')}\n\n📄 **Documents Required:** ${scheme.documentsRequired.join(', ')}\n\n🌐 **Official Portal:** [${scheme.officialPortalUrl}](${scheme.officialPortalUrl})\n📞 **Helpline:** ${scheme.helpline}\n📌 **Verified Source:** ${scheme.verifiedSource}`;

  return {
    found: true,
    scheme,
    summary,
    portalUrl: scheme.officialPortalUrl,
  };
}
