/**
 * AGRIKNOW AI - Phase 7 Pilot Feedback Service
 * Manages structured qualitative and quantitative feedback from farmers,
 * field officers, and agricultural scientists during field validation.
 */

import { supabase, isSupabaseConfigured } from '../lib/supabase.ts';
import { logger } from './telemetry/logger.ts';

export type ReviewerRole = 'farmer' | 'officer' | 'scientist' | 'extension_worker' | 'general_user';

export type PilotModule = 'assistant' | 'crop_disease' | 'soil_fertilizer' | 'crop_selection' | 'library';

export interface PilotFeedbackEntry {
  id: string;
  userId?: string;
  reviewerRole: ReviewerRole;
  module: PilotModule;
  queryText: string;
  answerSnippet: string;
  isHelpful: boolean;
  rating?: number; // 1 to 5
  accuracyFlags: string[]; // e.g. 'inaccurate_dosage', 'wrong_disease', 'unnatural_tamil', 'missing_disclaimer'
  tamilQualityRating?: number; // 1 to 5
  comments?: string;
  consentGranted: boolean;
  createdAt: string;
}

const LOCAL_FEEDBACK_KEY = 'agriknow_pilot_feedback_v1';
const inMemoryFeedbackBuffer: PilotFeedbackEntry[] = [];

export function getLocalPilotFeedback(): PilotFeedbackEntry[] {
  if (typeof localStorage === 'undefined') {
    return [...inMemoryFeedbackBuffer];
  }
  try {
    const raw = localStorage.getItem(LOCAL_FEEDBACK_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    logger.warn('PilotFeedback', 'Failed to read local feedback', { error: String(err) });
    return [...inMemoryFeedbackBuffer];
  }
}

export function saveLocalPilotFeedback(entry: PilotFeedbackEntry): void {
  if (typeof localStorage === 'undefined') {
    inMemoryFeedbackBuffer.unshift(entry);
    return;
  }
  try {
    const list = getLocalPilotFeedback();
    list.unshift(entry);
    localStorage.setItem(LOCAL_FEEDBACK_KEY, JSON.stringify(list.slice(0, 500)));
  } catch (err) {
    logger.warn('PilotFeedback', 'Failed to store local feedback', { error: String(err) });
    inMemoryFeedbackBuffer.unshift(entry);
  }
}

export async function submitPilotFeedback(
  feedback: Omit<PilotFeedbackEntry, 'id' | 'createdAt'>
): Promise<{ success: boolean; id: string; error?: string }> {
  if (!feedback.consentGranted) {
    return { success: false, id: '', error: 'Consent is required before submitting feedback.' };
  }

  const id = `pilot-fb-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const entry: PilotFeedbackEntry = {
    ...feedback,
    id,
    createdAt: new Date().toISOString(),
  };

  // Always store in local storage for offline resilience
  saveLocalPilotFeedback(entry);

  if (isSupabaseConfigured && supabase) {
    try {
      const { error } = await supabase.from('pilot_feedback').insert({
        id: entry.id,
        user_id: entry.userId || null,
        reviewer_role: entry.reviewerRole,
        module: entry.module,
        query_text: entry.queryText,
        answer_snippet: entry.answerSnippet.slice(0, 500),
        is_helpful: entry.isHelpful,
        rating: entry.rating || null,
        accuracy_flags: entry.accuracyFlags,
        tamil_quality_rating: entry.tamilQualityRating || null,
        comments: entry.comments || null,
        consent_granted: entry.consentGranted,
      });

      if (error) {
        logger.warn('PilotFeedback', 'Remote feedback insertion failed, saved locally', { error: error.message });
      }
    } catch (err) {
      logger.warn('PilotFeedback', 'Exception syncing feedback to Supabase', { error: String(err) });
    }
  }

  logger.info('PilotFeedback', `Feedback submitted by ${entry.reviewerRole} for ${entry.module}`, {
    helpful: entry.isHelpful,
    rating: entry.rating,
  });

  return { success: true, id };
}

export async function fetchAllPilotFeedback(): Promise<PilotFeedbackEntry[]> {
  const localList = getLocalPilotFeedback();

  if (isSupabaseConfigured && supabase) {
    try {
      const { data, error } = await supabase
        .from('pilot_feedback')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (!error && data && data.length > 0) {
        // Merge and deduplicate by ID
        const map = new Map<string, PilotFeedbackEntry>();
        for (const item of localList) map.set(item.id, item);
        for (const row of data) {
          map.set(row.id, {
            id: row.id,
            userId: row.user_id,
            reviewerRole: row.reviewer_role,
            module: row.module,
            queryText: row.query_text,
            answerSnippet: row.answer_snippet,
            isHelpful: row.is_helpful,
            rating: row.rating,
            accuracyFlags: row.accuracy_flags || [],
            tamilQualityRating: row.tamil_quality_rating,
            comments: row.comments,
            consentGranted: row.consent_granted,
            createdAt: row.created_at,
          });
        }
        return Array.from(map.values()).sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
      }
    } catch {
      // Fallback to local on network or auth issue
    }
  }

  return localList;
}
