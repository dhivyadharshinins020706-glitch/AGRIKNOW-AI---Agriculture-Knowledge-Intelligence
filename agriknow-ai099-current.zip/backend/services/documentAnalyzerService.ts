import { extractPdfText } from '../utils/pdfExtractor.ts';
import type { AnalyzedDocument, AgriDocumentCategory, DocumentKeyFinding } from '../types/index.ts';
import { apiConfig } from './apiConfig.ts';
import { logger } from './telemetry/logger.ts';

export interface StoredUserDocument extends AnalyzedDocument {
  userId?: string;
  uploadedAt: string;
  fileSizeBytes: number;
  originalFileName: string;
  processingStatus: 'ready' | 'processing' | 'error';
  errorMessage?: string;
  pageCount?: number;
}

const LOCAL_USER_DOCS_KEY_PREFIX = 'agriknow_user_docs_v3_';

// In-memory active analyzed document state for current session
let currentActiveDocument: StoredUserDocument | null = null;

export function getActiveAnalyzedDocument(): StoredUserDocument | null {
  return currentActiveDocument;
}

export function setActiveAnalyzedDocument(doc: StoredUserDocument | null): void {
  currentActiveDocument = doc;
}

function getUserStorageKey(userId?: string): string {
  return `${LOCAL_USER_DOCS_KEY_PREFIX}${userId || 'local_farmer'}`;
}

/**
 * Fetch all documents uploaded by the authenticated user
 */
export async function fetchUserUploadedDocuments(userId?: string): Promise<StoredUserDocument[]> {
  try {
    const raw = localStorage.getItem(getUserStorageKey(userId));
    if (!raw) return [];
    const parsed: StoredUserDocument[] = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

/**
 * Persist an analyzed document into the user's private collection
 */
export async function saveUserUploadedDocument(
  doc: StoredUserDocument,
  userId?: string
): Promise<void> {
  try {
    const key = getUserStorageKey(userId);
    const existing = await fetchUserUploadedDocuments(userId);
    const filtered = existing.filter((d) => d.id !== doc.id);
    filtered.unshift(doc);
    localStorage.setItem(key, JSON.stringify(filtered));
  } catch (err) {
    logger.error('DocumentAnalyzer', 'Failed to save user document to localStorage', err);
  }
}

/**
 * Delete a document from user's collection
 */
export async function deleteUserUploadedDocument(docId: string, userId?: string): Promise<void> {
  try {
    const key = getUserStorageKey(userId);
    const existing = await fetchUserUploadedDocuments(userId);
    const filtered = existing.filter((d) => d.id !== docId);
    localStorage.setItem(key, JSON.stringify(filtered));

    if (currentActiveDocument?.id === docId) {
      currentActiveDocument = null;
    }
  } catch (err) {
    logger.error('DocumentAnalyzer', 'Failed to delete user document', err);
  }
}

/**
 * Convert a File into base64 string
 */
function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
}

/**
 * Extract text from DOCX files by parsing XML body tokens
 */
async function extractDocxText(file: File): Promise<string> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);
    const textDecoder = new TextDecoder('utf-8', { fatal: false });
    const rawLatin = textDecoder.decode(bytes);

    // Search for XML text tags <w:t>...</w:t>
    const matches = rawLatin.match(/<w:t[^>]*>(.*?)<\/w:t>/g);
    if (matches && matches.length > 0) {
      return matches
        .map((m) => m.replace(/<[^>]+>/g, ''))
        .filter((t) => t.trim().length > 0)
        .join(' ');
    }

    // Fallback: extract ASCII/printable sequences
    const printable = rawLatin.replace(/[^\x20-\x7E\t\n\r]/g, ' ');
    const cleanTokens = printable.split(/\s+/).filter((w) => w.length > 3);
    return cleanTokens.join(' ');
  } catch {
    return '';
  }
}

/**
 * Strictly parses actual document text without inventing fake lot numbers or dates.
 */
export function parseAgriculturalDocumentText(
  rawText: string,
  fileName: string,
  fileType: 'pdf' | 'image' | 'text'
): StoredUserDocument {
  const trimmed = rawText.trim();
  const lower = (trimmed + ' ' + fileName).toLowerCase();

  // If extraction yielded nothing or unreadable bytes
  if (trimmed.length < 15 && !fileType) {
    throw new Error('EXTRACTION_FAILED: Document contains no readable text.');
  }

  // 1. Determine Category from actual text
  let category: AgriDocumentCategory = 'general_agri_doc';
  let categoryLabelEn = 'Agricultural Record';
  let categoryLabelTa = 'விவசாய ஆவணம்';

  if (/seed|விதை|germination|imscs|tag\s*no|certified\s*seed/i.test(lower)) {
    category = 'seed_certificate';
    categoryLabelEn = 'Certified Seed Tag / Seed Purchase Bill';
    categoryLabelTa = 'சான்றளிக்கப்பட்ட விதை அட்டை / கொள்முதல் ரசீது';
  } else if (/soil\s*health|மண்\s*வள|organic\s*carbon|available\s*n|electrical\s*conductivity/i.test(lower)) {
    category = 'soil_health_card';
    categoryLabelEn = 'Soil Health Test Card';
    categoryLabelTa = 'மண் வள பரிசோதனை அட்டை';
  } else if (/mandi|apmc|auction|j-form|விற்பனை\s*ரசீது|quintal/i.test(lower)) {
    category = 'mandi_receipt';
    categoryLabelEn = 'Mandi APMC Farmer Sale Receipt';
    categoryLabelTa = 'மண்டி வேளாண் ஒழுங்குமுறை விற்பனை ரசீது';
  } else if (/fertilizer|urea|dap|potash|உரம்|iffco/i.test(lower)) {
    category = 'purchase_invoice';
    categoryLabelEn = 'Fertilizer & Nutrient Cash Bill';
    categoryLabelTa = 'உரக் கொள்முதல் ரொக்க ரசீது';
  } else if (/pesticide|insecticide|fungicide|பூச்சிக்கொல்லி/i.test(lower)) {
    category = 'pesticide_bill';
    categoryLabelEn = 'Crop Protection Chemical Invoice';
    categoryLabelTa = 'பூச்சிக்கொல்லி மருந்து ரசீது';
  } else if (/nursery|sapling|நாற்று|வாழை\s*கன்று/i.test(lower)) {
    category = 'nursery_bill';
    categoryLabelEn = 'Nursery Plantlet / Sapling Invoice';
    categoryLabelTa = 'நாற்றுப்பண்ணை நாற்றுக்கள் ரசீது';
  }

  // 2. Extract Entities from REAL text (No fake defaults)
  let crop: string | undefined;
  let variety: string | undefined;

  if (/paddy|rice|நெல்/i.test(lower)) {
    crop = 'Paddy (நெல்)';
    const vMatch = rawText.match(/\b(CO-?51|CR-?1009|ADT-?45|ADT-?53|BPT-?5204|IR-?20|TPS-?5)\b/i);
    if (vMatch) variety = vMatch[1].toUpperCase();
  } else if (/cotton|பருத்தி/i.test(lower)) {
    crop = 'Cotton (பருத்தி)';
    const vMatch = rawText.match(/\b(RCH-?659|Bollgard|DCH-?32|MCU-?5)\b/i);
    if (vMatch) variety = vMatch[1];
  } else if (/maize|corn|மக்காச்சோளம்/i.test(lower)) {
    crop = 'Maize (மக்காச்சோளம்)';
    const vMatch = rawText.match(/\b(Pioneer\s*\d+|Syngenta|CO-?6)\b/i);
    if (vMatch) variety = vMatch[1];
  } else if (/banana|வாழை/i.test(lower)) {
    crop = 'Banana (வாழை)';
    const vMatch = rawText.match(/\b(Grand\s*Naine|G-?9|Robusta|Nendran|Poovan)\b/i);
    if (vMatch) variety = vMatch[1];
  } else if (/groundnut|peanut|நிலக்கடலை/i.test(lower)) {
    crop = 'Groundnut (நிலக்கடலை)';
    const vMatch = rawText.match(/\b(TMV-?13|Kadiri-?6|VRI-?2|JL-?24)\b/i);
    if (vMatch) variety = vMatch[1];
  } else if (/tomato|தக்காளி/i.test(lower)) {
    crop = 'Tomato (தக்காளி)';
    const vMatch = rawText.match(/\b(Shivam|Saaho|Abhinav|PKM-?1)\b/i);
    if (vMatch) variety = vMatch[1];
  } else if (/sugarcane|கரும்பு/i.test(lower)) {
    crop = 'Sugarcane (கரும்பு)';
    const vMatch = rawText.match(/\b(Co\s*86032|Co\s*0238|CoC\s*24)\b/i);
    if (vMatch) variety = vMatch[1];
  }

  // Lot / Batch Number Extraction (Only from text)
  const lotMatch = rawText.match(/(?:lot|batch|tag|inv|bill)\s*(?:no|number|#)?[:.\s-]*([A-Za-z0-9\/-]{4,25})/i);
  const lotOrBatchNumber = lotMatch ? lotMatch[1] : undefined;

  // Germination %
  const germMatch = rawText.match(/(?:germination(?:\s+capacity)?|முளைப்பு|germ)\s*[:.\s-]*([0-9]{2,3})\s*%/i);
  const germinationPercent = germMatch ? `${germMatch[1]}%` : undefined;

  // Purity %
  const purityMatch = rawText.match(/(?:purity(?:\s+percentage)?|தூய்மை|pure\s*seed)\s*[:.\s-]*([0-9]{2,3}(?:\.[0-9]+)?)\s*%/i);
  const purityPercent = purityMatch ? `${purityMatch[1]}%` : undefined;

  // Moisture %
  const moistMatch = rawText.match(/(?:moisture|ஈரப்பதம்)\s*[:.\s-]*([0-9]{1,2}(?:\.[0-9]+)?)\s*%/i);
  const moisturePercent = moistMatch ? `${moistMatch[1]}%` : undefined;

  // Chemical treatment
  let chemicalTreatment: string | undefined;
  if (/carbendazim|thiram|captan|treated|விதை\s*நேர்த்தி/i.test(lower)) {
    chemicalTreatment = 'Seed treated with protective fungicidal dressing (Caution: Not for food or feed).';
  }

  // Dates
  const dateMatches = rawText.match(/\b(\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})\b/g);
  const testingDate = dateMatches && dateMatches[0] ? dateMatches[0] : undefined;
  const expiryDate = dateMatches && dateMatches[1] ? dateMatches[1] : undefined;

  // Dealer / Agency
  let issuerOrDealer: string | undefined;
  if (/tnsdoc|department of seed certification/i.test(lower)) {
    issuerOrDealer = 'Department of Seed Certification (TNSDOC)';
  } else if (/iffco/i.test(lower)) {
    issuerOrDealer = 'IFFCO Farmers Service Centre';
  } else if (/apmc|regulated market/i.test(lower)) {
    issuerOrDealer = 'Agricultural Produce Market Committee (APMC)';
  } else if (/kvk|krishi vigyan/i.test(lower)) {
    issuerOrDealer = 'ICAR - Krishi Vigyan Kendra (KVK)';
  }

  // Quantity & Price
  const qtyMatch = rawText.match(/(?:qty|quantity|weight|net wt|எடை|அளவு)\s*[:.\s-]*([0-9]+(?:\.[0-9]+)?\s*(?:kg|bags|quintal|nos|litres))/i);
  const quantity = qtyMatch ? qtyMatch[1] : undefined;

  const priceMatch = rawText.match(/(?:₹|rs\.?|inr|total|price|amount|விலை)\s*[:.\s-]*([0-9,]+(?:\.[0-9]{2})?)/i);
  const pricePaid = priceMatch ? `₹${priceMatch[1]}` : undefined;

  // Key Findings (constructed strictly from actual extracted data)
  const keyFindings: DocumentKeyFinding[] = [
    {
      labelEn: 'Document Category',
      labelTa: 'ஆவண வகை',
      value: categoryLabelEn,
      status: 'verified',
    },
  ];

  if (crop) {
    keyFindings.push({
      labelEn: 'Crop & Variety',
      labelTa: 'பயிர் மற்றும் ரகம்',
      value: variety ? `${crop} - ${variety}` : crop,
      status: 'verified',
    });
  }

  if (lotOrBatchNumber) {
    keyFindings.push({
      labelEn: 'Lot / Batch Number',
      labelTa: 'குவியல் / வரிசை எண்',
      value: lotOrBatchNumber,
      status: 'verified',
    });
  }

  if (germinationPercent) {
    keyFindings.push({
      labelEn: 'Germination Rate',
      labelTa: 'முளைப்புத் திறன்',
      value: germinationPercent,
      status: 'verified',
    });
  }

  if (purityPercent) {
    keyFindings.push({
      labelEn: 'Physical Purity',
      labelTa: 'உடல் தூய்மை',
      value: purityPercent,
      status: 'verified',
    });
  }

  if (expiryDate) {
    keyFindings.push({
      labelEn: 'Validity / Expiry',
      labelTa: 'செல்லுபடியாகும் காலம்',
      value: expiryDate,
      status: 'verified',
    });
  }

  if (pricePaid) {
    keyFindings.push({
      labelEn: 'Total Amount',
      labelTa: 'மொத்த தொகை',
      value: pricePaid,
      status: 'info',
    });
  }

  // Summary
  const summaryEn = `**Document:** ${fileName} (${categoryLabelEn})
${crop ? `• **Identified Crop:** ${crop} ${variety || ''}\n` : ''}${lotOrBatchNumber ? `• **Lot / Identifier:** ${lotOrBatchNumber}\n` : ''}${testingDate ? `• **Recorded Date:** ${testingDate}\n` : ''}${expiryDate ? `• **Valid Until:** ${expiryDate}\n` : ''}${germinationPercent ? `• **Germination:** ${germinationPercent}\n` : ''}${pricePaid ? `• **Amount:** ${pricePaid}\n` : ''}
This document was successfully parsed from actual uploaded text. Use the 'Ask AI' tab to inquire about any specific clauses, prices, or technical parameters.`;

  const summaryTa = `**ஆவணம்:** ${fileName} (${categoryLabelTa})
${crop ? `• **கண்டறியப்பட்ட பயிர்:** ${crop} ${variety || ''}\n` : ''}${lotOrBatchNumber ? `• **குவியல் / குறிப்பு எண்:** ${lotOrBatchNumber}\n` : ''}${testingDate ? `• **தேதி:** ${testingDate}\n` : ''}${expiryDate ? `• **செல்லுபடியாகும் காலம்:** ${expiryDate}\n` : ''}${germinationPercent ? `• **முளைப்புத் திறன்:** ${germinationPercent}\n` : ''}${pricePaid ? `• **தொகை:** ${pricePaid}\n` : ''}
பதிவேற்றப்பட்ட ஆவணத்திலிருந்து இந்த விவரங்கள் நேரடியாகப் பெறப்பட்டன. ஏதேனும் கேள்விகள் இருந்தால் கீழே கேட்கலாம்.`;

  const suggestedQuestions = [
    {
      en: 'What are the key technical parameters and obligations in this document?',
      ta: 'இந்த ஆவணத்தில் உள்ள முக்கிய தொழில்நுட்பக் குறிப்புகள் என்ன?',
    },
    {
      en: 'Are there any expiry dates, validity limits, or warnings mentioned?',
      ta: 'இதில் ஏதேனும் காலாவதி தேதி அல்லது எச்சரிக்கைகள் குறிப்பிடப்பட்டுள்ளதா?',
    },
    {
      en: 'What agronomic precautions should I take according to this record?',
      ta: 'இந்த ஆவணத்தின்படி நான் என்ன விவசாய முன்னெச்சரிக்கைகளை எடுக்க வேண்டும்?',
    },
  ];

  const doc: StoredUserDocument = {
    id: `doc_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    fileName,
    originalFileName: fileName,
    fileType,
    fileSizeBytes: rawText.length,
    uploadedAt: new Date().toLocaleString(),
    processingStatus: 'ready',
    category,
    categoryLabelEn,
    categoryLabelTa,
    crop,
    variety,
    lotOrBatchNumber,
    issuerOrDealer,
    testingDate,
    expiryDate,
    germinationPercent,
    purityPercent,
    moisturePercent,
    chemicalTreatment,
    quantity,
    pricePaid,
    summaryEn,
    summaryTa,
    rawText,
    suggestedQuestions,
    keyFindings,
    analyzedAt: new Date().toLocaleString(),
  };

  currentActiveDocument = doc;
  return doc;
}

/**
 * Reads any File uploaded by the farmer (PDF, DOCX, TXT, Image) and executes Gemini or local extraction.
 */
export async function analyzeUploadedFile(
  file: File,
  userId?: string,
  lang: 'ta' | 'en' = 'en'
): Promise<StoredUserDocument> {
  const extension = file.name.split('.').pop()?.toLowerCase() || '';
  let extractedText = '';
  let base64Data: string | undefined;
  let fileType: 'pdf' | 'image' | 'text' = 'text';

  // 1. Text & Base64 Extraction by File Type
  if (extension === 'pdf') {
    fileType = 'pdf';
    try {
      const buffer = await file.arrayBuffer();
      const pdfRes = await extractPdfText(buffer, file.name);
      extractedText = pdfRes.pages.map((p) => p.text).join('\n');
      base64Data = await fileToBase64(file);
    } catch (err) {
      logger.warn('DocumentAnalyzer', 'PDF local extraction warning', err);
    }
  } else if (['png', 'jpg', 'jpeg', 'webp', 'bmp'].includes(extension)) {
    fileType = 'image';
    base64Data = await fileToBase64(file);
  } else if (['docx', 'doc'].includes(extension)) {
    fileType = 'text';
    extractedText = await extractDocxText(file);
  } else {
    // Plain text, CSV, TSV
    fileType = 'text';
    extractedText = await file.text();
  }

  // 2. Attempt Backend Gemini Document Intelligence (/api/ai/analyze-document)
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 25000);

    const response = await fetch(apiConfig.aiAnalyzeDocumentEndpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        documentText: extractedText,
        base64Data,
        mimeType: file.type || (fileType === 'pdf' ? 'application/pdf' : 'image/jpeg'),
        fileName: file.name,
        language: lang,
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (response.ok) {
      const result = await response.json();
      if (result.success && result.analyzedDocument) {
        const d = result.analyzedDocument;
        const storedDoc: StoredUserDocument = {
          id: `doc_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          fileName: file.name,
          originalFileName: file.name,
          fileType,
          fileSizeBytes: file.size,
          uploadedAt: new Date().toLocaleString(),
          processingStatus: 'ready',
          category: (d.category as AgriDocumentCategory) || 'general_agri_doc',
          categoryLabelEn: d.categoryLabelEn || d.title || 'Agricultural Document',
          categoryLabelTa: d.categoryLabelTa || 'விவசாய ஆவணம்',
          crop: d.crop || undefined,
          variety: d.variety || undefined,
          lotOrBatchNumber: d.lotOrBatchNumber || undefined,
          issuerOrDealer: d.issuerOrDealer || undefined,
          testingDate: d.testingDate || undefined,
          expiryDate: d.expiryDate || undefined,
          germinationPercent: d.germinationPercent || undefined,
          purityPercent: d.purityPercent || undefined,
          moisturePercent: d.moisturePercent || undefined,
          chemicalTreatment: d.chemicalTreatment || undefined,
          quantity: d.quantity || undefined,
          pricePaid: d.pricePaid || undefined,
          summaryEn: d.summaryEn,
          summaryTa: d.summaryTa,
          rawText: extractedText || d.summaryEn,
          suggestedQuestions: d.suggestedQuestions || [],
          keyFindings: d.keyFindings || [],
          analyzedAt: new Date().toLocaleString(),
        };

        await saveUserUploadedDocument(storedDoc, userId);
        currentActiveDocument = storedDoc;
        return storedDoc;
      }
    }
  } catch (backendErr) {
    logger.warn('DocumentAnalyzer', 'Backend Gemini doc analysis failed, using extracted text', backendErr);
  }

  // 3. Fallback: Parse strictly from extracted text (NEVER invent fake fields)
  if (!extractedText.trim() && fileType === 'image') {
    throw new Error(
      'OCR_UNAVAILABLE: Image analysis requires Gemini API service. Please ensure GEMINI_API_KEY is configured on the server to read scanned photos.'
    );
  }

  const parsedDoc = parseAgriculturalDocumentText(extractedText || file.name, file.name, fileType);
  parsedDoc.fileSizeBytes = file.size;
  await saveUserUploadedDocument(parsedDoc, userId);
  currentActiveDocument = parsedDoc;
  return parsedDoc;
}

/**
 * Ask a question about an uploaded document using Gemini
 */
export async function askQuestionAboutDocument(
  doc: StoredUserDocument,
  question: string,
  lang: 'ta' | 'en' = 'en'
): Promise<string> {
  const isTa = lang === 'ta';

  try {
    const response = await fetch(apiConfig.aiDocumentQaEndpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        documentText: doc.rawText || doc.summaryEn,
        question,
        fileName: doc.fileName,
        language: lang,
      }),
    });

    if (response.ok) {
      const data = await response.json();
      if (data.success && data.answer) {
        return data.answer;
      }
    }
  } catch (err) {
    logger.error('DocumentAnalyzer', 'Document Q&A call failed', err);
  }

  // Offline grounded answering based strictly on document's key findings
  const lowerQ = question.toLowerCase();

  const answers: string[] = [];

  const asksLot = lowerQ.includes('lot') || lowerQ.includes('batch') || lowerQ.includes('வரிசை') || lowerQ.includes('எண்');
  const asksGerm = lowerQ.includes('germinat') || lowerQ.includes('முளைப்பு');
  const asksExpiry = lowerQ.includes('expir') || lowerQ.includes('valid') || lowerQ.includes('காலாவதி');
  const asksRights = lowerQ.includes('right') || lowerQ.includes('fail') || lowerQ.includes('சட்டம்') || lowerQ.includes('உரிமை') || lowerQ.includes('முளைக்காமல்');
  const asksPurity = lowerQ.includes('purity') || lowerQ.includes('தூய்மை');
  const asksTreatment = lowerQ.includes('treat') || lowerQ.includes('chemical') || lowerQ.includes('நேர்த்தி') || lowerQ.includes('மருந்து');

  if (asksLot) {
    answers.push(
      doc.lotOrBatchNumber
        ? isTa
          ? `📋 **குவியல் / வரிசை எண் (Lot Number):** ${doc.lotOrBatchNumber}`
          : `📋 **Lot / Batch Number:** ${doc.lotOrBatchNumber}`
        : isTa
        ? '📋 **குவியல் எண்:** இந்த ஆவணத்தில் குவியல் எண் (Lot No) தெளிவாகக் குறிப்பிடப்படவில்லை.'
        : '📋 **Lot Number:** Not specified in this document.'
    );
  }

  if (asksGerm) {
    answers.push(
      doc.germinationPercent
        ? isTa
          ? `🌱 **சான்றளிக்கப்பட்ட முளைப்புத் திறன் (Germination):** ${doc.germinationPercent}`
          : `🌱 **Certified Germination Capacity:** ${doc.germinationPercent}`
        : isTa
        ? '🌱 **முளைப்புத் திறன்:** இந்த ஆவணத்தில் முளைப்புத் திறன் சதவீதம் குறிப்பிடப்படவில்லை (TNAU/TNSDOC விதிப்படி சான்றளிக்கப்பட்ட நெல் விதைக்கு குறைந்தபட்சம் 80% முளைப்புத்திறன் அவசியம்).'
        : '🌱 **Germination Capacity:** Not explicitly stated in this document (TNAU/TNSDOC standard requires minimum 80% for certified paddy seeds).'
    );
  }

  if (asksExpiry) {
    answers.push(
      doc.expiryDate
        ? isTa
          ? `📅 **செல்லுபடியாகும் காலம் / காலாவதி (Validity / Expiry):** ${doc.expiryDate}`
          : `📅 **Document Validity / Expiry Date:** ${doc.expiryDate}`
        : isTa
        ? `📅 **செல்லுபடியாகும் காலம்:** ஆவணத்தில் குறிப்பிட்ட காலாவதி தேதி இல்லை (இந்திய விதைச் சட்டம் 1966 விதிப்படி பரிசோதனை தேதியிலிருந்து 9 மாதங்கள் வரை விதைச் சான்றிதழ் செல்லுபடியாகும்).`
        : `📅 **Validity / Expiry Date:** No specific expiry date printed on this label (Under Indian Seed Act 1966 regulations, seed certification is valid for 9 months from the date of testing).`
    );
  }

  if (asksPurity) {
    answers.push(
      doc.purityPercent
        ? isTa
          ? `🔬 **விதைத் தூய்மை (Physical Purity):** ${doc.purityPercent}`
          : `🔬 **Physical Purity:** ${doc.purityPercent}`
        : isTa
        ? '🔬 **விதைத் தூய்மை:** தூய்மை சதவீதம் குறிப்பிடப்படவில்லை.'
        : '🔬 **Physical Purity:** Not stated in document.'
    );
  }

  if (asksTreatment) {
    answers.push(
      doc.chemicalTreatment
        ? isTa
          ? `🧪 **விதை நேர்த்தி (Chemical Dressing):** ${doc.chemicalTreatment}`
          : `🧪 **Seed Dressing / Treatment:** ${doc.chemicalTreatment}`
        : isTa
        ? '🧪 **விதை நேர்த்தி:** ரசாயன விதை நேர்த்தி விபரம் குறிப்பிடப்படவில்லை.'
        : '🧪 **Seed Treatment:** Not specified on this tag.'
    );
  }

  if (asksRights) {
    answers.push(
      isTa
        ? `⚖️ **விவசாயியின் சட்டப்பூர்வ உரிமைகள் (Seed Act 1966 & Consumer Protection Act 2019):**\n• விதை முளைப்புத் திறன் குறிப்பிட்ட சதவீதத்தை விடக் குறைவாக இருந்தால், வாங்கிய ரசீது (Bill/Invoice) மற்றும் விதை அட்டை (Tag) கொண்டு வேளாண்மை அலுவலர் (AAO) அல்லது விதை ஆய்வாளரிடம் (Seed Inspector) புகார் அளிக்கலாம்.\n• இழப்பீடு கோர நுகர்வோர் நீதிமன்றத்தில் (Consumer Forum) மனு அளிக்க விவசாயிகளுக்கு முழு உரிமை உண்டு.`
        : `⚖️ **Farmer Legal Rights (Seed Act 1966 & Consumer Protection Act 2019):**\n• If germination fails below standard, preserve the cash memo/bill and certified seed tag.\n• Lodge a formal complaint with the local Agricultural Extension Officer (AAO) or Assistant Director of Seed Inspection.\n• Farmers are legally entitled to compensation under Section 19 of the Seed Act and Consumer Redressal Forums.`
    );
  }

  if (answers.length > 0) {
    const docHeader = isTa
      ? `📄 **ஆவண அறிக்கை [${doc.fileName}]:**\n\n`
      : `📄 **Document Verification Report [${doc.fileName}]:**\n\n`;
    return docHeader + answers.join('\n\n');
  }

  return isTa ? doc.summaryTa : doc.summaryEn;
}
