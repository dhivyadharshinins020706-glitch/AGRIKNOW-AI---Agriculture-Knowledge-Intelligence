import { apiConfig } from './apiConfig';
import type { AgriWeather } from '@/types';

// Baseline agro-meteorological data for key agricultural districts
const districtWeatherMap: Record<string, AgriWeather> = {
  thanjavur: {
    location: 'Thanjavur, Tamil Nadu (Cauvery Delta)',
    tempC: 31,
    humidity: 78,
    windKmh: 12,
    rainChance: 60,
    condition: 'Humid, clouds building by evening',
    conditionTa: 'அதிக ஈரப்பதம், மாலையில் மேகமூட்டம்',
    farmingAdvice: 'Hold pesticide spraying until rain passes tomorrow. Check field drainage channels.',
    farmingAdviceTa: 'நாளை மழை வாய்ப்பு உள்ளதால் மருந்து தெளிப்பதை ஒத்திவைக்கவும். வடிகால் வாய்க்காலை சரிபார்க்கவும்.',
  },
  madurai: {
    location: 'Madurai, Tamil Nadu',
    tempC: 34,
    humidity: 62,
    windKmh: 14,
    rainChance: 25,
    condition: 'Partly sunny, warm breeze',
    conditionTa: 'பகுதி வெயில், மிதமான காற்று',
    farmingAdvice: 'Good window for soil preparation and light morning irrigation.',
    farmingAdviceTa: 'நிலம் உழவு செய்வதற்கும் காலையில் நீர் பாய்ச்சுவதற்கும் ஏற்ற வானிலை.',
  },
  coimbatore: {
    location: 'Coimbatore, Tamil Nadu',
    tempC: 29,
    humidity: 71,
    windKmh: 18,
    rainChance: 40,
    condition: 'Pleasant, gusty winds from Western Ghats',
    conditionTa: 'குளிர்ந்த காற்று, மேற்குத் தொடர்ச்சி மலை காற்று',
    farmingAdvice: 'Provide staking for banana and tall crops to withstand gusty winds.',
    farmingAdviceTa: 'பலத்த காற்று வீசுவதால் வாழை மற்றும் உயரமான பயிர்களுக்கு முட்டு கொடுக்கவும்.',
  },
  trichy: {
    location: 'Tiruchirappalli, Tamil Nadu',
    tempC: 33,
    humidity: 68,
    windKmh: 10,
    rainChance: 35,
    condition: 'Warm and dry morning, scattered clouds',
    conditionTa: 'வெதுவெதுப்பான காலை, சிதறிய மேகங்கள்',
    farmingAdvice: 'Suitable for urea top-dressing if soil has adequate moisture.',
    farmingAdviceTa: 'மண்ணில் போதிய ஈரம் இருந்தால் யூரியா மேலுரம் இடுவதற்கு உகந்த நேரம்.',
  },
  salem: {
    location: 'Salem, Tamil Nadu',
    tempC: 32,
    humidity: 65,
    windKmh: 11,
    rainChance: 30,
    condition: 'Sunny intervals with light humidity',
    conditionTa: 'வெயில் மற்றும் மிதமான ஈரப்பதம்',
    farmingAdvice: 'Scout tapioca and maize fields for sucking pests in morning hours.',
    farmingAdviceTa: 'காலை வேளையில் மரவள்ளி மற்றும் மக்காச்சோளப் பயிர்களில் பூச்சிகளைக் கண்காணிக்கவும்.',
  },
  tirunelveli: {
    location: 'Tirunelveli, Tamil Nadu',
    tempC: 33,
    humidity: 74,
    windKmh: 16,
    rainChance: 45,
    condition: 'Humid breeze, coastal clouds',
    conditionTa: 'கடல் காற்று, ஈரப்பதமான வானிலை',
    farmingAdvice: 'Inspect paddy nurseries for leaf blast under high humidity.',
    farmingAdviceTa: 'அதிக ஈரப்பதம் இருப்பதால் நெல் நாற்றங்காலில் இலைக்கருகல் நோயைக் கவனிக்கவும்.',
  },
};

export async function fetchDistrictWeather(districtName: string): Promise<AgriWeather> {
  const normalized = districtName.trim().toLowerCase();

  if (apiConfig.weatherApiUrl) {
    try {
      const response = await fetch(`${apiConfig.weatherApiUrl}?q=${encodeURIComponent(districtName)}`);
      if (response.ok) {
        const data = await response.json();
        return {
          location: `${districtName}, India`,
          tempC: Math.round(data.main?.temp ?? 31),
          humidity: data.main?.humidity ?? 75,
          windKmh: Math.round((data.wind?.speed ?? 3.5) * 3.6),
          rainChance: data.rain ? 70 : 30,
          condition: data.weather?.[0]?.description ?? 'Humid, clouds building',
          conditionTa: 'மேகமூட்டம் மற்றும் மிதமான காற்று',
          farmingAdvice: 'Check soil moisture before afternoon irrigation.',
          farmingAdviceTa: 'மதிய பாசனத்திற்கு முன் மண்ணின் ஈரப்பதத்தைச் சரிபார்க்கவும்.',
        };
      }
    } catch {
      // Fall through to regional agro-meteorological data
    }
  }

  // Lookup in regional map or default to Thanjavur
  return districtWeatherMap[normalized] || {
    ...districtWeatherMap.thanjavur,
    location: `${districtName || 'Thanjavur'}, Tamil Nadu`,
  };
}
