import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { FarmTask } from '@/types';

export async function fetchUserTasks(userId: string): Promise<FarmTask[]> {
  if (!isSupabaseConfigured || !supabase) return [];

  try {
    const { data, error } = await supabase
      .from('farm_tasks')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error || !data) return [];

    return data.map((row) => ({
      id: row.id,
      title: row.title,
      when: row.deadline,
      done: row.is_done,
      crop: row.crop,
      priority: row.priority as 'High' | 'Medium' | 'Low',
    }));
  } catch {
    return [];
  }
}

export async function saveTaskToDb(
  userId: string,
  task: Omit<FarmTask, 'id'>
): Promise<string | null> {
  if (!isSupabaseConfigured || !supabase) return null;

  try {
    const { data, error } = await supabase
      .from('farm_tasks')
      .insert({
        user_id: userId,
        title: task.title,
        deadline: task.when,
        is_done: task.done,
        crop: task.crop || null,
        priority: task.priority || 'Medium',
      })
      .select('id')
      .single();

    if (error || !data) return null;
    return data.id;
  } catch {
    return null;
  }
}

export async function toggleTaskInDb(taskId: string, isDone: boolean): Promise<boolean> {
  if (!isSupabaseConfigured || !supabase) return false;

  try {
    const { error } = await supabase
      .from('farm_tasks')
      .update({ is_done: isDone, updated_at: new Date().toISOString() })
      .eq('id', taskId);

    return !error;
  } catch {
    return false;
  }
}

export async function deleteTaskFromDb(taskId: string): Promise<boolean> {
  if (!isSupabaseConfigured || !supabase) return false;

  try {
    const { error } = await supabase.from('farm_tasks').delete().eq('id', taskId);
    return !error;
  } catch {
    return false;
  }
}
