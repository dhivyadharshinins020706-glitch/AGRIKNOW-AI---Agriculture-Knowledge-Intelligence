/**
 * AGRIKNOW AI - Production Google Gemini AI Orchestration Service
 * Powered by the official Google GenAI SDK (@google/genai) and REST fallback.
 * 
 * Supports:
 * - Reasoning & Text Generation (gemini-3.8-flash / configurable)
 * - Semantic Vector Embeddings (gemini-embedding-2 / configurable)
 * - Multimodal Crop Disease & Pest Vision Diagnosis
 * - Dynamic Multi-Format Document Intelligence (PDF, DOCX, TXT, CSV, Images)
 * - Grounded Document Q&A
 * - Exponential backoff retry, timeout handling, token usage & rate tracking
 * 
 * Secure server-side execution: API keys are read strictly from environment variables.
 */

import { GoogleGenAI } from '@google/genai';

export interface GeminiTextOptions {
  prompt: string;
  systemInstruction?: string;
  history?: { role: 'user' | 'assistant'; text: string }[];
  temperature?: number;
  maxOutputTokens?: number;
  model?: string;
  timeoutMs?: number;
}

export interface GeminiTextResult {
  text: string;
  modelUsed: string;
  tokensUsed?: number;
  finishReason?: string;
}

export interface VisionDiagnosisResult {
  visualObservations: string;
  cropIdentified: string;
  primaryDiagnosis: string;
  confidence: number;
  conditionType: 'fungal' | 'bacterial' | 'viral' | 'pest' | 'nutrient_deficiency' | 'environmental' | 'healthy' | 'unclear';
  differentialDiagnoses: {
    condition: string;
    probability: number;
    differentiatingClue: string;
  }[];
  whySuggested: string;
  missingInformation: string;
  managementPlan: {
    ipmAndCultural: string[];
    biologicalControls: string[];
    certifiedChemicals: {
      name: string;
      dosage: string;
      safetyNotes: string;
    }[];
  };
  expertEscalationNotice: string;
}

export interface DocumentAnalysisResult {
  title: string;
  category: string;
  categoryLabelEn: string;
  categoryLabelTa: string;
  crop?: string;
  variety?: string;
  lotOrBatchNumber?: string;
  issuerOrDealer?: string;
  testingDate?: string;
  expiryDate?: string;
  germinationPercent?: string;
  purityPercent?: string;
  moisturePercent?: string;
  chemicalTreatment?: string;
  quantity?: string;
  pricePaid?: string;
  subsidyDetail?: string;
  summaryEn: string;
  summaryTa: string;
  keyFindings: {
    labelEn: string;
    labelTa: string;
    value: string;
    status: 'verified' | 'warning' | 'info';
    pageNumber?: number;
    exactQuote?: string;
  }[];
  actionableGuidanceEn: string;
  actionableGuidanceTa: string;
  suggestedQuestions: { en: string; ta: string }[];
  extractedFields?: {
    key: string;
    labelEn: string;
    labelTa: string;
    originalValue: string;
    normalizedValue?: number | string;
    unit?: string;
    pageNumber?: number;
    confidence: number;
    exactSupportingText?: string;
    benchmarkStatus?: 'optimal' | 'low' | 'high' | 'warning' | 'info';
  }[];
  tables?: {
    title?: string;
    headers: string[];
    rows: string[][];
    pageNumber?: number;
  }[];
  soilParameters?: {
    pH?: number;
    ec?: number;
    organicCarbon?: number;
    availableN?: number;
    availableP?: number;
    availableK?: number;
    zinc?: number;
    iron?: number;
    sulphur?: number;
    soilType?: string;
  };
  fertilizerParameters?: {
    brandName?: string;
    grade?: string;
    bagWeightKg?: number;
    nitrogenWeightKg?: number;
    phosphorusWeightKg?: number;
    potassiumWeightKg?: number;
  };
  pesticideParameters?: {
    productName?: string;
    activeIngredient?: string;
    recommendedDosage?: string;
    waitingPeriodDays?: number;
    cibrcRegNumber?: string;
  };
  seedParameters?: {
    seedClass?: string;
    germinationPercent?: number;
    physicalPurityPercent?: number;
    lotNumber?: string;
  };
  warnings?: string[];
  isUnreadable?: boolean;
}

export interface GeminiUsageStats {
  totalRequests: number;
  successfulRequests: number;
  failedRequests: number;
  totalTokensUsed: number;
  activeModel: string;
  embeddingModel: string;
  lastRequestTime: string | null;
}

// In-memory telemetry
const usageStats: GeminiUsageStats = {
  totalRequests: 0,
  successfulRequests: 0,
  failedRequests: 0,
  totalTokensUsed: 0,
  activeModel: process.env.GEMINI_MODEL || 'gemini-2.5-flash-lite',
  embeddingModel: process.env.GEMINI_EMBEDDING_MODEL || 'gemini-embedding-2',
  lastRequestTime: null,
};

export function getGeminiUsageStats(): GeminiUsageStats {
  return { ...usageStats };
}

export function getGeminiApiKey(): string | null {
  const key =
    process.env.GEMINI_API_KEY ||
    process.env.GOOGLE_API_KEY ||
    process.env.VITE_GEMINI_API_KEY ||
    null;

  if (key && key.trim().length > 5 && !key.includes('YOUR_')) {
    return key.trim();
  }
  return null;
}

export function getGeminiModel(override?: string): string {
  if (override) return override;
  return process.env.GEMINI_MODEL || 'gemini-2.5-flash-lite';
}

export function getGeminiEmbeddingModel(override?: string): string {
  if (override) return override;
  return process.env.GEMINI_EMBEDDING_MODEL || 'gemini-embedding-2';
}

/**
 * Singleton GoogleGenAI SDK Client
 */
let cachedGenAiClient: GoogleGenAI | null = null;
let cachedApiKey: string | null = null;

function getGenAiClient(): GoogleGenAI | null {
  const apiKey = getGeminiApiKey();
  if (!apiKey) return null;
  if (!cachedGenAiClient || cachedApiKey !== apiKey) {
    cachedGenAiClient = new GoogleGenAI({ apiKey });
    cachedApiKey = apiKey;
  }
  return cachedGenAiClient;
}

/**
 * Execute an async operation with exponential backoff retry for transient errors
 */
async function withRetry<T>(
  operation: () => Promise<T>,
  retries = 3,
  delayMs = 1000,
  operationName = 'Gemini Operation'
): Promise<T> {
  let attempt = 0;
  while (attempt < retries) {
    try {
      return await operation();
    } catch (err: unknown) {
      attempt++;
      const errMsg = err instanceof Error ? err.message : String(err);
      const isTransient =
        errMsg.includes('429') ||
        errMsg.includes('503') ||
        errMsg.includes('RESOURCE_EXHAUSTED') ||
        errMsg.includes('UNAVAILABLE') ||
        errMsg.includes('fetch failed') ||
        errMsg.includes('ECONNRESET');

      if (attempt >= retries || !isTransient) {
        throw err;
      }

      const backoff = delayMs * Math.pow(2, attempt - 1);
      console.warn(`[Gemini Retry] ${operationName} failed (attempt ${attempt}/${retries}): ${errMsg}. Retrying in ${backoff}ms...`);
      await new Promise((resolve) => setTimeout(resolve, backoff));
    }
  }
  throw new Error(`${operationName} failed after ${retries} attempts.`);
}

/**
 * Generate Text Reasoning with Google Gemini using Official GenAI SDK and Model Failover
 */
export async function callGeminiText(options: GeminiTextOptions): Promise<GeminiTextResult> {
  usageStats.totalRequests++;
  usageStats.lastRequestTime = new Date().toISOString();

  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    usageStats.failedRequests++;
    throw new Error(
      'GEMINI_KEY_NOT_CONFIGURED: Google Gemini API key is not configured on the server. Please set GEMINI_API_KEY in your environment variables.'
    );
  }

  const modelsToTry = [
    options.model,
    process.env.GEMINI_MODEL,
    'gemini-flash-lite-latest',
    'gemini-3.5-flash-lite',
    'gemini-3.5-flash',
    'gemini-2.5-flash',
    'gemini-flash-latest',
    'gemini-3.8-flash',
    'gemini-pro-latest',
  ].filter(Boolean) as string[];

  // Deduplicate preserving priority order
  const uniqueModels = Array.from(new Set(modelsToTry));
  let lastError: unknown = null;

  for (const model of uniqueModels) {
    try {
      usageStats.activeModel = model;
      const client = getGenAiClient();

      // 1. Try with official GoogleGenAI SDK
      if (client && client.models) {
        try {
          const contents: any[] = [];

          if (options.history && options.history.length > 0) {
            for (const turn of options.history) {
              if (!turn.text || turn.text.trim().length === 0) continue;
              contents.push({
                role: turn.role === 'assistant' ? 'model' : 'user',
                parts: [{ text: turn.text }],
              });
            }
          }

          contents.push({
            role: 'user',
            parts: [{ text: options.prompt }],
          });

          const response = await client.models.generateContent({
            model,
            contents,
            config: {
              temperature: options.temperature ?? 0.2,
              maxOutputTokens: options.maxOutputTokens ?? 2500,
              systemInstruction: options.systemInstruction ? options.systemInstruction : undefined,
            },
          });

          const candidate = response.candidates?.[0];
          const text = response.text || candidate?.content?.parts?.map((p: any) => p.text).join('') || '';

          if (text.trim()) {
            usageStats.successfulRequests++;
            const tokens = response.usageMetadata?.totalTokenCount || 0;
            usageStats.totalTokensUsed += tokens;

            return {
              text,
              modelUsed: model,
              tokensUsed: tokens,
              finishReason: candidate?.finishReason || 'STOP',
            };
          }
        } catch (sdkErr: any) {
          console.warn(`[Gemini SDK Warning] SDK call for ${model} encountered error, trying REST:`, sdkErr?.message || sdkErr);
        }
      }

      // 2. Direct REST Fallback with current candidate model
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
      const contents: { role: 'user' | 'model'; parts: { text: string }[] }[] = [];

      if (options.history && options.history.length > 0) {
        for (const turn of options.history) {
          if (!turn.text || turn.text.trim().length === 0) continue;
          contents.push({
            role: turn.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: turn.text }],
          });
        }
      }

      contents.push({
        role: 'user',
        parts: [{ text: options.prompt }],
      });

      const bodyPayload: Record<string, unknown> = {
        contents,
        generationConfig: {
          temperature: options.temperature ?? 0.2,
          topP: 0.95,
          maxOutputTokens: options.maxOutputTokens ?? 2500,
        },
      };

      if (options.systemInstruction) {
        bodyPayload.systemInstruction = {
          parts: [{ text: options.systemInstruction }],
        };
      }

      const controller = new AbortController();
      const timeoutMs = options.timeoutMs ?? 20000;
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

      try {
        const res = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(bodyPayload),
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (!res.ok) {
          const errJson = await res.json().catch(() => ({}));
          const errMsg = errJson?.error?.message || `HTTP ${res.status} (${res.statusText})`;
          throw new Error(`GEMINI_API_ERROR: ${errMsg}`);
        }

        const data = await res.json();
        const candidate = data.candidates?.[0];
        const text = candidate?.content?.parts?.map((p: { text: string }) => p.text).join('') || '';

        if (!text.trim()) {
          throw new Error('GEMINI_EMPTY_RESPONSE: Gemini returned an empty response.');
        }

        usageStats.successfulRequests++;
        const tokens = data.usageMetadata?.totalTokenCount || 0;
        usageStats.totalTokensUsed += tokens;

        return {
          text,
          modelUsed: model,
          tokensUsed: tokens,
          finishReason: candidate?.finishReason || 'STOP',
        };
      } catch (restErr: any) {
        clearTimeout(timeoutId);
        throw restErr;
      }
    } catch (modelErr: any) {
      lastError = modelErr;
      const errMsg = modelErr instanceof Error ? modelErr.message : String(modelErr);
      console.warn(`[Gemini Failover] Model "${model}" failed (${errMsg}). Switching to next candidate model...`);
    }
  }

  usageStats.failedRequests++;
  throw new Error(`GEMINI_INFERENCE_ERROR: All candidate models failed. Last error: ${lastError instanceof Error ? lastError.message : String(lastError)}`);
}

/**
 * Generate Semantic Embeddings with Gemini text-embedding-004
 */
export async function callGeminiEmbeddings(text: string): Promise<number[]> {
  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    throw new Error('GEMINI_KEY_NOT_CONFIGURED: Set GEMINI_API_KEY in environment variables.');
  }

  const model = getGeminiEmbeddingModel();
  usageStats.embeddingModel = model;
  const client = getGenAiClient();

  return withRetry(
    async () => {
      if (client && client.models) {
        try {
          const res = await client.models.embedContent({
            model,
            contents: text,
          });

          const values = (res as any)?.embedding?.values;
          if (Array.isArray(values) && values.length > 0) {
            return values;
          }
        } catch (sdkErr: any) {
          console.warn('[Gemini SDK Embed] SDK fallback to REST:', sdkErr?.message);
        }
      }

      // REST fallback
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:embedContent?key=${apiKey}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: { parts: [{ text }] },
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(`GEMINI_EMBEDDING_ERROR: ${errJson?.error?.message || res.statusText}`);
      }

      const data = await res.json();
      const values = data?.embedding?.values;
      if (!Array.isArray(values)) {
        throw new Error('GEMINI_EMBEDDING_ERROR: Invalid embedding response format.');
      }
      return values;
    },
    3,
    1000,
    'Gemini Embedding Generation'
  );
}

/**
 * Perform Multimodal Crop Leaf / Pest Vision Diagnosis with Gemini
 */
export async function callGeminiVision(
  base64Data: string,
  mimeType: string,
  userNotes?: string,
  lang: 'ta' | 'en' = 'en'
): Promise<VisionDiagnosisResult> {
  usageStats.totalRequests++;
  usageStats.lastRequestTime = new Date().toISOString();

  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    usageStats.failedRequests++;
    throw new Error(
      'GEMINI_KEY_NOT_CONFIGURED: Google Gemini API key is not configured on the server. Please set GEMINI_API_KEY in your environment variables.'
    );
  }

  const model = getGeminiModel();
  usageStats.activeModel = model;
  const cleanBase64 = base64Data.replace(/^data:[^;]+;base64,/, '');

  const systemInstruction = `You are a Senior Plant Pathologist, Agricultural Entomologist, and Agronomist at Tamil Nadu Agricultural University (TNAU) and ICAR.
Your task is to visually examine an uploaded image of an agricultural crop, leaf, stem, fruit, or pest.
Perform an objective, scientifically rigorous diagnostic visual inspection.

CRITICAL DIAGNOSTIC RULES:
1. Objectively describe what is visibly seen (lesions, chlorosis, fungal mycelia, insect holes, leaf margins, necrotic spots, fruit damage).
2. Identify the most probable crop and primary condition.
3. NEVER claim 100% certainty from a single photograph. Give realistic confidence (60-92%).
4. Always provide 2-3 alternative differential diagnoses that share similar symptoms (e.g. bacterial blight vs fungal blast, potassium deficiency vs brown spot, mite damage vs virus).
5. Explain clearly WHY each possibility is considered based on visual clues.
6. List what MISSING information would confirm the diagnosis (e.g. underside of leaf, soil moisture, age of crop, recent chemical sprays).
7. Recommend verified, legal, CIBRC/TNAU-compliant management steps:
   - IPM & cultural practices
   - Biological bio-agents (Trichoderma, Pseudomonas, Neem oil, Beauveria)
   - Certified chemical interventions with exact dosages per litre
   - NEVER invent or recommend banned chemicals (e.g. Monocrotophos, Endosulfan, Methyl Parathion).
8. If the image is blurry, dark, not a crop, or healthy, state this transparently in 'conditionType' ('healthy', 'unclear', 'environmental').
9. The language requested is: ${lang === 'ta' ? 'Tamil (தமிழ்) with technical names in parentheses' : 'English'}.
10. Return ONLY valid JSON matching the requested structure without any markdown backticks.`;

  const promptText = `Analyze this crop leaf / agricultural photograph carefully.
${userNotes ? `Farmer's observations: "${userNotes}"` : 'No additional symptoms reported by farmer.'}

Return JSON with this exact schema:
{
  "visualObservations": "Detailed description of visible leaf/tissue symptoms",
  "cropIdentified": "Crop name and variety/type if recognizable",
  "primaryDiagnosis": "Primary disease or condition name",
  "confidence": 85,
  "conditionType": "fungal" | "bacterial" | "viral" | "pest" | "nutrient_deficiency" | "environmental" | "healthy" | "unclear",
  "differentialDiagnoses": [
    {
      "condition": "Alternative Condition Name",
      "probability": 25,
      "differentiatingClue": "Visual feature that distinguishes this from the primary condition"
    }
  ],
  "whySuggested": "Agronomic reasoning explaining why the primary diagnosis was chosen based on observed lesions/symptoms",
  "missingInformation": "What additional information or photos (e.g. lower canopy, leaf underside) would confirm diagnosis",
  "managementPlan": {
    "ipmAndCultural": ["Cultural step 1", "Sanitation step 2"],
    "biologicalControls": ["Bio-agent 1 with dosage", "Neem formulation with dosage"],
    "certifiedChemicals": [
      {
        "name": "Chemical Fungicide/Insecticide Name & Formulation",
        "dosage": "Exact dose per litre of water",
        "safetyNotes": "Pre-harvest interval and safety gear"
      }
    ]
  },
  "expertEscalationNotice": "Guidance on consulting local Assistant Agricultural Officer (AAO) or KVK"
}`;

  const modelsToTry = [
    'gemini-flash-lite-latest',
    'gemini-3.5-flash-lite',
    'gemini-3.5-flash',
    'gemini-2.5-flash',
    'gemini-flash-latest',
    'gemini-3.8-flash',
    'gemini-pro-latest',
  ];

  let lastVisionError: unknown = null;

  for (const model of modelsToTry) {
    try {
      usageStats.activeModel = model;
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 35000);

      try {
        const response = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [
              {
                role: 'user',
                parts: [
                  { text: promptText },
                  {
                    inlineData: {
                      mimeType,
                      data: cleanBase64,
                    },
                  },
                ],
              },
            ],
            systemInstruction: {
              parts: [{ text: systemInstruction }],
            },
            generationConfig: {
              temperature: 0.1,
              maxOutputTokens: 2500,
              responseMimeType: 'application/json',
            },
          }),
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
          const errJson = await response.json().catch(() => ({}));
          throw new Error(`GEMINI_VISION_ERROR: ${errJson?.error?.message || response.statusText}`);
        }

        const data = await response.json();
        const rawText = data.candidates?.[0]?.content?.parts?.map((p: { text: string }) => p.text).join('') || '';
        let cleanJson = rawText.trim();
        const jsonMatch = cleanJson.match(/```(?:json)?\s*([\s\S]*?)\s*```/) || cleanJson.match(/(\{[\s\S]*\})/);
        if (jsonMatch) {
          cleanJson = jsonMatch[1].trim();
        }
        const parsed: VisionDiagnosisResult = JSON.parse(cleanJson);

        usageStats.successfulRequests++;
        return parsed;
      } catch (callErr: unknown) {
        clearTimeout(timeoutId);
        throw callErr;
      }
    } catch (modelErr: any) {
      lastVisionError = modelErr;
      console.warn(`[Gemini Vision Failover] Model "${model}" failed (${modelErr?.message || modelErr}). Trying next candidate...`);
    }
  }

  usageStats.failedRequests++;
  throw new Error(`GEMINI_VISION_ERROR: All candidate models failed. Last error: ${lastVisionError instanceof Error ? lastVisionError.message : String(lastVisionError)}`);
}

/**
 * Dynamically extract and analyze real agricultural documents (Seed tags, Soil Cards, APMC bills) with Gemini
 */
export async function callGeminiDocumentAnalysis(
  documentText: string,
  base64Data?: string,
  mimeType?: string,
  fileName = 'document.pdf',
  lang: 'ta' | 'en' = 'en'
): Promise<DocumentAnalysisResult> {
  usageStats.totalRequests++;
  usageStats.lastRequestTime = new Date().toISOString();

  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    usageStats.failedRequests++;
    throw new Error(
      'GEMINI_KEY_NOT_CONFIGURED: Google Gemini API key is not configured on the server. Please set GEMINI_API_KEY in your environment variables.'
    );
  }

  const model = getGeminiModel();
  usageStats.activeModel = model;

  const systemInstruction = `You are AGRIKNOW AI - Senior Agricultural Document Intelligence Specialist.
You specialize in Indian agricultural documents: Soil Health Cards (SHC), Certified Seed Tags (IMSCS/TNSDOC), Mandi APMC J-Forms, Fertilizer Cash Memos & Labels (IFFCO, Coromandel, KRIBHCO), Pesticide Labels (CIBRC regulations), Water Quality Reports, and Subsidy/KCC/PM-Kisan records.

EXTRACT REAL DATA ONLY:
1. Extract actual text, numbers, dates, units, and tables directly from the document.
2. NEVER guess, fabricate, or hallucinate lot numbers, test dates, crop varieties, pH, NPK, or prices. If a parameter is absent, set it to null.
3. For Soil Health Cards: Identify pH, EC, Organic Carbon (OC), Nitrogen (N), Phosphorus (P), Potassium (K), Zinc (Zn), Iron (Fe), Sulphur (S).
4. For Fertilizer documents: Identify grade (e.g. 18-46-0, 46% N), net weight, brand, active nutrients.
5. For Pesticide labels: Identify active ingredients, dilution rate, waiting period / PHI (days), target pests.
6. For Seed tags: Identify certified class (Breeder/Foundation/Certified), germination %, purity %, lot no, validity.
7. Return clean, valid JSON matching the exact schema without backticks or markdown fences.`;

  const promptText = `Perform full-spectrum agricultural intelligence extraction on this document (${fileName}):

Document Content:
---
${documentText.slice(0, 10000)}
---

JSON Output Schema:
{
  "title": "Precise title of the document",
  "category": "soil_health_card" | "water_quality_report" | "fertilizer_bill" | "fertilizer_label" | "pesticide_bill" | "pesticide_label" | "seed_certificate" | "mandi_receipt" | "nursery_bill" | "crop_insurance_doc" | "government_scheme_doc" | "farm_expense_record" | "research_paper" | "general_agri_doc",
  "categoryLabelEn": "English category name",
  "categoryLabelTa": "Tamil category name",
  "crop": "Crop name if mentioned or null",
  "variety": "Variety name if mentioned or null",
  "lotOrBatchNumber": "Lot/Batch/Tag/Sample number or null",
  "issuerOrDealer": "Issuing agency, laboratory, or dealer name or null",
  "testingDate": "Testing / invoice date or null",
  "expiryDate": "Expiry / validity date or null",
  "germinationPercent": "Germination % if mentioned or null",
  "purityPercent": "Physical purity % if mentioned or null",
  "moisturePercent": "Moisture % if mentioned or null",
  "chemicalTreatment": "Fungicide / seed dressing warning or null",
  "quantity": "Quantity / weight with units or null",
  "pricePaid": "Price / total amount or null",
  "subsidyDetail": "Government subsidy details or null",
  "summaryEn": "Detailed factual English summary of all data points and obligations in this document",
  "summaryTa": "விரிவான தமிழ் விளக்கம் - விவசாயிக்கான முக்கிய தகவல்கள் மற்றும் பாதுகாப்பு எச்சரிக்கைகள்",
  "keyFindings": [
    {
      "labelEn": "Parameter Name (e.g. Soil pH, Germination Rate)",
      "labelTa": "அளவுருவின் பெயர் (மண் கார அமில நிலை, முளைப்புத் திறன்)",
      "value": "Exact value with unit (e.g. 7.4 pH, 88%)",
      "status": "verified" | "warning" | "info"
    }
  ],
  "extractedFields": [
    {
      "key": "field_key (e.g. pH, available_n, lot_no, price)",
      "labelEn": "Field Name En",
      "labelTa": "Field Name Ta",
      "originalValue": "Raw text value as seen in document",
      "normalizedValue": "Clean numerical or text value",
      "unit": "Measurement unit (e.g. %, kg/ha, dS/m, ₹)",
      "confidence": 0.95,
      "exactSupportingText": "Exact quote from document"
    }
  ],
  "tables": [
    {
      "title": "Table title if present",
      "headers": ["Header1", "Header2"],
      "rows": [["Cell1", "Cell2"]]
    }
  ],
  "soilParameters": {
    "pH": 7.2,
    "ec": 0.35,
    "organicCarbon": 0.58,
    "availableN": 120,
    "availableP": 6.8,
    "availableK": 95,
    "zinc": 0.9,
    "iron": 5.2,
    "sulphur": 11.5,
    "soilType": "Alluvial Clay Loam"
  },
  "fertilizerParameters": {
    "brandName": "IFFCO DAP",
    "grade": "18-46-0",
    "bagWeightKg": 50,
    "nitrogenWeightKg": 9.0,
    "phosphorusWeightKg": 23.0
  },
  "pesticideParameters": {
    "productName": "Tricyclazole 75% WP",
    "activeIngredient": "Tricyclazole",
    "recommendedDosage": "120 g/acre",
    "waitingPeriodDays": 30,
    "cibrcRegNumber": "CIR-11029"
  },
  "seedParameters": {
    "seedClass": "Certified Class 1",
    "germinationPercent": 88,
    "physicalPurityPercent": 98.5,
    "lotNumber": "TN-2024-CR1009"
  },
  "warnings": ["Any warnings, expired dates, or toxic alerts in document"],
  "actionableGuidanceEn": "Concrete next steps for the farmer",
  "actionableGuidanceTa": "விவசாயிக்கான அடுத்த கட்ட கள நடவடிக்கைகள்",
  "suggestedQuestions": [
    {
      "en": "Specific question the farmer can ask about this document?",
      "ta": "இந்த ஆவணம் குறித்து விவசாயி கேட்கக்கூடிய கேள்வி?"
    }
  ]
}`;

  const parts: { text?: string; inlineData?: { mimeType: string; data: string } }[] = [{ text: promptText }];

  if (base64Data && mimeType) {
    const cleanBase64 = base64Data.replace(/^data:[^;]+;base64,/, '');
    parts.push({
      inlineData: {
        mimeType,
        data: cleanBase64,
      },
    });
  }

  const modelsToTry = [
    'gemini-flash-lite-latest',
    'gemini-3.5-flash-lite',
    'gemini-3.5-flash',
    'gemini-2.5-flash',
    'gemini-flash-latest',
    'gemini-3.8-flash',
    'gemini-pro-latest',
  ];

  let lastDocError: unknown = null;

  for (const model of modelsToTry) {
    try {
      usageStats.activeModel = model;
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 35000);

      try {
        const response = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ role: 'user', parts }],
            systemInstruction: { parts: [{ text: systemInstruction }] },
            generationConfig: {
              temperature: 0.1,
              maxOutputTokens: 2500,
              responseMimeType: 'application/json',
            },
          }),
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
          const errJson = await response.json().catch(() => ({}));
          throw new Error(`GEMINI_DOC_ERROR: ${errJson?.error?.message || response.statusText}`);
        }

        const data = await response.json();
        const rawText = data.candidates?.[0]?.content?.parts?.map((p: { text: string }) => p.text).join('') || '';
        let cleanJson = rawText.trim();
        const jsonMatch = cleanJson.match(/```(?:json)?\s*([\s\S]*?)\s*```/) || cleanJson.match(/(\{[\s\S]*\})/);
        if (jsonMatch) {
          cleanJson = jsonMatch[1].trim();
        }
        const parsed: DocumentAnalysisResult = JSON.parse(cleanJson);

        usageStats.successfulRequests++;
        return parsed;
      } catch (callErr: unknown) {
        clearTimeout(timeoutId);
        throw callErr;
      }
    } catch (modelErr: any) {
      lastDocError = modelErr;
      console.warn(`[Gemini Document Analysis Failover] Model "${model}" failed (${modelErr?.message || modelErr}). Trying next candidate...`);
    }
  }

  usageStats.failedRequests++;
  throw new Error(`GEMINI_DOC_ERROR: All candidate models failed. Last error: ${lastDocError instanceof Error ? lastDocError.message : String(lastDocError)}`);
}

/**
 * Answer specific farmer questions grounded directly in an uploaded document
 * Supports THREE INTELLIGENT MODES:
 * Mode A: Document-Only Answering (with exact "not found" honesty if absent)
 * Mode B: Document + Verified Agricultural Knowledge (TNAU / ICAR)
 * Mode C: General Agricultural Questions (answers cleanly without forcing document)
 */
export async function callGeminiDocumentQa(
  documentText: string,
  question: string,
  fileName = 'document',
  lang: 'ta' | 'en' = 'en'
): Promise<string> {
  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    throw new Error(
      'GEMINI_KEY_NOT_CONFIGURED: Google Gemini API key is not configured on the server. Please set GEMINI_API_KEY in your environment variables.'
    );
  }

  const isTa = lang === 'ta';

  const systemInstruction = `You are AgriKnow AI - Senior Agricultural Document Intelligence Specialist.
The farmer has uploaded an agricultural document named "${fileName}".
You are an intelligent, warm, conversational agricultural expert (like ChatGPT / Gemini).

HOW TO ANSWER:
1. Natural & Direct:
   - Answer the farmer's question in a natural, fluid, and helpful tone.
   - Do NOT output rigid robotic category labels like "MODE A" or "MODE B" or "DOCUMENT-ONLY ANSWERING".
2. Document Precision:
   - When the farmer asks about specific facts, numbers, crop variety, lot number, germination %, expiry date, purity, or prices from the uploaded document, state the exact facts clearly and accurately.
   - If a specific piece of information is NOT present in the document, state honestly that this detail is not mentioned in the uploaded file, without inventing data.
3. Beyond the Document (Actionable Agronomic Guidance):
   - When the farmer asks questions that go beyond the document (e.g. sowing methods, precautions, fertilizer schedules, soil suitability, seed treatment, storage, or legal protections), provide deep, expert, university-backed agricultural guidance (TNAU & ICAR standards) tailored to the crop and variety in the document.
4. Language:
   - Answer 100% in ${isTa ? 'Tamil (தமிழ்)' : 'English'}. Match the farmer's language fluently.`;

  const promptText = `Uploaded Document Content (${fileName}):
---
${documentText.slice(0, 12000)}
---

Farmer's Question: "${question}"`;

  const result = await callGeminiText({
    prompt: promptText,
    systemInstruction,
    temperature: 0.1,
    maxOutputTokens: 2000,
  });

  return result.text;
}

/**
 * Cross-Document Comparative Intelligence Engine
 * Compares two or three agricultural documents (e.g. Previous Soil Report vs Current Soil Report,
 * or Soil Health Card vs Fertilizer Bill) computing parameter deltas and agronomic alignment.
 */
export async function callGeminiDocumentComparison(
  doc1: { name: string; text: string },
  doc2: { name: string; text: string },
  doc3?: { name: string; text: string },
  question?: string,
  lang: 'ta' | 'en' = 'en'
): Promise<string> {
  const apiKey = getGeminiApiKey();
  if (!apiKey) {
    throw new Error('GEMINI_KEY_NOT_CONFIGURED: Google Gemini API key is not configured.');
  }

  const isTa = lang === 'ta';

  const systemInstruction = `You are AGRIKNOW AI Cross-Document Intelligence Architect.
You compare multiple uploaded agricultural documents (e.g. Previous Soil Test vs Current Soil Test, or Soil Health Card vs Fertilizer Purchase Bill).

Your task:
1. Extract parameters from each document and compute exact differences (deltas).
2. For temporal comparisons (e.g. Soil Test 2024 vs Soil Test 2026): identify parameters that improved (e.g. Organic Carbon increase), degraded (e.g. acidification pH drop), or remained stable.
3. For Soil vs Fertilizer purchase comparisons: verify whether the purchased fertilizers (e.g. Urea, DAP, MOP) align with the soil report's deficits or whether the farmer over-purchased nutrients already in excess.
4. Highlight missing, inconsistent, or suspicious information.
5. Provide actionable, evidence-based recommendations citing the document names.
6. Language: Output comprehensive analysis in ${isTa ? 'Tamil (தமிழ்)' : 'English'}.`;

  const prompt = `Compare these agricultural documents:

Document 1: ${doc1.name}
---
${doc1.text.slice(0, 6000)}
---

Document 2: ${doc2.name}
---
${doc2.text.slice(0, 6000)}
---
${doc3 ? `\nDocument 3: ${doc3.name}\n---\n${doc3.text.slice(0, 6000)}\n---\n` : ''}

${question ? `Farmer's Specific Comparison Question: "${question}"` : 'Provide full cross-document parameter delta comparison, soil fertility trajectory, and fertilizer purchase alignment analysis.'}`;

  const result = await callGeminiText({
    prompt,
    systemInstruction,
    temperature: 0.1,
    maxOutputTokens: 2500,
  });

  return result.text;
}
