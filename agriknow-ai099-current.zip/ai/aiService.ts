import { apiConfig } from './apiConfig';
import type { AiAnswerResult } from '@/types';
import type { Lang } from '@/lib/i18n';
import { executeAdvancedRag } from './rag/advancedRagEngine';
import { assistantRateLimiter } from '@/utils/rateLimiter';
import { sanitizeInputText } from '@/utils/security';
import { logger } from '@/services/telemetry/logger';
import { matchSchemeForQuery } from './schemesService';
import { buildPersonalizedContextPrompt } from './personalizationService';
import { getActiveAnalyzedDocument } from './documentAnalyzerService';

/**
 * AGRIKNOW AI - Primary Agricultural Intelligence Assistant
 * Directly invokes Google Gemini via the backend AI orchestrator with grounded RAG retrieval.
 * Zero hardcoded canned responses.
 */
export async function askAgriAssistant(
  question: string,
  lang: Lang,
  history?: { role: 'user' | 'assistant'; text: string }[]
): Promise<AiAnswerResult> {
  const isTa = lang === 'ta';

  // 1. Client-Side Rate Limiter Check (Max 15 queries/min)
  const rateCheck = assistantRateLimiter.checkLimit();
  if (!rateCheck.allowed) {
    logger.warn('Security', 'Rate limit exceeded for farmer assistant query');
    return {
      text: isTa
        ? `⚠️ **பாதுகாப்பு அறிவிப்பு:** குறுகிய நேரத்தில் அதிக வினவல்கள் கேட்கப்பட்டுள்ளன. தயவுசெய்து ${rateCheck.retryAfterSeconds} வினாடிகள் காத்திருந்து மீண்டும் கேட்கவும்.`
        : `⚠️ **Rate Limit Notice:** Too many queries in short succession. Please wait ${rateCheck.retryAfterSeconds} seconds before sending another question.`,
      sourceIds: [],
      isLiveBackend: false,
      provider: 'AGRIKNOW Rate Limiter',
      confidence: 1.0,
      isError: true,
      retryable: true,
    };
  }

  // 2. Production Input Sanitization
  const cleanQuestion = sanitizeInputText(question, 800);
  const trimmed = cleanQuestion || question.trim();

  logger.info('Assistant', `Processing farmer query [${lang}] (length: ${trimmed.length})`);

  // 3. Government Scheme Fast Resolution (Official Schemes DB)
  const schemeMatch = matchSchemeForQuery(trimmed, lang);
  if (schemeMatch.found && schemeMatch.summary) {
    return {
      text: schemeMatch.summary,
      sourceIds: [schemeMatch.scheme?.id || 'scheme-pm-kisan'],
      isLiveBackend: false,
      provider: 'Verified Govt Portal / Ministry of Agriculture',
      confidence: 0.99,
      suggestedFollowUps: [
        { en: 'How to apply for this scheme online?', ta: 'இந்த திட்டத்திற்கு ஆன்லைனில் விண்ணப்பிப்பது எப்படி?' },
        { en: 'What documents are required at the local CSC center?', ta: 'இ-சேவை மையத்தில் சமர்ப்பிக்க வேண்டிய ஆவணங்கள் என்ன?' },
      ],
    };
  }

  // 4. Grounded Hybrid RAG Retrieval (Dense Embeddings + BM25 + Cross-Encoder)
  const personalContext = buildPersonalizedContextPrompt(lang);
  const contextualizedQuery = personalContext ? `${trimmed} ${personalContext}` : trimmed;
  const ragResponse = await executeAdvancedRag(contextualizedQuery, lang, history);

  // If query is explicitly non-agricultural (e.g. TC-8: solar inverter circuit repair, crypto, car engine) -> Honest refusal guardrail
  if (ragResponse.isAbstained) {
    return {
      text: ragResponse.answerText,
      sourceIds: [],
      isLiveBackend: false,
      provider: ragResponse.provider,
      confidence: ragResponse.confidence,
      ragTrace: ragResponse.trace,
      suggestedFollowUps: ragResponse.suggestedFollowUps,
    };
  }

  // 5. Construct Grounded Context from Verified Passages & Active Document
  const activeDoc = getActiveAnalyzedDocument();
  const contextPassages = ragResponse.evidenceList
    .map(
      (e, idx) =>
        `[Document ${idx + 1}]: "${e.documentTitle}" (Page ${e.pageNumber || 1}, ${e.sourceInstitution}):\n${e.excerpt}`
    )
    .join('\n\n');

  // Format conversational turns for backend (last 6 turns, avoiding crosstalk)
  const formattedHistory = (history || []).slice(-6).map((turn) => ({
    role: turn.role,
    text: turn.text,
  }));

  // 6. Invoke Real Backend Gemini AI Orchestrator (/api/ai/ask)
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 25000);

    const response = await fetch(apiConfig.aiAskEndpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        question: trimmed,
        language: lang,
        history: formattedHistory,
        context: contextPassages,
        documentContext: activeDoc
          ? {
              id: activeDoc.id,
              title: activeDoc.fileName || 'Uploaded Document',
              category: activeDoc.category,
              crop: activeDoc.crop,
              variety: activeDoc.variety,
              lotOrBatchNumber: activeDoc.lotOrBatchNumber,
              germinationPercent: activeDoc.germinationPercent,
              rawText: activeDoc.rawText ? activeDoc.rawText.slice(0, 3000) : '',
            }
          : null,
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (response.ok) {
      const data = await response.json();
      return {
        text: data.answer,
        sourceIds: ragResponse.sourceIds.length > 0 ? ragResponse.sourceIds : ['tnau-blast'],
        isLiveBackend: true,
        provider: data.provider || 'Google Gemini 1.5 Flash (Grounded RAG)',
        confidence: 0.95,
        ragTrace: ragResponse.trace,
        suggestedFollowUps: ragResponse.suggestedFollowUps,
      };
    } else {
      const errData = await response.json().catch(() => ({}));
      const isMissingKey = errData?.error === 'GEMINI_KEY_NOT_CONFIGURED';

      if (isMissingKey) {
        return {
          text: isTa
            ? `⚠️ **AgriKnow AI நுண்ணறிவுச் சேவை அறிவிப்பு:**\n\nவழங்கியில் கூகுள் Gemini API சாவி (\`GEMINI_API_KEY\`) உள்ளமைக்கப்படவில்லை.\n\nநேரடி செயற்கை நுண்ணறிவுப் பகுப்பாய்வு மற்றும் பல்நோக்கு பட ஆய்வை இயக்க, சர்வர் சூழல் மாறிகளில் (Environment Variables) \`GEMINI_API_KEY\`-ஐ அமைக்கவும்.`
            : `⚠️ **AgriKnow AI Intelligence Service Notice:**\n\nThe Google Gemini API key (\`GEMINI_API_KEY\`) is not configured in the server environment.\n\nTo enable real-time dynamic AI reasoning, contextual responses, and multimodal diagnosis, please set \`GEMINI_API_KEY\` in your environment variables.`,
          sourceIds: ragResponse.sourceIds,
          isLiveBackend: false,
          provider: 'Configuration Required (GEMINI_API_KEY)',
          confidence: 0.0,
          isError: true,
          retryable: true,
          ragTrace: ragResponse.trace,
        };
      }

      throw new Error(errData?.message || `Server returned HTTP ${response.status}`);
    }
  } catch (netErr: unknown) {
    const errorMsg = netErr instanceof Error ? netErr.message : String(netErr);
    logger.error('Assistant', 'Backend Gemini call failed', netErr);

    return {
      text: isTa
        ? `⚠️ **இணைப்புப் பிழை:** செயற்கை நுண்ணறிவுச் சேவையைத் தொடர்புகொள்ள முடியவில்லை (${errorMsg}). தயவுசெய்து உங்கள் இணைய இணைப்பைச் சரிபார்த்துவிட்டு மீண்டும் முயற்சிக்கவும்.`
        : `⚠️ **Communication Error:** Could not reach the Gemini reasoning service (${errorMsg}). Please verify your connection and click 'Retry'.`,
      sourceIds: [],
      isLiveBackend: false,
      provider: 'Service Error',
      confidence: 0,
      isError: true,
      retryable: true,
      ragTrace: ragResponse.trace,
    };
  }
}
