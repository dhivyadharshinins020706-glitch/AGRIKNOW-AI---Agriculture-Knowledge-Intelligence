import type { DocumentChunk, IngestionOptions } from '../types/ingestion';

/**
 * Meaningful semantic chunker with boundary detection and configurable overlap.
 * Splits on paragraphs, sentence endings, or list items rather than cutting words in half.
 * Preserves complete traceability (documentId, pageNumber, character spans, crop, region).
 */

export function chunkDocumentText(
  documentId: string,
  documentTitle: string,
  pages: { pageNumber: number; cleanedText: string }[],
  options: IngestionOptions
): DocumentChunk[] {
  const chunks: DocumentChunk[] = [];
  let chunkGlobalIndex = 0;

  const targetSize = Math.max(200, options.chunkSize || 650);
  const overlap = Math.min(Math.floor(targetSize * 0.4), Math.max(0, options.chunkOverlap || 120));

  pages.forEach((page) => {
    const text = page.cleanedText;
    if (!text || text.trim().length === 0) return;

    // Split text into semantic segments (paragraphs, bullet points, or sentences)
    const rawParagraphs = text.split(/\n\n+/);
    const segments: string[] = [];

    rawParagraphs.forEach((p) => {
      const trimmed = p.trim();
      if (!trimmed) return;

      if (trimmed.length <= targetSize) {
        segments.push(trimmed);
      } else {
        // Sub-split by sentences
        const sentences = trimmed.match(/[^.!?।\n]+[.!?।\n]+|[^.!?।\n]+$/g) || [trimmed];
        let buffer = '';
        sentences.forEach((sent) => {
          if (buffer.length + sent.length <= targetSize) {
            buffer += (buffer ? ' ' : '') + sent.trim();
          } else {
            if (buffer) segments.push(buffer);
            buffer = sent.trim();
          }
        });
        if (buffer) segments.push(buffer);
      }
    });

    // Assemble segments into chunks respecting targetSize and overlap
    let currentChunk = '';
    let startCharIdx = 0;

    for (let i = 0; i < segments.length; i++) {
      const seg = segments[i];

      if (currentChunk.length === 0) {
        currentChunk = seg;
      } else if (currentChunk.length + seg.length + 1 <= targetSize) {
        currentChunk += '\n\n' + seg;
      } else {
        // Finalize current chunk
        const chunkContent = currentChunk.trim();
        if (chunkContent.length > 20) {
          chunks.push({
            id: `chunk-${documentId}-${chunkGlobalIndex}`,
            documentId,
            documentTitle,
            chunkIndex: chunkGlobalIndex++,
            pageNumber: page.pageNumber,
            crop: options.targetCrops[0] || 'General Agriculture',
            topic: options.primaryTopic || options.category,
            region: 'Tamil Nadu',
            language: options.language,
            sourceInstitution: options.institution,
            content: chunkContent,
            tokenCount: Math.ceil(chunkContent.length / 4), // Standard ~4 chars per token rule
            charStart: startCharIdx,
            charEnd: startCharIdx + chunkContent.length,
            createdAt: new Date().toISOString(),
          });
        }

        // Apply overlap for the next chunk
        if (overlap > 0 && currentChunk.length > overlap) {
          const overlapText = currentChunk.slice(currentChunk.length - overlap);
          currentChunk = overlapText + ' ' + seg;
        } else {
          currentChunk = seg;
        }
        startCharIdx += chunkContent.length;
      }
    }

    // Push the remaining buffer for the page
    if (currentChunk.trim().length > 20) {
      const chunkContent = currentChunk.trim();
      chunks.push({
        id: `chunk-${documentId}-${chunkGlobalIndex}`,
        documentId,
        documentTitle,
        chunkIndex: chunkGlobalIndex++,
        pageNumber: page.pageNumber,
        crop: options.targetCrops[0] || 'General Agriculture',
        topic: options.primaryTopic || options.category,
        region: 'Tamil Nadu',
        language: options.language,
        sourceInstitution: options.institution,
        content: chunkContent,
        tokenCount: Math.ceil(chunkContent.length / 4),
        charStart: startCharIdx,
        charEnd: startCharIdx + chunkContent.length,
        createdAt: new Date().toISOString(),
      });
    }
  });

  return chunks;
}
