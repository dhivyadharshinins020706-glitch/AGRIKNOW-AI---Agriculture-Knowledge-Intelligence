/**
 * Agricultural text cleaner and conflict detector.
 * Normalizes agronomic text, removes noise headers/footers, and scans for outdated/conflicting guidance.
 */

export interface CleaningReport {
  cleanedText: string;
  hasConflicts: boolean;
  conflictNotes?: string;
  wordCount: number;
}

// Banned chemicals or hazardous compounds in Indian agriculture flagged for human agronomist review
const BANNED_CHEMICAL_TRIGGERS = [
  'monocrotophos',
  'endosulfan',
  'carbofuran',
  'methomyl',
  'triazophos',
  'paraquat',
  'phorate',
];

export function cleanAgriculturalText(rawText: string, pageNumber: number): CleaningReport {
  let text = rawText;

  // 1. Remove common PDF header/footer noise and page markings
  text = text.replace(/Page\s+\d+\s+of\s+\d+/gi, '');
  text = text.replace(/Page\s+\d+/gi, '');
  text = text.replace(/TNAU\s+Agritech\s+Portal/gi, '');
  text = text.replace(/ICAR\s+Publication\s+Series/gi, '');
  text = text.replace(/Government\s+of\s+Tamil\s+Nadu\s+-\s+Department\s+of\s+Agriculture/gi, '');

  // 2. Fix hyphenated line breaks (e.g. "insec-\nticide" -> "insecticide")
  text = text.replace(/([a-zA-Z\u0B80-\u0BFF]+)-\s*[\r\n]+\s*([a-zA-Z\u0B80-\u0BFF]+)/g, '$1$2');

  // 3. Normalize multiple whitespace and carriage returns
  text = text.replace(/\r\n/g, '\n');
  text = text.replace(/\r/g, '\n');
  text = text.replace(/[ \t]+/g, ' ');
  text = text.replace(/\n{3,}/g, '\n\n');

  // 4. Strip control characters except newline and tab
  // eslint-disable-next-line no-control-regex
  text = text.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');

  const cleanedText = text.trim();

  // 5. Detect conflicting or banned agricultural recommendations
  const lower = cleanedText.toLowerCase();
  const flaggedChemicals = BANNED_CHEMICAL_TRIGGERS.filter((chem) => lower.includes(chem));

  const hasConflicts = flaggedChemicals.length > 0;
  let conflictNotes: string | undefined;

  if (hasConflicts) {
    conflictNotes = `Page ${pageNumber} contains reference to restricted/banned chemical(s): ${flaggedChemicals.join(
      ', '
    )}. Requires agronomist review before publishing to live AI context.`;
  }

  const wordCount = cleanedText.length > 0 ? cleanedText.split(/\s+/).length : 0;

  return {
    cleanedText,
    hasConflicts,
    conflictNotes,
    wordCount,
  };
}
