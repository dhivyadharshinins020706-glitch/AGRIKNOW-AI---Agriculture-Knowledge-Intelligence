/**
 * Multilingual Semantic Embedding Generator and Vector Similarity Engine.
 * Generates unit-normalized 128-dimensional dense vectors from Tamil & English agricultural text.
 * Suitable for pgvector (FLOAT8[] / vector(128)) and vector database ingestion (Qdrant, Pinecone).
 */

const VECTOR_DIM = 128;

/**
 * Computes deterministic 32-bit hash of a token string.
 */
function hashString(str: string, seed = 0): number {
  let h1 = 0xdeadbeef ^ seed;
  let h2 = 0x41c6ce57 ^ seed;
  for (let i = 0; i < str.length; i++) {
    const ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return 4294967296 * (2097151 & h2) + (h1 >>> 0);
}

/**
 * Extracts subword n-grams and tokens from Tamil and English text.
 */
function extractFeatures(text: string): string[] {
  const normalized = text.toLowerCase().trim();
  const words = normalized.split(/[\s,.;:!?()[\]"'/\\-]+/).filter((w) => w.length > 1);

  const features: string[] = [...words];

  // Character 3-grams for morphology and subword matching (especially effective for Tamil inflections)
  words.forEach((w) => {
    if (w.length >= 3) {
      for (let i = 0; i <= w.length - 3; i++) {
        features.push(w.slice(i, i + 3));
      }
    }
  });

  return features;
}

/**
 * Generates an L2-normalized 128-dimensional embedding vector for a piece of text.
 */
export function generateEmbeddingVector(text: string): number[] {
  const vector = new Float32Array(VECTOR_DIM);
  const features = extractFeatures(text);

  if (features.length === 0) {
    return Array.from(vector);
  }

  // Feature hashing with term frequency
  features.forEach((feat) => {
    const h = hashString(feat);
    const index = Math.abs(h) % VECTOR_DIM;
    const sign = (h & 0x80000000) === 0 ? 1.0 : -1.0;
    vector[index] += sign * 1.0;
  });

  // Calculate L2 Norm
  let sumSq = 0;
  for (let i = 0; i < VECTOR_DIM; i++) {
    sumSq += vector[i] * vector[i];
  }

  const norm = Math.sqrt(sumSq) || 1.0;

  // Normalize to unit length: ||v|| = 1.0
  const normalizedVector: number[] = [];
  for (let i = 0; i < VECTOR_DIM; i++) {
    normalizedVector.push(parseFloat((vector[i] / norm).toFixed(6)));
  }

  return normalizedVector;
}

/**
 * Calculates Cosine Similarity between two unit-normalized embedding vectors.
 * Since both vectors are L2 normalized, cosine similarity is simply the dot product.
 * Returns a value in [-1.0, 1.0].
 */
export function cosineSimilarity(vecA: number[], vecB: number[]): number {
  if (!vecA || !vecB || vecA.length !== vecB.length) return 0;

  let dotProduct = 0;
  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
  }

  return Math.max(-1.0, Math.min(1.0, dotProduct));
}
