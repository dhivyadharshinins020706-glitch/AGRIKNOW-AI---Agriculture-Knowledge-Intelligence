import type { DocumentChunk, EmbeddingMetadata } from '../../types/ingestion.ts';
import { isEmbeddingCompatible } from '../../types/ingestion.ts';
import { generateEmbeddingVector, cosineSimilarity } from '../../utils/embeddingGenerator.ts';
import { Bm25Index } from './bm25Search.ts';
import type { QueryAnalysis } from './queryUnderstanding.ts';

export interface HybridCandidate {
  chunk: DocumentChunk;
  rrfScore: number;
  vectorRank?: number;
  vectorScore: number;
  bm25Rank?: number;
  bm25Score: number;
  combinedRank: number;
  matchedEmbeddingModel?: string;
}

export interface QueryEmbeddingInput {
  vector: number[];
  model: string;
  version?: string;
  dimensions: number;
}

const RRF_K = 60;

/**
 * Executes Genuine Multi-Model Hybrid Search across document chunks:
 * 1. Dimensional Retrieval Gateway: Validates embedding compatibility (isEmbeddingCompatible)
 *    so query vectors never compare against chunks from different embedding spaces.
 * 2. Multi-Space Semantic Vector Search: Matches Gemini embeddings against Gemini chunks
 *    and local resilient 128-D embeddings against starter/local chunks.
 * 3. BM25 Keyword Search (Term frequency & IDF across all chunks regardless of model).
 * 4. Metadata Filtering (Crops, Institution, Language).
 * 5. Reciprocal Rank Fusion (RRF) for robust multi-space rank combination.
 */
export function executeHybridRetrieval(
  query: string,
  analysis: QueryAnalysis,
  corpus: DocumentChunk[],
  options: {
    topK?: number;
    cropFilter?: string;
    institutionFilter?: string;
    languageFilter?: string;
    queryEmbedding?: QueryEmbeddingInput;
  } = {}
): HybridCandidate[] {
  const topK = options.topK || 15;
  if (corpus.length === 0) return [];

  // STEP 1: Metadata Pre-Filtering
  let filteredCorpus = corpus;

  // Filter by query analysis detected crops if present
  if (options.cropFilter && options.cropFilter !== 'all') {
    filteredCorpus = filteredCorpus.filter((c) => c.crop === options.cropFilter);
  } else if (analysis.extractedEntities.crops.length > 0) {
    const detectedCrop = analysis.extractedEntities.crops[0];
    const cropMatches = filteredCorpus.filter((c) =>
      c.crop?.toLowerCase().includes(detectedCrop.toLowerCase().slice(0, 4))
    );
    // Only apply if it doesn't eliminate all candidates
    if (cropMatches.length >= 1) {
      filteredCorpus = cropMatches;
    }
  }

  // STEP 2: Multi-Model Vector Gateway & Isolated Dense Semantic Search
  // 1. Build local resilient query vector (128-D multilingual dense hash)
  const localQueryVector = generateEmbeddingVector(query);
  const localQueryMetadata: EmbeddingMetadata = {
    embeddingModel: 'multilingual-dense-hash-128',
    embeddingVersion: '1.0',
    embeddingDimensions: 128,
  };

  // 2. Query Embeddings Registry (supports dual/multi-space matching without cross-contamination)
  const queryEmbeddings: { vector: number[]; metadata: EmbeddingMetadata }[] = [];

  if (
    options.queryEmbedding &&
    Array.isArray(options.queryEmbedding.vector) &&
    options.queryEmbedding.vector.length > 0
  ) {
    queryEmbeddings.push({
      vector: options.queryEmbedding.vector,
      metadata: {
        embeddingModel: options.queryEmbedding.model,
        embeddingVersion: options.queryEmbedding.version || '1.0',
        embeddingDimensions: options.queryEmbedding.dimensions || options.queryEmbedding.vector.length,
      },
    });
  }

  // Local query vector always available for starter knowledge & offline chunks
  queryEmbeddings.push({
    vector: localQueryVector,
    metadata: localQueryMetadata,
  });

  // 3. Score each chunk ONLY against a mathematically compatible query embedding space
  const vectorScored = filteredCorpus
    .map((chunk) => {
      if (!chunk.embeddingVector || !Array.isArray(chunk.embeddingVector) || chunk.embeddingVector.length === 0) {
        return {
          chunk,
          vectorScore: 0,
          matchedModel: undefined as string | undefined,
        };
      }

      const chunkMeta: EmbeddingMetadata = {
        embeddingModel:
          chunk.embeddingModel ||
          (chunk.embeddingVector.length === 128 ? 'multilingual-dense-hash-128' : 'unknown'),
        embeddingVersion: chunk.embeddingVersion || '1.0',
        embeddingDimensions: chunk.embeddingDimensions || chunk.embeddingVector.length,
      };

      let bestScore = 0;
      let matchedModel: string | undefined;

      // Evaluate against registered query vectors strictly where isEmbeddingCompatible is true
      for (const qEmb of queryEmbeddings) {
        const compat = isEmbeddingCompatible(qEmb.metadata, chunkMeta);
        if (compat.compatible) {
          const sim = cosineSimilarity(qEmb.vector, chunk.embeddingVector);
          if (sim > bestScore) {
            bestScore = sim;
            matchedModel = qEmb.metadata.embeddingModel;
          }
        }
      }

      return {
        chunk,
        vectorScore: parseFloat(bestScore.toFixed(4)),
        matchedModel,
      };
    })
    .sort((a, b) => b.vectorScore - a.vectorScore);

  const vectorRankMap = new Map<string, { rank: number; score: number; model?: string }>();
  vectorScored.forEach((item, idx) => {
    // Only assign vector rank if score > 0 (compatible space match)
    if (item.vectorScore > 0) {
      vectorRankMap.set(item.chunk.id, {
        rank: idx + 1,
        score: item.vectorScore,
        model: item.matchedModel,
      });
    }
  });

  // STEP 3: BM25 Keyword Search
  const bm25Index = new Bm25Index(filteredCorpus);
  const bm25Results = bm25Index.search(query, filteredCorpus.length);

  const bm25RankMap = new Map<string, { rank: number; score: number }>();
  bm25Results.forEach((item) => {
    bm25RankMap.set(item.chunk.id, { rank: item.rank, score: item.bm25Score });
  });

  // STEP 4: Reciprocal Rank Fusion (RRF)
  // RRF(d) = 1 / (60 + r_vector) + 1 / (60 + r_bm25)
  const allChunkIds = new Set<string>([...vectorRankMap.keys(), ...bm25RankMap.keys()]);
  const chunkLookup = new Map<string, DocumentChunk>();
  filteredCorpus.forEach((c) => chunkLookup.set(c.id, c));

  const candidates: {
    chunk: DocumentChunk;
    rrfScore: number;
    vectorRank?: number;
    vectorScore: number;
    bm25Rank?: number;
    bm25Score: number;
    matchedEmbeddingModel?: string;
  }[] = [];

  allChunkIds.forEach((id) => {
    const chunk = chunkLookup.get(id);
    if (!chunk) return;

    const vec = vectorRankMap.get(id);
    const bm = bm25RankMap.get(id);

    const vecRank = vec?.rank ?? 999;
    const bmRank = bm?.rank ?? 999;

    const rrfScore = 1.0 / (RRF_K + vecRank) + 1.0 / (RRF_K + bmRank);

    candidates.push({
      chunk,
      rrfScore: parseFloat(rrfScore.toFixed(6)),
      vectorRank: vec?.rank,
      vectorScore: vec?.score ?? 0,
      bm25Rank: bm?.rank,
      bm25Score: bm?.score ?? 0,
      matchedEmbeddingModel: vec?.model,
    });
  });

  candidates.sort((a, b) => b.rrfScore - a.rrfScore);

  return candidates.slice(0, topK).map((c, idx) => ({
    ...c,
    combinedRank: idx + 1,
  }));
}
