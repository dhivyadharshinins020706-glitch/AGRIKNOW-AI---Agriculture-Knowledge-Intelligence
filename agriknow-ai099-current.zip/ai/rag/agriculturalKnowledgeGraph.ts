/**
 * Agricultural Knowledge Graph (Graph RAG).
 * Stores relational ontological links between Crops, Diseases, Pests, Symptoms, Nutrients, Treatments, and Regions.
 * Every edge and node preserves university source citations and page references.
 */

export type EntityType =
  | 'crop'
  | 'disease'
  | 'pest'
  | 'symptom'
  | 'nutrient'
  | 'fertilizer'
  | 'treatment'
  | 'region';

export type RelationType =
  | 'AFFECTED_BY'
  | 'EXHIBITS_SYMPTOM'
  | 'REQUIRES_NUTRIENT'
  | 'SUPPLIED_BY'
  | 'TREATED_BY'
  | 'PREVALENT_IN'
  | 'MANAGED_BY_PRACTICE';

export interface GraphNode {
  id: string;
  name: string;
  nameTa: string;
  type: EntityType;
  description: string;
  sourceDocId: string;
  pageNumber: number;
}

export interface GraphEdge {
  sourceId: string;
  targetId: string;
  relation: RelationType;
  description: string;
  descriptionTa: string;
  confidence: number;
  sourceDocId: string;
  pageNumber: number;
}

export interface TraversalResult {
  nodes: GraphNode[];
  edges: GraphEdge[];
  relationalContext: string[];
  relationalContextTa: string[];
}

export const agriculturalNodes: GraphNode[] = [
  // Crops
  {
    id: 'crop_paddy',
    name: 'Paddy / Rice',
    nameTa: 'நெல்',
    type: 'crop',
    description: 'Staple grain of Tamil Nadu, extensively cultivated in Cauvery Delta.',
    sourceDocId: 'doc-tnau-paddy-sri',
    pageNumber: 1,
  },
  {
    id: 'crop_cotton',
    name: 'Cotton',
    nameTa: 'பருத்தி',
    type: 'crop',
    description: 'Major fiber cash crop of western and southern Tamil Nadu.',
    sourceDocId: 'doc-icar-cotton-ipm',
    pageNumber: 1,
  },
  {
    id: 'crop_groundnut',
    name: 'Groundnut',
    nameTa: 'நிலக்கடலை',
    type: 'crop',
    description: 'Oilseed crop requiring high soil calcium during pod filling.',
    sourceDocId: 'doc-tnau-groundnut-gypsum',
    pageNumber: 1,
  },
  {
    id: 'crop_sugarcane',
    name: 'Sugarcane',
    nameTa: 'கரும்பு',
    type: 'crop',
    description: 'Heavy feeder crop requiring drip fertigation and ratoon management.',
    sourceDocId: 'doc-tnau-sugarcane-fertigation',
    pageNumber: 1,
  },
  {
    id: 'crop_banana',
    name: 'Banana',
    nameTa: 'வாழை',
    type: 'crop',
    description: 'Perennial fruit crop susceptible to Sigatoka leaf spot.',
    sourceDocId: 'doc-icar-banana-sigatoka',
    pageNumber: 1,
  },
  {
    id: 'crop_maize',
    name: 'Maize',
    nameTa: 'மக்காச்சோளம்',
    type: 'crop',
    description: 'Cereal crop vulnerable to invasive Fall Armyworm.',
    sourceDocId: 'doc-tnau-maize-faw',
    pageNumber: 1,
  },

  // Diseases & Pests
  {
    id: 'disease_blast',
    name: 'Rice Blast (Magnaporthe oryzae)',
    nameTa: 'நெல் குலை நோய்',
    type: 'disease',
    description: 'Fungal blast disease forming spindle-shaped lesions with brown margins.',
    sourceDocId: 'doc-tnau-paddy-sri',
    pageNumber: 12,
  },
  {
    id: 'pest_stem_borer',
    name: 'Yellow Stem Borer (Scirpophaga incertulas)',
    nameTa: 'மஞ்சள் தண்டு துளைப்பான்',
    type: 'pest',
    description: 'Lepidopteran borer causing dead hearts in tillering and white ears at heading.',
    sourceDocId: 'doc-tnau-paddy-sri',
    pageNumber: 14,
  },
  {
    id: 'pest_bollworm',
    name: 'Cotton Bollworm (Helicoverpa armigera)',
    nameTa: 'பருத்தி காய்ப்புழு',
    type: 'pest',
    description: 'Voracious boll feeder causing flared squares and internal boll rot.',
    sourceDocId: 'doc-icar-cotton-ipm',
    pageNumber: 4,
  },
  {
    id: 'disease_tikka',
    name: 'Tikka Leaf Spot (Cercospora)',
    nameTa: 'டிக்கா இலைப்புள்ளி நோய்',
    type: 'disease',
    description: 'Fungal leaf spot reducing groundnut photosynthetic area.',
    sourceDocId: 'doc-tnau-groundnut-gypsum',
    pageNumber: 9,
  },
  {
    id: 'disease_sigatoka',
    name: 'Banana Sigatoka Leaf Spot (Mycosphaerella)',
    nameTa: 'வாழை சிகடோகா இலைப்புள்ளி',
    type: 'disease',
    description: 'Fungal disease causing streaks and necrosis on banana leaves.',
    sourceDocId: 'doc-icar-banana-sigatoka',
    pageNumber: 6,
  },
  {
    id: 'pest_fall_armyworm',
    name: 'Fall Armyworm (Spodoptera frugiperda)',
    nameTa: 'மக்காச்சோளப் படைப்புழு',
    type: 'pest',
    description: 'Invasive pest boring into maize whorls with characteristic window pane damage.',
    sourceDocId: 'doc-tnau-maize-faw',
    pageNumber: 5,
  },

  // Symptoms
  {
    id: 'symptom_spindle_lesions',
    name: 'Spindle-shaped Leaf Spots',
    nameTa: 'கதிர் போன்ற மையப் புள்ளிகள்',
    type: 'symptom',
    description: 'Diamond or spindle shaped lesions with grey centers and brown borders.',
    sourceDocId: 'doc-tnau-paddy-sri',
    pageNumber: 12,
  },
  {
    id: 'symptom_dead_heart',
    name: 'Dead Heart in Central Tiller',
    nameTa: 'குருத்து காய்வு',
    type: 'symptom',
    description: 'Central leaf shoot turns yellow, dries up, and pulls out easily.',
    sourceDocId: 'doc-tnau-paddy-sri',
    pageNumber: 14,
  },
  {
    id: 'symptom_pop_pods',
    name: 'Pop Pods / Hollow Groundnut Shells',
    nameTa: 'பொக்கு காய் / பருப்பற்ற காய்கள்',
    type: 'symptom',
    description: 'Groundnut pods fail to develop kernels due to calcium deficiency.',
    sourceDocId: 'doc-tnau-groundnut-gypsum',
    pageNumber: 5,
  },
  {
    id: 'symptom_window_panes',
    name: 'Window Pane Whorl Feeding',
    nameTa: 'இலைகளில் ஜன்னல் போன்ற துளைகள்',
    type: 'symptom',
    description: 'Papery translucent leaf patches followed by ragged whorl holes with frass.',
    sourceDocId: 'doc-tnau-maize-faw',
    pageNumber: 5,
  },

  // Nutrients & Amendments
  {
    id: 'nutrient_calcium',
    name: 'Calcium (Ca)',
    nameTa: 'கால்சியம்',
    type: 'nutrient',
    description: 'Crucial for cell wall formation, groundnut pod kernel development.',
    sourceDocId: 'doc-tnau-groundnut-gypsum',
    pageNumber: 5,
  },
  {
    id: 'nutrient_potassium',
    name: 'Potassium / Potash (K)',
    nameTa: 'சாம்பல் சத்து / பொட்டாஷ்',
    type: 'nutrient',
    description: 'Improves disease resistance and bunch weight in banana and sugarcane.',
    sourceDocId: 'doc-icar-banana-sigatoka',
    pageNumber: 8,
  },
  {
    id: 'fertilizer_gypsum',
    name: 'Agricultural Gypsum (CaSO4.2H2O)',
    nameTa: 'விவசாய ஜிப்சம்',
    type: 'fertilizer',
    description: 'Supplies 23% Calcium and 18% Sulphur; applied at 40-45 DAS in groundnut.',
    sourceDocId: 'doc-tnau-groundnut-gypsum',
    pageNumber: 5,
  },

  // Treatments & Controls
  {
    id: 'treatment_tricyclazole',
    name: 'Tricyclazole 75% WP',
    nameTa: 'ட்ரைசைக்ளசோல் 75% WP',
    type: 'treatment',
    description: 'Systemic fungicide specific for blast prevention; 120 g/acre.',
    sourceDocId: 'doc-tnau-paddy-sri',
    pageNumber: 12,
  },
  {
    id: 'treatment_pheromone_traps',
    name: 'Pheromone Funnel Traps',
    nameTa: 'மோகினிப் பொறி / இனக்கவர்ச்சி பொறி',
    type: 'treatment',
    description: '5 traps per acre for ETL monitoring and male moth mass trapping.',
    sourceDocId: 'doc-icar-cotton-ipm',
    pageNumber: 4,
  },
  {
    id: 'treatment_awd_irrigation',
    name: 'Alternate Wetting and Drying (AWD)',
    nameTa: 'காய்ச்சலும் பாய்ச்சலும் பாசனம்',
    type: 'treatment',
    description: 'Intermittent irrigation suppressing anaerobic root rot and saving 40% water.',
    sourceDocId: 'doc-tnau-paddy-sri',
    pageNumber: 12,
  },
  {
    id: 'treatment_metarhizium',
    name: 'Metarhizium rileyi Biopesticide',
    nameTa: 'மெட்டாரைசியம் உயிரி பூஞ்சை',
    type: 'treatment',
    description: 'Entomopathogenic fungus applied to maize whorls against Fall Armyworm.',
    sourceDocId: 'doc-tnau-maize-faw',
    pageNumber: 6,
  },

  // Regions
  {
    id: 'region_cauvery_delta',
    name: 'Cauvery Delta Zone (Thanjavur, Tiruvarur, Nagapattinam)',
    nameTa: 'காவிரி டெல்டா மண்டலம்',
    type: 'region',
    description: 'Intensive paddy tract vulnerable to Kuruvai and Samba blast outbreaks.',
    sourceDocId: 'doc-tnau-paddy-sri',
    pageNumber: 1,
  },
  {
    id: 'region_western_tract',
    name: 'Western Zone (Coimbatore, Tirupur, Erode)',
    nameTa: 'மேற்கு மண்டலம்',
    type: 'region',
    description: 'Cotton and sugarcane heartland with drip irrigation adoption.',
    sourceDocId: 'doc-icar-cotton-ipm',
    pageNumber: 1,
  },
];

export const agriculturalEdges: GraphEdge[] = [
  // Paddy Edges
  {
    sourceId: 'crop_paddy',
    targetId: 'disease_blast',
    relation: 'AFFECTED_BY',
    description: 'Paddy is susceptible to Rice Blast during cloudy, humid weather.',
    descriptionTa: 'மேகமூட்டமான காலங்களில் நெல் பயிர் குலை நோயால் பாதிக்கப்படுகிறது.',
    confidence: 0.98,
    sourceDocId: 'doc-tnau-paddy-sri',
    pageNumber: 12,
  },
  {
    sourceId: 'disease_blast',
    targetId: 'symptom_spindle_lesions',
    relation: 'EXHIBITS_SYMPTOM',
    description: 'Rice blast causes spindle-shaped lesions with grey centres.',
    descriptionTa: 'குலை நோய் இலைகளில் கதிர் வடிவ சாம்பல் நிற புள்ளிகளை உண்டாக்கும்.',
    confidence: 0.96,
    sourceDocId: 'doc-tnau-paddy-sri',
    pageNumber: 12,
  },
  {
    sourceId: 'disease_blast',
    targetId: 'treatment_tricyclazole',
    relation: 'TREATED_BY',
    description: 'Rice blast is controlled by Tricyclazole 75% WP at 120 g/acre.',
    descriptionTa: 'குலை நோயை ட்ரைசைக்ளசோல் 75% WP (ஏக்கருக்கு 120 கிராம்) தெளித்து கட்டுப்படுத்தலாம்.',
    confidence: 0.95,
    sourceDocId: 'doc-tnau-paddy-sri',
    pageNumber: 12,
  },
  {
    sourceId: 'crop_paddy',
    targetId: 'pest_stem_borer',
    relation: 'AFFECTED_BY',
    description: 'Paddy is attacked by Yellow Stem Borer at tillering and heading.',
    descriptionTa: 'தூர் கட்டும் மற்றும் கதிர் வரும் பருவத்தில் தண்டு துளைப்பான் தாக்கும்.',
    confidence: 0.97,
    sourceDocId: 'doc-tnau-paddy-sri',
    pageNumber: 14,
  },
  {
    sourceId: 'pest_stem_borer',
    targetId: 'symptom_dead_heart',
    relation: 'EXHIBITS_SYMPTOM',
    description: 'Stem borer larvae feed inside tillers, causing dead hearts.',
    descriptionTa: 'தண்டு துளைப்பான் புழுக்கள் தண்டுக்குள் துளைத்து குருத்து காய்வை உண்டாக்கும்.',
    confidence: 0.98,
    sourceDocId: 'doc-tnau-paddy-sri',
    pageNumber: 14,
  },
  {
    sourceId: 'crop_paddy',
    targetId: 'treatment_awd_irrigation',
    relation: 'MANAGED_BY_PRACTICE',
    description: 'Alternate Wetting and Drying saves 40% water and strengthens root system.',
    descriptionTa: 'காய்ச்சலும் பாய்ச்சலும் பாசன முறை 40% நீரைக் காப்பதுடன் வேரை வலுப்படுத்தும்.',
    confidence: 0.95,
    sourceDocId: 'doc-tnau-paddy-sri',
    pageNumber: 12,
  },
  {
    sourceId: 'crop_paddy',
    targetId: 'region_cauvery_delta',
    relation: 'PREVALENT_IN',
    description: 'Paddy is the primary agricultural crop in Cauvery Delta.',
    descriptionTa: 'காவிரி டெல்டா மண்டலத்தின் முதன்மைப் பயிர் நெல் ஆகும்.',
    confidence: 0.99,
    sourceDocId: 'doc-tnau-paddy-sri',
    pageNumber: 1,
  },

  // Groundnut Edges
  {
    sourceId: 'crop_groundnut',
    targetId: 'nutrient_calcium',
    relation: 'REQUIRES_NUTRIENT',
    description: 'Groundnut requires high calcium absorption in the podding zone.',
    descriptionTa: 'நிலக்கடலை காய் பிடிக்கும் பருவத்தில் அதிக கால்சியம் சத்து தேவைப்படுகிறது.',
    confidence: 0.99,
    sourceDocId: 'doc-tnau-groundnut-gypsum',
    pageNumber: 5,
  },
  {
    sourceId: 'nutrient_calcium',
    targetId: 'fertilizer_gypsum',
    relation: 'SUPPLIED_BY',
    description: 'Calcium is provided by broadcasting Gypsum at 400 kg/ha at 40-45 DAS.',
    descriptionTa: 'விதைத்த 40-45 நாட்களில் ஏக்கருக்கு 160-200 கிலோ ஜிப்சம் இடுவதன் மூலம் கால்சியம் கிடைக்கும்.',
    confidence: 0.98,
    sourceDocId: 'doc-tnau-groundnut-gypsum',
    pageNumber: 5,
  },
  {
    sourceId: 'symptom_pop_pods',
    targetId: 'nutrient_calcium',
    relation: 'EXHIBITS_SYMPTOM',
    description: 'Pop pods (hollow kernels) are caused by calcium deficiency.',
    descriptionTa: 'பொக்கு காய்கள் தோன்றுவது கால்சியம் சத்து பற்றாக்குறையின் நேரடி அறிகுறி.',
    confidence: 0.96,
    sourceDocId: 'doc-tnau-groundnut-gypsum',
    pageNumber: 5,
  },
  {
    sourceId: 'crop_groundnut',
    targetId: 'disease_tikka',
    relation: 'AFFECTED_BY',
    description: 'Groundnut is susceptible to Tikka leaf spot.',
    descriptionTa: 'நிலக்கடலை டிக்கா இலைப்புள்ளி நோயால் பாதிக்கப்படுகிறது.',
    confidence: 0.95,
    sourceDocId: 'doc-tnau-groundnut-gypsum',
    pageNumber: 9,
  },

  // Cotton Edges
  {
    sourceId: 'crop_cotton',
    targetId: 'pest_bollworm',
    relation: 'AFFECTED_BY',
    description: 'Cotton is attacked by Helicoverpa bollworms.',
    descriptionTa: 'பருத்தியை காய்ப்புழுக்கள் தீவிரமாக தாக்கும்.',
    confidence: 0.98,
    sourceDocId: 'doc-icar-cotton-ipm',
    pageNumber: 4,
  },
  {
    sourceId: 'pest_bollworm',
    targetId: 'treatment_pheromone_traps',
    relation: 'TREATED_BY',
    description: 'Helicoverpa is monitored and controlled using pheromone traps (5/acre).',
    descriptionTa: 'இனக்கவர்ச்சி பொறிகள் (ஏக்கருக்கு 5) அமைத்து காய்ப்புழுவைக் கட்டுப்படுத்தலாம்.',
    confidence: 0.94,
    sourceDocId: 'doc-icar-cotton-ipm',
    pageNumber: 4,
  },
  {
    sourceId: 'crop_cotton',
    targetId: 'region_western_tract',
    relation: 'PREVALENT_IN',
    description: 'Cotton is extensively grown in Coimbatore, Tirupur, and Salem.',
    descriptionTa: 'கோவை, திருப்பூர் மற்றும் சேலம் பகுதிகளில் பருத்தி பரவலாக பயிரிடப்படுகிறது.',
    confidence: 0.95,
    sourceDocId: 'doc-icar-cotton-ipm',
    pageNumber: 1,
  },

  // Banana Edges
  {
    sourceId: 'crop_banana',
    targetId: 'disease_sigatoka',
    relation: 'AFFECTED_BY',
    description: 'Banana suffers from Sigatoka leaf spot during rainy and humid seasons.',
    descriptionTa: 'மழைக்காலங்களில் வாழை பயிர் சிகடோகா இலைப்புள்ளி நோயால் பாதிக்கப்படும்.',
    confidence: 0.96,
    sourceDocId: 'doc-icar-banana-sigatoka',
    pageNumber: 6,
  },
  {
    sourceId: 'crop_banana',
    targetId: 'nutrient_potassium',
    relation: 'REQUIRES_NUTRIENT',
    description: 'Banana requires heavy potassium fertilization (300 g K2O/plant) for bunch yield.',
    descriptionTa: 'வாழைக்கு தார் எடை அதிகரிக்க செடிக்கு 300 கிராம் பொட்டாஷ் உரம் தேவை.',
    confidence: 0.97,
    sourceDocId: 'doc-icar-banana-sigatoka',
    pageNumber: 8,
  },

  // Maize Edges
  {
    sourceId: 'crop_maize',
    targetId: 'pest_fall_armyworm',
    relation: 'AFFECTED_BY',
    description: 'Maize is heavily attacked by Fall Armyworm at 15-40 DAS.',
    descriptionTa: 'மக்காச்சோளம் விதைத்த 15-40 நாட்களில் படைப்புழுவால் தாக்கப்படும்.',
    confidence: 0.98,
    sourceDocId: 'doc-tnau-maize-faw',
    pageNumber: 5,
  },
  {
    sourceId: 'pest_fall_armyworm',
    targetId: 'symptom_window_panes',
    relation: 'EXHIBITS_SYMPTOM',
    description: 'Fall armyworm causes window pane translucent holes in whorls.',
    descriptionTa: 'படைப்புழு இலைகளில் ஜன்னல் போன்ற மெல்லிய துளைகளை உண்டாக்கும்.',
    confidence: 0.97,
    sourceDocId: 'doc-tnau-maize-faw',
    pageNumber: 5,
  },
  {
    sourceId: 'pest_fall_armyworm',
    targetId: 'treatment_metarhizium',
    relation: 'TREATED_BY',
    description: 'Metarhizium rileyi biopesticide provides eco-friendly whorl control.',
    descriptionTa: 'மெட்டாரைசியம் ரைலி உயிரி பூஞ்சை படைப்புழுவுக்கு சிறந்த இயற்கை மருந்தாகும்.',
    confidence: 0.92,
    sourceDocId: 'doc-tnau-maize-faw',
    pageNumber: 6,
  },
];

/**
 * Traverses the Agricultural Knowledge Graph starting from identified seed entities.
 * Returns connected subgraph nodes, edges, and formatted natural language relational facts.
 */
export function traverseAgriculturalGraph(seedKeywords: string[]): TraversalResult {
  const matchedNodeIds = new Set<string>();

  // Match seed nodes by name or nameTa
  seedKeywords.forEach((kw) => {
    const lower = kw.toLowerCase().trim();
    if (!lower) return;

    agriculturalNodes.forEach((node) => {
      if (
        node.name.toLowerCase().includes(lower) ||
        node.nameTa.toLowerCase().includes(lower) ||
        lower.includes(node.name.toLowerCase().slice(0, 5)) ||
        lower.includes(node.nameTa.toLowerCase().slice(0, 4))
      ) {
        matchedNodeIds.add(node.id);
      }
    });
  });

  // Collect 1-hop and 2-hop edges
  const traversedEdges: GraphEdge[] = [];
  const traversedNodeIds = new Set<string>(matchedNodeIds);

  agriculturalEdges.forEach((edge) => {
    if (matchedNodeIds.has(edge.sourceId) || matchedNodeIds.has(edge.targetId)) {
      traversedEdges.push(edge);
      traversedNodeIds.add(edge.sourceId);
      traversedNodeIds.add(edge.targetId);
    }
  });

  const traversedNodes = agriculturalNodes.filter((n) => traversedNodeIds.has(n.id));

  // Generate structured relational context sentences with source citations
  const relationalContext: string[] = traversedEdges.map(
    (e) => `[Graph Knowledge] ${e.description} (Source: ${e.sourceDocId}, Page ${e.pageNumber})`
  );

  const relationalContextTa: string[] = traversedEdges.map(
    (e) => `[தொடர்புடைய அறிவு] ${e.descriptionTa} (ஆதாரம்: ${e.sourceDocId}, பக்கம் ${e.pageNumber})`
  );

  return {
    nodes: traversedNodes,
    edges: traversedEdges,
    relationalContext,
    relationalContextTa,
  };
}
