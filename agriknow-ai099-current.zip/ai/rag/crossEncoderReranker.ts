import type { DocumentChunk } from '../../types/ingestion.ts';
import { tokenizeText } from './bm25Search.ts';
import { generateEmbeddingVector, cosineSimilarity } from '../../utils/embeddingGenerator.ts';

export interface RerankedCandidate {
  chunk: DocumentChunk;
  crossEncoderScore: number;
  initialRank: number;
  rerankedRank: number;
  semanticAlignment: number;
  entityCoverage: number;
}

export interface RerankerOptions {
  topK?: number;
  authorityWeight?: number;
}

/**
 * Multilingual Agricultural Cross-Encoder Reranker.
 * Evaluates joint query-document relevance by computing token interaction, entity coverage,
 * exact phrase proximity, semantic dense vector cosine similarity, and source authority.
 */
export function rerankCandidates(
  query: string,
  candidates: { chunk: DocumentChunk; initialRank: number }[],
  options: RerankerOptions = {}
): RerankedCandidate[] {
  const topK = options.topK || 5;
  const authorityWeight = options.authorityWeight || 0.15;

  if (candidates.length === 0) return [];

  const queryTokens = tokenizeText(query);
  const queryVector = generateEmbeddingVector(query);
  const queryLower = query.toLowerCase();

  const scored: {
    chunk: DocumentChunk;
    initialRank: number;
    score: number;
    semanticAlignment: number;
    entityCoverage: number;
  }[] = [];

  candidates.forEach(({ chunk, initialRank }) => {
    const textLower = `${chunk.documentTitle} ${chunk.crop || ''} ${chunk.content}`.toLowerCase();
    const chunkTokens = new Set(tokenizeText(textLower));

    // 1. Entity and Token Coverage (What fraction of query terms exist in the chunk)
    let matchedTokens = 0;
    queryTokens.forEach((t) => {
      if (chunkTokens.has(t)) matchedTokens++;
    });
    const entityCoverage = queryTokens.length > 0 ? matchedTokens / queryTokens.length : 0;

    // 2. Exact Phrase and Proximity Bonus
    let phraseBonus = 0;
    const words = queryLower.split(/\s+/).filter((w) => w.length > 2);
    for (let i = 0; i < words.length - 1; i++) {
      const bigram = `${words[i]} ${words[i + 1]}`;
      if (textLower.includes(bigram)) {
        phraseBonus += 0.12;
      }
    }
    phraseBonus = Math.min(0.25, phraseBonus);

    // 3. Dense Semantic Cosine Alignment
    let semanticAlignment = 0;
    if (chunk.embeddingVector && chunk.embeddingVector.length > 0) {
      semanticAlignment = Math.max(0, cosineSimilarity(queryVector, chunk.embeddingVector));
    }

    // 4. Source Authority Multiplier (TNAU, ICAR, KVK verified manuals)
    let authorityBonus = 0;
    const inst = chunk.sourceInstitution.toLowerCase();
    if (inst.includes('tnau') || inst.includes('tamil nadu agricultural university')) {
      authorityBonus = authorityWeight;
    } else if (inst.includes('icar')) {
      authorityBonus = authorityWeight * 0.95;
    } else if (inst.includes('department of agriculture')) {
      authorityBonus = authorityWeight * 0.85;
    }

    // 5. Cross-Encoder Composite Relevance Score in [0, 1]
    const finalScore =
      semanticAlignment * 0.45 +
      entityCoverage * 0.30 +
      phraseBonus +
      authorityBonus;

    scored.push({
      chunk,
      initialRank,
      score: parseFloat(finalScore.toFixed(4)),
      semanticAlignment: parseFloat(semanticAlignment.toFixed(4)),
      entityCoverage: parseFloat(entityCoverage.toFixed(4)),
    });
  });

  // Sort descending by cross-encoder score
  scored.sort((a, b) => b.score - a.score);

  return scored.slice(0, topK).map((item, idx) => ({
    chunk: item.chunk,
    crossEncoderScore: item.score,
    initialRank: item.initialRank,
    rerankedRank: idx + 1,
    semanticAlignment: item.semanticAlignment,
    entityCoverage: item.entityCoverage,
  }));
}
