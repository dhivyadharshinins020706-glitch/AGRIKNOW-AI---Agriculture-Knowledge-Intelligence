/**
 * AGRIKNOW AI - In-Memory Query & Embedding LRU Cache
 * Delivers sub-millisecond (<1ms) response times for recurring agricultural queries.
 */

import type { AdvancedRagResponse } from './advancedRagEngine';

interface CacheEntry {
  response: AdvancedRagResponse;
  expiresAt: number;
}

export class RagQueryCache {
  private cache = new Map<string, CacheEntry>();
  private maxEntries: number;
  private defaultTtlMs: number;

  constructor(maxEntries = 100, defaultTtlSeconds = 900) {
    this.maxEntries = maxEntries;
    this.defaultTtlMs = defaultTtlSeconds * 1000;
  }

  private generateKey(query: string, lang: string): string {
    return `${lang}:${query.trim().toLowerCase().replace(/\s+/g, ' ')}`;
  }

  public get(query: string, lang = 'ta'): AdvancedRagResponse | null {
    const key = this.generateKey(query, lang);
    const entry = this.cache.get(key);

    if (!entry) return null;

    if (Date.now() > entry.expiresAt) {
      this.cache.delete(key);
      return null;
    }

    // Refresh position for LRU
    this.cache.delete(key);
    this.cache.set(key, entry);

    return entry.response;
  }

  public set(query: string, response: AdvancedRagResponse, lang = 'ta', ttlSeconds?: number): void {
    const key = this.generateKey(query, lang);
    const ttlMs = ttlSeconds ? ttlSeconds * 1000 : this.defaultTtlMs;

    // Evict oldest if capacity reached
    if (this.cache.size >= this.maxEntries) {
      const oldestKey = this.cache.keys().next().value;
      if (oldestKey) {
        this.cache.delete(oldestKey);
      }
    }

    this.cache.set(key, {
      response,
      expiresAt: Date.now() + ttlMs,
    });
  }

  public clear(): void {
    this.cache.clear();
  }

  public size(): number {
    return this.cache.size;
  }
}

export const globalRagCache = new RagQueryCache(120, 900); // 120 items, 15 min TTL
