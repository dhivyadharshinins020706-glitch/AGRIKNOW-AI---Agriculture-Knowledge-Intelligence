import type { DocumentChunk } from '../../types/ingestion';

/**
 * High-performance, zero-dependency BM25 Retrieval Engine.
 * Supports tokenization and subword matching for English & Tamil scripts.
 * Parameters: k1 = 1.5, b = 0.75.
 */

const K1 = 1.5;
const B = 0.75;

export interface Bm25ScoredChunk {
  chunk: DocumentChunk;
  bm25Score: number;
  rank: number;
}

const COMMON_STOPWORDS = new Set([
  'a', 'an', 'the', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'from',
  'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had',
  'do', 'does', 'did', 'can', 'could', 'should', 'would', 'my', 'your', 'his',
  'her', 'its', 'our', 'their', 'how', 'what', 'when', 'where', 'why', 'which',
]);

/**
 * Tokenizes text into normalized words and character 3-grams for Tamil morphological matching
 */
export function tokenizeText(text: string): string[] {
  const normalized = text.toLowerCase().trim();
  const words = normalized
    .split(/[\s,.;:!?()[\]"'/\\-]+/)
    .filter((w) => w.length > 1 && !COMMON_STOPWORDS.has(w));

  const tokens: string[] = [...words];

  // Subword 3-grams for Tamil compound words and inflections
  words.forEach((w) => {
    if (w.length >= 3 && /[\u0B80-\u0BFF]/.test(w)) {
      for (let i = 0; i <= w.length - 3; i++) {
        tokens.push(w.slice(i, i + 3));
      }
    }
  });

  return tokens;
}

export class Bm25Index {
  private corpus: DocumentChunk[] = [];
  private docTokens: string[][] = [];
  private docLengths: number[] = [];
  private avgDocLength = 0;
  private docFreqs: Map<string, number> = new Map();

  constructor(chunks: DocumentChunk[]) {
    this.buildIndex(chunks);
  }

  public buildIndex(chunks: DocumentChunk[]) {
    this.corpus = chunks;
    this.docTokens = [];
    this.docLengths = [];
    this.docFreqs = new Map();

    let totalLength = 0;

    chunks.forEach((chunk) => {
      const tokens = tokenizeText(
        `${chunk.documentTitle} ${chunk.crop || ''} ${chunk.topic || ''} ${chunk.content}`
      );
      this.docTokens.push(tokens);
      this.docLengths.push(tokens.length);
      totalLength += tokens.length;

      // Unique tokens for document frequency calculation
      const uniqueTokens = new Set(tokens);
      uniqueTokens.forEach((t) => {
        this.docFreqs.set(t, (this.docFreqs.get(t) || 0) + 1);
      });
    });

    this.avgDocLength = chunks.length > 0 ? totalLength / chunks.length : 1;
  }

  /**
   * Computes BM25 score for all documents against a query string.
   */
  public search(query: string, topK = 15): Bm25ScoredChunk[] {
    const queryTokens = tokenizeText(query);
    if (queryTokens.length === 0 || this.corpus.length === 0) return [];

    const numDocs = this.corpus.length;
    const scores: { chunk: DocumentChunk; bm25Score: number }[] = [];

    for (let i = 0; i < numDocs; i++) {
      const docToks = this.docTokens[i];
      const docLen = this.docLengths[i];
      let score = 0;

      // Calculate term frequencies in current doc
      const tfMap: Map<string, number> = new Map();
      docToks.forEach((t) => {
        tfMap.set(t, (tfMap.get(t) || 0) + 1);
      });

      queryTokens.forEach((qTok) => {
        const tf = tfMap.get(qTok) || 0;
        if (tf > 0) {
          const df = this.docFreqs.get(qTok) || 0;
          // Standard Robertson-Sparck Jones IDF
          const idf = Math.log(1 + (numDocs - df + 0.5) / (df + 0.5));
          const num = tf * (K1 + 1);
          const denom = tf + K1 * (1 - B + B * (docLen / this.avgDocLength));
          score += idf * (num / denom);
        }
      });

      if (score > 0.05) {
        scores.push({
          chunk: this.corpus[i],
          bm25Score: parseFloat(score.toFixed(4)),
        });
      }
    }

    scores.sort((a, b) => b.bm25Score - a.bm25Score);

    return scores.slice(0, topK).map((item, idx) => ({
      chunk: item.chunk,
      bm25Score: item.bm25Score,
      rank: idx + 1,
    }));
  }
}
