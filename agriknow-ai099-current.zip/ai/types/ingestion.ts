export type TrustedInstitution =
  | 'Tamil Nadu Agricultural University (TNAU)'
  | 'Indian Council of Agricultural Research (ICAR)'
  | 'Department of Agriculture & Farmers Welfare'
  | 'Krishi Vigyan Kendra (KVK)'
  | 'Central Institute for Cotton Research (ICAR-CICR)'
  | 'National Research Centre for Banana (ICAR-NRCB)'
  | 'Other';

export type DocumentCategory =
  | 'Crop Manual'
  | 'Disease Management'
  | 'Fertilizer & Soil Guide'
  | 'Pest Advisory'
  | 'Water Management'
  | 'Government Scheme';

export type TargetCrop =
  | 'Paddy (நெல்)'
  | 'Cotton (பருத்தி)'
  | 'Sugarcane (கரும்பு)'
  | 'Maize (மக்காச்சோளம்)'
  | 'Banana (வாழை)'
  | 'Groundnut (நிலக்கடலை)'
  | 'Pulses (பருப்பு வகைகள்)'
  | 'General Agriculture';

export type IngestionStatus =
  | 'uploaded'
  | 'processing'
  | 'extracted'
  | 'chunked'
  | 'indexed'
  | 'failed';

export type VerificationStatus =
  | 'unverified'
  | 'pending_review'
  | 'verified'
  | 'flagged_conflicting'
  | 'rejected';

export interface IngestedDocument {
  id: string;
  title: string;
  description: string;
  institution: TrustedInstitution;
  category: DocumentCategory;
  crops: string[];
  topics: string[];
  language: 'Tamil' | 'English' | 'Bilingual';
  publicationDate: string;
  fileName: string;
  fileSizeBytes: number;
  fileHash: string; // SHA-256 for duplicate checking
  fileUrl?: string;
  status: IngestionStatus;
  verificationStatus: VerificationStatus;
  verificationNotes?: string;
  verifiedBy?: string;
  verifiedAt?: string;
  errorMessage?: string;
  totalPages: number;
  totalChunks: number;
  createdAt: string;
  updatedAt: string;
}

export interface DocumentChunk {
  id: string;
  documentId: string;
  documentTitle: string;
  chunkIndex: number;
  pageNumber: number;
  crop?: string;
  topic?: string;
  region: string;
  language: string;
  sourceInstitution: string;
  content: string;
  tokenCount: number;
  charStart?: number;
  charEnd?: number;
  embeddingVector?: number[]; // Semantic dense embedding vector
  embeddingModel?: string; // e.g. 'multilingual-dense-hash-128', 'gemini-embedding-2'
  embeddingVersion?: string; // e.g. '1.0'
  embeddingDimensions?: number; // e.g. 128, 768, 3072
  similarityScore?: number; // Calculated during search
  createdAt: string;
}

export interface IngestionOptions {
  chunkSize: number; // in characters, default ~650
  chunkOverlap: number; // in characters, default ~120
  targetCrops: string[];
  primaryTopic?: string;
  language: 'Tamil' | 'English' | 'Bilingual';
  institution: TrustedInstitution;
  category: DocumentCategory;
}

export interface IngestionStepLog {
  id: string;
  timestamp: string;
  step: 'validation' | 'hash' | 'extraction' | 'cleaning' | 'chunking' | 'embedding' | 'storage' | 'error';
  message: string;
  tone: 'info' | 'success' | 'warning' | 'danger';
}

export interface IngestionStats {
  totalDocuments: number;
  totalChunks: number;
  verifiedDocuments: number;
  pendingReviewDocuments: number;
  flaggedDocuments: number;
  cropDistribution: Record<string, number>;
  totalStorageBytes: number;
  modelDistribution?: Record<string, number>;
}

/**
 * Embedding metadata contract for cross-model isolation and compatibility validation.
 * Used to enforce that query vectors and chunk vectors are never compared across different
 * embedding spaces.
 */
export interface EmbeddingMetadata {
  embeddingModel: string;
  embeddingVersion?: string;
  embeddingDimensions: number;
}

export interface EmbeddingCompatibilityResult {
  compatible: boolean;
  reason?: string;
}

/**
 * Validates whether two embedding metadata signatures belong to the same embedding space
 * and are safe for vector similarity comparison (e.g. cosine distance).
 * Strict rules:
 * 1. embedding_model must match exactly.
 * 2. embedding_dimensions must match exactly.
 * 3. embedding_version must be compatible (if specified on both, major versions must match).
 * 4. Never compare vectors from different embedding spaces.
 */
export function isEmbeddingCompatible(
  query: EmbeddingMetadata,
  target: EmbeddingMetadata
): EmbeddingCompatibilityResult {
  if (!query.embeddingModel || !target.embeddingModel) {
    return {
      compatible: false,
      reason: 'Missing embedding_model identifier on query or target.',
    };
  }

  if (query.embeddingModel !== target.embeddingModel) {
    return {
      compatible: false,
      reason: `Embedding model mismatch: cannot compare "${query.embeddingModel}" with "${target.embeddingModel}".`,
    };
  }

  if (query.embeddingDimensions !== target.embeddingDimensions) {
    return {
      compatible: false,
      reason: `Embedding dimensions mismatch: query has ${query.embeddingDimensions} dimensions while target has ${target.embeddingDimensions}.`,
    };
  }

  if (query.embeddingVersion && target.embeddingVersion) {
    const queryMajor = query.embeddingVersion.split('.')[0];
    const targetMajor = target.embeddingVersion.split('.')[0];
    if (queryMajor !== targetMajor) {
      return {
        compatible: false,
        reason: `Embedding version incompatibility: query version ${query.embeddingVersion} vs target version ${target.embeddingVersion}.`,
      };
    }
  }

  return { compatible: true };
}
