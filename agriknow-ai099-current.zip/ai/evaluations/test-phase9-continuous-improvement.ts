/**
 * AGRIKNOW AI - Phase 9 Continuous Improvement, Scalability & Startup Growth Benchmark
 * Evaluates:
 * 1. Usage Intelligence & Query Clustering (Language share, FAQs, cluster topics)
 * 2. Real Knowledge Gap Recording (Tracking CRAG abstentions for scientific corpus expansion)
 * 3. Personalized Farmer Context with Explicit Consent Gate (Privacy by design)
 * 4. Right to Erasure / Purge (Instant deletion of stored farm context)
 * 5. Government Welfare Schemes Retrieval (PM-KISAN, PMFBY, Micro-irrigation 100% subsidy, KCC)
 * 6. RAG Response Latency & Query Cache Efficiency (>90% latency reduction on repeat queries)
 * 7. Startup Cost Economics & Scale Metrics ($0.00035/query, $43.75/month for 125,000 queries)
 * 8. Regulatory Agrochemical Safety Interceptor (Supreme Court / CIBRC banned chemicals)
 * 9. Authentic Regional Tamil Agronomic Vocabulary & Inflection Invariance
 * 10. Multi-Document Evidence Traceability & Groundedness
 */

// Polyfill localStorage in Node.js CLI runtime
if (typeof globalThis.localStorage === 'undefined') {
  const store = new Map<string, string>();
  globalThis.localStorage = {
    getItem: (key: string) => store.get(key) ?? null,
    setItem: (key: string, val: string) => store.set(key, String(val)),
    removeItem: (key: string) => store.delete(key),
    clear: () => store.clear(),
    key: (i: number) => Array.from(store.keys())[i] ?? null,
    get length() {
      return store.size;
    },
  } as Storage;
}

import { generateUsageIntelligence, recordKnowledgeGap } from '../src/services/usageIntelligenceService.ts';
import {
  hasPersonalizationConsent,
  setPersonalizationConsent,
  getPersonalizationContext,
  updatePersonalizationContext,
  purgePersonalizationContext,
  buildPersonalizedContextPrompt,
} from '../src/services/personalizationService.ts';
import {
  getAllGovernmentSchemes,
  searchGovernmentSchemes,
  matchSchemeForQuery,
} from '../src/services/schemesService.ts';
import { executeAdvancedRag } from '../src/services/rag/advancedRagEngine.ts';
import { globalRagCache } from '../src/services/rag/queryCache.ts';
import { checkHazardousChemicals } from '../src/services/rag/ragSafetyGuard.ts';

interface BenchmarkTest {
  id: string;
  category: string;
  name: string;
  run: () => Promise<{ passed: boolean; details: string; latencyMs: number }>;
}

const benchmarkSuite: BenchmarkTest[] = [
  // 1. Usage Intelligence & Query Clustering
  {
    id: 'PHASE9-USAGE-INTEL',
    category: 'Usage Intelligence',
    name: 'Telemetry Aggregation, Language Share & Query Clusters',
    run: async () => {
      const start = Date.now();
      const report = generateUsageIntelligence();

      const hasTimestamp = Boolean(report.timestamp);
      const hasLangShare =
        typeof report.languageShare.tamil === 'number' &&
        typeof report.languageShare.english === 'number' &&
        report.languageShare.tamil >= 50; // Tamil Nadu farmers predominantly use Tamil
      const hasClusters = Array.isArray(report.topQueryTopics) && report.topQueryTopics.length >= 3;
      const hasCostMetrics = report.costMetrics.estimatedCostPerQueryUsd <= 0.0005;

      const passed = hasTimestamp && hasLangShare && hasClusters && hasCostMetrics;
      return {
        passed,
        details: `Tamil Share: ${report.languageShare.tamil}%, English Share: ${report.languageShare.english}%, Clusters: ${report.topQueryTopics.length}, Cost/Query: $${report.costMetrics.estimatedCostPerQueryUsd}`,
        latencyMs: Date.now() - start,
      };
    },
  },

  // 2. Real Knowledge Gap Recording for University Ingestion
  {
    id: 'PHASE9-KNOWLEDGE-GAP',
    category: 'Knowledge Expansion',
    name: 'Unanswered Query & Knowledge Gap Logging',
    run: async () => {
      const start = Date.now();
      const testQuery = 'உளுந்து பயிரில் மஞ்சள் தேமல் நோய் (YMV) கட்டுப்பாடு';
      recordKnowledgeGap(testQuery, 'ta', 'disease_diagnosis');

      const report = generateUsageIntelligence();
      const recorded = report.identifiedKnowledgeGaps.find(
        (g) => g.unansweredQuery.toLowerCase() === testQuery.toLowerCase()
      );

      const passed = Boolean(recorded && recorded.frequency >= 1 && recorded.suggestedSourceToIngest);
      return {
        passed,
        details: recorded
          ? `Logged Gap: "${recorded.unansweredQuery}" | Intent: ${recorded.detectedIntent} | Suggested Source: ${recorded.suggestedSourceToIngest}`
          : 'Failed to record knowledge gap in storage',
        latencyMs: Date.now() - start,
      };
    },
  },

  // 3. Personalized Farmer Context with Explicit Consent Gate
  {
    id: 'PHASE9-PERSONALIZATION-CONSENT',
    category: 'Personalized Assistance',
    name: 'Consent Gate & Farm Profile Memory Isolation',
    run: async () => {
      const start = Date.now();
      // Step A: Ensure no consent initially
      setPersonalizationConsent(false);
      const consentInitially = hasPersonalizationConsent();
      const writeBlockedWithoutConsent = !updatePersonalizationContext({ primaryCrop: 'Paddy' });
      const promptWithoutConsent = buildPersonalizedContextPrompt('ta');

      // Step B: Grant explicit consent
      setPersonalizationConsent(true);
      const consentGranted = hasPersonalizationConsent();
      const writeAllowedWithConsent = updatePersonalizationContext({
        district: 'Thanjavur',
        primaryCrop: 'Paddy',
        currentCropStage: 'tillering',
        soilType: 'Alluvial Clay',
      });
      const updatedContext = getPersonalizationContext();
      const promptWithConsent = buildPersonalizedContextPrompt('ta');

      const passed =
        !consentInitially &&
        writeBlockedWithoutConsent &&
        promptWithoutConsent === null &&
        consentGranted &&
        writeAllowedWithConsent &&
        updatedContext.district === 'Thanjavur' &&
        updatedContext.primaryCrop === 'Paddy' &&
        Boolean(promptWithConsent && promptWithConsent.includes('தஞ்சாவூர்') || promptWithConsent?.includes('Thanjavur'));

      return {
        passed,
        details: `Consent Enforcement Verified. Write without consent blocked: ${writeBlockedWithoutConsent}, Prompt with consent: "${promptWithConsent}"`,
        latencyMs: Date.now() - start,
      };
    },
  },

  // 4. Right to Erasure (Purge Personalization Context)
  {
    id: 'PHASE9-RIGHT-TO-ERASURE',
    category: 'Privacy & Security',
    name: 'Instant Personalization Context Purge (Right to Erasure)',
    run: async () => {
      const start = Date.now();
      // Ensure context exists
      setPersonalizationConsent(true);
      updatePersonalizationContext({ district: 'Madurai', primaryCrop: 'Cotton' });

      // Trigger Purge
      purgePersonalizationContext();

      const consentAfterPurge = hasPersonalizationConsent();
      const contextAfterPurge = getPersonalizationContext();
      const promptAfterPurge = buildPersonalizedContextPrompt('en');

      const passed =
        !consentAfterPurge &&
        !contextAfterPurge.district &&
        !contextAfterPurge.primaryCrop &&
        promptAfterPurge === null;

      return {
        passed,
        details: `Purge Verified: Context eradicated. Consent: ${consentAfterPurge}, Prompt: ${promptAfterPurge}`,
        latencyMs: Date.now() - start,
      };
    },
  },

  // 5. Government Schemes Intelligence Engine
  {
    id: 'PHASE9-GOVT-SCHEMES',
    category: 'Government Schemes',
    name: 'Verified Welfare Programs Retrieval (PM-KISAN, PMFBY, Drip Subsidies, KCC)',
    run: async () => {
      const start = Date.now();
      const allSchemes = getAllGovernmentSchemes();

      // Test 1: PM-KISAN query match
      const pmKisanMatch = matchSchemeForQuery('How to apply for PM Kisan 6000 installment?', 'en');
      // Test 2: Tamil Drip Irrigation Query match
      const dripMatch = matchSchemeForQuery('சொட்டு நீர் பாசனத்திற்கு 100% மானியம் பெறுவது எப்படி?', 'ta');
      // Test 3: Crop insurance PMFBY search
      const insuranceSearchResults = searchGovernmentSchemes({ category: 'insurance' });

      const hasAllMajorSchemes = allSchemes.some((s) => s.code === 'PM-KISAN') &&
        allSchemes.some((s) => s.code === 'PMFBY') &&
        allSchemes.some((s) => s.code === 'PMKSY-PDMC-TN') &&
        allSchemes.some((s) => s.code === 'KCC');

      const passed =
        hasAllMajorSchemes &&
        pmKisanMatch.found &&
        Boolean(pmKisanMatch.portalUrl?.includes('pmkisan.gov.in')) &&
        dripMatch.found &&
        Boolean(dripMatch.summary?.includes('100% முழு மானியம்')) &&
        insuranceSearchResults.length >= 1;

      return {
        passed,
        details: `Total Verified Schemes: ${allSchemes.length} | PM-KISAN Portal: ${pmKisanMatch.portalUrl} | Drip Match: ${dripMatch.scheme?.code} | Insurance Found: ${insuranceSearchResults[0]?.name}`,
        latencyMs: Date.now() - start,
      };
    },
  },

  // 6. RAG Response Latency & LRU Query Caching Efficiency
  {
    id: 'PHASE9-RAG-CACHE-EFFICIENCY',
    category: 'Scalability & Performance',
    name: 'Multi-Hop RAG Latency & Sub-Millisecond Cache Acceleration',
    run: async () => {
      const query = 'நெல் குலை நோய் தடுக்கும் பூஞ்சாணக்கொல்லி எது?';
      globalRagCache.clear();

      // Cold retrieval
      const t0 = performance.now();
      const coldRes = await executeAdvancedRag(query, 'ta');
      const coldLatency = performance.now() - t0;

      // Warm cached retrieval
      const t1 = performance.now();
      const warmRes = await executeAdvancedRag(query, 'ta');
      const warmLatency = performance.now() - t1;

      const cacheHit = warmRes.provider.includes('Cache');
      const latencyDropPct = ((coldLatency - warmLatency) / coldLatency) * 100;

      const passed = !coldRes.isAbstained && cacheHit && warmLatency < 50;

      return {
        passed,
        details: `Cold Latency: ${coldLatency.toFixed(1)}ms -> Warm Latency: ${warmLatency.toFixed(2)}ms (Speedup: ${latencyDropPct.toFixed(1)}%, Cache Hit: ${cacheHit})`,
        latencyMs: Math.round(warmLatency),
      };
    },
  },

  // 7. Startup Cost Economics & Scale Metrics ($0.00035/query)
  {
    id: 'PHASE9-COST-ECONOMICS',
    category: 'Cost Optimization',
    name: 'Operating Cost Model Verification ($0.00035/query for 250,000 farmers)',
    run: async () => {
      const start = Date.now();
      const report = generateUsageIntelligence();

      const costPerQuery = report.costMetrics.estimatedCostPerQueryUsd;
      const targetMaxCost = 0.0005; // Less than half a cent
      const monthlyQueriesFor25kFarmers = 125000; // 5 queries/month/farmer
      const projectedMonthlyCost = monthlyQueriesFor25kFarmers * costPerQuery;

      const passed = costPerQuery <= targetMaxCost && projectedMonthlyCost < 50;

      return {
        passed,
        details: `Estimated Cost Per Query: $${costPerQuery} | 125k Queries Projected Monthly Cost: $${projectedMonthlyCost.toFixed(2)} (< $50/month)`,
        latencyMs: Date.now() - start,
      };
    },
  },

  // 8. Regulatory Agrochemical Safety Interceptor (Supreme Court / CIBRC)
  {
    id: 'PHASE9-CHEMICAL-SAFETY-GUARD',
    category: 'Safety & Compliance',
    name: 'Supreme Court & CIBRC Banned Pesticide Interceptor',
    run: async () => {
      const start = Date.now();
      const hazardousCheck = checkHazardousChemicals('கத்தரி பயிருக்கு மோனோகுரோட்டோபாஸ் (Monocrotophos) தெளிக்கலாமா?', '');

      const isBanned = hazardousCheck.isBanned;
      const hasCibrcWarning = Boolean(
        hazardousCheck.reason &&
        (hazardousCheck.reason.includes('Banned') ||
         hazardousCheck.reason.includes('banned') ||
         hazardousCheck.reason.includes('Supreme Court') ||
         hazardousCheck.reason.includes('Insecticides Act'))
      );
      const hasSafeAlternatives = Boolean(hazardousCheck.safeAlternatives && hazardousCheck.safeAlternatives.length > 0);

      const passed = isBanned && hasCibrcWarning && hasSafeAlternatives;

      return {
        passed,
        details: `Chemical Detected: ${hazardousCheck.chemicalName} | Banned: ${isBanned} | Reason: ${hazardousCheck.reason?.substring(0, 60)}... | Legal Bio-Alternatives: ${hazardousCheck.safeAlternatives}`,
        latencyMs: Date.now() - start,
      };
    },
  },

  // 9. Authentic Regional Tamil Agronomic Vocabulary & Inflection Invariance
  {
    id: 'PHASE9-TAMIL-VOCAB-INVARIANCE',
    category: 'Multilingual NLP',
    name: 'Colloquial Tamil Agronomic Terms & Inflection Robustness',
    run: async () => {
      const start = Date.now();
      // Case 1: Locative inflection 'கரும்பில்' matching 'Sugarcane (கரும்பு)'
      const resSugarcane = await executeAdvancedRag('கரும்பில் சொட்டுநீர் உர பாசனம் மற்றும் மூடாக்கு மேலாண்மை', 'ta');
      // Case 2: Regional colloquial idiom 'காய்ச்சலும் பாய்ச்சலும்' (AWD)
      const resAwd = await executeAdvancedRag('நெல் சாகுபடியில் காய்ச்சலும் பாய்ச்சலும் நீர் மேலாண்மை முறை என்ன?', 'ta');

      const passedSugarcane =
        resSugarcane.answerText.includes('Sugarcane') ||
        resSugarcane.answerText.includes('கரும்பு') ||
        resSugarcane.sourceIds.includes('doc-tnau-sugarcane-fertigation');
      const passedAwd = resAwd.answerText.includes('நீர்') || resAwd.answerText.includes('காய்ச்சலும் பாய்ச்சலும்');

      const passed = passedSugarcane && passedAwd;

      return {
        passed,
        details: `Sugarcane Inflection Handled: ${passedSugarcane} (Sources: [${resSugarcane.sourceIds.join(', ')}]) | AWD Colloquial Term Recognized: ${passedAwd}`,
        latencyMs: Date.now() - start,
      };
    },
  },

  // 10. Multi-Document Evidence Traceability & Groundedness
  {
    id: 'PHASE9-GROUNDED-TRACEABILITY',
    category: 'RAG Groundedness',
    name: 'Institutional Source Citation Traceability (TNAU / ICAR / CIBRC)',
    run: async () => {
      const start = Date.now();
      const res = await executeAdvancedRag('What is the recommended seed treatment and blast management in paddy?', 'en');

      const hasCitations = res.sourceIds.length > 0;
      const hasEvidenceExcerpts = res.evidenceList.length > 0;
      const hasInstitution = res.evidenceList.some(
        (e) => e.sourceInstitution.includes('TNAU') || e.sourceInstitution.includes('ICAR')
      );

      const passed = hasCitations && hasEvidenceExcerpts && hasInstitution && !res.isAbstained;

      return {
        passed,
        details: `Source IDs: [${res.sourceIds.join(', ')}] | Citations Count: ${res.evidenceList.length} | Institutions: ${res.evidenceList.map((e) => e.sourceInstitution).join('; ')}`,
        latencyMs: Date.now() - start,
      };
    },
  },
];

async function runPhase9Benchmark() {
  console.log('='.repeat(80));
  console.log('🚀 AGRIKNOW AI — PHASE 9 CONTINUOUS IMPROVEMENT & SCALABILITY BENCHMARK');
  console.log('='.repeat(80));
  console.log(`Timestamp: ${new Date().toISOString()}`);
  console.log(`Evaluator: Automated Production Verification Suite`);
  console.log(`Total Test Scenarios: ${benchmarkSuite.length}`);
  console.log('-'.repeat(80));

  let passCount = 0;
  const results: { id: string; name: string; passed: boolean; latencyMs: number; details: string }[] = [];

  for (const test of benchmarkSuite) {
    try {
      const result = await test.run();
      if (result.passed) {
        passCount++;
        console.log(`✅ [PASS] ${test.id.padEnd(28)} | ${result.latencyMs.toString().padStart(4)}ms | ${test.name}`);
        console.log(`   └─ Details: ${result.details}`);
      } else {
        console.log(`❌ [FAIL] ${test.id.padEnd(28)} | ${result.latencyMs.toString().padStart(4)}ms | ${test.name}`);
        console.log(`   └─ Failure: ${result.details}`);
      }
      results.push({ id: test.id, name: test.name, passed: result.passed, latencyMs: result.latencyMs, details: result.details });
    } catch (err: unknown) {
      console.log(`❌ [ERROR] ${test.id.padEnd(28)} | Exception: ${(err as Error).message}`);
      results.push({ id: test.id, name: test.name, passed: false, latencyMs: 0, details: (err as Error).message });
    }
  }

  console.log('-'.repeat(80));
  const passRate = ((passCount / benchmarkSuite.length) * 100).toFixed(1);
  console.log(`📊 BENCHMARK SUMMARY: ${passCount}/${benchmarkSuite.length} PASSED (${passRate}%)`);
  console.log('='.repeat(80));

  if (passCount === benchmarkSuite.length) {
    console.log('🎉 ALL PHASE 9 BENCHMARK EVALUATIONS PASSED WITH 100% INTEGRITY.');
    process.exit(0);
  } else {
    console.error(`⚠️ Benchmark failed with ${benchmarkSuite.length - passCount} failing tests.`);
    process.exit(1);
  }
}

runPhase9Benchmark();
