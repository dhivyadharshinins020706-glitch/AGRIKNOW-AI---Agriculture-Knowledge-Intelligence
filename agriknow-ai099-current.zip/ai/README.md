# AGRIKNOW AI — Artificial Intelligence & Advanced RAG Module

The AI module powers the Agricultural Knowledge Intelligence Engine. It implements an Advanced Retrieval-Augmented Generation (RAG) architecture tailored for Indian agriculture and bilingual queries (Tamil & English).

## Structure
- `rag/`:
  - `advancedRagEngine.ts`: Multi-stage RAG coordinator:
    1. Query normalization & intent recognition (crop, symptom, soil, region, language)
    2. Hybrid Search (Vector cosine similarity + BM25 keyword matching + metadata filtering)
    3. Cross-document reranking with dynamic Top-K selection
    4. Multi-hop synthesis across conflicting and complementary agricultural documents
    5. Corrective RAG with safe abstention thresholds (rejects unverified recommendations)
  - `queryCache.ts`: High-performance in-memory LRU query cache with 15-minute TTL (<2ms repeat response latency)
  - `ragSafetyGuard.ts`: 
    - Prompt injection & instruction override defense
    - Delimiter escape & passive evidence encapsulation (`<<<UNTRUSTED_DOCUMENT_EVIDENCE>>>`)
    - Banned hazardous chemical interceptor (Monocrotophos, Endosulfan, Phorate, Carbofuran)
  - `mockRagData.ts`: Verified offline research corpus from ICAR and TNAU
- `nlp/`:
  - `chunker.ts`: Semantic sentence-boundary document chunker with configurable overlap
  - `textCleaner.ts`: Unicode normalizer, Tamil character preserver, ligature cleaner
  - `embeddingGenerator.ts`: Multilingual embedding generation interface
  - `pdfExtractor.ts`: Document segmentation and page-aware text extraction
- `services/`:
  - `aiService.ts`: Primary conversational assistant orchestration, streaming, rate-limit enforcement, and speech-to-text / text-to-speech bridge
