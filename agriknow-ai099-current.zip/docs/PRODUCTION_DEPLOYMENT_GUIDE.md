# AGRIKNOW AI — Production Deployment & Public Launch Guide

This document defines the deployment architecture, environment configurations, security guidelines, rollback protocols, and maintenance procedures for **AGRIKNOW AI**.

---

## 🏛️ 1. Production Hosting Architecture

```
                                [ Indian Farmers & Extension Workers ]
                                                  │
                                                  ▼
                                      [ Vercel Global Edge CDN ]
                                       - HTTPS / TLS 1.3
                                       - Auto Gzip / Brotli Compression
                                       - DDoS Protection & Rate Limiting
                                       - SPA Rewrites (/* -> /index.html)
                                                  │
                                                  ▼
                                      [ AGRIKNOW AI Client SPA ]
                                  React 18 + TypeScript + Tailwind CSS
                                                  │
                      ┌───────────────────────────┴───────────────────────────┐
                      ▼                                                       ▼
          [ In-Memory AI / Advanced RAG ]                             [ Supabase Managed Cloud ]
          - Query Normalization & Language Router                     - PostgreSQL 15 (Managed)
          - Hybrid Retrieval (Vector + BM25 + RRF)                    - pgvector (128-D / 1536-D)
          - Knowledge Graph Traversal                                 - Row Level Security (RLS)
          - Chemical Guard (Insecticides Act 1968)                    - Realtime Telemetry & Audit
          - Cross-Encoder Reranking & In-Memory LRU Cache             - Automated Daily Backups
```

### Hosting Platform Selection Rationale
| Component | Selected Platform | Rationale |
| :--- | :--- | :--- |
| **Frontend & RAG Client** | **Vercel** | Global Edge CDN with zero cold-start, automatic Let's Encrypt SSL, instant rollbacks, and high availability across Indian ISPs (Jio, Airtel, BSNL). |
| **Database & Vector Store** | **Supabase (Managed PostgreSQL)** | Native `pgvector` support for cosine similarity, automatic Row Level Security, built-in Auth, automated daily snapshots, and zero infra overhead. |
| **Agricultural Evidence** | **Bundled ICAR/TNAU Corpus + Cloud Ingestion** | Hybrid availability: verified starter research corpus is instantly accessible offline/locally, while cloud database handles admin ingestion. |

---

## 🌐 2. Domain & HTTPS Configuration

- **Primary Production URL:** [https://agriknow-ai.vercel.app](https://agriknow-ai.vercel.app)
- **SSL / TLS Version:** TLS 1.3 / TLS 1.2 with HSTS (`Strict-Transport-Security: max-age=63072000; includeSubDomains; preload`).
- **Custom Domain Setup (Optional):**
  1. Add domain `agriknow.in` or `agriknow.ai` in Vercel Dashboard $\rightarrow$ Settings $\rightarrow$ Domains.
  2. Configure DNS A record pointing to `76.76.21.21` or CNAME to `cname.vercel-dns.com`.
  3. Vercel automatically provisions and renews Let's Encrypt SSL certificates.

---

## 🔐 3. Environment Variables & Secret Separation

| Variable | Environment | Description | Sensitivity |
| :--- | :---: | :--- | :---: |
| `VITE_SUPABASE_URL` | Dev / Staging / Prod | Supabase Project REST Endpoint URL | Public |
| `VITE_SUPABASE_ANON_KEY` | Dev / Staging / Prod | Supabase Anonymous Client Key (RLS protected) | Public |
| `VITE_API_BASE_URL` | Staging / Prod | Optional backend Edge Function proxy | Public |
| `VITE_AI_MODEL_ENDPOINT` | Prod | Optional custom LLM inference endpoint | Public |
| `VITE_WEATHER_API_KEY` | Prod | Hyperlocal agricultural weather service key | Secret |
| `VERCEL_TOKEN` | CI/CD | Vercel deployment token stored in GitHub Secrets | **Strict Secret** |

> **Security Rule:** Never commit `.env` or `.env.local` to Git. Only `.env.example` is committed. All sensitive credentials are configured via Vercel Project Environment Variables and GitHub Action Secrets.

---

## 🔄 4. CI/CD & Automated Verification Pipeline

Every push or pull request to `main` triggers `.github/workflows/ci-cd.yml`:

1. **Lint & Code Quality:** `npm run lint` (0 errors required).
2. **Type Safety:** `npm run typecheck` (strict TypeScript validation).
3. **Phase 4 RAG Engine Benchmark:** 8/8 tests verifying retrieval, RRF ranking, citations, and honest abstention.
4. **Phase 5 Assistant Benchmark:** 6/6 tests verifying bilingual follow-ups and TNAU agronomy recommendations.
5. **Phase 6 Security & Reliability:** 10/10 tests verifying XSS sanitization, upload magic bytes, prompt injection defenses, rate limiting, and PII masking.
6. **Phase 7 Pilot Scenarios Benchmark:** 10/10 tests verifying all 6 major Tamil Nadu crops and informed consent gates.
7. **Database Backup Integrity:** Verifies snapshot generation and cryptographic SHA-256 validation.
8. **Production Build:** `npm run build` compiles minified bundle in `<4s`.
9. **Automatic Deployment:** On `main` merge, deploys to Vercel and tests public HTTP 200 health.

---

## 🛟 5. Rollback & Incident Response Procedure

### Immediate Rollback Criteria
1. Live endpoint returns HTTP 5xx or fails health check.
2. Unhandled runtime crash caught by Error Boundary impacting $>2\%$ of sessions.
3. Unsafe pesticide dosage or banned chemical advice reported by agricultural officers.
4. Data loss or database connectivity breach.

### Rollback Commands
```bash
# Option A: Instant Vercel CLI Rollback
vercel rollback [DEPLOYMENT_URL_OR_ID]

# Option B: Vercel Web Dashboard
Navigate to https://vercel.com/medical-ai-app/agriknow-ai -> Deployments
Click the previous healthy deployment -> Select "Promote to Production"
```

---

## 💰 6. Estimated Operating Costs

| Tier | Estimated Monthly Cost | Traffic Capacity |
| :--- | :---: | :--- |
| **Pilot / Hobby Tier (Current)** | **$0 / month** | Up to 10,000 active farmers / month; 100 GB bandwidth; 500 MB database. |
| **State-Wide Production Tier** | **$45 / month** | Up to 250,000 active farmers / month ($20 Vercel Pro + $25 Supabase Pro with 8 GB RAM, daily backups, and SLA). |
