# AGRIKNOW AI — PHASE 10: BUSINESS MODEL, MONETIZATION & STARTUP READINESS STRATEGY

**Document Version:** 1.0.0  
**Date:** November 2026  
**Classification:** Confidential — Startup Strategy & Commercial Planning  
**Target Market:** India (Primary: Tamil Nadu & South India; Secondary: National)

---

## Executive Summary

AGRIKNOW AI is an advanced, multilingual, university-grounded Agricultural Retrieval-Augmented Generation (RAG) platform. By combining Tamil and English natural language query understanding, hybrid BM25 + semantic vector search, agricultural knowledge graph traversal, and Corrective RAG (CRAG) quality guardrails, the platform delivers verifiable agronomic advice cited directly to Tamil Nadu Agricultural University (TNAU) and Indian Council of Agricultural Research (ICAR) manuals.

This document establishes the commercial monetization strategy, unit economics, go-to-market plan, regulatory compliance framework, and financial roadmap for AGRIKNOW AI's launch as a sustainable agtech enterprise.

---

## 1. Market Research & Industry Landscape

### 1.1 The Indian AgriTech Opportunity
According to recent industry research (EY India AgriTech Report; Bain & Company "India Agritech Opportunity"):
* **Market Size:** The Indian agricultural technology addressable market is estimated at **$24 Billion**, with current technological penetration below **2.5%**, indicating significant headroom for growth.
* **Smallholder Dominance:** Per the Ministry of Agriculture & Farmers Welfare (Agriculture Census), **86.2% of Indian farmers are small and marginal** (operating < 2 hectares / 5 acres of land). In Tamil Nadu, there are approximately **7.9 million operational landholdings** with an average landholding size of **0.75 hectares**.
* **Smartphone & Mobile Data Penetration:** Over **420+ million rural Indians** are active internet users (IAMAI / Kantar). The vast majority access digital services primarily in vernacular languages (Tamil, Hindi, Telugu, Marathi).

### 1.2 The Agricultural Extension Gap
Traditional agricultural extension in India faces structural bottlenecks:
* The national extension worker-to-farmer ratio is estimated at **1:1,162** (well below the FAO recommendation of 1:400).
* Farmers frequently rely on local retail input dealers for crop protection advice. Because input dealers operate on sales commissions, this creates an inherent conflict of interest, often resulting in over-application of fertilizers and inappropriate pesticide choices that increase cost of cultivation by 20–35% while degrading soil health.

### 1.3 Competitor Landscape & AGRIKNOW AI Positioning

| Provider | Operating Model | Monetization Method | Critical Limitations | AGRIKNOW AI Advantage |
| :--- | :--- | :--- | :--- | :--- |
| **Plantix** | Mobile CV disease detection | Agrochemical banner ads & pesticide sponsor referrals | Computer vision often misidentifies overlapping symptoms; commercial agrochemical bias | Grounded exclusively in verified university research (TNAU/ICAR); zero agrochemical sponsorships |
| **DeHaat / AgroStar** | Full-stack input commerce + advisory | Retail product margins on seeds, chemicals & fertilizers | Advisory is an acquisition funnel for selling physical inventory | Independent advisory integrity; checks banned substances under Insecticides Act 1968 |
| **Kisan Suvidha / Mkisan** | Govt portal & SMS broadcasts | 100% Taxpayer funded | Generic one-way broadcast SMS; no conversational multi-hop RAG or personalized soil interpretation | Real-time bilingual conversational AI with deep multi-hop RAG & custom soil card analysis |
| **Cropin** | Enterprise satellite farm management | B2B enterprise SaaS for agribusiness supply chains | Expensive enterprise tool; inaccessible to individual smallholder farmers | Free smallholder access supported by B2B/FPO SaaS |

---

## 2. Customer Segmentation

AGRIKNOW AI addresses five distinct, complementary customer segments:

```mermaid
graph TD
    A["AGRIKNOW AI Platform"] --> B["Segment 1: Smallholder Farmers (Free)"]
    A --> C["Segment 2: FPOs & PACS (B2B SaaS)"]
    A --> D["Segment 3: Agribusiness & Input Corporates (Enterprise)"]
    A --> E["Segment 4: Universities & KVKs (Research Tier)"]
    A --> F["Segment 5: State Agriculture Departments (B2G)"]
```

1. **Individual Smallholder Farmers (B2C — Free):**
   - Profile: Farmers cultivating 0.5 to 5 acres in Tamil Nadu (Cauvery delta, western belt, southern rainfed tract).
   - Needs: Rapid, trustworthy pest/disease identification in Tamil; exact soil test dosage guidance; weather and mandi rates; government scheme subsidies.
2. **Farmer Producer Organizations (FPOs) & PACS (B2B SaaS — Pro Tier):**
   - Profile: Over 700+ registered FPOs in Tamil Nadu (promoted via NABARD, SFAC, and TN Small Farmers Agri-Business Consortium). Typical membership: 300 to 1,000 farmers.
   - Needs: Block-level pest outbreak tracking; member harvest scheduling; bulk soil card digitization; bulk SMS/WhatsApp advisory broadcasts.
3. **Agribusiness Input & Seed Corporates (Enterprise SaaS):**
   - Profile: Hybrid seed producers, bio-fertilizer manufacturers, and contract farming companies (e.g. sugar mills, cotton ginners).
   - Needs: Field executive mobile agronomy co-pilot, proprietary internal research ingestion, dedicated API integration, regional disease sentiment dashboards.
4. **State Agricultural Universities & KVKs (Institutional Tier):**
   - Profile: TNAU campuses, 32 Krishi Vigyan Kendras across Tamil Nadu, ICAR institutes.
   - Needs: Two-way extension channel; automated capture of unanswered farmer questions (knowledge gaps) for academic trial planning; student research annotation portals.
5. **Government & State Extension Departments (B2G):**
   - Profile: Department of Agriculture, Department of Horticulture, Govt of Tamil Nadu.
   - Needs: Real-time district crop health indicators, verifying scheme uptake, tracking banned chemical inquiries.

---

## 3. Business Model & Monetization Architecture

AGRIKNOW AI adopts a **Dual-Engine Hybrid B2B/B2G SaaS + Smallholder Free Model**:

```mermaid
flowchart LR
    Farmers["Smallholder Farmers\n(Kisan Free: ₹0 Forever)"]
    Platform["AGRIKNOW AI Engine\n(Multilingual RAG + Knowledge Graph)"]
    FPOs["FPOs & PACS\n(Pro Tier: ₹2,499/mo)"]
    Corporates["Agri-Enterprises & Seed Mills\n(Enterprise Tier: ₹14,999/mo)"]
    Universities["Universities & KVKs\n(Research Tier: ₹4,999/mo)"]

    Platform -->|Free Advisory & Safety| Farmers
    FPOs -->|Subscription Revenue| Platform
    Corporates -->|Licensing & Dedicated API| Platform
    Universities -->|Research Ingestion Grants| Platform
    Platform -->|Outbreak Analytics & Bulk Tools| FPOs
    Platform -->|Custom Ingestion & Webhooks| Corporates
    Platform -->|Knowledge Gap Intelligence| Universities
```

### 3.1 Why B2B/B2G Cross-Subsidizes B2C Free
1. **Preserving Farmer Trust:** Direct monetization of smallholder farmers (charging pay-per-query or monthly fees) creates steep adoption barriers in rural India and incentivizes monetization through pesticide sales.
2. **High Enterprise Willingness-to-Pay:** FPOs, sugar mills, seed corporations, and contract farming companies lose millions annually to late pest detection, improper fertilizer schedules, and field officer overhead. They readily pay ₹2,499 to ₹14,999/month for digitized acreage management and operational dashboards.
3. **Data Integrity & Impartiality:** By refusing agrochemical manufacturer advertising, AGRIKNOW AI preserves its status as an objective university-grounded platform.

---

## 4. Product Packaging & Pricing Strategy

| Feature / Capability | Kisan Free (விவசாயி) | FPO & Cooperative Pro | Agri-Enterprise & Seed Corp | University & KVK Research |
| :--- | :--- | :--- | :--- | :--- |
| **Monthly Pricing (INR)** | **₹0 (Free Forever)** | **₹2,499 / month** | **₹14,999 / month** | **₹4,999 / month** |
| **Annual Pricing (INR)** | **₹0** | **₹24,990 / year** (~17% off) | **₹149,990 / year** (~17% off) | **₹49,990 / year** (~17% off) |
| **Target Audience** | Individual smallholders | FPOs, PACS (up to 500 members) | Agribusinesses & seed firms | SAUs, ICAR, KVK researchers |
| **Tamil & English AI Assistant** | Full Access | Full Access | Full Access | Full Access |
| **Disease Diagnosis & Causes** | Full Access | Full Access | Full Access | Full Access |
| **Soil Health Card Analysis** | Full Access | Bulk CSV Batch Upload | Custom Parameter Mapping | Batch Trial Soil Analysis |
| **Banned Agrochemical Guard** | Full Unrestricted Access | Full Unrestricted Access | Full Unrestricted Access | Full Unrestricted Access |
| **University Evidence Citations** | Full Unrestricted Access | Full Unrestricted Access | Full Unrestricted Access | Full Unrestricted Access |
| **Government Schemes & Portals**| Full Unrestricted Access | Full Unrestricted Access | Full Unrestricted Access | Full Unrestricted Access |
| **District Outbreak Analytics** | Community Alert View | Dedicated Block Map & Alerts | District Sentiment & Trends | State-wide Epidemiology View |
| **Custom Knowledge Ingestion** | — | — | Proprietary Research / Catalogs | University Extension Bulletins |
| **Dedicated API & Webhooks** | — | — | 99.9% SLA Dedicated Endpoints | Research Data API |
| **Seats / Multi-User Logins** | 1 (Farmer Profile) | 5 Extension Staff Accounts | 50 Field Officer Accounts | 20 Faculty / Student Seats |
| **Support SLA** | Community / FAQ | 4-Hour Response SLA | Dedicated Agronomy Architect | Academic Coordinator |

### 4.1 Strict Ethical Farmer Guarantee
> [!IMPORTANT]
> **Zero Paywalls on Agricultural Safety:** Under no circumstances will chemical toxicity warnings, Supreme Court / CIBRC banned chemical alerts, TNAU/ICAR citations, or basic disease management be restricted behind a paid tier. Safety and evidence traceability are considered universal agricultural rights.

---

## 5. Cost Structure & Unit Economics

### 5.1 Query Unit Economics
Operating metrics derived from AGRIKNOW AI's actual Phase 8 and Phase 9 production benchmarks:
* **Blended Query Latency:** ~25ms cold / ~0.8ms cached.
* **Cache Hit Rate:** 68.5% across repeated regional queries.
* **Cost Per Query:** **$0.00035 USD ≈ ₹0.0306 INR**.
* **Monthly Query Volume per Active Farmer:** ~5 queries / month.
* **Monthly Infrastructure Cost per Active Farmer:** **₹0.15 INR / farmer / month**.

### 5.2 FPO Pro Tier Gross Margins
* Typical active FPO (500 enrolled members):
  * Monthly query volume: ~15,000 to 20,000 queries.
  * Direct LLM + Vector Search COGS: $20,000 \times ₹0.0306 = ₹612 / month$.
  * Monthly Subscription Revenue: **₹2,499 / month**.
  * **Gross Profit:** **₹1,887 / month**.
  * **Gross Margin:** **75.5%**.

---

## 6. 12-Month Financial Projections (3 Scenarios)

All figures in Indian Rupees (INR). Base assumptions: USD/INR = 87.5; zero external debt.

| Financial Metric | Conservative Scenario | Moderate Scenario | Optimistic Scenario |
| :--- | :--- | :--- | :--- |
| **Active Free Farmers** | 15,000 | 50,000 | 150,000 |
| **Paid FPO Subscriptions (₹25k/yr)** | 12 FPOs | 45 FPOs | 120 FPOs |
| **Paid Enterprise Subscriptions (₹150k/yr)** | 2 Corporates | 6 Corporates | 15 Corporates |
| **Paid University Subscriptions (₹50k/yr)** | 3 Institutes | 8 Institutes | 18 Institutes |
| **Annual Recurring Revenue (ARR)** | **₹8,09,640** | **₹24,24,410** | **₹61,48,350** |
| **Annual COGS (Hosting, LLM, Storage)**| ₹1,26,000 | ₹2,28,000 | ₹4,95,000 |
| **Annual Opex (Agronomist, Travel, Legal)**| ₹5,40,000 | ₹11,20,000 | ₹24,50,000 |
| **Net Annual Profit / Loss** | **+ ₹1,43,640** | **+ ₹10,76,410** | **+ ₹32,03,350** |
| **Net Profit Margin** | 17.7% | 44.4% | 52.1% |
| **Breakeven Horizon** | **Month 9** | **Month 6** | **Month 4** |

---

## 7. Customer Acquisition Strategy (Go-To-Market)

```mermaid
flowchart TD
    GTM1["Channel 1: KVK Demonstrations\n(Monthly scientific field days at district KVKs)"]
    GTM2["Channel 2: FPO General Body Meetings\n(Direct demo to Board of Directors & Lead Farmers)"]
    GTM3["Channel 3: Village Input Retailers\n(Tabletop QR stands with no-commission objective positioning)"]
    GTM4["Channel 4: WhatsApp Farmer Groups\n(Shareable bilingual diagnosis cards with deep links)"]

    GTM1 --> Funnel["Farmer & FPO Onboarding Funnel"]
    GTM2 --> Funnel
    GTM3 --> Funnel
    GTM4 --> Funnel
    Funnel --> FreeFarmer["Kisan Free Tier Adoption"]
    Funnel --> FpoPaid["FPO Pro Tier Conversion\n(CAC: ₹4,500 | Payback: 2.4 months)"]
```

1. **Krishi Vigyan Kendra (KVK) Scientific Field Days:**
   - Conduct live demonstrations during Rabi and Kharif pre-sowing farmer training camps in Thanjavur, Madurai, Coimbatore, and Salem.
   - Cost: ₹2,000 per field day (tea/pamphlets). Yields 80–120 farmer signups and direct introductions to local FPO chairpersons.
2. **FPO Board Direct Outreach:**
   - Present the FPO Outbreak Dashboard to FPO Boards of Directors and Chief Executive Officers (CEOs).
   - Value Proposition: Reduces field staff travel expenses by 40% and provides digitized farmer compliance documentation for NABARD reporting.
   - Customer Acquisition Cost (CAC): **₹4,500 per FPO**. With ₹1,874 monthly gross profit contribution, the **payback period is 2.4 months**.
3. **Tabletop QR Stands at Fertilizer / PACS Outlets:**
   - Place laminated Tamil QR stands ("உங்கள் பயிர் நோயை உடனே கண்டறியுங்கள் — TNAU பரிந்துரை") at 100 primary village cooperative credit societies.
4. **Organic Peer-to-Peer WhatsApp Referral:**
   - Farmers share bilingual PDF or text diagnosis summaries directly to WhatsApp farming groups with one click.

---

## 8. Institutional Partnership Strategy

| Category | Target Institutions | Concrete Value Proposition | Realistic Engagement Pathway |
| :--- | :--- | :--- | :--- |
| **Academic & Extension** | Tamil Nadu Agricultural University (TNAU), ICAR-NRCB, ICAR-CICR | Free digitized dissemination of university crop manuals with full institutional citation and copyright protection | Present at TNAU Directorate of Extension Education; submit technical evaluation report |
| **FPO Promoting Bodies** | NABARD (Tamil Nadu Regional Office), Small Farmers Agribusiness Consortium (SFAC) | Scalable digital advisory infrastructure for newly formed FPOs under the 10,000 FPO scheme | Apply for NABARD Rural Innovation & Incubation promotional support |
| **Financial & Insurance** | Primary Agricultural Cooperative Credit Societies (PACS), PMFBY Insurers | Verified farmer advisory trail reducing non-wilful loan default and crop failure claims | Pilot in 2 Cauvery Delta PACS districts (Thanjavur & Tiruvarur) |
| **Sustainable Agri Inputs** | Certified Organic Bio-fertilizer & Bio-control Producers | Verified bio-control alternatives surfaced when banned chemical interceptor triggers | Non-exclusive directory inclusion for certified CIBRC legal alternatives |

---

## 9. Business Model Canvas (BMC)

```
┌───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                                 AGRIKNOW AI BUSINESS MODEL CANVAS                                     │
├───────────────────────┬───────────────────────┬─────────────────────────┬───────────────────────┬─────────────────────┤
│ KEY PARTNERS          │ KEY ACTIVITIES        │ VALUE PROPOSITIONS      │ CUSTOMER RELATIONSHIPS│ CUSTOMER SEGMENTS   │
│                       │                       │                         │                       │                     │
│ • TNAU & ICAR         │ • Bilingual RAG & KG  │ Farmers:                │ • Community Trust &   │ • Smallholder       │
│   Extension           │   maintenance         │ • Trustworthy, grounded │   Bilingual WhatsApp  │   Farmers (Free)    │
│   Directorates        │ • Continuous corpus   │   advice in natural     │ • FPO Dedicated Key   │ • FPOs & PACS       │
│ • NABARD TN Regional  │   verification        │   Tamil & English       │   Account Management  │   (B2B SaaS)        │
│   Office              │ • Outbreak analytics  │ • Free chemical safety  │ • Field Demonstrations│ • Agribusiness &    │
│ • State FPO           │   & model monitoring  │   & university evidence │   at District KVKs    │   Seed Corporates   │
│   Federations         │ • KVK farmer training │ FPOs & Agribusinesses:  ├───────────────────────┤ • State Agriculture │
│ • Primary Agri        ├───────────────────────┤ • Outbreak tracking &   │ CHANNELS              │   Universities &    │
│   Cooperative Credit  │ KEY RESOURCES         │   acreage intelligence  │                       │   KVKs              │
│   Societies (PACS)    │                       │ • 70% reduction in field│ • Mobile PWA & Web App│                     │
│                       │ • University Ingestion│   officer advisory time │ • KVK Field Days      │                     │
│                       │   Pipeline & Corpus   │ • Verified DPDP Act     │ • FPO WhatsApp Groups │                     │
│                       │ • Multilingual RAG    │   compliance            │ • PACS QR Standees    │                     │
│                       │   In-Memory Engine    │                         │ • Direct Enterprise   │                     │
│                       │ • Core Engineering &  │                         │   Inside Sales        │                     │
│                       │   Agronomy Team       │                         │                       │                     │
├───────────────────────┴───────────────────────┴─────────────────────────┴───────────────────────┴─────────────────────┤
│ COST STRUCTURE                                                          │ REVENUE STREAMS                             │
│ • Cloud Hosting & Edge CDN (Vercel, Supabase): ₹8,000 - ₹25,000/mo      │ • FPO & Cooperative Pro Subscriptions:      │
│ • Vector Storage & LLM Inference: ₹0.0306 / query (68.5% cache reduced) │   ₹2,499/month (or ₹24,990/year)            │
│ • Field Agronomist Salaries & KVK Travel: ₹45,000 - ₹90,000/mo          │ • Agri-Enterprise Licensing & Custom API:   │
│ • Legal, Compliance, GST & DPIIT Annual Filings: ₹60,000/yr             │   ₹14,999/month (or ₹149,990/year)          │
│ • FPO Customer Acquisition Cost (CAC): ₹4,500 / FPO                     │ • University Extension Bulletins Portal:    │
│                                                                         │   ₹4,999/month (or ₹49,990/year)            │
│                                                                         │ • 100% Free Forever for Individual Farmers  │
└───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 10. Legal, Regulatory & Governance Framework

### 10.1 Digital Personal Data Protection Act 2023 (DPDP Act)
* **Lawful Basis:** Personal farm context (district, crop, soil, acreage) is gathered exclusively with affirmative informed consent under Section 6 of the DPDP Act 2023.
* **Right to Erasure (Section 12):** The application features an instant, one-click `purgePersonalizationContext()` button on the Profile screen, immediately deleting all local and server-side farmer records.
* **No Telemetry PII Leakage:** Farmers' mobile numbers and phone identities are masked and never transmitted in AI prompt contexts or analytics payloads.

### 10.2 Indian Insecticides Act 1968 & Supreme Court Directives
* **Strict Interception of Banned Chemicals:** Any farmer query inquiring about Monocrotophos, Endosulfan, Carbofuran, Methomyl, or Phorate is pre-emptively intercepted before generating an answer.
* **Clear Statutory Disclaimers:** CIBRC regulatory orders and legal bio-alternatives (e.g. Neem oil, Trichogramma, pheromone traps) are prominently displayed.

### 10.3 Agricultural Advisory Disclaimer (Consumer Protection Act 2019)
* Clear statutory disclaimers explain that AI agronomic recommendations provide educational support based on published university manuals.
* Field inspection by the local Assistant Agricultural Officer (AAO) or nearest KVK scientist is mandated for acute symptoms or uncertain diagnoses.

---

## 11. Risk Analysis & Mitigation Strategy

| Risk Category | Identified Threat | Likelihood | Impact | Concrete Mitigation Strategy |
| :--- | :--- | :--- | :--- | :--- |
| **Agronomic / Liability** | Hallucinated chemical dosage causing crop injury | Very Low | Critical | Multi-document CRAG verification, hard-coded chemical bounds, pre-emptive banned substance interceptors, mandatory expert review notices. |
| **Adoption / Cultural** | Resistance to typing text queries among older rural farmers | Medium | High | Bilingual voice-to-text integration, simplified iconography, visual disease comparison cards, and local ambassador training. |
| **Financial / Runway** | Delayed B2B enterprise sales cycles | Medium | Medium | Low fixed operational burn (< ₹15,000/month base infra). Break-even achievable with only 12 FPO Pro subscriptions. |
| **Regulatory / IP** | Copyright disputes on university publications | Low | Medium | Strict metadata attribution linking directly to published ICAR/TNAU public extension guides without claiming proprietary ownership. |
| **Technical / Infra** | High latency or API outages during harvest pest outbreaks | Low | Medium | Multi-tiered in-memory LRU caching, graceful fallback to canned verified rule banks, and offline PWA functionality. |

---

## 12. 12-Month Execution & Financial Roadmap

```mermaid
gantt
    title AGRIKNOW AI 12-Month Execution Roadmap
    dateFormat  YYYY-MM
    section Regulatory & Pilots
    DPIIT Startup India & Private Limited Incorporation :2026-11, 2026-12
    Field Pilots across 10 Delta KVKs & 5 FPOs           :2026-12, 2027-02
    section Commercial Launch
    Launch FPO Pro Dashboard & Self-Serve Billing        :2027-02, 2027-03
    Achieve 15 Paid FPOs (Operational Breakeven)        :2027-03, 2027-05
    section Enterprise & Scale
    Enterprise Seed & Agrochemical Custom Ingestion API :2027-05, 2027-07
    Scale to 50 FPOs & 100,000 Active Farmers           :2027-07, 2027-10
    NABARD & State Agriculture Dept B2G Pilot            :2027-09, 2027-11
```

* **Quarter 1 (Months 1–3) — Legal Structuring & Pilot Validation:**
  - Incorporate as a Private Limited entity with DPIIT Startup India recognition (qualifying for Section 80-IAC tax incentives and patent/trademark fee concessions).
  - Complete controlled pilots across 10 Krishi Vigyan Kendras in Tamil Nadu (Thanjavur, Madurai, Coimbatore).
  - Target: 10,000 registered farmers, 5 pilot FPOs.
* **Quarter 2 (Months 4–6) — Commercial FPO Rollout & Breakeven:**
  - Launch self-serve FPO onboarding portal with automated bulk soil card analysis.
  - Onboard 15–20 paying FPO Pro customers (achieving operational cash-flow breakeven).
  - Target: ₹50,000/month ARR run rate; 35,000 active farmers.
* **Quarter 3 (Months 7–9) — Enterprise Ingestion & University Portals:**
  - Roll out dedicated API and isolated tenant ingestion for agribusiness partners (seed corporations and sugar mills).
  - Partner with TNAU Directorate of Extension for institutional research telemetry licensing.
  - Target: 40 paying FPOs, 4 Enterprise customers, ₹1,50,000/month ARR run rate.
* **Quarter 4 (Months 10–12) — State-wide Scale & Institutional Integration:**
  - Expand knowledge base to 12 major South Indian crops (adding pulses, turmeric, spices).
  - Apply for NABARD Rural Innovation Assistance grant and integration with Uzhavan App digital ecosystem.
  - Target: 120+ FPOs, 150,000+ active farmers, profitable operations with >₹50 Lakhs annual recurring revenue.

---

## 13. Strategic Conclusion

AGRIKNOW AI demonstrates that agricultural AI can achieve commercial sustainability without compromising smallholder welfare. By monetizing enterprise intelligence, acreage management, and institutional extension dashboards, AGRIKNOW AI guarantees **free, untainted, life-saving agricultural advice** to every Indian farmer forever.
