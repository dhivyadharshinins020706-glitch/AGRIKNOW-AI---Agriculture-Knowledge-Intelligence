# AGRIKNOW AI — Embedding Migration, Retrieval Gateway & Rollback Guide

**Platform Version:** AGRIKNOW AI v2.4 (Enterprise Agronomic Intelligence)  
**Primary Generative Engine:** Google Gemini (`gemini-3.8-flash`)  
**Primary Embedding Engine:** Google Gemini Embedding 2 (`gemini-embedding-2`)  
**Resilient Fallback Embedding:** Multilingual Dense Hash (`multilingual-dense-hash-128`, 128-D)  

---

## 1. Background & Migration Objectives

Google deprecated `gemini-2.0-flash` on June 1, 2026, and `text-embedding-004` on January 14, 2026. AGRIKNOW AI has upgraded its primary intelligence infrastructure to:
- **`gemini-3.8-flash`**: Real multimodal reasoning and agricultural dialogue synthesis.
- **`gemini-embedding-2`**: High-dimensional semantic embeddings for crop disease, pest control, and soil management manuals.

To protect agricultural advice integrity, prevent downtime, and eliminate mathematical vector space corruption, the platform employs a four-phase migration architecture:

```
[Phase A: Schema Tagging] ──▶ [Phase B: Gateway & Ingestion] ──▶ [Phase C: Re-Embedding & Verification] ──▶ [Phase D: Deprecation]
        ✅ Complete                     ✅ Complete                             ✅ Complete                          Planned
```

---

## 2. Phase A: Database Schema Tagging & Provenance Verification

### Database Migrations
- **Locations**: `database/migrations/20261103000004_embedding_schema_tagging.sql` and `supabase/migrations/20261103000004_embedding_schema_tagging.sql` (100% byte-for-byte identical).
- **Columns Added to `public.document_chunks`**:
  - `embedding_model TEXT`: Model identifier (e.g. `gemini-embedding-2`, `multilingual-dense-hash-128`).
  - `embedding_version TEXT`: Semantic versioning (e.g. `1.0`).
  - `embedding_dimensions INTEGER`: Dimensionality of `embedding_vector` (e.g. 128, 768, 1536).

### Multi-Factor Provenance Guarantee
The SQL `UPDATE` uses a native PostgreSQL `UUID = UUID` foreign key join (`c.document_id = d.id`), completely eliminating invalid string-to-UUID casts. It verifies parent documents using a conjunctive constraint:
1. `d.verification_status = 'verified'`
2. `d.institution IN ('Tamil Nadu Agricultural University (TNAU)', 'Central Institute for Cotton Research (ICAR-CICR)', ...)`
3. Exact pairwise match on official title and canonical filename.
4. Synthetic dummy test hashes (e.g. `sha256("")`) are intentionally excluded to prevent false-positive matching against zero-byte uploads.

---

## 3. Phase B: Multi-Model Gateway & Retrieval Space Isolation

### Mathematical Vector Space Isolation
Different embedding models produce non-interchangeable vector spaces. Comparing a 768-D Gemini vector directly with a 128-D local vector produces undefined cosine similarity scores.

AGRIKNOW AI enforces strict space isolation via `isEmbeddingCompatible(queryMeta, chunkMeta)`:
1. `embedding_model` must match exactly.
2. `embedding_dimensions` must match exactly.
3. Major versions in `embedding_version` must match.
4. If incompatible, vector similarity is set to 0 (unranked in vector channel). The chunk remains retrievable via **BM25 keyword search**.

### Reciprocal Rank Fusion (RRF)
RRF combines rank positions rather than raw scores:
$$RRF(d) = \frac{1}{60 + r_{\text{vector}}} + \frac{1}{60 + r_{\text{bm25}}}$$

- Gemini chunks compete in the Gemini vector channel.
- Starter/local chunks compete in the 128-D local vector channel.
- BM25 indexes all chunks across all models without bias.

---

## 4. Phase C: Re-Embedding Procedures

### Method 1: Command-Line Interface (CLI)

```bash
# 1. Inspect current corpus distribution without modifying data
npm run reembed -- --dry-run

# 2. Run retrieval accuracy benchmark on pilot queries
npm run reembed -- --benchmark

# 3. Perform re-embedding using gemini-embedding-2 (requires GEMINI_API_KEY)
npm run reembed -- --reembed

# 4. Instant rollback to local 128-D embeddings if needed
npm run reembed -- --rollback
```

### Method 2: Ingestion Admin Dashboard (UI)
1. Navigate to `/ingestion` in the application.
2. Ensure you are authorized in **Officer / Scientist** mode.
3. Inspect the **Vector Space Gateway & Ingestion Status** bar.
4. Click **Re-Embed Corpus (Gemini)** to initiate non-destructive re-embedding.
5. In case of API rate-limiting or network failure, existing 128-D vectors remain untouched.

---

## 5. Verification Benchmark Criteria

Every re-embedding operation must satisfy the following retrieval benchmarks:

| Benchmark Case | Language | Query Sample | Expected Citation | Target Metric |
|---|---|---|---|---|
| **Paddy SRI** | Tamil | நெல்லில் குலை நோய் தாக்கினால் என்ன மருந்து தெளிக்க வேண்டும்? | `doc-tnau-paddy-sri` (Page 12) | Top-1 match, Confidence $\ge 30\%$ |
| **Cotton IPM** | English | How to monitor and control cotton bollworm using pheromone traps? | `doc-icar-cotton-ipm` (Page 4) | Top-1 match, Confidence $\ge 50\%$ |
| **Groundnut Gypsum** | Tamil | நிலக்கடலையில் பொக்கு காய் வராமல் இருக்க ஜிப்சம் எப்போது இட வேண்டும்? | `doc-tnau-groundnut-gypsum` (Page 5) | Top-1 match, Confidence $\ge 70\%$ |

---

## 6. Zero-Downtime Rollback Procedure

If the Gemini API experiences an extended regional outage or quota exhaustion:

1. **CLI Rollback**:
   ```bash
   npm run reembed -- --rollback
   ```
2. **UI Rollback**:
   Click **Rollback 128-D** on the Ingestion Admin dashboard.
3. **Database Reversion (SQL)**:
   ```sql
   UPDATE public.document_chunks
   SET 
       embedding_model = 'multilingual-dense-hash-128',
       embedding_version = '1.0',
       embedding_dimensions = 128
   WHERE embedding_model != 'multilingual-dense-hash-128';
   ```
4. **Result**: Chunks revert instantly to the local deterministic hash space without service interruption.
