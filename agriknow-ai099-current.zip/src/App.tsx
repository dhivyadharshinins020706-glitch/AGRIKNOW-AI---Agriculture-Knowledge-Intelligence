import type { ComponentType } from 'react';
import { useRoute } from '@/lib/router';
import { AppShell } from '@/components/layout/AppShell';
import { ErrorBoundary } from '@/components/ui/ErrorBoundary';
import { buttonClass } from '@/components/ui/Button';
import { FarmerGuideBot } from '@/components/guide/FarmerGuideBot';
import LandingPage from '@/pages/LandingPage';
import LoginPage from '@/pages/LoginPage';
import DashboardPage from '@/pages/DashboardPage';
import AssistantPage from '@/pages/AssistantPage';
import DiseasesPage from '@/pages/DiseasesPage';
import SoilPage from '@/pages/SoilPage';
import CropsPage from '@/pages/CropsPage';
import LibraryPage from '@/pages/LibraryPage';
import IngestionAdminPage from '@/pages/IngestionAdminPage';
import EvidencePage from '@/pages/EvidencePage';
import ProfilePage from '@/pages/ProfilePage';

const shellRoutes: Record<string, ComponentType> = {
  // Dashboard / Home
  '/dashboard': DashboardPage,
  '/home': DashboardPage,
  '/app': DashboardPage,

  // Assistant / Ask AI
  '/assistant': AssistantPage,
  '/ask': AssistantPage,
  '/ask-ai': AssistantPage,
  '/chat': AssistantPage,
  '/ai': AssistantPage,

  // Crop Health / Diseases / Pests
  '/diseases': DiseasesPage,
  '/disease': DiseasesPage,
  '/crop-health': DiseasesPage,
  '/crophealth': DiseasesPage,
  '/health': DiseasesPage,
  '/pests': DiseasesPage,
  '/pest': DiseasesPage,

  // Soil & Fertilizers
  '/soil': SoilPage,
  '/soil-fertilizer': SoilPage,
  '/soil-fertilizers': SoilPage,
  '/soil-and-fertilizer': SoilPage,
  '/soil-and-fertilizers': SoilPage,
  '/fertilizer': SoilPage,
  '/fertilizers': SoilPage,

  // Crop Choice / Advisor
  '/crops': CropsPage,
  '/crop': CropsPage,
  '/crop-choice': CropsPage,
  '/cropchoice': CropsPage,
  '/crop-advisor': CropsPage,
  '/cropadvisor': CropsPage,
  '/advisor': CropsPage,
  '/comparison': CropsPage,

  // Knowledge Library & Schemes
  '/library': LibraryPage,
  '/knowledge': LibraryPage,
  '/schemes': LibraryPage,
  '/government-schemes': LibraryPage,
  '/advisory': LibraryPage,
  '/bulletins': LibraryPage,

  // Ingestion Pipeline
  '/ingestion': IngestionAdminPage,
  '/ingestion-pipeline': IngestionAdminPage,
  '/ingestionpipeline': IngestionAdminPage,
  '/ingestion_pipeline': IngestionAdminPage,
  '/admin': IngestionAdminPage,
  '/admin-ingestion': IngestionAdminPage,
  '/pipeline': IngestionAdminPage,
  '/ingest': IngestionAdminPage,
  '/data-ingestion': IngestionAdminPage,
  '/knowledge-pipeline': IngestionAdminPage,

  // Evidence / Sources
  '/evidence': EvidencePage,
  '/sources': EvidencePage,
  '/source': EvidencePage,
  '/citations': EvidencePage,
  '/citation': EvidencePage,

  // Profile / Settings
  '/profile': ProfilePage,
  '/settings': ProfilePage,
  '/preferences': ProfilePage,
  '/account': ProfilePage,
};

function NotFound() {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center py-20 text-center">
      <p className="text-sm font-semibold uppercase tracking-[0.14em] text-leaf-700">Page not found</p>
      <h1 className="mt-3 text-3xl font-bold text-ink-900">This page is not on your farm</h1>
      <p className="mt-3 text-base text-ink-600">The link may be old or mistyped. Let&apos;s head back to your dashboard.</p>
      <a href="#/dashboard" className={buttonClass('primary', 'lg', 'mt-8')}>
        Go to dashboard
      </a>
    </div>
  );
}

export default function App() {
  const { path } = useRoute();

  const isLanding = path === '/' || path === '';
  const isLogin = path === '/login' || path === '/signin' || path === '/auth';
  const Page = shellRoutes[path];

  return (
    <ErrorBoundary>
      {isLanding ? (
        <LandingPage />
      ) : isLogin ? (
        <LoginPage />
      ) : (
        <AppShell>{Page ? <Page /> : <NotFound />}</AppShell>
      )}
      <FarmerGuideBot />
    </ErrorBoundary>
  );
}
