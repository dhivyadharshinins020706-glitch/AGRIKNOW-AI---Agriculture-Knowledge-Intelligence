import { diseases } from '../data/crops.ts';
import type { Disease } from '../types/index.ts';
import { apiConfig } from './apiConfig.ts';
import { logger } from './telemetry/logger.ts';

export interface AlternativeDiagnosis {
  disease: Disease;
  probability: number;
  differentiatingClue: string;
  differentiatingClueTa: string;
}

export interface DifferentialDiagnosisResult {
  cropName: string;
  cropNameTa: string;
  primaryDisease: Disease;
  confidence: number;
  matchReason: string;
  matchReasonTa: string;
  alternativePossibilities: AlternativeDiagnosis[];
  symptomExplanation: string;
  symptomExplanationTa: string;
  visualObservations?: string;
  whySuggested?: string;
  missingInformation?: string;
  environmentalRiskFactors: string[];
  environmentalRiskFactorsTa: string[];
  organicManagement: string[];
  organicManagementTa: string[];
  chemicalManagement: string[];
  chemicalManagementTa: string[];
  safetyPrecautions?: string[];
  safetyPrecautionsTa?: string[];
  inspectionWarning: string;
  inspectionWarningTa: string;
  sourceDocId: string;
  sourceInstitution: string;
  pageNumber: number;
  isVisionAi?: boolean;
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
}

/**
 * Real Multimodal Crop Leaf & Pest Diagnosis
 * When an image or symptoms are provided, calls AgriKnow AI (Google Gemini Vision & Clinical Pathologist)
 * to inspect the photo and field symptoms dynamically.
 */
export async function diagnoseCropSymptom(
  cropId: string,
  symptomsText = '',
  imageFile?: File,
  lang: 'ta' | 'en' = 'en'
): Promise<DifferentialDiagnosisResult> {
  const isTa = lang === 'ta';

  // 1. Send to AgriKnow AI Real-Time Endpoint (Vision / Clinical Pathology)
  try {
    let base64Data = '';
    let mimeType = 'image/jpeg';
    if (imageFile) {
      base64Data = await fileToBase64(imageFile);
      mimeType = imageFile.type || 'image/jpeg';
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 40000);

    const userNotesText = [
      `Crop: ${cropId}`,
      symptomsText ? `Reported Symptoms: ${symptomsText}` : '',
      imageFile ? 'Leaf photograph attached for visual inspection.' : 'No photo provided; diagnose based on reported symptoms.',
    ].filter(Boolean).join('. ');

    const response = await fetch(apiConfig.aiDiagnoseEndpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        imageBase64: base64Data,
        mimeType,
        userNotes: userNotesText,
        language: lang,
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (response.ok) {
      const data = await response.json();
      if (data.success && data.diagnosis) {
        const v = data.diagnosis;

        const matchingCatalog = diseases.find(
          (d) =>
            d.name.toLowerCase().includes(v.primaryDiagnosis.toLowerCase()) ||
            v.primaryDiagnosis.toLowerCase().includes(d.name.toLowerCase())
        );

        // Build dynamic disease object prioritizing real AI analysis
        const primaryDisease: Disease = {
          id: matchingCatalog?.id || `ai_diag_${Date.now()}`,
          name: v.primaryDiagnosis,
          nameTa: isTa ? v.primaryDiagnosis : (matchingCatalog?.nameTa || v.primaryDiagnosis),
          cropId: cropId || matchingCatalog?.cropId || 'general',
          cropName: v.cropIdentified || matchingCatalog?.cropName || cropId,
          scientificName: matchingCatalog?.scientificName || (v.conditionType === 'pest' ? 'Insect Pest Agent' : 'Plant Pathological Agent'),
          type: v.conditionType === 'pest' ? 'Pest' : 'Disease',
          severity: (v.confidence >= 80 ? 'High' : 'Medium') as any,
          symptoms: [v.visualObservations || v.whySuggested],
          symptomsTa: [v.visualObservations || v.whySuggested],
          causes: [v.whySuggested],
          causesTa: [v.whySuggested],
          organicTreatment: v.managementPlan?.biologicalControls || [],
          chemicalTreatment: (v.managementPlan?.certifiedChemicals || []).map(
            (c: { name: string; dosage: string; safetyNotes?: string }) =>
              `${c.name} @ ${c.dosage}${c.safetyNotes ? ` (${c.safetyNotes})` : ''}`
          ),
          chemicalControl: (v.managementPlan?.certifiedChemicals || []).map(
            (c: { name: string; dosage: string; safetyNotes?: string }) =>
              `${c.name} @ ${c.dosage}${c.safetyNotes ? ` (${c.safetyNotes})` : ''}`
          ),
          chemicalControlTa: (v.managementPlan?.certifiedChemicals || []).map(
            (c: { name: string; dosage: string; safetyNotes?: string }) =>
              `${c.name} @ ${c.dosage}${c.safetyNotes ? ` (${c.safetyNotes})` : ''}`
          ),
          biologicalControl: v.managementPlan?.biologicalControls || [],
          biologicalControlTa: v.managementPlan?.biologicalControls || [],
          prevention: v.managementPlan?.ipmAndCultural || [],
          preventiveMeasures: v.managementPlan?.ipmAndCultural || [],
          preventiveMeasuresTa: v.managementPlan?.ipmAndCultural || [],
          sourceIds: matchingCatalog?.sourceIds || ['tnau-guidelines', 'icar-crop-protection'],
          image: '',
          confidence: v.confidence,
        };

        const alternatives: AlternativeDiagnosis[] = (v.differentialDiagnoses || []).map(
          (alt: { condition: string; probability: number; differentiatingClue: string }) => ({
            disease: {
              id: `alt_${Math.random()}`,
              name: alt.condition,
              nameTa: alt.condition,
              cropId: cropId || 'general',
              cropName: v.cropIdentified || cropId,
              scientificName: 'Alternative Differential Agent',
              type: 'Disease',
              severity: 'Medium' as any,
              symptoms: [alt.differentiatingClue],
              organicTreatment: [],
              chemicalTreatment: [],
              chemicalControl: [],
              biologicalControl: [],
              prevention: [],
              preventiveMeasures: [],
              sourceIds: ['tnau-guidelines'],
              image: '',
            },
            probability: alt.probability,
            differentiatingClue: alt.differentiatingClue,
            differentiatingClueTa: alt.differentiatingClue,
          })
        );

        const defaultEnvEn = [
          'High relative humidity (>85%) and leaf canopy wetness duration >10 hours',
          'Prolonged cloudy weather and dense crop spacing favor spore dispersal',
        ];
        const defaultEnvTa = [
          'காற்றில் அதிக ஈரப்பதம் (>85%) மற்றும் இலைகளில் நீண்ட நேரம் நீர் தங்குதல்',
          'தொடர் மேகமூட்டம் மற்றும் பயிர் நெருக்கம் நோய் பரவலைத் தூண்டும்',
        ];

        const defaultSafetyEn = [
          'Wear PPE gloves, safety goggles, and face mask during spray preparation and application.',
          'Observe mandatory Pre-Harvest Intervals (PHI) as specified on CIBRC labels before harvesting.',
          'Never spray against prevailing wind direction or near water bodies and bee hives.',
        ];
        const defaultSafetyTa = [
          'மருந்து தயாரிக்கும் போதும் தெளிக்கும் போதும் கையுறை, முகக்கவசம் கட்டாயம் அணியவும்.',
          'அறுவடைக்கு முன் குறிப்பிட்ட இடைவெளி நாட்களை (PHI) கட்டாயம் கடைபிடிக்கவும்.',
          'காற்று வீசும் திசைக்கு எதிராகவும் நீர்நிலைகள் அருகிலும் தெளிப்பதைத் தவிர்க்கவும்.',
        ];

        return {
          cropName: v.cropIdentified || cropId,
          cropNameTa: v.cropIdentified || (cropId === 'paddy' ? 'நெல்' : cropId),
          primaryDisease,
          confidence: v.confidence,
          matchReason: v.whySuggested,
          matchReasonTa: v.whySuggested,
          visualObservations: v.visualObservations,
          whySuggested: v.whySuggested,
          missingInformation: v.missingInformation,
          alternativePossibilities: alternatives,
          symptomExplanation: v.visualObservations,
          symptomExplanationTa: v.visualObservations,
          environmentalRiskFactors: v.environmentalTriggers && v.environmentalTriggers.length > 0 ? v.environmentalTriggers : defaultEnvEn,
          environmentalRiskFactorsTa: v.environmentalTriggers && v.environmentalTriggers.length > 0 ? v.environmentalTriggers : defaultEnvTa,
          organicManagement: v.managementPlan?.biologicalControls || [],
          organicManagementTa: v.managementPlan?.biologicalControls || [],
          chemicalManagement: (v.managementPlan?.certifiedChemicals || []).map(
            (c: { name: string; dosage: string }) => `${c.name} @ ${c.dosage}`
          ),
          chemicalManagementTa: (v.managementPlan?.certifiedChemicals || []).map(
            (c: { name: string; dosage: string }) => `${c.name} @ ${c.dosage}`
          ),
          safetyPrecautions: v.safetyPrecautions && v.safetyPrecautions.length > 0 ? v.safetyPrecautions : defaultSafetyEn,
          safetyPrecautionsTa: v.safetyPrecautions && v.safetyPrecautions.length > 0 ? v.safetyPrecautions : defaultSafetyTa,
          inspectionWarning: `AgriKnow Advisory: ${v.missingInformation}. ${v.expertEscalationNotice || 'Verify with local agricultural extension officer (AAO).'}`.trim(),
          inspectionWarningTa: `களப் பாதுகாப்பு ஆலோசனை: ${v.missingInformation}. ${v.expertEscalationNotice || 'உள்ளூர் வேளாண் உதவி அலுவலரை (AAO) அணுகி உறுதிப்படுத்தவும்.'}`.trim(),
          sourceDocId: 'agriknow-ai-tnau-model',
          sourceInstitution: 'Tamil Nadu Agricultural University (TNAU) & ICAR Crop Health Protocol',
          pageNumber: 1,
          isVisionAi: Boolean(imageFile),
        };
      }
    } else {
      const errJson = await response.json().catch(() => ({}));
      if (errJson?.error === 'GEMINI_KEY_NOT_CONFIGURED') {
        logger.warn('DiseaseService', 'Gemini key missing for diagnosis');
      }
    }
  } catch (visionErr) {
    logger.error('DiseaseService', 'AgriKnow AI diagnosis request failed, falling back to local database', visionErr);
  }

  // 2. Offline Fallback: Text-Based Heuristic Matching from Verified University Catalog
  const lowerSymptom = symptomsText.toLowerCase();
  const cropCandidates = diseases.filter((d) => d.cropId === cropId);
  const fallback = cropCandidates[0] || diseases[0];

  let selected = fallback;
  let confidence = 86;

  if (cropId === 'paddy') {
    if (lowerSymptom.includes('dead heart') || lowerSymptom.includes('குருத்து') || lowerSymptom.includes('borer') || lowerSymptom.includes('துளைப்பான்')) {
      selected = cropCandidates.find((d) => d.id === 'rice-stem-borer') || fallback;
      confidence = 91;
    } else if (lowerSymptom.includes('blast') || lowerSymptom.includes('spindle') || lowerSymptom.includes('குலை') || lowerSymptom.includes('spot')) {
      selected = cropCandidates.find((d) => d.id === 'rice-blast') || fallback;
      confidence = 89;
    } else if (lowerSymptom.includes('sheath') || lowerSymptom.includes('மடல்')) {
      selected = cropCandidates.find((d) => d.id === 'rice-sheath-blight') || fallback;
      confidence = 88;
    }
  } else if (cropId === 'groundnut') {
    if (lowerSymptom.includes('pop') || lowerSymptom.includes('பொக்கு') || lowerSymptom.includes('gypsum')) {
      selected = cropCandidates.find((d) => d.id === 'groundnut-tikka') || fallback;
      confidence = 90;
    }
  } else if (cropId === 'cotton') {
    if (lowerSymptom.includes('boll') || lowerSymptom.includes('காய்') || lowerSymptom.includes('worm')) {
      selected = cropCandidates.find((d) => d.id === 'pink-bollworm' || d.id === 'cotton-bollworm') || fallback;
      confidence = 93;
    }
  } else if (cropId === 'maize') {
    selected = cropCandidates.find((d) => d.id === 'maize-armyworm') || fallback;
    confidence = 92;
  } else if (cropId === 'banana') {
    selected = cropCandidates.find((d) => d.id === 'banana-sigatoka') || fallback;
    confidence = 90;
  }

  const alternatives: AlternativeDiagnosis[] = cropCandidates
    .filter((d) => d.id !== selected.id)
    .slice(0, 2)
    .map((alt, idx) => ({
      disease: alt,
      probability: Math.max(15, confidence - 25 - idx * 10),
      differentiatingClue: `Differs from ${selected.name} by lesion geometry, collar tissue condition, and symptom progression.`,
      differentiatingClueTa: `இது ${selected.name} நோயிலிருந்து புள்ளி வடிவம் மற்றும் கருகலின் தன்மையால் வேறுபடுகிறது.`,
    }));

  const isBlast = selected.id === 'rice-blast';
  const isStemBorer = selected.id === 'rice-stem-borer';
  const isGroundnutTikka = selected.id === 'groundnut-tikka';

  return {
    cropName: selected.cropName,
    cropNameTa: cropId === 'paddy' ? 'நெல்' : cropId === 'cotton' ? 'பருத்தி' : cropId === 'groundnut' ? 'நிலக்கடலை' : selected.cropName,
    primaryDisease: selected,
    confidence,
    matchReason: isBlast
      ? 'Visual symptoms match spindle/diamond shaped lesions with grey centres and yellow chlorotic borders.'
      : isStemBorer
      ? 'Central leaf shoot drying up with easy detachment ("dead heart") during tillering stage.'
      : isGroundnutTikka
      ? 'Circular dark brown leaf spots with bright yellow chlorotic halo on groundnut leaves.'
      : `Symptom morphology aligns with verified ${selected.name} pathological field indicators.`,
    matchReasonTa: isBlast
      ? 'இலையில் சாம்பல் நிற மையமும் பழுப்பு நிற ஓரமும் கொண்ட வைர வடிவப் புள்ளிகள் குலை நோயின் அறிகுறிகளுடன் பொருந்துகின்றன.'
      : isStemBorer
      ? 'தூர் கட்டும் பருவத்தில் நடுக்குருத்து காய்ந்து எளிதாக உருவி வரும் குருத்து காய்வு அறிகுறி காணப்படுகிறது.'
      : isGroundnutTikka
      ? 'நிலக்கடலை இலையில் மஞ்சள் நிற வளையத்துடன் கூடிய அடர் பழுப்பு நிற வட்டப் புள்ளிகள் டிக்கா நோயின் அடையாளமாகும்.'
      : `வயல்வெளி அறிகுறிகள் ${selected.name} நோயின் நிலையான அடையாளங்களுடன் பொருந்துகின்றன.`,
    alternativePossibilities: alternatives,
    symptomExplanation: isBlast
      ? 'Fungal infection airborne under low night temperature (20-24°C) with prolonged leaf wetness over 10 hours and excess nitrogen application.'
      : isStemBorer
      ? 'Lepidopteran larvae bore into the stem collar, severing vascular bundles and causing tiller dieback.'
      : 'Pathogen proliferation triggered by continuous cloudy weather, microclimate humidity, and susceptible crop age.',
    symptomExplanationTa: isBlast
      ? 'இரவு நேரக் குறைந்த வெப்பநிலை (20-24°C), காற்றில் அதிக ஈரப்பதம் மற்றும் அளவுக்கு அதிகமான யூரியா உரம் இடுவதால் பூஞ்சை வேகமாகப் பரவும்.'
      : isStemBorer
      ? 'அந்துப்பூச்சியின் புழுக்கள் தண்டுக்குள் துளைத்து உணவு நாளங்களை துண்டிப்பதால் நடுக்குருத்து காய்ந்துவிடும்.'
      : 'தொடர் மேகமூட்டம், ஈரப்பதம் மற்றும் பயிரின் இளம் பருவத்தால் நோய் தாக்குதல் அதிகரிக்கிறது.',
    environmentalRiskFactors: [
      'Cloudy, overcast weather with relative humidity above 85%',
      'Excessive single-dose application of chemical nitrogen (urea)',
      'Close plant spacing without ventilation',
    ],
    environmentalRiskFactorsTa: [
      'தொடர் மேகமூட்டம் மற்றும் 85%-க்கு அதிகமான காற்றில் உள்ள ஈரப்பதம்',
      'அளவுக்கு அதிகமாக ஒரே தவணையில் யூரியா உரமிடுதல்',
      'செடிகளுக்கு இடையே போதிய இடைவெளி மற்றும் காற்றோட்டம் இல்லாமை',
    ],
    organicManagement: selected.organicTreatment || [
      'Spray Neem Seed Kernel Extract (NSKE 5%) or Neem Oil (3%) thoroughly on leaf undersides.',
      'Apply Pseudomonas fluorescens bio-fungicide at 10 g/litre of water in early morning.',
    ],
    organicManagementTa: [
      'வேப்பங்கொட்டை சாறு 5% அல்லது வேப்பெண்ணெய் (லிட்டருக்கு 30 மிலி) இலைகளின் அடியில் படும்படி தெளிக்கவும்.',
      'சூடோமோனாஸ் ப்ளூரசன்ஸ் உயிரி மருந்தை லிட்டருக்கு 10 கிராம் வீதம் காலையில் தெளிக்கவும்.',
    ],
    chemicalManagement: selected.chemicalControl || [
      'Spray Tricyclazole 75% WP @ 0.6 g/litre of water for fungal blast control.',
    ],
    chemicalManagementTa: selected.chemicalControlTa || [
      'குலை நோய் கட்டுப்பாட்டிற்கு ட்ரைசைக்ளசோல் 75% WP மருந்தை 1 லிட்டர் தண்ணீருக்கு 0.6 கிராம் கலந்து தெளிக்கவும்.',
    ],
    safetyPrecautions: [
      'Wear chemical-resistant gloves, safety goggles, and face mask during spray preparation.',
      'Observe mandatory Pre-Harvest Interval (PHI) as specified on CIBRC label before harvest.',
      'Never spray against the wind direction or near water bodies and bee hives.',
    ],
    safetyPrecautionsTa: [
      'மருந்து தயாரிக்கும் போதும் தெளிக்கும் போதும் கையுறை, முகக்கவசம் கட்டாயம் அணியவும்.',
      'அறுவடைக்கு முன் குறிப்பிட்ட இடைவெளி நாட்களை (PHI) கட்டாயம் கடைபிடிக்கவும்.',
      'காற்று வீசும் திசைக்கு எதிராகவும் நீர்நிலைகள் அருகிலும் தெளிப்பதைத் தவிர்க்கவும்.',
    ],
    inspectionWarning:
      'Mandatory Physical Field Inspection: Visual symptoms may overlap with bacterial leaf blight or nutritional zinc deficiency. Confirm collar symptoms with your block Assistant Agricultural Officer (AAO) or TNAU KVK before spraying chemicals.',
    inspectionWarningTa:
      'களப் பாதுகாப்பு ஆலோசனை: வயல்வெளி அறிகுறிகள் பாக்டீரியா இலைக்கருகல் அல்லது துத்தநாக சத்துக் குறைபாட்டுடன் ஒத்திருக்கலாம். ரசாயன மருந்துகளைத் தெளிக்கும் முன் உங்கள் வட்டார வேளாண் விரிவாக்க அலுவலர் (AAO) அல்லது KVK விஞ்ஞானியிடம் உறுதி செய்யவும்.',
    sourceDocId: isBlast ? 'doc-tnau-paddy-sri' : 'doc-icar-cotton-ipm',
    sourceInstitution: 'Tamil Nadu Agricultural University (TNAU) Diagnostic Guidelines',
    pageNumber: isBlast ? 12 : 4,
    isVisionAi: false,
  };
}

export async function diagnoseCropLeaf(cropId: string, imageFile?: File, lang: 'ta' | 'en' = 'en') {
  return diagnoseCropSymptom(cropId, '', imageFile, lang);
}
