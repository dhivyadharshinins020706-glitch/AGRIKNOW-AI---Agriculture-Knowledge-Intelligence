import React, { useState, useEffect } from 'react';
import {
  Mail,
  Lock,
  Eye,
  EyeOff,
  Check,
  LogIn,
  Heart,
  Leaf,
  BarChart3,
  ShieldCheck,
  Loader2,
  AlertCircle,
  CheckCircle2,
  X,
  ArrowLeft,
  User,
  Phone,
  MapPin,
  Sparkles,
  Database,
  ExternalLink,
  Copy,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import loginBgFarm from '@/assets/login-bg-farm.jpg';

// Google SVG Icon
function GoogleIcon({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24">
      <path
        fill="#4285F4"
        d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.04h3.88c2.28-2.09 3.66-5.17 3.66-9.14z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.04c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.26v3.13C3.27 21.37 7.34 24 12 24z"
      />
      <path
        fill="#FBBC05"
        d="M5.28 14.28c-.25-.72-.38-1.49-.38-2.28s.13-1.56.38-2.28V6.59H1.26C.46 8.19 0 10.03 0 12s.46 3.81 1.26 5.41l4.02-3.13z"
      />
      <path
        fill="#EA4335"
        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.27 2.63 1.26 6.59l4.02 3.13c.95-2.83 3.6-4.97 6.72-4.97z"
      />
    </svg>
  );
}

// Brand Leaf Squircle Icon matching reference
function AgriKnowSquircleLogo({
  containerClassName = 'w-12 h-12 rounded-2xl',
  iconClassName = 'w-6 h-6',
}: {
  containerClassName?: string;
  iconClassName?: string;
}) {
  return (
    <div
      className={`${containerClassName} bg-gradient-to-br from-[#86efac] via-[#4ade80] to-[#22c55e] flex items-center justify-center shadow-md shadow-emerald-500/15 flex-shrink-0`}
    >
      <svg viewBox="0 0 32 32" className={`${iconClassName}`} fill="none">
        <path
          d="M16 26V15M16 15C16 10 11 7 6 8C6 13 9 17 16 15ZM16 15C16 11 21 8 26 9C26 14 23 18 16 15Z"
          stroke="#064e3b"
          strokeWidth="2.8"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="#064e3b"
          fillOpacity="0.9"
        />
      </svg>
    </div>
  );
}

export default function LoginPage() {
  const { signIn, signInWithGoogle, signInDemo, signUp, resetPassword, user, isConfigured } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Supabase help modal
  const [isSupabaseHelpOpen, setIsSupabaseHelpOpen] = useState(false);

  // Modals for Forgot Password and Sign Up
  const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotDone, setForgotDone] = useState(false);

  const [isSignUpModalOpen, setIsSignUpModalOpen] = useState(false);
  const [signUpName, setSignUpName] = useState('');
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPhone, setSignUpPhone] = useState('');
  const [signUpDistrict, setSignUpDistrict] = useState('Thanjavur');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [signUpLoading, setSignUpLoading] = useState(false);

  // Load remembered email on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem('agriknow_remember_email');
      if (saved) {
        setEmail(saved);
        setRememberMe(true);
      }
    } catch {
      // Ignore
    }
  }, []);

  // If already logged in, automatically redirect to dashboard
  useEffect(() => {
    if (user) {
      setSuccessMsg(`Signed in as ${user.email || 'Farmer'}. Redirecting to your farm dashboard...`);
      const timer = setTimeout(() => {
        window.location.hash = '#/dashboard';
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [user]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanEmail = email.trim();
    if (!cleanEmail) {
      setErrorMsg('Please enter your email address or username.');
      return;
    }
    if (!password) {
      setErrorMsg('Please enter your password.');
      return;
    }

    setIsLoading(true);
    try {
      const res = await signIn(cleanEmail, password);
      if (res.error) {
        setErrorMsg(res.error);
      } else {
        if (rememberMe) {
          try {
            localStorage.setItem('agriknow_remember_email', cleanEmail);
          } catch {
            // Ignore
          }
        } else {
          try {
            localStorage.removeItem('agriknow_remember_email');
          } catch {
            // Ignore
          }
        }
        setSuccessMsg('Welcome back! Redirecting to your farm dashboard...');
        setTimeout(() => {
          window.location.hash = '#/dashboard';
        }, 600);
      }
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : 'Login failed. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setErrorMsg(null);
    setSuccessMsg(null);
    setIsGoogleLoading(true);
    try {
      const res = await signInWithGoogle();
      if (res.error) {
        if (
          res.error.includes('provider is not enabled') ||
          res.error.includes('Unsupported provider') ||
          res.error.includes('validation_failed')
        ) {
          setErrorMsg(
            'Google Sign-In is not enabled in your Supabase project yet. You can sign in immediately using Email & Password (or click "Sign Up" below), or enable Google in Supabase (Authentication > Providers > Google).'
          );
        } else {
          setErrorMsg(res.error);
        }
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('provider is not enabled') || msg.includes('Unsupported provider')) {
        setErrorMsg(
          'Google Sign-In is not enabled in your Supabase project yet. Please use Email & Password, or continue in Demo Mode.'
        );
      } else {
        setErrorMsg(msg || 'Google sign in failed.');
      }
    } finally {
      setIsGoogleLoading(false);
    }
  };

  const handleDemoLogin = () => {
    setErrorMsg(null);
    signInDemo(email.trim() || 'farmer@agriknow.ai');
    setSuccessMsg('Welcome, Farmer! Launching your AGRIKNOW AI dashboard in demo mode...');
    setTimeout(() => {
      window.location.hash = '#/dashboard';
    }, 500);
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (!forgotEmail.trim()) {
      setErrorMsg('Please enter your email to receive password reset instructions.');
      return;
    }
    setForgotLoading(true);
    try {
      const res = await resetPassword(forgotEmail.trim());
      if (res.error) {
        setErrorMsg(res.error);
      } else {
        setForgotDone(true);
      }
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to send reset email.');
    } finally {
      setForgotLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (!signUpName.trim()) {
      setErrorMsg('Please enter your full name.');
      return;
    }
    if (!signUpEmail.trim()) {
      setErrorMsg('Please enter your email address.');
      return;
    }
    if (signUpPassword.length < 6) {
      setErrorMsg('Password must be at least 6 characters long.');
      return;
    }

    setSignUpLoading(true);
    try {
      const res = await signUp(
        signUpEmail.trim(),
        signUpPassword,
        signUpName.trim(),
        signUpPhone.trim(),
        signUpDistrict
      );
      if (res.error) {
        setErrorMsg(res.error);
      } else {
        setIsSignUpModalOpen(false);
        setSuccessMsg('Account created successfully! Welcome to AGRIKNOW AI.');
        setTimeout(() => {
          window.location.hash = '#/dashboard';
        }, 700);
      }
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : 'Registration failed.');
    } finally {
      setSignUpLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full bg-[#FAFBF9] text-gray-900 overflow-x-hidden flex flex-col justify-between selection:bg-emerald-200 selection:text-emerald-950 font-sans">
      {/* Full Atmospheric Farm Background from User Artwork */}
      <div className="pointer-events-none absolute inset-0 z-0 overflow-hidden">
        <img
          src={loginBgFarm}
          alt="Agricultural sunrise paddy field landscape"
          className="w-full h-full object-cover object-bottom"
        />

        {/* Top smooth off-white fade to ensure high-contrast typography for brand, headline & badges */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#FAFBF9] via-[#FAFBF9]/80 via-35% to-transparent pointer-events-none" />

        {/* Subtle right fade to enhance white login card float & shadow */}
        <div className="absolute inset-0 bg-gradient-to-l from-[#FAFBF9]/65 via-transparent to-transparent pointer-events-none" />

        {/* Upper Left Green Radial Glow */}
        <div
          className="pointer-events-none absolute -top-24 -left-24 w-[650px] h-[650px] rounded-full opacity-70"
          style={{
            background:
              'radial-gradient(circle at 30% 30%, rgba(187, 247, 208, 0.6) 0%, rgba(220, 252, 231, 0.3) 45%, transparent 70%)',
            filter: 'blur(40px)',
          }}
        />

        {/* Upper Right Lavender Radial Glow */}
        <div
          className="pointer-events-none absolute -top-20 -right-20 w-[620px] h-[620px] rounded-full opacity-65"
          style={{
            background:
              'radial-gradient(circle at 70% 30%, rgba(233, 213, 255, 0.65) 0%, rgba(245, 243, 255, 0.3) 50%, transparent 75%)',
            filter: 'blur(45px)',
          }}
        />

        {/* Subtle Botanical Leaf Silhouettes watermark in middle-right background */}
        <div className="pointer-events-none absolute right-[35%] top-[20%] w-72 h-72 opacity-[0.06] rotate-12">
          <svg viewBox="0 0 200 200" fill="#16a34a">
            <path d="M100 0 C120 40 160 80 200 100 C160 120 120 160 100 200 C80 160 40 120 0 100 C40 80 80 40 100 0 Z" />
          </svg>
        </div>
        <div className="pointer-events-none absolute right-[10%] bottom-[8%] w-80 h-80 opacity-[0.05] -rotate-12">
          <svg viewBox="0 0 200 200" fill="#16a34a">
            <path d="M100 0 C120 40 160 80 200 100 C160 120 120 160 100 200 C80 160 40 120 0 100 C40 80 80 40 100 0 Z" />
          </svg>
        </div>
      </div>

      {/* Main Container: Split-screen composition (Left ~57%, Right ~43%) */}
      <div className="relative z-10 w-full max-w-[1440px] mx-auto min-h-screen flex flex-col lg:flex-row items-stretch px-6 sm:px-10 lg:px-14 py-8 lg:py-10">
        {/* ================= LEFT SECTION (~57% width) ================= */}
        <div className="w-full lg:w-[57%] flex flex-col justify-between relative pb-8 lg:pb-4 z-10">
          {/* Top Brand Header */}
          <div className="flex items-center gap-3.5">
            <AgriKnowSquircleLogo containerClassName="w-12 h-12 rounded-2xl" iconClassName="w-7 h-7" />
            <div className="flex flex-col">
              <div className="flex items-center tracking-tight leading-none">
                <span className="text-[23px] font-black text-gray-900 tracking-tight">AGRIKNOW</span>
                <span className="text-[23px] font-black text-[#16a34a] tracking-tight ml-1.5">AI</span>
              </div>
              <span className="text-xs font-semibold text-gray-500 tracking-normal mt-1">
                Agricultural Knowledge Intelligence
              </span>
            </div>
          </div>

          {/* Left Hero Content */}
          <div className="my-auto pt-10 pb-6 lg:pt-14 lg:pb-10 max-w-xl">
            {/* Headline */}
            <h1 className="text-5xl sm:text-[56px] lg:text-[62px] font-black text-[#0f172a] tracking-[-0.03em] leading-[1.08]">
              Smarter Farming.<br />
              Brighter <span className="text-[#16a34a]">Tomorrow.</span>
            </h1>

            {/* Description */}
            <p className="text-gray-600 text-base sm:text-[18px] font-medium leading-relaxed mt-5 max-w-lg">
              Access trusted agricultural knowledge,<br className="hidden sm:inline" />
              get expert advice, and make informed<br className="hidden sm:inline" />
              decisions for a better harvest.
            </p>

            {/* 3 Feature Badges */}
            <div className="flex flex-wrap items-center gap-3 mt-8">
              {/* Badge 1: Expert Guidance */}
              <div className="inline-flex items-center gap-2 bg-white/90 backdrop-blur-md border border-white/90 rounded-full px-4 py-2.5 shadow-[0_2px_10px_rgba(0,0,0,0.04)] text-xs font-bold text-gray-800">
                <div className="w-4 h-4 rounded-full flex items-center justify-center text-[#16a34a]">
                  <Leaf className="w-3.5 h-3.5 fill-[#16a34a] stroke-[#16a34a]" />
                </div>
                <span>Expert Guidance</span>
              </div>

              {/* Badge 2: Crop Solutions */}
              <div className="inline-flex items-center gap-2 bg-white/90 backdrop-blur-md border border-white/90 rounded-full px-4 py-2.5 shadow-[0_2px_10px_rgba(0,0,0,0.04)] text-xs font-bold text-gray-800">
                <BarChart3 className="w-4 h-4 text-[#16a34a] stroke-[2.4]" />
                <span>Crop Solutions</span>
              </div>

              {/* Badge 3: Trusted Info */}
              <div className="inline-flex items-center gap-2 bg-white/90 backdrop-blur-md border border-white/90 rounded-full px-4 py-2.5 shadow-[0_2px_10px_rgba(0,0,0,0.04)] text-xs font-bold text-gray-800">
                <ShieldCheck className="w-4 h-4 text-[#16a34a] stroke-[2.4]" />
                <span>Trusted Info</span>
              </div>
            </div>
          </div>

          {/* Bottom Tagline Capsule (sitting naturally over the panoramic paddy field) */}
          <div className="mt-auto pt-6 pb-2">
            <div className="inline-flex items-center gap-2 bg-white/85 backdrop-blur-md border border-white/80 rounded-full py-2.5 px-4 sm:px-5 shadow-[0_4px_16px_rgba(0,0,0,0.06)] text-xs sm:text-[13px] font-semibold text-gray-800">
              <Heart className="w-4 h-4 text-[#16a34a] fill-[#16a34a] flex-shrink-0" />
              <span>Empowering Farmers • Supporting Agriculture • Building a Sustainable Future</span>
            </div>
          </div>
        </div>

        {/* ================= RIGHT SECTION (~43% width) ================= */}
        <div className="w-full lg:w-[43%] flex items-center justify-center lg:justify-end z-20 mt-8 lg:mt-0">
          {/* Login Card (Exact Visual Reconstruction) */}
          <div className="w-full max-w-[430px] bg-white rounded-[34px] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.07)] border border-gray-100/90 relative overflow-hidden p-8 sm:p-9">
            {/* Top-Right Decorative Soft Green Shape */}
            <div
              className="absolute -top-2 -right-2 w-32 h-32 pointer-events-none"
              style={{
                background: 'radial-gradient(circle at 100% 0%, rgba(187, 247, 208, 0.45) 0%, rgba(220, 252, 231, 0.15) 60%, transparent 80%)',
                borderBottomLeftRadius: '100%',
              }}
            />

            {/* Card Header */}
            <div className="flex flex-col items-center text-center relative z-10">
              <AgriKnowSquircleLogo
                containerClassName="w-14 h-14 rounded-2xl mb-4"
                iconClassName="w-8 h-8"
              />
              <h2 className="text-2xl sm:text-[26px] font-black text-gray-900 tracking-tight">
                Welcome Back!
              </h2>
              <p className="text-sm font-medium text-gray-500 mt-1 mb-6">
                Sign in to continue to AGRIKNOW AI
              </p>
            </div>

            {/* Error & Success Alerts */}
            {errorMsg && (
              <div className="mb-5 p-3.5 rounded-2xl bg-red-50 border border-red-200/90 flex flex-col gap-2.5 text-xs text-red-700 animate-in fade-in duration-200">
                <div className="flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                  <div className="flex-1 font-medium leading-relaxed">{errorMsg}</div>
                  <button
                    type="button"
                    onClick={() => setErrorMsg(null)}
                    className="text-red-500 hover:text-red-700 transition-colors p-0.5"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {errorMsg.includes('Supabase is not configured') && (
                  <div className="pt-2 border-t border-red-200/70 flex flex-col sm:flex-row gap-2">
                    <button
                      type="button"
                      onClick={handleDemoLogin}
                      className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Continue in Demo Mode</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsSupabaseHelpOpen(true)}
                      className="py-2 px-3 rounded-xl border border-red-300 bg-white hover:bg-red-50 text-red-800 font-semibold text-xs flex items-center justify-center gap-1 transition-all"
                    >
                      <Database className="w-3.5 h-3.5" />
                      <span>Setup Guide</span>
                    </button>
                  </div>
                )}

                {errorMsg.includes('Google Sign-In is not enabled') && (
                  <div className="pt-2 border-t border-red-200/70 flex flex-col sm:flex-row gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setErrorMsg(null);
                        setIsSignUpModalOpen(true);
                      }}
                      className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all"
                    >
                      <User className="w-3.5 h-3.5" />
                      <span>Create Account with Email</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleDemoLogin}
                      className="py-2 px-3 rounded-xl border border-red-300 bg-white hover:bg-red-50 text-red-800 font-semibold text-xs flex items-center justify-center gap-1 transition-all"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Demo Mode</span>
                    </button>
                  </div>
                )}
              </div>
            )}

            {successMsg && (
              <div className="mb-5 p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200/80 flex items-start gap-2.5 text-xs text-emerald-800 animate-in fade-in duration-200">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1 font-medium leading-relaxed">{successMsg}</div>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleLogin} className="space-y-4 relative z-10">
              {/* Email Input */}
              <div className="relative">
                <Mail className="w-5 h-5 text-gray-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email address or Username"
                  required
                  autoComplete="username"
                  className="w-full bg-white border border-gray-200 rounded-2xl py-3.5 pl-12 pr-4 text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:border-[#16a34a] focus:ring-4 focus:ring-emerald-500/10 transition-all shadow-sm"
                />
              </div>

              {/* Password Input */}
              <div className="relative">
                <Lock className="w-5 h-5 text-gray-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  required
                  autoComplete="current-password"
                  className="w-full bg-white border border-gray-200 rounded-2xl py-3.5 pl-12 pr-12 text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:border-[#16a34a] focus:ring-4 focus:ring-emerald-500/10 transition-all shadow-sm"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors p-1"
                  tabIndex={-1}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>

              {/* Remember Me / Forgot Password */}
              <div className="flex items-center justify-between text-sm pt-1">
                <label className="flex items-center gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="sr-only"
                  />
                  <div
                    className={`w-5 h-5 rounded-md flex items-center justify-center transition-all ${
                      rememberMe
                        ? 'bg-[#16a34a] text-white shadow-sm'
                        : 'border border-gray-300 bg-white hover:border-gray-400'
                    }`}
                  >
                    {rememberMe && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </div>
                  <span className="text-gray-700 font-medium text-sm">Remember me</span>
                </label>

                <button
                  type="button"
                  onClick={() => {
                    setForgotEmail(email);
                    setIsForgotModalOpen(true);
                  }}
                  className="text-sm font-semibold text-[#16a34a] hover:text-[#15803d] hover:underline transition-colors"
                >
                  Forgot password?
                </button>
              </div>

              {/* Primary Login Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full mt-2 py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#22c55e] to-[#16a34a] hover:from-[#16a34a] hover:to-[#15803d] text-white font-bold text-base shadow-[0_10px_24px_rgba(34,197,94,0.32)] hover:shadow-[0_12px_28px_rgba(34,197,94,0.42)] active:scale-[0.99] transition-all flex items-center justify-center gap-2.5 disabled:opacity-75 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <LogIn className="w-5 h-5" />
                    <span>Login</span>
                  </>
                )}
              </button>
            </form>

            {/* Separator */}
            <div className="relative flex items-center py-4 my-1">
              <div className="flex-grow border-t border-gray-200"></div>
              <span className="flex-shrink mx-4 text-xs font-semibold text-gray-400">or</span>
              <div className="flex-grow border-t border-gray-200"></div>
            </div>

            {/* Google Authentication Button */}
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isGoogleLoading}
              className="w-full py-3.5 px-4 rounded-2xl bg-white hover:bg-gray-50 border border-gray-200 text-gray-700 font-semibold text-sm shadow-sm hover:border-gray-300 active:scale-[0.99] transition-all flex items-center justify-center gap-3 disabled:opacity-75 disabled:cursor-not-allowed"
            >
              {isGoogleLoading ? (
                <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
              ) : (
                <>
                  <GoogleIcon className="w-5 h-5" />
                  <span>Continue with Google</span>
                </>
              )}
            </button>

            {/* Optional Offline Demo Login when Supabase is not configured yet */}
            {!isConfigured && (
              <div className="pt-3">
                <button
                  type="button"
                  onClick={handleDemoLogin}
                  className="w-full py-3 px-4 rounded-2xl bg-emerald-50 hover:bg-emerald-100/90 border border-emerald-300/80 text-[#16a34a] font-bold text-xs shadow-sm hover:shadow transition-all flex items-center justify-center gap-2 group"
                >
                  <Sparkles className="w-4 h-4 text-[#16a34a] group-hover:scale-110 transition-transform" />
                  <span>Explore Dashboard in Demo Mode</span>
                </button>
              </div>
            )}

            {/* Registration Footer */}
            <div className="text-center pt-5 text-sm text-gray-500 font-medium">
              Don&apos;t have an account?{' '}
              <button
                type="button"
                onClick={() => setIsSignUpModalOpen(true)}
                className="text-[#16a34a] font-bold hover:underline transition-colors ml-1"
              >
                Sign Up
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ================= FORGOT PASSWORD MODAL ================= */}
      {isForgotModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-white rounded-[28px] shadow-2xl p-7 relative border border-gray-100">
            <button
              type="button"
              onClick={() => {
                setIsForgotModalOpen(false);
                setForgotDone(false);
              }}
              className="absolute top-5 right-5 text-gray-400 hover:text-gray-600 transition-colors p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-[#16a34a] flex items-center justify-center">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-gray-900">Reset Your Password</h3>
                <p className="text-xs text-gray-500">We will email you a secure link to reset it.</p>
              </div>
            </div>

            {forgotDone ? (
              <div className="py-6 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-100 text-[#16a34a] flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6 stroke-[3]" />
                </div>
                <h4 className="text-base font-bold text-gray-900">Password Reset Link Sent!</h4>
                <p className="text-sm text-gray-600">
                  Please check <strong className="text-gray-900">{forgotEmail}</strong> for instructions to reset your password.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setIsForgotModalOpen(false);
                    setForgotDone(false);
                  }}
                  className="w-full mt-4 py-3 rounded-xl bg-[#16a34a] text-white font-semibold text-sm hover:bg-[#15803d] transition-all"
                >
                  Back to Sign In
                </button>
              </div>
            ) : (
              <form onSubmit={handleForgotPassword} className="space-y-4 mt-2">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                    Account Email
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      placeholder="farmer@example.com"
                      required
                      className="w-full border border-gray-200 rounded-xl py-3 pl-10 pr-4 text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:border-[#16a34a] focus:ring-2 focus:ring-emerald-500/10"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsForgotModalOpen(false)}
                    className="w-1/2 py-3 rounded-xl border border-gray-200 text-gray-700 font-semibold text-sm hover:bg-gray-50 transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={forgotLoading}
                    className="w-1/2 py-3 rounded-xl bg-[#16a34a] text-white font-semibold text-sm hover:bg-[#15803d] transition-all flex items-center justify-center gap-2 disabled:opacity-75"
                  >
                    {forgotLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Send Link'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* ================= SIGN UP MODAL ================= */}
      {isSignUpModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200 overflow-y-auto">
          <div className="w-full max-w-md bg-white rounded-[28px] shadow-2xl p-7 relative border border-gray-100 my-8">
            <button
              type="button"
              onClick={() => setIsSignUpModalOpen(false)}
              className="absolute top-5 right-5 text-gray-400 hover:text-gray-600 transition-colors p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-5">
              <AgriKnowSquircleLogo containerClassName="w-11 h-11 rounded-xl" iconClassName="w-6 h-6" />
              <div>
                <h3 className="text-lg font-black text-gray-900">Create Farmer Account</h3>
                <p className="text-xs text-gray-500">Join AGRIKNOW AI for smart farming insights.</p>
              </div>
            </div>

            <form onSubmit={handleSignUp} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Full Name</label>
                <div className="relative">
                  <User className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={signUpName}
                    onChange={(e) => setSignUpName(e.target.value)}
                    placeholder="Muthukumar"
                    required
                    className="w-full border border-gray-200 rounded-xl py-2.5 pl-10 pr-4 text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:border-[#16a34a] focus:ring-2 focus:ring-emerald-500/10"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Email Address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={signUpEmail}
                    onChange={(e) => setSignUpEmail(e.target.value)}
                    placeholder="farmer@example.com"
                    required
                    className="w-full border border-gray-200 rounded-xl py-2.5 pl-10 pr-4 text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:border-[#16a34a] focus:ring-2 focus:ring-emerald-500/10"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Phone (Optional)</label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      value={signUpPhone}
                      onChange={(e) => setSignUpPhone(e.target.value)}
                      placeholder="9876543210"
                      className="w-full border border-gray-200 rounded-xl py-2.5 pl-9 pr-3 text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:border-[#16a34a] focus:ring-2 focus:ring-emerald-500/10"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">District</label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={signUpDistrict}
                      onChange={(e) => setSignUpDistrict(e.target.value)}
                      placeholder="Thanjavur"
                      className="w-full border border-gray-200 rounded-xl py-2.5 pl-9 pr-3 text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:border-[#16a34a] focus:ring-2 focus:ring-emerald-500/10"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    value={signUpPassword}
                    onChange={(e) => setSignUpPassword(e.target.value)}
                    placeholder="At least 6 characters"
                    required
                    minLength={6}
                    className="w-full border border-gray-200 rounded-xl py-2.5 pl-10 pr-4 text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:border-[#16a34a] focus:ring-2 focus:ring-emerald-500/10"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={signUpLoading}
                className="w-full mt-3 py-3 rounded-xl bg-gradient-to-r from-[#22c55e] to-[#16a34a] text-white font-bold text-sm shadow-md hover:from-[#16a34a] hover:to-[#15803d] transition-all flex items-center justify-center gap-2 disabled:opacity-75"
              >
                {signUpLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Create Account'}
              </button>

              <div className="text-center pt-2 text-xs text-gray-500">
                Already registered?{' '}
                <button
                  type="button"
                  onClick={() => setIsSignUpModalOpen(false)}
                  className="text-[#16a34a] font-bold hover:underline"
                >
                  Sign In
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* ================= SUPABASE SETUP GUIDE MODAL ================= */}
      {isSupabaseHelpOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200 overflow-y-auto">
          <div className="w-full max-w-lg bg-white rounded-[28px] shadow-2xl p-7 relative border border-gray-100 my-8">
            <button
              type="button"
              onClick={() => setIsSupabaseHelpOpen(false)}
              className="absolute top-5 right-5 text-gray-400 hover:text-gray-600 transition-colors p-1"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-11 h-11 rounded-2xl bg-emerald-50 text-[#16a34a] flex items-center justify-center flex-shrink-0">
                <Database className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-black text-gray-900">Configure Supabase Backend</h3>
                <p className="text-xs text-gray-500">Enable cloud authentication and sync across devices.</p>
              </div>
            </div>

            <div className="space-y-4 text-xs text-gray-700 leading-relaxed">
              <div className="p-3.5 rounded-2xl bg-gray-50 border border-gray-200 space-y-2">
                <div className="font-bold text-gray-900 flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#16a34a] text-white flex items-center justify-center text-[10px]">1</span>
                  Create a Free Supabase Project
                </div>
                <p className="text-gray-600">
                  Go to{' '}
                  <a
                    href="https://supabase.com"
                    target="_blank"
                    rel="noreferrer"
                    className="text-[#16a34a] font-bold underline inline-flex items-center gap-1"
                  >
                    supabase.com <ExternalLink className="w-3 h-3" />
                  </a>{' '}
                  and click <strong>New Project</strong>. Choose any database password and region.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-gray-50 border border-gray-200 space-y-2">
                <div className="font-bold text-gray-900 flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#16a34a] text-white flex items-center justify-center text-[10px]">2</span>
                  Get Your API Keys
                </div>
                <p className="text-gray-600">
                  In your Supabase dashboard, navigate to <strong>Project Settings</strong> (gear icon) &rarr; <strong>API</strong>. Copy:
                </p>
                <ul className="list-disc list-inside text-gray-600 space-y-1 pl-1">
                  <li><strong>Project URL</strong> &rarr; <code className="bg-gray-200 px-1 py-0.5 rounded text-[11px]">VITE_SUPABASE_URL</code></li>
                  <li><strong>Project API anon key</strong> &rarr; <code className="bg-gray-200 px-1 py-0.5 rounded text-[11px]">VITE_SUPABASE_ANON_KEY</code></li>
                </ul>
              </div>

              <div className="p-3.5 rounded-2xl bg-gray-50 border border-gray-200 space-y-2">
                <div className="font-bold text-gray-900 flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#16a34a] text-white flex items-center justify-center text-[10px]">3</span>
                  Add to .env or Vercel
                </div>
                <p className="text-gray-600">
                  <strong>Local Dev:</strong> Add these lines to your <code className="bg-gray-200 px-1 py-0.5 rounded text-[11px]">.env</code> or <code className="bg-gray-200 px-1 py-0.5 rounded text-[11px]">.env.local</code> file:
                </p>
                <pre className="p-2.5 rounded-xl bg-gray-900 text-emerald-400 font-mono text-[11px] overflow-x-auto select-all">
{`VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOi...`}
                </pre>
                <p className="text-gray-600 mt-2">
                  <strong>Live Vercel Site:</strong> Go to Vercel Dashboard &rarr; Project Settings &rarr; <strong>Environment Variables</strong> &rarr; Add both variables &rarr; Redeploy.
                </p>
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-gray-100 flex flex-col sm:flex-row gap-2.5">
              <button
                type="button"
                onClick={() => {
                  setIsSupabaseHelpOpen(false);
                  handleDemoLogin();
                }}
                className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-[#22c55e] to-[#16a34a] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm hover:from-[#16a34a] hover:to-[#15803d] transition-all"
              >
                <Sparkles className="w-4 h-4" />
                <span>Continue in Demo Mode for Now</span>
              </button>
              <button
                type="button"
                onClick={() => setIsSupabaseHelpOpen(false)}
                className="py-3 px-4 rounded-xl border border-gray-200 text-gray-700 font-semibold text-xs hover:bg-gray-50 transition-all"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
