import { useEffect, useState, type ChangeEvent } from 'react';
import {
  Camera,
  ImagePlus,
  RotateCcw,
  Search,
  Sparkles,
  Stethoscope,
  Leaf,
  FlaskConical,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  Eye,
} from 'lucide-react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/Card';
import { Badge, severityTone } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { ProgressRing } from '@/components/ui/ProgressRing';
import { AiProcessing } from '@/components/ai/AiProcessing';
import { diseases, diseaseCropFilters } from '@/data/crops';
import type { Disease } from '@/types';
import { DiseaseDetail } from '@/components/diseases/DiseaseDetail';
import { DifferentialDiagnosisModal } from '@/components/diseases/DifferentialDiagnosisModal';
import { PageHeader } from '@/components/ui/PageHeader';
import { Sheet } from '@/components/ui/Sheet';
import { useToast } from '@/contexts/ToastContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { diagnoseCropSymptom, type DifferentialDiagnosisResult } from '@/services/diseaseService';
import { validateImageUpload } from '@/utils/uploadValidator';

const scanSteps = [
  'Examining leaf colour and lesion morphology',
  'Matching against TNAU & ICAR pathological datasets',
  'Evaluating alternative differential diagnoses',
  'Verifying organic and recommended chemical dosages',
];

const scanStepsTa = [
  'இலை நிறம் மற்றும் புள்ளிகளின் வடிவத்தை ஆராய்கிறது',
  'பல்கலைக்கழக நோய் தரவுகளுடன் ஒப்பிடுகிறது',
  'சாத்தியமான பிற மாற்று நோய்களை வேறுபடுத்துகிறது',
  'இயற்கை மற்றும் பரிந்துரைக்கப்பட்ட மருந்துகளைத் தயாரிக்கிறது',
];

function PhotoScanner({ onOpenDisease }: { onOpenDisease: (disease: Disease) => void }) {
  const { lang, t } = useLanguage();
  const [selectedCropId, setSelectedCropId] = useState('paddy');
  const [symptomText, setSymptomText] = useState('');
  const [preview, setPreview] = useState<string | null>(null);
  const [fileObject, setFileObject] = useState<File | undefined>(undefined);
  const [status, setStatus] = useState<'idle' | 'analyzing' | 'done'>('idle');
  const [diffDiagnosis, setDiffDiagnosis] = useState<DifferentialDiagnosisResult | null>(null);
  const [showDiffModal, setShowDiffModal] = useState(false);
  const { show } = useToast();

  useEffect(() => {
    return () => {
      if (preview) URL.revokeObjectURL(preview);
    };
  }, [preview]);

  const handleFile = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const validation = await validateImageUpload(file);
    if (!validation.isValid) {
      show(lang === 'ta' ? validation.errorTa || validation.error! : validation.error!, {
        tone: 'error',
      });
      return;
    }

    setFileObject(file);
    setPreview(URL.createObjectURL(file));
    setStatus('idle');
  };

  const startAnalysis = async () => {
    setStatus('analyzing');
    try {
      const res = await diagnoseCropSymptom(selectedCropId, symptomText, fileObject, lang as 'ta' | 'en');
      setDiffDiagnosis(res);
      setStatus('done');
    } catch (err: any) {
      show(lang === 'ta' ? 'நோய் ஆய்வில் பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்.' : 'Error during AI diagnosis. Please try again.', {
        tone: 'error',
      });
      setStatus('idle');
    }
  };

  const reset = () => {
    setPreview(null);
    setFileObject(undefined);
    setSymptomText('');
    setStatus('idle');
    setDiffDiagnosis(null);
  };

  const safeDefaultDisease: Disease = diseases[0] ?? {
    id: 'rice-blast',
    name: 'Rice Blast',
    cropId: 'paddy',
    cropName: 'Paddy',
    type: 'Disease',
    severity: 'High',
    symptoms: ['Diamond-shaped grey spots with brown edges on leaves'],
    organicTreatment: ['Drain standing water for 2 to 3 days', 'Spray neem oil 3%'],
    chemicalTreatment: ['Tricyclazole 75% WP at label dose'],
    prevention: ['Use resistant varieties', 'Split nitrogen doses'],
    sourceIds: ['tnau-blast'],
  };

  const resultDisease = diffDiagnosis?.primaryDisease ?? safeDefaultDisease;
  const isTa = lang === 'ta';

  return (
    <>
      <Card className="overflow-hidden">
        <div className="grid gap-0 md:grid-cols-2">
          <div className="p-5 sm:p-7">
            <div className="flex items-center justify-between">
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-sun-100 text-sun-800">
                <Camera className="h-6 w-6" aria-hidden />
              </span>
              <div className="flex items-center gap-2">
                <label htmlFor="crop-select" className="text-xs font-semibold text-ink-600">
                  {lang === 'ta' ? 'பயிர்:' : 'Crop:'}
                </label>
                <select
                  id="crop-select"
                  value={selectedCropId}
                  onChange={(e) => setSelectedCropId(e.target.value)}
                  className="h-9 rounded-lg border border-ink-200 bg-white px-2.5 text-xs font-medium text-ink-900 focus:border-leaf-500 focus:outline-none"
                >
                  <option value="paddy">{lang === 'ta' ? 'நெல் (Paddy)' : 'Paddy'}</option>
                  <option value="groundnut">{lang === 'ta' ? 'நிலக்கடலை (Groundnut)' : 'Groundnut'}</option>
                  <option value="cotton">{lang === 'ta' ? 'பருத்தி (Cotton)' : 'Cotton'}</option>
                  <option value="tomato">{lang === 'ta' ? 'தக்காளி (Tomato)' : 'Tomato'}</option>
                  <option value="chilli">{lang === 'ta' ? 'மிளகாய் (Chilli)' : 'Chilli'}</option>
                  <option value="wheat">{lang === 'ta' ? 'கோதுமை (Wheat)' : 'Wheat'}</option>
                  <option value="banana">{lang === 'ta' ? 'வாழை (Banana)' : 'Banana'}</option>
                  <option value="maize">{lang === 'ta' ? 'மக்காச்சோளம் (Maize)' : 'Maize'}</option>
                  <option value="sugarcane">{lang === 'ta' ? 'கரும்பு (Sugarcane)' : 'Sugarcane'}</option>
                  <option value="blackgram">{lang === 'ta' ? 'உளுந்து (Blackgram)' : 'Blackgram'}</option>
                  <option value="coconut">{lang === 'ta' ? 'தென்னை (Coconut)' : 'Coconut'}</option>
                  <option value="mango">{lang === 'ta' ? 'மா (Mango)' : 'Mango'}</option>
                  <option value="onion">{lang === 'ta' ? 'வெங்காயம் (Onion)' : 'Onion'}</option>
                  <option value="auto">{lang === 'ta' ? 'தானாகக் கண்டறி / பிற பயிர்கள்' : 'Auto-detect / Other'}</option>
                </select>
              </div>
            </div>

            <h2 className="mt-4 text-xl font-bold text-ink-900">{t('diseases.photoTitle')}</h2>
            <p className="mt-2 text-sm text-ink-600 leading-relaxed">
              {t('diseases.photoSubtitle')}
            </p>

            {/* Symptom Text Input */}
            <div className="mt-4">
              <label htmlFor="symptom-input" className="block text-xs font-bold text-ink-700 mb-1">
                {lang === 'ta'
                  ? 'கண்டறிந்த அறிகுறிகள் (விரும்பினால்):'
                  : 'Observed Symptoms & Field Signs (Optional):'}
              </label>
              <input
                id="symptom-input"
                type="text"
                value={symptomText}
                onChange={(e) => setSymptomText(e.target.value)}
                placeholder={
                  lang === 'ta'
                    ? 'எ.கா: சாம்பல் நிற வைர வடிவ புள்ளிகள், தூர் நடுக்குருத்து காய்வு, இலை சுருட்டல்'
                    : 'e.g. Spindle shaped spots, dead heart in central tiller, yellowing, leaf curl'
                }
                className="w-full rounded-xl border border-ink-200 bg-ink-50 px-3.5 py-2 text-xs text-ink-900 placeholder:text-ink-400 focus:border-leaf-500 focus:bg-white focus:outline-none"
              />
            </div>

            {status === 'idle' && !preview && (
              <label className="group mt-4 flex min-h-[140px] cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-ink-300 bg-ink-50 p-5 text-center transition hover:border-leaf-400 hover:bg-leaf-50">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white text-leaf-700 shadow-sm transition group-hover:scale-110">
                  <ImagePlus className="h-5 w-5" aria-hidden />
                </span>
                <span className="text-sm font-bold text-ink-900">{t('diseases.choosePhoto')}</span>
                <span className="text-xs text-ink-500">JPG or PNG / கேமரா புகைப்படம்</span>
                <input type="file" accept="image/*" capture="environment" onChange={handleFile} className="sr-only" />
              </label>
            )}

            {(preview || symptomText.trim().length > 0) && status !== 'analyzing' && (
              <div className="mt-4 flex flex-wrap items-center gap-3">
                {status === 'idle' && (
                  <Button onClick={startAnalysis}>
                    <Sparkles className="h-4 w-4" aria-hidden />
                    {lang === 'ta' ? 'அறிகுறிகளை ஆய்வு செய்' : 'Run Differential Diagnosis'}
                  </Button>
                )}
                <Button variant="secondary" onClick={reset}>
                  <RotateCcw className="h-4 w-4" aria-hidden />
                  {t('diseases.chooseAnother')}
                </Button>
              </div>
            )}
          </div>

          <div className="relative min-h-[240px] bg-ink-100">
            {preview ? (
              <img src={preview} alt="Selected crop leaf" className="absolute inset-0 h-full w-full object-cover" />
            ) : (
              <img
                src="https://images.pexels.com/photos/2382904/pexels-photo-2382904.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                alt="Farm field with paddy crop"
                className="absolute inset-0 h-full w-full object-cover"
                loading="lazy"
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-ink-900/60 via-transparent to-transparent" />
          </div>
        </div>

        {status === 'analyzing' && (
          <div className="border-t border-ink-100 p-5 sm:p-7">
            <AiProcessing
              title={lang === 'ta' ? 'அக்ரினோ நுண்ணறிவு இலை மற்றும் நோய் அறிகுறிகளை ஆராய்கிறது...' : 'AgriKnow AI is analyzing leaf morphology and crop health...'}
              steps={lang === 'ta' ? scanStepsTa : scanSteps}
              onComplete={() => {}}
            />
          </div>
        )}

        {status === 'done' && diffDiagnosis && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col gap-6 border-t border-ink-100 bg-leaf-50/70 p-5 sm:p-7"
          >
            {/* 1. Primary Diagnosis Header */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="flex items-center gap-4">
                <ProgressRing
                  value={diffDiagnosis.confidence}
                  size={72}
                  stroke={7}
                  colorClass="stroke-leaf-500"
                  label={`${diffDiagnosis.confidence}%`}
                />
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone="success">
                      {diffDiagnosis.confidence}% {isTa ? 'அறிவியல் உறுதிப்பாடு' : 'Diagnostic Match'}
                    </Badge>
                    <Badge tone="info">{diffDiagnosis.cropName}</Badge>
                    {diffDiagnosis.isVisionAi && (
                      <Badge tone="info">AgriKnow Vision</Badge>
                    )}
                  </div>
                  <h3 className="mt-1 text-xl font-bold text-ink-900">
                    {resultDisease.name}
                  </h3>
                  <p className="mt-0.5 text-xs text-ink-700 leading-relaxed font-medium">
                    {isTa ? diffDiagnosis.matchReasonTa : diffDiagnosis.matchReason}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <Button onClick={() => setShowDiffModal(true)} className="flex items-center gap-1.5 shadow-sm">
                  <Stethoscope className="h-4 w-4" />
                  <span>{isTa ? 'முழு மருத்துவ அறிக்கை' : 'View Differential Report'}</span>
                </Button>
                <Button variant="secondary" onClick={() => onOpenDisease(resultDisease)}>
                  {isTa ? 'கையேடு விவரம்' : 'Standard Guide'}
                </Button>
                <Button variant="secondary" onClick={reset} title={isTa ? 'புதிய புகைப்படம்' : 'New Scan'}>
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* 2. Visual Observations Card */}
            {diffDiagnosis.visualObservations && (
              <div className="rounded-xl border border-leaf-200 bg-white p-4 shadow-xs space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-bold text-leaf-800 uppercase tracking-wide">
                  <Eye className="h-4 w-4 text-leaf-600" />
                  <span>{isTa ? 'நேரடி இலை காட்சி மற்றும் கள அறிகுறிகள் (Visual Observations):' : 'Visual Observations & Leaf Signs (AgriKnow Vision):'}</span>
                </div>
                <p className="text-xs sm:text-sm text-ink-800 leading-relaxed font-medium">
                  {diffDiagnosis.visualObservations}
                </p>
              </div>
            )}

            {/* 3. Pathological Cause & Environmental Risk Factors ("Behind the Disease") */}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-xl border border-ink-200 bg-white p-4 shadow-xs space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-bold text-ink-800 uppercase tracking-wide">
                  <CheckCircle2 className="h-4 w-4 text-ink-600" />
                  <span>{isTa ? 'நோய் உருவான காரணம் & பயிர் விளக்கம் (Causes):' : 'Agronomic Rationale & Causes (Why Suggested):'}</span>
                </div>
                <p className="text-xs text-ink-700 leading-relaxed">
                  {isTa ? diffDiagnosis.whySuggested : diffDiagnosis.whySuggested}
                </p>
              </div>

              <div className="rounded-xl border border-sun-200 bg-sun-50/70 p-4 shadow-xs space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-bold text-sun-900 uppercase tracking-wide">
                  <AlertTriangle className="h-4 w-4 text-sun-600" />
                  <span>{isTa ? 'சாதகமான சூழல் & தட்பவெப்ப காரணிகள்:' : 'Environmental Triggers & Risk Factors:'}</span>
                </div>
                <ul className="space-y-1 text-xs text-ink-700 list-disc list-inside">
                  {(isTa ? diffDiagnosis.environmentalRiskFactorsTa : diffDiagnosis.environmentalRiskFactors).map((risk, i) => (
                    <li key={i}>{risk}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* 4. Actionable Treatment Plan: Biological & Certified Chemical */}
            <div className="grid gap-4 sm:grid-cols-2">
              {/* Biological / Organic */}
              <div className="rounded-xl border border-leaf-200 bg-white p-4 shadow-xs space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-leaf-800 uppercase tracking-wide">
                  <Leaf className="h-4 w-4 text-leaf-600" />
                  <span>{isTa ? 'இயற்கை & உயிரியல் கட்டுப்பாடு (Biological):' : 'Organic & Biological Controls:'}</span>
                </div>
                <ul className="space-y-1.5 text-xs text-ink-800 list-disc list-inside">
                  {(isTa ? diffDiagnosis.organicManagementTa : diffDiagnosis.organicManagement).map((org, i) => (
                    <li key={i} className="leading-relaxed">{org}</li>
                  ))}
                </ul>
              </div>

              {/* Certified Chemical Treatment */}
              <div className="rounded-xl border border-ink-200 bg-white p-4 shadow-xs space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-ink-900 uppercase tracking-wide">
                  <FlaskConical className="h-4 w-4 text-leaf-700" />
                  <span>{isTa ? 'பரிந்துரைக்கப்பட்ட ரசாயன மருந்துகள் & அளவுகள்:' : 'Certified Chemical Treatments (Exact Doses):'}</span>
                </div>
                <ul className="space-y-1.5 text-xs text-ink-800 list-disc list-inside">
                  {(isTa ? diffDiagnosis.chemicalManagementTa : diffDiagnosis.chemicalManagement).map((chem, i) => (
                    <li key={i} className="leading-relaxed font-semibold text-leaf-950">{chem}</li>
                  ))}
                </ul>
                <p className="text-[11px] text-ink-500 italic pt-1 border-t border-ink-100">
                  {isTa ? 'அறுவடை இடைவெளி (PHI) மற்றும் பாதுகாப்பு கையுறைகளைக் கடைபிடிக்கவும்.' : 'Always observe mandatory Pre-Harvest Intervals (PHI) and wear PPE.'}
                </p>
              </div>
            </div>

            {/* 5. Differential Clues Preview & Missing Info */}
            <div className="grid gap-3 sm:grid-cols-2">
              {diffDiagnosis.alternativePossibilities.length > 0 && (
                <div className="rounded-xl border border-ink-200 bg-white/90 p-3.5 text-xs text-ink-700 space-y-1">
                  <span className="font-bold text-ink-900 block">
                    {isTa ? 'மாற்று நோய்கள் (Differential Diagnoses):' : 'Alternative Possibilities Considered:'}
                  </span>
                  {diffDiagnosis.alternativePossibilities.map((alt, idx) => (
                    <div key={idx} className="flex items-start justify-between gap-2 pt-1 border-t border-ink-100 text-[11px]">
                      <span className="font-semibold text-ink-800">{alt.disease.name} ({alt.probability}%)</span>
                      <span className="text-ink-600 text-right">{isTa ? alt.differentiatingClueTa : alt.differentiatingClue}</span>
                    </div>
                  ))}
                </div>
              )}

              {diffDiagnosis.missingInformation && (
                <div className="rounded-xl border border-sun-200 bg-sun-50/60 p-3.5 text-xs text-sun-900 space-y-1">
                  <span className="font-bold text-sun-950 flex items-center gap-1.5">
                    <HelpCircle className="h-3.5 w-3.5 text-sun-700" />
                    {isTa ? 'உறுதிப்படுத்த தேவைப்படும் கள ஆய்வு:' : 'Field Inspection Needed to Confirm:'}
                  </span>
                  <p className="text-[11px] leading-relaxed text-sun-800">
                    {diffDiagnosis.missingInformation}
                  </p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </Card>

      {showDiffModal && diffDiagnosis && (
        <DifferentialDiagnosisModal
          diagnosis={diffDiagnosis}
          onClose={() => setShowDiffModal(false)}
        />
      )}
    </>
  );
}

export default function DiseasesPage() {
  const { t, lang } = useLanguage();
  const [query, setQuery] = useState('');
  const [crop, setCrop] = useState('all');
  const [selected, setSelected] = useState<Disease | null>(null);

  const visible = diseases.filter((item) => {
    const matchesCrop = crop === 'all' || item.cropId === crop;
    const haystack = `${item.name} ${item.cropName} ${item.symptoms.join(' ')}`.toLowerCase();
    return matchesCrop && haystack.includes(query.trim().toLowerCase());
  });

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow={lang === 'ta' ? 'பயிர் மருத்துவர்' : 'Crop health'}
        title={t('diseases.title')}
        subtitle={t('diseases.subtitle')}
      />

      <PhotoScanner onOpenDisease={setSelected} />

      <section aria-labelledby="library-heading" className="space-y-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <h2 id="library-heading" className="text-xl font-bold text-ink-900 sm:text-2xl">
            {t('diseases.catalogTitle')}
          </h2>
          <label className="relative block w-full lg:w-80">
            <span className="sr-only">Search problems</span>
            <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-ink-500" aria-hidden />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder={t('diseases.searchPlaceholder')}
              className="h-12 w-full rounded-xl border border-ink-200 bg-white pl-11 pr-4 text-base text-ink-900 placeholder:text-ink-500 transition focus:border-aqua-500 focus:outline-none focus:ring-4 focus:ring-aqua-200/60"
            />
          </label>
        </div>

        <div role="radiogroup" aria-label="Filter by crop" className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:px-0">
          {diseaseCropFilters.map((filter) => {
            const active = crop === filter.id;
            return (
              <button
                key={filter.id}
                type="button"
                role="radio"
                aria-checked={active}
                onClick={() => setCrop(filter.id)}
                className={`shrink-0 rounded-full px-4 py-2 text-sm font-medium transition ${
                  active ? 'bg-ink-900 text-white' : 'border border-ink-200 bg-white text-ink-700 hover:border-ink-300 hover:text-ink-900'
                }`}
              >
                {filter.label}
              </button>
            );
          })}
        </div>

        {visible.length === 0 ? (
          <Card className="p-10 text-center">
            <p className="text-base font-bold text-ink-900">
              {lang === 'ta' ? 'பொருந்தும் நோய்கள் எதுவும் இல்லை' : 'No problems match your search'}
            </p>
            <p className="mt-1 text-sm text-ink-500">
              {lang === 'ta' ? 'வேறு வார்த்தையைத் தேடவும் அல்லது அனைத்து பயிர்களையும் தேர்ந்தெடுக்கவும்.' : 'Try a different keyword or choose All crops.'}
            </p>
          </Card>
        ) : (
          <ul className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {visible.map((item) => (
              <li key={item.id}>
                <Card hover className="flex h-full flex-col p-5 sm:p-6">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone={severityTone[item.severity || 'Medium'] || 'warning'}>{item.severity || 'Medium'} risk</Badge>
                    <Badge tone="neutral">{item.type}</Badge>
                    <Badge tone="info">{item.cropName}</Badge>
                  </div>
                  <h3 className="mt-4 text-lg font-bold text-ink-900">{item.name}</h3>
                  <p className="text-sm text-ink-500">
                    {lang === 'ta' ? `${item.cropName} பயிரை பாதிக்கிறது` : `Affects ${item.cropName.toLowerCase()}`}
                  </p>
                  <p className="mt-3 flex-1 text-[15px] leading-relaxed text-ink-700">{item.symptoms[0]}</p>
                  <Button variant="secondary" className="mt-5 w-full" onClick={() => setSelected(item)}>
                    {lang === 'ta' ? 'சிகிச்சை விவரம்' : 'View treatment'}
                  </Button>
                </Card>
              </li>
            ))}
          </ul>
        )}
      </section>

      <Sheet open={selected !== null} onClose={() => setSelected(null)} title={selected?.name ?? ''}>
        {selected && <DiseaseDetail disease={selected} />}
      </Sheet>
    </div>
  );
}
