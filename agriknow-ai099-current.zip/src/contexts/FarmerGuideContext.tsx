import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { GuideContent } from '@/data/farmerGuideData';

interface FarmerGuideContextType {
  isGuideEnabled: boolean;
  toggleGuide: () => void;
  setGuideEnabled: (enabled: boolean) => void;
  activeGuide: GuideContent | null;
  setActiveGuide: (content: GuideContent | null) => void;
  isFrozen: boolean;
  toggleFreeze: () => void;
  setIsFrozen: (val: boolean) => void;
  hoveredElement: HTMLElement | null;
  setHoveredElement: (el: HTMLElement | null) => void;
}

const FarmerGuideContext = createContext<FarmerGuideContextType | undefined>(undefined);

const STORAGE_KEY = 'agriknow_farmer_robot_guide_enabled';

export function FarmerGuideProvider({ children }: { children: ReactNode }) {
  const [isGuideEnabled, setIsGuideEnabled] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored !== null ? stored === 'true' : true; // Default ON so farmers immediately see the helpful guide
    } catch {
      return true;
    }
  });

  const [activeGuide, setActiveGuide] = useState<GuideContent | null>(null);
  const [isFrozen, setIsFrozen] = useState<boolean>(false);
  const [hoveredElement, setHoveredElement] = useState<HTMLElement | null>(null);

  const setGuideEnabled = (enabled: boolean) => {
    setIsGuideEnabled(enabled);
    try {
      localStorage.setItem(STORAGE_KEY, String(enabled));
    } catch {
      // Ignore localStorage errors
    }
  };

  const toggleGuide = () => {
    setGuideEnabled(!isGuideEnabled);
  };

  const toggleFreeze = () => {
    setIsFrozen((prev) => !prev);
  };

  // Keyboard shortcut: Press 'g' or 'G' to toggle guide; 'f' or 'F' to freeze/unfreeze; 'Escape' to unfreeze/clear
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const isInput = target && (
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.isContentEditable
      );

      if (isInput) return;

      if (e.key === 'g' || e.key === 'G') {
        toggleGuide();
      } else if (e.key === 'f' || e.key === 'F') {
        toggleFreeze();
      } else if (e.key === 'Escape') {
        setIsFrozen(false);
        setActiveGuide(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isGuideEnabled, isFrozen]);

  return (
    <FarmerGuideContext.Provider
      value={{
        isGuideEnabled,
        toggleGuide,
        setGuideEnabled,
        activeGuide,
        setActiveGuide,
        isFrozen,
        toggleFreeze,
        setIsFrozen,
        hoveredElement,
        setHoveredElement,
      }}
    >
      {children}
    </FarmerGuideContext.Provider>
  );
}

export function useFarmerGuide(): FarmerGuideContextType {
  const context = useContext(FarmerGuideContext);
  if (!context) {
    throw new Error('useFarmerGuide must be used within a FarmerGuideProvider');
  }
  return context;
}
