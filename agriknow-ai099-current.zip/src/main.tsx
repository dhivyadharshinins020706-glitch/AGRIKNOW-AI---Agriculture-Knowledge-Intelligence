import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { MotionConfig } from 'framer-motion';
import App from './App';
import { LanguageProvider } from '@/contexts/LanguageContext';
import { AuthProvider } from '@/contexts/AuthContext';
import { ToastProvider } from '@/contexts/ToastContext';
import { FarmerProvider } from '@/contexts/FarmerContext';
import { FarmerGuideProvider } from '@/contexts/FarmerGuideContext';
import { ErrorBoundary } from '@/components/ui/ErrorBoundary';
import { AuthModal } from '@/components/auth/AuthModal';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <MotionConfig reducedMotion="user">
        <LanguageProvider>
          <AuthProvider>
            <FarmerProvider>
              <FarmerGuideProvider>
                <ToastProvider>
                  <App />
                  <AuthModal />
                </ToastProvider>
              </FarmerGuideProvider>
            </FarmerProvider>
          </AuthProvider>
        </LanguageProvider>
      </MotionConfig>
    </ErrorBoundary>
  </StrictMode>,
);
