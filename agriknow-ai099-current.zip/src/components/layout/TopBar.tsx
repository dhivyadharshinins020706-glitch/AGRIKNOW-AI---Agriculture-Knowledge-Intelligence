import { useState } from 'react';
import {
  Bell,
  Cloud,
  CloudOff,
  CloudRain,
  ExternalLink,
  LogIn,
  LogOut,
  TriangleAlert,
  UserRound,
  CheckCircle2,
  Activity,
  ShieldAlert,
  Award,
  Sparkles,
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useFarmer } from '@/contexts/FarmerContext';
import { useAuth } from '@/contexts/AuthContext';
import { useFarmerGuide } from '@/contexts/FarmerGuideContext';
import { FarmerRobotAvatar } from '@/components/guide/FarmerRobotAvatar';
import { Logo } from '@/components/layout/Logo';
import { Segmented } from '@/components/ui/Segmented';
import { Sheet } from '@/components/ui/Sheet';
import { Badge } from '@/components/ui/Badge';
import type { Lang } from '@/lib/i18n';

interface TopBarProps {
  onOpenHealth?: () => void;
  onOpenLegal?: () => void;
  onOpenPilotReview?: () => void;
  onOpenPricing?: () => void;
}

const languageOptions: { value: Lang; label: string }[] = [
  { value: 'en', label: 'English' },
  { value: 'ta', label: 'தமிழ்' },
];

export function TopBar({ onOpenHealth, onOpenLegal, onOpenPilotReview, onOpenPricing }: TopBarProps) {
  const { lang, setLang } = useLanguage();
  const { profile, isCloudSyncing } = useFarmer();
  const { user, role, isConfigured, openAuthModal, signOut } = useAuth();
  const { isGuideEnabled, toggleGuide } = useFarmerGuide();
  const [alertsOpen, setAlertsOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const isTa = lang === 'ta';

  const alerts = [
    {
      id: 'a1',
      icon: TriangleAlert,
      tone: 'warning' as const,
      title: isTa ? 'புகையான் பூச்சி எச்சரிக்கை' : 'Planthopper pest risk in paddy',
      desc: isTa
        ? 'தஞ்சாவூர் டெல்டா பகுதியில் அதிக ஈரப்பதம் காரணமாக புகையான் பூச்சி பரவும் அபாயம் உள்ளது. வரப்புகளில் நீர் வடித்து தூர் பகுதியில் கண்காணிக்கவும்.'
        : 'High humidity in the delta belt favours brown planthopper. Scout 10 hills per field and drain standing water.',
      actionLink: '#/diseases',
      actionText: isTa ? 'வழிகாட்டுதலைப் பார்' : 'See guidance',
    },
    {
      id: 'a2',
      icon: CloudRain,
      tone: 'info' as const,
      title: isTa ? 'மழை எச்சரிக்கை: நாளை 60% வாய்ப்பு' : 'Rain forecast: 60% chance tomorrow',
      desc: isTa
        ? 'நாளை மாலை இடியுடன் கூடிய மழை பெய்ய வாய்ப்புள்ளது. பூச்சிக்கொல்லி அல்லது யூரியா உரம் தெளிப்பதைத் தவிர்க்கவும்.'
        : 'Evening thundershowers expected. Delay fertilizer top-dressing and chemical sprays to prevent nutrient runoff.',
      actionLink: '#/dashboard',
      actionText: isTa ? 'வானிலை விவரம்' : 'Weather details',
    },
  ];

  return (
    <>
      <header className="sticky top-0 z-30 border-b border-ink-200/70 bg-ink-50/85 backdrop-blur-xl">
        <div className="flex h-16 items-center justify-between gap-3 px-4 sm:px-6 lg:h-[72px] lg:px-10">
          <div className="lg:hidden">
            <Logo />
          </div>

          <div className="ml-auto flex items-center gap-2 sm:gap-3">
            {/* AgriKnow Online Status Indicator */}
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border border-leaf-200 bg-leaf-50 text-leaf-800 shadow-sm">
              {isCloudSyncing ? (
                <>
                  <Cloud className="h-3.5 w-3.5 text-aqua-600 animate-pulse" />
                  <span className="text-ink-600">{isTa ? 'இணைக்கிறது...' : 'Syncing...'}</span>
                </>
              ) : user ? (
                <>
                  <CheckCircle2 className="h-3.5 w-3.5 text-leaf-600" />
                  <span className="text-ink-700">{isTa ? 'கிளவுட் இணைப்பில்' : 'Cloud Synced'}</span>
                </>
              ) : typeof navigator !== 'undefined' && !navigator.onLine ? (
                <>
                  <CloudOff className="h-3.5 w-3.5 text-sun-500" />
                  <span className="text-ink-500">{isTa ? 'ஆஃப்லைன்' : 'Offline'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="h-3.5 w-3.5 text-leaf-600" />
                  <span className="text-leaf-800 font-semibold">{isTa ? 'AgriKnow ஆன்லைன்' : 'AgriKnow Online'}</span>
                </>
              )}
            </div>

            {/* Interactive Farmer Robot Guide Toggle Switch */}
            <button
              id="top-guide-toggle"
              data-guide="top-guide-toggle"
              type="button"
              onClick={toggleGuide}
              aria-label={
                isTa
                  ? (isGuideEnabled ? 'உழவன் ரோபோ வழிகாட்டியை அணைக்கவும்' : 'உழவன் ரோபோ வழிகாட்டியை இயக்கவும்')
                  : (isGuideEnabled ? 'Turn Off Farmer Robot Guide' : 'Turn On Farmer Robot Guide')
              }
              title={
                isTa
                  ? (isGuideEnabled ? 'உழவன் ரோபோ வழிகாட்டியை அணைக்கவும் (G விசை)' : 'உழவன் ரோபோ வழிகாட்டியை இயக்கவும் (G விசை)')
                  : (isGuideEnabled ? 'Turn Off Farmer Robot Guide (Press "G")' : 'Turn On Farmer Robot Guide (Press "G")')
              }
              className={`flex h-11 items-center gap-2 rounded-xl border px-3 text-xs font-bold transition ${
                isGuideEnabled
                  ? 'border-leaf-400 bg-leaf-100/90 text-leaf-900 shadow-xs hover:bg-leaf-200'
                  : 'border-ink-200 bg-white text-ink-500 hover:border-ink-300 hover:text-ink-700'
              }`}
            >
              <div className="relative shrink-0">
                <FarmerRobotAvatar size={22} isHoveringFeature={isGuideEnabled} />
                <span
                  className={`absolute -top-1 -right-1 h-2 w-2 rounded-full border border-white ${
                    isGuideEnabled ? 'bg-leaf-500 animate-pulse' : 'bg-ink-300'
                  }`}
                />
              </div>
              <span className="hidden sm:inline font-semibold">
                {isGuideEnabled ? (isTa ? 'வழிகாட்டி: ஆன்' : 'Guide: ON') : (isTa ? 'வழிகாட்டி: ஆஃப்' : 'Guide: OFF')}
              </span>
            </button>

            <Segmented
              id="top-language"
              label="Language"
              options={languageOptions}
              value={lang}
              onChange={setLang}
              className="scale-95"
            />

            {/* System Health & Telemetry Probe Button */}
            <button
              type="button"
              aria-label={isTa ? 'கணினி நிலை & நம்பகத்தன்மை' : 'System Health Diagnostics'}
              title={isTa ? 'கணினி நிலை & நம்பகத்தன்மை' : 'System Health Diagnostics'}
              onClick={onOpenHealth}
              className="flex h-11 w-11 items-center justify-center rounded-xl border border-ink-200 bg-white text-ink-700 transition hover:border-aqua-400 hover:bg-aqua-50/50 hover:text-ink-900"
            >
              <Activity className="h-4 w-4 text-aqua-700" aria-hidden />
            </button>

            {/* Phase 7 Pilot Audit & Quality Review Portal */}
            <button
              type="button"
              aria-label={isTa ? 'முன்னோடி ஆய்வு தணிக்கை' : 'Phase 7 Pilot Review'}
              title={isTa ? 'முன்னோடி ஆய்வு தணிக்கை & அளவீடுகள்' : 'Phase 7 Pilot Review & Quality Metrics'}
              onClick={onOpenPilotReview}
              className="flex h-11 w-11 items-center justify-center rounded-xl border border-brand-300 bg-brand-50/60 text-brand-800 transition hover:bg-brand-100 hover:border-brand-400"
            >
              <Award className="h-4 w-4 text-brand-600" aria-hidden />
            </button>

            {/* Phase 10 Plans & Institutional Pricing Button */}
            <button
              type="button"
              aria-label={isTa ? 'சந்தா திட்டங்கள் & விலை' : 'Plans & Institutional Pricing'}
              title={isTa ? 'சந்தா திட்டங்கள் & விலை' : 'Plans & Institutional Pricing'}
              onClick={onOpenPricing}
              className="hidden sm:flex h-11 items-center gap-1.5 rounded-xl border border-leaf-300 bg-leaf-50 px-3 text-xs font-bold text-leaf-800 transition hover:bg-leaf-100 hover:border-leaf-400"
            >
              <Sparkles className="h-4 w-4 text-leaf-600" aria-hidden />
              <span>{isTa ? 'திட்டங்கள் & விலை' : 'Plans & Pricing'}</span>
            </button>

            {/* Notifications Button */}
            <button
              type="button"
              aria-label="Notifications"
              onClick={() => setAlertsOpen(true)}
              className="relative flex h-11 w-11 items-center justify-center rounded-xl border border-ink-200 bg-white text-ink-700 transition hover:border-ink-300 hover:text-ink-900"
            >
              <Bell className="h-5 w-5" aria-hidden />
              <span className="absolute right-2.5 top-2.5 h-2.5 w-2.5 rounded-full bg-sun-400 ring-2 ring-white" />
            </button>

            {/* User Auth Button */}
            {user ? (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex h-11 items-center gap-2 rounded-xl bg-ink-900 px-3 text-white transition hover:bg-ink-700"
                  aria-expanded={userMenuOpen}
                >
                  <UserRound className="h-4 w-4" aria-hidden />
                  <span className="hidden max-w-[120px] truncate text-xs font-semibold sm:inline">
                    {profile.name}
                  </span>
                </button>

                {userMenuOpen && (
                  <div className="absolute right-0 top-13 z-50 w-56 rounded-2xl border border-ink-200 bg-white p-2 shadow-lift">
                    <div className="border-b border-ink-100 p-2.5">
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-bold text-ink-900 truncate">{profile.name}</p>
                        <span className="rounded-full bg-leaf-100 px-2 py-0.5 text-[10px] font-bold text-leaf-800 uppercase">
                          {role}
                        </span>
                      </div>
                      <p className="text-[11px] text-ink-500 truncate mt-0.5">{user.email}</p>
                    </div>
                    <div className="p-1 space-y-1">
                      <a
                        href="#/profile"
                        onClick={() => setUserMenuOpen(false)}
                        className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-xs font-medium text-ink-700 hover:bg-ink-50"
                      >
                        <UserRound className="h-4 w-4" />
                        {isTa ? 'பண்ணை அமைப்புகள்' : 'Profile & Settings'}
                      </a>
                      <button
                        type="button"
                        onClick={() => {
                          setUserMenuOpen(false);
                          if (onOpenPricing) onOpenPricing();
                        }}
                        className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-xs font-medium text-ink-700 hover:bg-ink-50 text-left"
                      >
                        <Sparkles className="h-4 w-4 text-leaf-600" />
                        {isTa ? 'சந்தா திட்டங்கள் & விலை' : 'Plans & Pricing'}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setUserMenuOpen(false);
                          if (onOpenLegal) onOpenLegal();
                        }}
                        className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-xs font-medium text-ink-700 hover:bg-ink-50 text-left"
                      >
                        <ShieldAlert className="h-4 w-4 text-leaf-700" />
                        {isTa ? 'சட்டம் & ஆலோசனைக் கொள்கை' : 'Legal & Advice Policy'}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setUserMenuOpen(false);
                          signOut();
                        }}
                        className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-xs font-medium text-danger-700 hover:bg-danger-50"
                      >
                        <LogOut className="h-4 w-4" />
                        {isTa ? 'வெளியேறு (Logout)' : 'Sign Out'}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <a
                href="#/login"
                className="flex h-11 items-center gap-2 rounded-xl bg-leaf-400 px-4 text-xs font-bold text-ink-900 shadow-card transition hover:bg-leaf-300"
              >
                <LogIn className="h-4 w-4" aria-hidden />
                <span>{isTa ? 'உள்நுழை' : 'Sign In'}</span>
              </a>
            )}
          </div>
        </div>
      </header>

      {/* Notifications Drawer */}
      <Sheet
        open={alertsOpen}
        onClose={() => setAlertsOpen(false)}
        title={isTa ? 'பண்ணை எச்சரிக்கைகள்' : 'Farm Alerts & Advisories'}
      >
        <div className="space-y-4">
          {alerts.map((alert) => {
            const Icon = alert.icon;
            return (
              <div
                key={alert.id}
                className="rounded-2xl border border-ink-200 bg-white p-4 shadow-card"
              >
                <div className="flex items-start gap-3">
                  <span
                    className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${
                      alert.tone === 'warning' ? 'bg-sun-100 text-sun-800' : 'bg-aqua-100 text-aqua-800'
                    }`}
                  >
                    <Icon className="h-5 w-5" aria-hidden />
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-base font-bold text-ink-900">{alert.title}</p>
                      <Badge tone={alert.tone}>{alert.tone === 'warning' ? 'Alert' : 'Advisory'}</Badge>
                    </div>
                    <p className="mt-1.5 text-sm text-ink-600 leading-relaxed">{alert.desc}</p>
                    <a
                      href={alert.actionLink}
                      onClick={() => setAlertsOpen(false)}
                      className="mt-3 inline-flex items-center gap-1.5 text-sm font-semibold text-leaf-700 hover:text-leaf-800"
                    >
                      {alert.actionText}
                      <ExternalLink className="h-3.5 w-3.5" aria-hidden />
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </Sheet>
    </>
  );
}
