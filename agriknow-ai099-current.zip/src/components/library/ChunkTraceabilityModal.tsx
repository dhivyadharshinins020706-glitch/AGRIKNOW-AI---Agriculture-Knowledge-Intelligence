import { useState, useEffect } from 'react';
import { X, Layers, Copy, Check, Hash, FileText } from 'lucide-react';
import type { IngestedDocument, DocumentChunk } from '@/types/ingestion';
import { fetchDocumentChunks } from '@/services/ingestionService';
import { useLanguage } from '@/contexts/LanguageContext';

interface ChunkTraceabilityModalProps {
  document: IngestedDocument;
  onClose: () => void;
}

export function ChunkTraceabilityModal({ document, onClose }: ChunkTraceabilityModalProps) {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';

  const [chunks, setChunks] = useState<DocumentChunk[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedChunk, setSelectedChunk] = useState<DocumentChunk | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showEmbedding, setShowEmbedding] = useState(false);

  useEffect(() => {
    let active = true;
    fetchDocumentChunks(document.id).then((data) => {
      if (active) {
        setChunks(data);
        if (data.length > 0) setSelectedChunk(data[0]);
        setLoading(false);
      }
    });
    return () => {
      active = false;
    };
  }, [document.id]);

  const copyText = (chunk: DocumentChunk) => {
    navigator.clipboard.writeText(chunk.content);
    setCopiedId(chunk.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/60 p-4 backdrop-blur-sm animate-fade-in"
    >
      <div className="relative flex max-h-[90vh] w-full max-w-5xl flex-col rounded-2xl bg-white shadow-2xl overflow-hidden border border-ink-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-ink-200 bg-ink-50 px-6 py-4">
          <div className="flex items-center gap-3 min-w-0">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-lilac-200 text-lilac-900 font-bold">
              <Layers className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <h2 className="truncate text-lg font-bold text-ink-900">
                {isTa ? 'ஆவணத் துண்டுகள் மற்றும் தடமறிதல்' : 'Chunk Traceability & Vector Index'}
              </h2>
              <p className="truncate text-xs text-ink-600">
                {document.title} • {document.institution} ({chunks.length} {isTa ? 'துண்டுகள்' : 'chunks'})
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-ink-400 hover:bg-ink-200 hover:text-ink-700 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex flex-1 flex-col overflow-hidden md:flex-row">
          {/* Left: Chunks Navigation List */}
          <div className="w-full border-r border-ink-200 bg-ink-50/50 p-4 md:w-80 overflow-y-auto max-h-[40vh] md:max-h-none">
            <div className="mb-2 flex items-center justify-between text-xs font-semibold text-ink-500">
              <span>{isTa ? 'துண்டுகளின் பட்டியல்' : 'Semantic Chunks'}</span>
              <span>{chunks.length} total</span>
            </div>

            {loading ? (
              <div className="py-12 text-center text-sm text-ink-500">
                {isTa ? 'துண்டுகளை ஏற்றுகிறது...' : 'Loading indexed chunks...'}
              </div>
            ) : chunks.length === 0 ? (
              <div className="py-12 text-center text-sm text-ink-500">
                {isTa ? 'துண்டுகள் எதுவும் இல்லை.' : 'No chunks found for this document.'}
              </div>
            ) : (
              <div className="space-y-2">
                {chunks.map((c) => {
                  const active = selectedChunk?.id === c.id;
                  return (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setSelectedChunk(c)}
                      className={`w-full text-left rounded-xl p-3 text-xs transition border ${
                        active
                          ? 'border-leaf-500 bg-leaf-50/80 shadow-sm'
                          : 'border-ink-200 bg-white hover:border-ink-300'
                      }`}
                    >
                      <div className="flex items-center justify-between font-bold text-ink-900">
                        <span>Chunk #{c.chunkIndex + 1}</span>
                        <span className="rounded bg-ink-100 px-1.5 py-0.5 text-[10px] text-ink-700">
                          Page {c.pageNumber}
                        </span>
                      </div>
                      <p className="mt-1 line-clamp-2 text-ink-600">{c.content}</p>
                      <div className="mt-2 flex items-center gap-2 text-[10px] text-ink-500">
                        <span>{c.tokenCount} tokens</span>
                        <span>•</span>
                        <span className="truncate">{c.topic || c.crop}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right: Selected Chunk Details & Traceability Panel */}
          <div className="flex-1 flex flex-col p-6 overflow-y-auto">
            {selectedChunk ? (
              <div className="space-y-6">
                {/* Traceability Metadata Bar */}
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 rounded-xl border border-ink-200 bg-ink-50/70 p-4">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-ink-400">
                      {isTa ? 'பக்க எண்' : 'Source Page'}
                    </span>
                    <p className="text-sm font-bold text-ink-900">Page {selectedChunk.pageNumber}</p>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-ink-400">
                      {isTa ? 'பயிர் / தலைப்பு' : 'Crop / Topic'}
                    </span>
                    <p className="text-sm font-bold text-ink-900 truncate">
                      {selectedChunk.crop || 'General'}
                    </p>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-ink-400">
                      {isTa ? 'டோக்கன் எண்ணிக்கை' : 'Tokens'}
                    </span>
                    <p className="text-sm font-bold text-ink-900">{selectedChunk.tokenCount} tokens</p>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-ink-400">
                      {isTa ? 'மூல நிறுவனம்' : 'Institution'}
                    </span>
                    <p className="text-sm font-bold text-leaf-800 truncate">
                      {selectedChunk.sourceInstitution}
                    </p>
                  </div>
                </div>

                {/* Chunk Extracted Content */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-bold text-ink-900 flex items-center gap-1.5">
                      <FileText className="h-4 w-4 text-leaf-600" />
                      {isTa ? 'துண்டின் உரை உள்ளடக்கம்' : 'Extracted Text Passage'}
                    </h3>
                    <button
                      type="button"
                      onClick={() => copyText(selectedChunk)}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-ink-200 bg-white px-2.5 py-1 text-xs font-semibold text-ink-700 hover:bg-ink-50 transition"
                    >
                      {copiedId === selectedChunk.id ? (
                        <>
                          <Check className="h-3.5 w-3.5 text-leaf-600" />
                          <span>{isTa ? 'நகலெடுக்கப்பட்டது' : 'Copied'}</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-3.5 w-3.5" />
                          <span>{isTa ? 'உரையை நகலெடு' : 'Copy Passage'}</span>
                        </>
                      )}
                    </button>
                  </div>
                  <div className="rounded-xl border border-ink-200 bg-white p-4 font-mono text-xs sm:text-sm text-ink-800 leading-relaxed whitespace-pre-wrap">
                    {selectedChunk.content}
                  </div>
                </div>

                {/* Vector Embedding Inspector */}
                <div className="rounded-xl border border-lilac-200 bg-lilac-50/50 p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Hash className="h-4 w-4 text-lilac-700" />
                      <span className="text-xs font-bold text-ink-900">
                        {selectedChunk.embeddingModel || (isTa ? 'பன்மொழி அடர்ந்த வெக்டர்' : 'Dense Vector Embedding')}
                      </span>
                      <span className="rounded bg-lilac-200/80 px-1.5 py-0.5 text-[10px] font-bold text-lilac-900">
                        {selectedChunk.embeddingDimensions || selectedChunk.embeddingVector?.length || 128}-D
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowEmbedding(!showEmbedding)}
                      className="text-xs font-bold text-lilac-700 hover:text-lilac-900 underline"
                    >
                      {showEmbedding
                        ? isTa
                          ? 'மறை'
                          : 'Hide Vector'
                        : isTa
                        ? 'வெக்டரைக் காட்டு'
                        : 'Inspect Vector Values'}
                    </button>
                  </div>
                  <p className="mt-1 text-xs text-ink-600">
                    {isTa
                      ? 'L2 விதிமுறைக்கு இயல்பாக்கப்பட்ட வெக்டர். Qdrant / Supabase pgvector உடன் நேரடி ஒத்திசைவு.'
                      : 'L2 unit-normalized vector ready for Qdrant and Supabase pgvector cosine retrieval.'}
                  </p>

                  {showEmbedding && (
                    <div className="mt-3 max-h-32 overflow-y-auto rounded-lg bg-ink-900 p-3 font-mono text-[10px] text-aqua-400">
                      [
                      {selectedChunk.embeddingVector && selectedChunk.embeddingVector.length > 0
                        ? selectedChunk.embeddingVector.join(', ')
                        : 'No vector calculated'}
                      ]
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex flex-1 items-center justify-center text-sm text-ink-500">
                {isTa ? 'விவரங்களைக் காண ஒரு துண்டைத் தேர்ந்தெடுக்கவும்.' : 'Select a chunk from the left to inspect traceability.'}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-ink-200 bg-ink-50 px-6 py-3">
          <span className="text-xs text-ink-500 font-mono">
            Document SHA-256: {document.fileHash.slice(0, 20)}...
          </span>
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-ink-900 px-4 py-2 text-xs font-semibold text-white hover:bg-ink-800 transition"
          >
            {isTa ? 'மூடு' : 'Close Traceability View'}
          </button>
        </div>
      </div>
    </div>
  );
}
