// AGRIKNOW AI — Cute Farmer Robot Avatar Component
// Features a traditional agricultural straw hat, green sprout antenna, expressive LED eyes, and hovering thruster.

interface FarmerRobotAvatarProps {
  className?: string;
  size?: number;
  isHoveringFeature?: boolean;
}

export function FarmerRobotAvatar({ className = '', size = 52, isHoveringFeature = false }: FarmerRobotAvatarProps) {
  return (
    <div
      style={{ width: size, height: size }}
      className={`relative select-none pointer-events-none transition-transform duration-300 ${
        isHoveringFeature ? 'scale-110 rotate-3' : 'scale-100'
      } ${className}`}
    >
      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="h-full w-full drop-shadow-lg"
      >
        <defs>
          {/* Hat Gradient: Golden straw weave */}
          <linearGradient id="strawHatGrad" x1="50" y1="5" x2="50" y2="35" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#F5D061" />
            <stop offset="50%" stopColor="#E6B837" />
            <stop offset="100%" stopColor="#C9971D" />
          </linearGradient>

          {/* Hat Ribbon: Emerald leaf ribbon */}
          <linearGradient id="hatRibbonGrad" x1="20" y1="30" x2="80" y2="30" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#2E7D32" />
            <stop offset="100%" stopColor="#4CAF50" />
          </linearGradient>

          {/* Robot Head Gradient: Crisp clean pearlescent white/silver */}
          <linearGradient id="robotBodyGrad" x1="50" y1="28" x2="50" y2="82" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="70%" stopColor="#F0FDF4" />
            <stop offset="100%" stopColor="#DCFCE7" />
          </linearGradient>

          {/* Visor Screen: Deep dark glossy obsidian with cyan rim */}
          <linearGradient id="visorGrad" x1="50" y1="40" x2="50" y2="68" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#0B132B" />
            <stop offset="100%" stopColor="#1C2541" />
          </linearGradient>

          {/* Eye Glow: Expressive emerald-cyan LED */}
          <radialGradient id="eyeGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#6EE7B7" />
            <stop offset="60%" stopColor="#10B981" />
            <stop offset="100%" stopColor="#059669" />
          </radialGradient>

          {/* Thruster Flame: Gentle green agro-energy glow */}
          <radialGradient id="thrusterGlow" cx="50%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#A7F3D0" stopOpacity="0.9" />
            <stop offset="50%" stopColor="#34D399" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#059669" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* 1. Hover Propulsion Energy Beneath Body */}
        <ellipse cx="50" cy="88" rx="14" ry="5" fill="url(#thrusterGlow)" className="animate-pulse" />
        <ellipse cx="50" cy="85" rx="7" ry="2.5" fill="#6EE7B7" opacity="0.8" />

        {/* 2. Robot Floating Body */}
        <rect
          x="32"
          y="68"
          width="36"
          height="16"
          rx="8"
          fill="url(#robotBodyGrad)"
          stroke="#86EFAC"
          strokeWidth="1.8"
        />
        {/* Heart / Leaf Agro-Badge on Chest */}
        <circle cx="50" cy="76" r="4.5" fill="#10B981" />
        <path
          d="M50 73.5 C51.5 72, 53.5 73, 53.5 74.5 C53.5 76, 50 78, 50 78 C50 78, 46.5 76, 46.5 74.5 C46.5 73, 48.5 72, 50 73.5 Z"
          fill="#ECFDF5"
        />

        {/* 3. Cute Robot Arms / Hands */}
        <circle cx="28" cy="72" r="4" fill="#DCFCE7" stroke="#86EFAC" strokeWidth="1.2" />
        <circle cx="72" cy="72" r="4" fill="#DCFCE7" stroke="#86EFAC" strokeWidth="1.2" />

        {/* 4. Robot Head */}
        <rect
          x="22"
          y="32"
          width="56"
          height="42"
          rx="18"
          fill="url(#robotBodyGrad)"
          stroke="#86EFAC"
          strokeWidth="2"
        />

        {/* 5. Antenna with Sprouting Green Leaf on Top */}
        <line x1="50" y1="12" x2="50" y2="28" stroke="#65A30D" strokeWidth="2" strokeLinecap="round" />
        <circle cx="50" cy="11" r="2.5" fill="#84CC16" />
        {/* Leaf Sprout */}
        <path
          d="M50 11 C46 7, 43 12, 50 11 Z"
          fill="#4ADE80"
          stroke="#16A34A"
          strokeWidth="0.8"
        />
        <path
          d="M50 11 C54 7, 57 12, 50 11 Z"
          fill="#22C55E"
          stroke="#16A34A"
          strokeWidth="0.8"
        />

        {/* 6. Traditional Farmer Straw Hat (Tilted playfully) */}
        <g transform="rotate(-6 50 25)">
          {/* Hat Cone */}
          <path
            d="M50 8 L22 30 Q50 34 78 30 Z"
            fill="url(#strawHatGrad)"
            stroke="#B45309"
            strokeWidth="1.2"
          />
          {/* Hat Weave Lines */}
          <path d="M50 8 L36 31" stroke="#D97706" strokeWidth="0.8" opacity="0.6" />
          <path d="M50 8 L64 31" stroke="#D97706" strokeWidth="0.8" opacity="0.6" />
          <path d="M50 8 L50 32" stroke="#D97706" strokeWidth="0.8" opacity="0.6" />
          {/* Hat Ribbon */}
          <path
            d="M23 29 Q50 33 77 29 L78 32 Q50 36 22 32 Z"
            fill="url(#hatRibbonGrad)"
          />
          {/* Hat Brim */}
          <ellipse cx="50" cy="31" rx="30" ry="5.5" fill="#FDE047" stroke="#CA8A04" strokeWidth="1.2" />
        </g>

        {/* 7. Glossy Visor Screen */}
        <rect
          x="28"
          y="42"
          width="44"
          height="24"
          rx="10"
          fill="url(#visorGrad)"
          stroke="#0F766E"
          strokeWidth="1"
        />
        {/* Screen Glass Reflection Highlight */}
        <path
          d="M32 44 Q50 43 66 45 C66 47 48 46 32 48 Z"
          fill="#FFFFFF"
          opacity="0.25"
        />

        {/* 8. Expressive Glowing LED Eyes */}
        {/* Left Eye */}
        <ellipse
          cx="40"
          cy="53"
          rx="4.5"
          ry={isHoveringFeature ? '6' : '5'}
          fill="url(#eyeGlow)"
          className="transition-all duration-300"
        />
        <circle cx="41.5" cy="51.5" r="1.5" fill="#FFFFFF" />

        {/* Right Eye */}
        <ellipse
          cx="60"
          cy="53"
          rx="4.5"
          ry={isHoveringFeature ? '6' : '5'}
          fill="url(#eyeGlow)"
          className="transition-all duration-300"
        />
        <circle cx="61.5" cy="51.5" r="1.5" fill="#FFFFFF" />

        {/* 9. Rosy Cheeks */}
        <circle cx="33" cy="58" r="2.5" fill="#F87171" opacity="0.55" />
        <circle cx="67" cy="58" r="2.5" fill="#F87171" opacity="0.55" />

        {/* 10. Cute Digital Smile */}
        <path
          d="M45 58 Q50 63 55 58"
          stroke="#34D399"
          strokeWidth="1.6"
          strokeLinecap="round"
          fill="none"
        />
      </svg>
    </div>
  );
}
