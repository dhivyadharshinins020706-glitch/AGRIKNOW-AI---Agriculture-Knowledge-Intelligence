import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Sparkles,
  CheckCircle2,
  ChevronRight,
  X,
  Lock,
  Unlock,
  Minimize2,
  Maximize2,
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useFarmerGuide } from '@/contexts/FarmerGuideContext';
import { matchGuideContent, type GuideContent } from '@/data/farmerGuideData';
import { FarmerRobotAvatar } from '@/components/guide/FarmerRobotAvatar';

export function FarmerGuideBot() {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';
  const {
    isGuideEnabled,
    activeGuide,
    setActiveGuide,
    isFrozen,
    toggleFreeze,
    setIsFrozen,
  } = useFarmerGuide();

  // Mouse real coordinates & smoothed trailing position
  const mousePos = useRef({ x: -200, y: -200 });
  const botPos = useRef({ x: -200, y: -200 });
  const frozenPos = useRef({ x: 0, y: 0 });
  const [, setRenderTick] = useState(0);

  // Layout & Flip calculations
  const [isPointerVisible, setIsPointerVisible] = useState(false);
  const [isFlippedX, setIsFlippedX] = useState(false);
  const [isFlippedY, setIsFlippedY] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);

  // Anti-jitter & Hysteresis refs
  const dwellTimerRef = useRef<number | null>(null);
  const lingerTimerRef = useRef<number | null>(null);
  const lockedElementRectRef = useRef<DOMRect | null>(null);
  const currentContentRef = useRef<GuideContent | null>(null);
  currentContentRef.current = activeGuide;

  useEffect(() => {
    if (!isGuideEnabled) return;

    let animationFrameId: number;

    const handlePointerMove = (e: PointerEvent) => {
      if (e.pointerType === 'touch') return;

      mousePos.current = { x: e.clientX, y: e.clientY };

      if (!isPointerVisible) {
        setIsPointerVisible(true);
        if (botPos.current.x < 0) {
          botPos.current = { x: e.clientX + 24, y: e.clientY + 18 };
        }
      }

      // If guide is FROZEN, do not follow mouse and do not switch features
      if (isFrozen) {
        return;
      }

      // 1. Hysteresis Protection: Check if cursor is still inside or near active element (+45px buffer)
      if (lockedElementRectRef.current && currentContentRef.current) {
        const r = lockedElementRectRef.current;
        const buffer = 45;
        const isNearActiveElement =
          e.clientX >= r.left - buffer &&
          e.clientX <= r.right + buffer &&
          e.clientY >= r.top - buffer &&
          e.clientY <= r.bottom + buffer;

        if (isNearActiveElement) {
          // Keep current information active; clear any pending disappearance timer
          if (lingerTimerRef.current) {
            window.clearTimeout(lingerTimerRef.current);
            lingerTimerRef.current = null;
          }
          return;
        }
      }

      // 2. Feature Detection
      const el = document.elementFromPoint(e.clientX, e.clientY) as HTMLElement | null;
      const matched = matchGuideContent(el);

      if (matched) {
        // Dwell check: Must hover for at least 120ms to prevent accidental flash on fast sweep
        if (matched.id !== currentContentRef.current?.id) {
          if (dwellTimerRef.current) window.clearTimeout(dwellTimerRef.current);

          dwellTimerRef.current = window.setTimeout(() => {
            setActiveGuide(matched);
            if (el) {
              lockedElementRectRef.current = el.getBoundingClientRect();
            }
            if (lingerTimerRef.current) {
              window.clearTimeout(lingerTimerRef.current);
              lingerTimerRef.current = null;
            }
            dwellTimerRef.current = null;
          }, 120);
        } else {
          // Same feature: refresh bounding rect and cancel linger timer
          if (el) lockedElementRectRef.current = el.getBoundingClientRect();
          if (lingerTimerRef.current) {
            window.clearTimeout(lingerTimerRef.current);
            lingerTimerRef.current = null;
          }
        }
      } else {
        if (dwellTimerRef.current) {
          window.clearTimeout(dwellTimerRef.current);
          dwellTimerRef.current = null;
        }

        // Linger: When cursor moves to empty space, keep current information visible for 4.5 seconds
        // This solves "if any small cursor movement happens, information disappears"
        if (!lingerTimerRef.current && currentContentRef.current) {
          lingerTimerRef.current = window.setTimeout(() => {
            setActiveGuide(null);
            lockedElementRectRef.current = null;
            lingerTimerRef.current = null;
          }, 4500);
        }
      }
    };

    const handlePointerLeave = () => {
      setIsPointerVisible(false);
    };

    window.addEventListener('pointermove', handlePointerMove, { passive: true });
    document.addEventListener('mouseleave', handlePointerLeave);

    // Smooth Damped Follow Physics (Lerp)
    const updatePhysics = () => {
      if (mousePos.current.x >= 0 && !isFrozen) {
        const viewportW = window.innerWidth;
        const viewportH = window.innerHeight;

        const cardWidth = 330;
        const cardHeight = 250;

        // Auto-flip near screen edges so it never leaves viewport
        const flipX = mousePos.current.x + cardWidth + 40 > viewportW;
        const flipY = mousePos.current.y + cardHeight + 40 > viewportH;

        setIsFlippedX(flipX);
        setIsFlippedY(flipY);

        const targetX = flipX ? mousePos.current.x - cardWidth - 20 : mousePos.current.x + 24;
        const targetY = flipY ? mousePos.current.y - cardHeight - 16 : mousePos.current.y + 16;

        // Clamp safely on screen
        const clampedTargetX = Math.max(12, Math.min(viewportW - cardWidth - 12, targetX));
        const clampedTargetY = Math.max(12, Math.min(viewportH - cardHeight - 12, targetY));

        // Dead-zone damping to eliminate micro-vibrations when user rests hand
        const dx = clampedTargetX - botPos.current.x;
        const dy = clampedTargetY - botPos.current.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        // Smooth calm factor (~0.09) with small dead-zone
        if (dist > 1.5) {
          const factor = 0.09;
          botPos.current.x += dx * factor;
          botPos.current.y += dy * factor;
          setRenderTick((t) => (t + 1) % 1000);
        }
      }

      animationFrameId = requestAnimationFrame(updatePhysics);
    };

    animationFrameId = requestAnimationFrame(updatePhysics);

    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      document.removeEventListener('mouseleave', handlePointerLeave);
      cancelAnimationFrame(animationFrameId);
      if (dwellTimerRef.current) window.clearTimeout(dwellTimerRef.current);
      if (lingerTimerRef.current) window.clearTimeout(lingerTimerRef.current);
    };
  }, [isGuideEnabled, isFrozen]);

  // Handle freeze positioning: snapshot current coordinate when freezing
  const handleToggleFreeze = () => {
    if (!isFrozen) {
      frozenPos.current = { x: botPos.current.x, y: botPos.current.y };
      toggleFreeze();
    } else {
      toggleFreeze();
    }
  };

  if (!isGuideEnabled || !isPointerVisible || botPos.current.x < 0) {
    return null;
  }

  const currentContent: GuideContent | null = activeGuide;
  const renderX = isFrozen ? frozenPos.current.x : botPos.current.x;
  const renderY = isFrozen ? frozenPos.current.y : botPos.current.y;

  return (
    <div
      style={{
        transform: `translate3d(${renderX}px, ${renderY}px, 0)`,
        position: 'fixed',
        top: 0,
        left: 0,
        zIndex: 9999,
        pointerEvents: 'none', // Base container allows clicks to pass through
      }}
      className="will-change-transform select-none"
      aria-live="polite"
    >
      <div className={`relative flex items-start gap-2.5 ${isFlippedX ? 'flex-row-reverse' : 'flex-row'}`}>
        {/* The Cute Farmer Robot Avatar */}
        <div className="relative shrink-0 filter drop-shadow-md">
          <FarmerRobotAvatar size={44} isHoveringFeature={Boolean(currentContent)} />
          {currentContent && (
            <span className="absolute -inset-1 rounded-full bg-leaf-400/25 blur-xs animate-ping-slow pointer-events-none" />
          )}
        </div>

        {/* The Moving Information Bar (Follows cursor smoothly, stays stable, freeze-capable) */}
        <AnimatePresence mode="wait">
          {currentContent ? (
            <motion.div
              key={currentContent.id}
              initial={{ opacity: 0, scale: 0.94, y: isFlippedY ? 8 : -8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, transition: { duration: 0.16 } }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              style={{ pointerEvents: 'auto' }} // Allows clicking Freeze, Minimize, or Close
              className={`w-[300px] sm:w-[330px] rounded-2xl border-2 shadow-2xl backdrop-blur-xl text-ink-900 transition-colors duration-200 ${
                isFrozen
                  ? 'border-leaf-500 bg-white shadow-leaf-500/20 ring-2 ring-leaf-400/30'
                  : 'border-leaf-300 bg-white/95'
              }`}
            >
              {/* Header: Title, Category & Freeze Controls */}
              <div className="flex items-center justify-between border-b border-ink-100 bg-leaf-50/80 px-3.5 py-2 rounded-t-2xl">
                <div className="flex items-center gap-1.5 min-w-0">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-leaf-100 text-leaf-700">
                    <Sparkles className="h-3 w-3" />
                  </span>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-leaf-900 truncate">
                    {isTa ? 'உழவன் பாட்' : 'AgriBot'}
                  </span>
                  {isFrozen && (
                    <span className="rounded-full bg-leaf-500 px-1.5 py-0.2 text-[9px] font-bold text-white uppercase tracking-wider">
                      {isTa ? 'நிலையானது' : 'Frozen'}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  {/* Freeze / Lock Toggle */}
                  <button
                    type="button"
                    onClick={handleToggleFreeze}
                    aria-label={isFrozen ? 'Unfreeze' : 'Freeze'}
                    title={
                      isTa
                        ? isFrozen
                          ? 'தகவலை விடுவிக்க (F விசை)'
                          : 'தகவல் நகராமல் நிலையாக வைக்க (F விசை)'
                        : isFrozen
                        ? 'Unfreeze guide (Press "F")'
                        : 'Freeze information here (Press "F")'
                    }
                    className={`flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] font-bold transition ${
                      isFrozen
                        ? 'bg-leaf-600 text-white shadow-xs'
                        : 'bg-white border border-ink-200 text-ink-700 hover:bg-leaf-100 hover:text-leaf-800'
                    }`}
                  >
                    {isFrozen ? <Lock className="h-2.5 w-2.5" /> : <Unlock className="h-2.5 w-2.5" />}
                    <span>{isTa ? (isFrozen ? 'விடுவி' : 'முடக்கு') : (isFrozen ? 'Frozen' : 'Freeze')}</span>
                  </button>

                  {/* Minimize / Expand */}
                  <button
                    type="button"
                    onClick={() => setIsMinimized(!isMinimized)}
                    aria-label="Minimize"
                    className="p-1 rounded text-ink-400 hover:bg-ink-100 hover:text-ink-700 transition"
                  >
                    {isMinimized ? <Maximize2 className="h-3 w-3" /> : <Minimize2 className="h-3 w-3" />}
                  </button>

                  {/* Close */}
                  <button
                    type="button"
                    onClick={() => {
                      setIsFrozen(false);
                      setActiveGuide(null);
                    }}
                    aria-label="Close"
                    className="p-1 rounded text-ink-400 hover:bg-ink-100 hover:text-ink-700 transition"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>

              {/* Feature Title */}
              <div className="px-3.5 pt-2.5 pb-1">
                <h4 className="text-[13px] font-bold text-ink-950 flex items-center gap-1.5 leading-snug">
                  <span>{isTa ? currentContent.titleTa : currentContent.titleEn}</span>
                </h4>
              </div>

              {/* 3-Part Information Body */}
              {!isMinimized && (
                <div className="px-3.5 pb-3 space-y-2 text-xs">
                  {/* 1. What it does */}
                  <div className="rounded-xl bg-ink-50 p-2 border border-ink-100">
                    <span className="font-bold text-ink-900 block mb-0.5 flex items-center gap-1 text-[11px]">
                      <CheckCircle2 className="h-3 w-3 text-leaf-600" />
                      {isTa ? 'என்ன செய்கிறது?' : 'What it does:'}
                    </span>
                    <p className="leading-relaxed text-ink-700 text-[11px]">
                      {isTa ? currentContent.whatItDoesTa : currentContent.whatItDoesEn}
                    </p>
                  </div>

                  {/* 2. Why useful */}
                  <div className="rounded-xl bg-leaf-50/70 p-2 border border-leaf-200">
                    <span className="font-bold text-leaf-900 block mb-0.5 flex items-center gap-1 text-[11px]">
                      <Sparkles className="h-3 w-3 text-sun-600" />
                      {isTa ? 'விவசாயிகளுக்கு என்ன பயன்?' : 'Why it is useful to you:'}
                    </span>
                    <p className="leading-relaxed text-leaf-950 font-medium text-[11px]">
                      {isTa ? currentContent.whyUsefulTa : currentContent.whyUsefulEn}
                    </p>
                  </div>

                  {/* 3. How to use */}
                  <div className="rounded-xl bg-sun-50/70 p-2 border border-sun-200">
                    <span className="font-bold text-sun-900 block mb-0.5 flex items-center gap-1 text-[11px]">
                      <ChevronRight className="h-3 w-3 text-sun-700" />
                      {isTa ? 'பயன்படுத்துவது எப்படி?' : 'How to use it:'}
                    </span>
                    <p className="leading-relaxed text-sun-950 text-[11px]">
                      {isTa ? currentContent.howToUseTa : currentContent.howToUseEn}
                    </p>
                  </div>

                  {/* Footer hint */}
                  <div className="pt-1.5 border-t border-ink-100 flex items-center justify-between text-[9px] text-ink-400">
                    <span>{isTa ? 'F - முடக்க • G - ஆன்/ஆஃப்' : 'Press "F" to freeze • "G" toggle'}</span>
                    <span className="text-leaf-600 font-semibold">{isTa ? 'TNAU சான்றளிக்கப்பட்டது' : 'TNAU Verified'}</span>
                  </div>
                </div>
              )}
            </motion.div>
          ) : (
            /* Standby Mini-Pill trailing with cursor over neutral area */
            <motion.div
              initial={{ opacity: 0, scale: 0.85 }}
              animate={{ opacity: 0.88, scale: 1 }}
              exit={{ opacity: 0, scale: 0.85 }}
              className="flex items-center gap-1.5 rounded-full border border-leaf-300 bg-white/95 px-2.5 py-1 shadow-md backdrop-blur-sm"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-leaf-500 animate-ping-slow" />
              <span className="text-[10px] font-semibold text-leaf-900">
                {isTa ? 'அம்சங்களை அறிய நகர்த்தவும்' : 'Hover any feature to explain'}
              </span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
