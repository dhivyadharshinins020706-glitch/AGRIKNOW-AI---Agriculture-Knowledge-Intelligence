import { X, ShieldCheck, AlertTriangle, CheckCircle2, Building2, BookOpen, Stethoscope, Sprout } from 'lucide-react';
import type { DifferentialDiagnosisResult } from '@/services/diseaseService';
import { useLanguage } from '@/contexts/LanguageContext';

interface DifferentialDiagnosisModalProps {
  diagnosis: DifferentialDiagnosisResult;
  onClose: () => void;
}

export function DifferentialDiagnosisModal({
  diagnosis,
  onClose,
}: DifferentialDiagnosisModalProps) {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/60 p-4 backdrop-blur-sm animate-fade-in"
    >
      <div className="relative flex max-h-[92vh] w-full max-w-4xl flex-col rounded-2xl bg-white shadow-2xl overflow-hidden border border-ink-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-ink-200 bg-leaf-50 px-6 py-4">
          <div className="flex items-center gap-3 min-w-0">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-leaf-500 text-white font-bold">
              <Stethoscope className="h-6 w-6" />
            </span>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-ink-900 truncate">
                  {isTa ? 'பயிர் நோய் வேறுபாட்டு ஆய்வு (Differential Diagnosis)' : 'Crop Disease Differential Diagnosis'}
                </h2>
                <span className="rounded-full bg-leaf-100 px-2.5 py-0.5 text-xs font-bold text-leaf-800">
                  {diagnosis.confidence}% {isTa ? 'சாத்தியம்' : 'Probable'}
                </span>
              </div>
              <p className="text-xs text-ink-600 truncate">
                {diagnosis.cropName} • {diagnosis.sourceInstitution} (Page {diagnosis.pageNumber})
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-ink-400 hover:bg-ink-200 hover:text-ink-700 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Physical Inspection Disclaimer */}
          <div className="rounded-xl border border-sun-300 bg-sun-50/80 p-4 text-xs text-sun-900 flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-sun-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">
                {isTa ? 'களப் பாதுகாப்பு & ஆய்வக உறுதிப்படுத்தல் அறிவிப்பு' : 'Mandatory Clinical & Safety Advisory'}
              </p>
              <p className="mt-1 leading-relaxed text-sun-800">
                {isTa ? diagnosis.inspectionWarningTa : diagnosis.inspectionWarning}
              </p>
            </div>
          </div>

          {/* Primary Probable Diagnosis Card */}
          <div className="rounded-2xl border border-leaf-200 bg-gradient-to-br from-leaf-50/50 via-white to-white p-5 space-y-3 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-leaf-700 flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4 text-leaf-600" />
                {isTa ? 'முதன்மை சாத்தியமான நோய் / பூச்சி' : 'Primary Probable Diagnosis'}
                {diagnosis.isVisionAi && (
                  <span className="ml-2 rounded-full bg-aqua-100 px-2 py-0.5 text-[10px] font-bold text-aqua-800">
                    AgriKnow Vision Inspected
                  </span>
                )}
              </span>
              <span className="rounded bg-leaf-500 px-2 py-0.5 text-xs font-bold text-white font-mono">
                {diagnosis.confidence}% Match
              </span>
            </div>
            <h3 className="text-xl font-bold text-ink-900">{diagnosis.primaryDisease.name}</h3>
            
            {diagnosis.visualObservations && (
              <div className="rounded-xl border border-ink-200 bg-ink-50/70 p-3 text-xs text-ink-800">
                <span className="font-bold text-ink-900 block mb-1">
                  {isTa ? 'நேரடி காட்சி ஆய்வுக் குறிப்பு (Visual Observations):' : 'Direct Visual Observations (AgriKnow Vision):'}
                </span>
                <p className="leading-relaxed">{diagnosis.visualObservations}</p>
              </div>
            )}

            <p className="text-sm text-ink-700 leading-relaxed font-medium">
              {isTa ? diagnosis.matchReasonTa : diagnosis.matchReason}
            </p>
            <p className="text-xs text-ink-600 leading-relaxed">
              {isTa ? diagnosis.symptomExplanationTa : diagnosis.symptomExplanation}
            </p>

            {diagnosis.missingInformation && (
              <div className="rounded-xl border border-sun-200 bg-sun-50 p-3 text-xs text-sun-900">
                <span className="font-bold block mb-0.5">
                  {isTa ? 'உறுதிப்படுத்த தேவைப்படும் கூடுதல் தகவல்:' : 'Additional Diagnostic Information Needed to Confirm:'}
                </span>
                <p className="leading-relaxed">{diagnosis.missingInformation}</p>
              </div>
            )}
          </div>

          {/* Alternative Explanations (Differential Diagnosis) */}
          {diagnosis.alternativePossibilities.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-ink-900 flex items-center gap-1.5">
                <Sprout className="h-4 w-4 text-lilac-600" />
                {isTa ? 'மாற்று விளக்கங்கள் & வேறுபாட்டு அறிகுறிகள்' : 'Alternative Possibilities (Differential Explanations)'}
              </h4>
              <div className="grid gap-3 sm:grid-cols-2">
                {diagnosis.alternativePossibilities.map((alt) => (
                  <div key={alt.disease.id} className="rounded-xl border border-ink-200 bg-ink-50/50 p-4 space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-bold text-ink-900">
                      <span>{alt.disease.name}</span>
                      <span className="text-ink-500 font-mono">{alt.probability}% probability</span>
                    </div>
                    <p className="text-xs text-ink-600 leading-relaxed">
                      {isTa ? alt.differentiatingClueTa : alt.differentiatingClue}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Environmental Causes & Risk Factors */}
          <div className="rounded-xl border border-ink-200 bg-white p-5 space-y-2.5">
            <h4 className="text-sm font-bold text-ink-900">
              {isTa ? 'சுற்றுச்சூழல் காரணிகள் & ஆபத்து கூறுகள்' : 'Environmental Triggers & Risk Factors'}
            </h4>
            <ul className="space-y-1 text-xs text-ink-700 list-disc list-inside">
              {(isTa ? diagnosis.environmentalRiskFactorsTa : diagnosis.environmentalRiskFactors).map((risk, i) => (
                <li key={i}>{risk}</li>
              ))}
            </ul>
          </div>

          {/* Dual Management: Organic & Chemical */}
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-xl border border-leaf-200 bg-leaf-50/40 p-5 space-y-2.5">
              <h4 className="text-sm font-bold text-leaf-900 flex items-center gap-1.5">
                <ShieldCheck className="h-4 w-4 text-leaf-600" />
                {isTa ? '1. இயற்கை & உழவியல் முறைகள்' : '1. Organic & Cultural Control'}
              </h4>
              <ul className="space-y-1.5 text-xs text-ink-800 list-disc list-inside">
                {(isTa ? diagnosis.organicManagementTa : diagnosis.organicManagement).map((org, i) => (
                  <li key={i} className="leading-relaxed">{org}</li>
                ))}
              </ul>
            </div>

            <div className="rounded-xl border border-sun-200 bg-sun-50/40 p-5 space-y-2.5">
              <h4 className="text-sm font-bold text-sun-900 flex items-center gap-1.5">
                <Building2 className="h-4 w-4 text-sun-600" />
                {isTa ? '2. பரிந்துரைக்கப்பட்ட ரசாயன மேலாண்மை' : '2. University-Recommended Chemical Treatment'}
              </h4>
              <ul className="space-y-1.5 text-xs text-ink-800 list-disc list-inside">
                {(isTa ? diagnosis.chemicalManagementTa : diagnosis.chemicalManagement).map((chem, i) => (
                  <li key={i} className="leading-relaxed">{chem}</li>
                ))}
              </ul>
            </div>
          </div>

          {/* Mandatory Safety Precautions */}
          <div className="rounded-xl border border-danger-200 bg-danger-50/30 p-5 space-y-2">
            <h4 className="text-xs font-bold text-danger-900 uppercase tracking-wide">
              {isTa ? 'கட்டாய பாதுகாப்பு நெறிமுறைகள்' : 'Mandatory Chemical Safety & Pre-Harvest Intervals'}
            </h4>
            <div className="grid gap-1.5 sm:grid-cols-2 text-xs text-ink-800">
              {((isTa ? diagnosis.safetyPrecautionsTa : diagnosis.safetyPrecautions) || [
                isTa ? 'பாதுகாப்பு கையுறைகள் மற்றும் முகக்கவசம் அணியவும்' : 'Wear PPE gloves and mask during spray',
                isTa ? 'அறுவடைக்கு முன் குறிப்பிட்ட இடைவெளி நாட்களை (PHI) கடைபிடிக்கவும்' : 'Strictly observe Pre-Harvest Intervals (PHI)',
              ]).map((sec: string, i: number) => (
                <div key={i} className="flex items-start gap-2">
                  <span className="text-danger-600 font-bold">•</span>
                  <span>{sec}</span>
                </div>
              ))}
            </div>
          </div>

          {/* University Citation Footnote */}
          <div className="flex items-center justify-between text-xs text-ink-500 border-t border-ink-100 pt-3">
            <span className="flex items-center gap-1.5 font-medium">
              <BookOpen className="h-4 w-4 text-leaf-600" />
              Source: {diagnosis.sourceInstitution} (Page {diagnosis.pageNumber})
            </span>
            <a
              href={`#/evidence?doc=${diagnosis.sourceDocId}`}
              className="text-leaf-700 hover:text-leaf-800 font-bold underline"
            >
              {isTa ? 'ஆதாரத்தைக் காண்க' : 'View in Evidence Explorer'}
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end border-t border-ink-200 bg-ink-50 px-6 py-3">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-ink-900 px-5 py-2 text-xs font-bold text-white hover:bg-ink-800 transition"
          >
            {isTa ? 'சரி, புரிந்தது' : 'Understood & Close'}
          </button>
        </div>
      </div>
    </div>
  );
}
