import { BookOpen, CircleCheck, FlaskConical, Leaf, ShieldCheck, Stethoscope } from 'lucide-react';
import { Badge, severityTone } from '@/components/ui/Badge';
import { findSource } from '@/data/sources';
import type { Disease } from '@/types';
import { useLanguage } from '@/contexts/LanguageContext';
import type { ReactNode } from 'react';

function Section({ icon: Icon, title, children }: { icon: typeof Leaf; title: string; children: ReactNode }) {
  return (
    <section className="space-y-3">
      <h3 className="flex items-center gap-2 text-base font-bold text-ink-900">
        <Icon className="h-5 w-5 text-leaf-700" aria-hidden />
        {title}
      </h3>
      {children}
    </section>
  );
}

function BulletList({ items }: { items: string[] }) {
  if (!items || items.length === 0) {
    return <p className="text-xs text-ink-500 italic">No specific instructions recorded.</p>;
  }
  return (
    <ul className="space-y-2.5">
      {items.map((item, idx) => (
        <li key={idx} className="flex gap-3 text-[15px] leading-relaxed text-ink-700">
          <CircleCheck className="mt-0.5 h-5 w-5 shrink-0 text-leaf-500" aria-hidden />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  );
}

export function DiseaseDetail({ disease }: { disease: Disease }) {
  const { lang } = useLanguage();
  const isTa = lang === 'ta';

  if (!disease) return null;

  const symptoms = (isTa && disease.symptomsTa?.length ? disease.symptomsTa : disease.symptoms) ?? [];
  const organicMethods = (isTa && disease.biologicalControlTa?.length ? disease.biologicalControlTa : (disease.organicTreatment || disease.biologicalControl)) ?? [];
  const chemicalMethods = (isTa && disease.chemicalControlTa?.length ? disease.chemicalControlTa : (disease.chemicalTreatment || disease.chemicalControl)) ?? [];
  const preventiveSteps = (isTa && disease.preventiveMeasuresTa?.length ? disease.preventiveMeasuresTa : (disease.prevention || disease.preventiveMeasures)) ?? [];

  return (
    <div className="space-y-7">
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone={severityTone[disease.severity || 'Medium'] || 'warning'}>
          {disease.severity || 'Medium'} {isTa ? 'ஆபத்து நிலை' : 'risk'}
        </Badge>
        <Badge tone="neutral">{disease.type}</Badge>
        <Badge tone="info">{isTa && disease.nameTa ? disease.cropName : disease.cropName}</Badge>
      </div>

      <Section icon={Stethoscope} title={isTa ? 'நோயை அடையாளம் காண்பது எப்படி' : 'How to recognise it'}>
        <BulletList items={symptoms} />
      </Section>

      <div className="grid gap-7 sm:grid-cols-2">
        <Section icon={Leaf} title={isTa ? 'இயற்கை & உயிரியல் முறைகள்' : 'Natural methods'}>
          <BulletList items={organicMethods} />
        </Section>
        <Section icon={FlaskConical} title={isTa ? 'பரிந்துரைக்கப்பட்ட ரசாயன மருந்துகள்' : 'Chemical control'}>
          <BulletList items={chemicalMethods} />
          <p className="rounded-xl bg-sun-50 px-3 py-2 text-xs leading-relaxed text-sun-800">
            {isTa
              ? 'எப்போதும் மருந்து அட்டையில் உள்ள சரியான அளவைக் கடைபிடிக்கவும். தேவைப்பட்டால் உங்கள் வேளாண் அலுவலரிடம் உறுதிப்படுத்தவும்.'
              : 'Always follow the dose on the product label and confirm with your local Krishi Officer.'}
          </p>
        </Section>
      </div>

      <Section icon={ShieldCheck} title={isTa ? 'தடுப்பு & உழவியல் முறைகள்' : 'Prevention'}>
        <BulletList items={preventiveSteps} />
      </Section>

      <Section icon={BookOpen} title={isTa ? 'ஆய்வு ஆதாரங்கள்' : 'Sources'}>
        <ul className="grid gap-2 sm:grid-cols-2">
          {(disease.sourceIds ?? []).map((sourceId) => {
            const source = findSource(sourceId);
            if (!source) return null;
            return (
              <li key={sourceId}>
                <a
                  href={`#/evidence?doc=${sourceId}`}
                  className="block rounded-xl border border-ink-200 p-3 transition hover:border-lilac-400 hover:bg-lilac-50"
                >
                  <span className="block text-sm font-medium text-ink-900">{source.title}</span>
                  <span className="text-xs text-ink-500">
                    {source.publisher}, {source.year}
                  </span>
                </a>
              </li>
            );
          })}
        </ul>
      </Section>
    </div>
  );
}
