import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  BookOpen,
  Sparkles,
  Activity,
  Volume2,
  VolumeX,
  CornerDownRight,
  MessageSquareQuote,
  Copy,
  Check,
  RotateCcw,
  ThumbsUp,
  ThumbsDown,
} from 'lucide-react';
import { findSource } from '@/data/sources';
import type { ChatMessage } from '@/types';
import { RagTraceModal } from './RagTraceModal';
import { PilotFeedbackModal } from '@/components/pilot/PilotFeedbackModal';
import { useLanguage } from '@/contexts/LanguageContext';
import { useToast } from '@/contexts/ToastContext';

function AnswerBody({ text }: { text?: string }) {
  const blocks = (text || '').split('\n');
  return (
    <div className="space-y-2 text-[15px] leading-relaxed text-ink-800">
      {blocks.map((line, index) => {
        if (line.trim() === '') return null;
        const numbered = line.match(/^(\d)\.\s(.*)$/);
        if (numbered) {
          return (
            <p key={index} className="flex gap-3">
              <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-leaf-100 text-xs font-bold text-leaf-800">
                {numbered[1]}
              </span>
              <span className="min-w-0">{numbered[2]}</span>
            </p>
          );
        }
        return <p key={index}>{line}</p>;
      })}
    </div>
  );
}

export function ChatBubble({
  message,
  sourcesLabel,
  onSelectFollowUp,
  onRegenerate,
}: {
  message: ChatMessage;
  sourcesLabel: string;
  onSelectFollowUp?: (query: string) => void;
  onRegenerate?: () => void;
}) {
  const { lang } = useLanguage();
  const { show } = useToast();
  const [showTrace, setShowTrace] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [copied, setCopied] = useState(false);
  const [feedbackVote, setFeedbackVote] = useState<'up' | 'down' | null>(null);

  if (!message) return null;
  const isUser = message.role === 'user';

  // Copy Answer Text
  const handleCopy = () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(message.text).then(() => {
        setCopied(true);
        show(lang === 'ta' ? 'பதில் நகலெடுக்கப்பட்டது' : 'Answer copied to clipboard', { tone: 'success' });
        setTimeout(() => setCopied(false), 2000);
      });
    }
  };

  // Up/Down Vote
  const handleVote = (vote: 'up' | 'down') => {
    setFeedbackVote(vote);
    show(
      lang === 'ta'
        ? (vote === 'up' ? 'நன்றி! உங்கள் கருத்து பதிவு செய்யப்பட்டது.' : 'கருத்து பெறப்பட்டது. பதில்களை மேம்படுத்துகிறோம்.')
        : (vote === 'up' ? 'Thank you! Feedback recorded.' : 'Feedback recorded. Improving recommendations.'),
      { tone: 'info' }
    );
  };

  // Audio Text-to-Speech (Tamil & English support)
  const toggleSpeechPlayback = () => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    window.speechSynthesis.cancel();
    const cleanText = message.text.replace(/[*#_~`>]/g, '').replace(/[^\p{L}\p{N}\s.,?!;:'"()-]/gu, '').trim();
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = lang === 'ta' ? 'ta-IN' : 'en-IN';
    utterance.rate = 0.95;

    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    setIsPlayingAudio(true);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
        className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
      >
        {!isUser && (
          <span className="mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-lilac-200 to-aqua-100 text-lilac-800">
            <Sparkles className="h-4 w-4" aria-hidden />
          </span>
        )}
        <div className={`max-w-[88%] sm:max-w-[78%] ${isUser ? 'order-first' : ''}`}>
          <div
            className={`rounded-2xl px-4 py-3.5 sm:px-5 relative group ${
              isUser
                ? 'rounded-br-md bg-ink-900 text-[15px] leading-relaxed text-white'
                : 'rounded-tl-md border border-ink-200/70 bg-white shadow-card'
            }`}
          >
            {message.imageUrl && (
              <div className="mb-2.5 overflow-hidden rounded-xl border border-white/20 max-w-xs">
                <img
                  src={message.imageUrl}
                  alt="Crop Diagnostic Observation"
                  className="max-h-56 w-full object-cover rounded-lg"
                />
              </div>
            )}
            {isUser ? <p>{message.text}</p> : <AnswerBody text={message.text} />}

            {/* Quick Actions Bar inside bubble header */}
            {!isUser && (
              <div className="absolute right-3 top-3 flex items-center gap-1 opacity-80 group-hover:opacity-100 transition">
                <button
                  type="button"
                  onClick={handleCopy}
                  title={lang === 'ta' ? 'நகலெடு' : 'Copy answer'}
                  className="p-1.5 rounded-lg text-ink-400 hover:text-leaf-700 hover:bg-leaf-50 transition"
                >
                  {copied ? <Check className="h-4 w-4 text-leaf-600" /> : <Copy className="h-4 w-4" />}
                </button>
                <button
                  type="button"
                  onClick={toggleSpeechPlayback}
                  title={lang === 'ta' ? 'பதிலை சத்தமாக வாசி' : 'Read answer aloud'}
                  className="p-1.5 rounded-lg text-ink-400 hover:text-leaf-700 hover:bg-leaf-50 transition"
                >
                  {isPlayingAudio ? (
                    <VolumeX className="h-4 w-4 text-leaf-600 animate-pulse" />
                  ) : (
                    <Volume2 className="h-4 w-4" />
                  )}
                </button>
              </div>
            )}
          </div>

          {!isUser && (
            <div className="mt-2.5 flex flex-col gap-2 pl-1">
              <div className="flex flex-wrap items-center gap-2">
                {/* Provider Badge */}
                {message.provider && (
                  <span className="inline-flex items-center gap-1 rounded-full border border-ink-200 bg-ink-50 px-2.5 py-0.5 text-[11px] font-semibold text-ink-600">
                    <Sparkles className="h-3 w-3 text-leaf-600" />
                    <span>{message.provider.replace(/Google Gemini/gi, 'AgriKnow').split('(')[0].trim()}</span>
                  </span>
                )}

                {/* Helpful / Unhelpful Reactions */}
                <div className="inline-flex items-center rounded-full border border-ink-200 bg-white p-0.5 shadow-2xs">
                  <button
                    type="button"
                    onClick={() => handleVote('up')}
                    title={lang === 'ta' ? 'பயனுள்ளது' : 'Helpful'}
                    className={`rounded-full p-1 transition ${
                      feedbackVote === 'up' ? 'bg-leaf-100 text-leaf-800' : 'text-ink-400 hover:text-leaf-600 hover:bg-ink-100'
                    }`}
                  >
                    <ThumbsUp className="h-3 w-3" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleVote('down')}
                    title={lang === 'ta' ? 'பயனற்றது' : 'Unhelpful'}
                    className={`rounded-full p-1 transition ${
                      feedbackVote === 'down' ? 'bg-danger-100 text-danger-800' : 'text-ink-400 hover:text-danger-600 hover:bg-ink-100'
                    }`}
                  >
                    <ThumbsDown className="h-3 w-3" />
                  </button>
                </div>

                {onRegenerate && (
                  <button
                    type="button"
                    onClick={onRegenerate}
                    title={lang === 'ta' ? 'மீண்டும் உருவாக்கு' : 'Regenerate response'}
                    className="inline-flex items-center gap-1 rounded-full border border-ink-200 bg-white px-2 py-0.5 text-[11px] font-medium text-ink-600 hover:border-leaf-300 hover:bg-leaf-50 transition shadow-2xs"
                  >
                    <RotateCcw className="h-3 w-3" />
                    <span>{lang === 'ta' ? 'மீண்டும் உருவாக்கு' : 'Regenerate'}</span>
                  </button>
                )}

                {message.ragTrace && (
                  <button
                    type="button"
                    onClick={() => setShowTrace(true)}
                    className="inline-flex items-center gap-1.5 rounded-full border border-aqua-400/80 bg-aqua-50 px-2.5 py-0.5 text-xs font-bold text-aqua-900 transition hover:bg-aqua-100 shadow-sm"
                  >
                    <Activity className="h-3.5 w-3.5 text-aqua-600" />
                    <span>RAG Trace ({message.ragTrace.latencyMs.total}ms)</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setShowFeedback(true)}
                  className="inline-flex items-center gap-1 rounded-full border border-brand-300 bg-brand-50 px-2.5 py-0.5 text-xs font-bold text-brand-900 transition hover:bg-brand-100 shadow-xs"
                  title="Phase 7 Pilot Review & Feedback"
                >
                  <MessageSquareQuote className="h-3.5 w-3.5 text-brand-600" />
                  <span>{lang === 'ta' ? 'கருத்து (Review)' : 'Feedback'}</span>
                </button>

                {message.sourceIds && message.sourceIds.length > 0 && (
                  <>
                    <span className="text-xs font-medium text-ink-500">{sourcesLabel}</span>
                    {message.sourceIds.map((sourceId, index) => {
                      const source = findSource(sourceId);
                      if (!source) return null;
                      return (
                        <a
                          key={sourceId}
                          href={`#/evidence?doc=${sourceId}`}
                          className="inline-flex max-w-full items-center gap-1.5 rounded-full border border-lilac-300 bg-lilac-50 px-3 py-1 text-xs font-medium text-lilac-800 transition hover:border-lilac-400 hover:bg-lilac-100"
                        >
                          <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-lilac-400 text-[10px] font-bold text-ink-900">
                            {index + 1}
                          </span>
                          <BookOpen className="h-3.5 w-3.5 shrink-0" aria-hidden />
                          <span className="truncate">{source.title}</span>
                        </a>
                      );
                    })}
                  </>
                )}
              </div>

              {/* Contextual Follow-Up Suggestions */}
              {message.suggestedFollowUps && message.suggestedFollowUps.length > 0 && onSelectFollowUp && (
                <div className="mt-1 flex flex-wrap items-center gap-1.5">
                  <span className="text-[11px] font-semibold text-ink-400 flex items-center gap-1">
                    <CornerDownRight className="h-3 w-3" />
                    {lang === 'ta' ? 'தொடர்புடைய கேள்விகள்:' : 'Follow-up queries:'}
                  </span>
                  {message.suggestedFollowUps.map((chip, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => onSelectFollowUp(lang === 'ta' ? chip.ta : chip.en)}
                      className="rounded-full border border-ink-200 bg-ink-50 px-3 py-1 text-xs font-medium text-ink-800 hover:border-leaf-400 hover:bg-leaf-50 transition text-left"
                    >
                      {lang === 'ta' ? chip.ta : chip.en}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </motion.div>

      {showTrace && message.ragTrace && (
        <RagTraceModal trace={message.ragTrace} onClose={() => setShowTrace(false)} />
      )}

      {showFeedback && (
        <PilotFeedbackModal
          isOpen={showFeedback}
          onClose={() => setShowFeedback(false)}
          module="assistant"
          queryText={message.ragTrace?.originalQuery || message.text.slice(0, 80)}
          answerSnippet={message.text.slice(0, 300)}
        />
      )}
    </>
  );
}
