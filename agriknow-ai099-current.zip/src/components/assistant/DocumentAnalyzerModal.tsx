import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FileText,
  Upload,
  X,
  CheckCircle2,
  AlertTriangle,
  FileSearch,
  ArrowRight,
  ShieldCheck,
  Tag,
  Building2,
  Calendar,
  Layers,
  Trash2,
  MessageSquare,
  GitCompare,
  Send,
  Loader2,
  HelpCircle,
  FileCheck,
} from 'lucide-react';
import {
  analyzeUploadedFile,
  fetchUserUploadedDocuments,
  deleteUserUploadedDocument,
  askQuestionAboutDocument,
  setActiveAnalyzedDocument,
  type StoredUserDocument,
} from '@/services/documentAnalyzerService';
import type { Lang } from '@/lib/i18n';
import { useAuth } from '@/contexts/AuthContext';

interface DocumentAnalyzerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDocumentAnalyzed: (doc: StoredUserDocument) => void;
  lang: Lang;
}

export function DocumentAnalyzerModal({
  isOpen,
  onClose,
  onDocumentAnalyzed,
  lang,
}: DocumentAnalyzerModalProps) {
  const isTa = lang === 'ta';
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Tabs: 'upload' | 'history' | 'compare'
  const [activeTab, setActiveTab] = useState<'upload' | 'history' | 'compare'>('upload');
  const [userDocs, setUserDocs] = useState<StoredUserDocument[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [analyzedDoc, setAnalyzedDoc] = useState<StoredUserDocument | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Interactive Document Q&A state
  const [qaInput, setQaInput] = useState('');
  const [qaLoading, setQaLoading] = useState(false);
  const [qaHistory, setQaHistory] = useState<{ q: string; a: string }[]>([]);

  // Document Comparison state
  const [compareDocId1, setCompareDocId1] = useState<string>('');
  const [compareDocId2, setCompareDocId2] = useState<string>('');

  const loadDocs = async () => {
    const docs = await fetchUserUploadedDocuments(user?.id);
    setUserDocs(docs);
    if (docs.length > 0 && !compareDocId1) {
      setCompareDocId1(docs[0].id);
      if (docs.length > 1) setCompareDocId2(docs[1].id);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadDocs();
      setAnalyzedDoc(null);
      setError(null);
      setActiveTab('upload');
    }
  }, [isOpen, user?.id]);

  if (!isOpen) return null;

  const handleFileUpload = async (file: File) => {
    setIsProcessing(true);
    setError(null);
    try {
      const doc = await analyzeUploadedFile(file, user?.id, lang as 'ta' | 'en');
      setAnalyzedDoc(doc);
      setActiveAnalyzedDocument(doc);
      await loadDocs();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(
        msg.includes('OCR_UNAVAILABLE')
          ? isTa
            ? 'புகைப்படங்களை OCR முறையில் படிக்க AgriKnow API சாவி தேவை. தயவுசெய்து PDF அல்லது உரை ஆவணத்தைப் பதிவேற்றவும்.'
            : 'Image OCR requires AgriKnow API key. Please upload a PDF or text document.'
          : isTa
          ? `ஆவணத்தைப் பகுப்பாய்வு செய்வதில் பிழை: ${msg}`
          : `Failed to analyze document: ${msg}`
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDelete = async (docId: string) => {
    if (window.confirm(isTa ? 'இந்த ஆவணத்தை நீக்க விரும்புகிறீர்களா?' : 'Delete this document?')) {
      await deleteUserUploadedDocument(docId, user?.id);
      if (analyzedDoc?.id === docId) {
        setAnalyzedDoc(null);
      }
      await loadDocs();
    }
  };

  const handleAskQuestion = async () => {
    if (!analyzedDoc || !qaInput.trim() || qaLoading) return;
    const q = qaInput.trim();
    setQaInput('');
    setQaLoading(true);

    try {
      const answer = await askQuestionAboutDocument(analyzedDoc, q, lang as 'ta' | 'en');
      setQaHistory((prev) => [...prev, { q, a: answer }]);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setQaHistory((prev) => [
        ...prev,
        { q, a: isTa ? `பிழை: ${msg}` : `Error: ${msg}` },
      ]);
    } finally {
      setQaLoading(false);
    }
  };

  const handleConfirmAddToChat = () => {
    if (!analyzedDoc) return;
    onDocumentAnalyzed(analyzedDoc);
    onClose();
  };

  const doc1 = userDocs.find((d) => d.id === compareDocId1);
  const doc2 = userDocs.find((d) => d.id === compareDocId2);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-3xl border border-leaf-200 bg-white shadow-2xl flex flex-col"
        >
          {/* Header */}
          <div className="sticky top-0 z-10 flex items-center justify-between border-b border-ink-100 bg-gradient-to-r from-leaf-50 via-white to-aqua-50 px-6 py-4">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-leaf-500 text-white shadow-md shadow-leaf-500/30">
                <FileSearch className="h-5 w-5" />
              </span>
              <div>
                <h3 className="text-base font-bold text-ink-900">
                  {isTa ? 'விவசாய ஆவண மேலாண்மை மையம்' : 'Agricultural Document Workspace'}
                </h3>
                <p className="text-xs text-ink-500">
                  {isTa
                    ? 'விதை அட்டை, உர ரசீது, APMC பில் & மண் அட்டைகளைப் பகுப்பாய்வு செய்க'
                    : 'Real-time dynamic parsing for seed tags, bills, and farm records'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="rounded-full p-2 text-ink-400 hover:bg-ink-100 hover:text-ink-700 transition"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="flex border-b border-ink-100 bg-ink-50/70 px-6">
            <button
              type="button"
              onClick={() => setActiveTab('upload')}
              className={`flex items-center gap-1.5 border-b-2 px-4 py-3 text-xs font-bold transition ${
                activeTab === 'upload'
                  ? 'border-leaf-500 text-leaf-800 bg-white'
                  : 'border-transparent text-ink-600 hover:text-ink-900'
              }`}
            >
              <Upload className="h-4 w-4" />
              <span>{isTa ? 'புதிய ஆவணம் பதிவேற்றம்' : 'Upload Document'}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('history')}
              className={`flex items-center gap-1.5 border-b-2 px-4 py-3 text-xs font-bold transition ${
                activeTab === 'history'
                  ? 'border-leaf-500 text-leaf-800 bg-white'
                  : 'border-transparent text-ink-600 hover:text-ink-900'
              }`}
            >
              <Layers className="h-4 w-4" />
              <span>{isTa ? `எனது ஆவணங்கள் (${userDocs.length})` : `My Documents (${userDocs.length})`}</span>
            </button>

            {userDocs.length >= 2 && (
              <button
                type="button"
                onClick={() => setActiveTab('compare')}
                className={`flex items-center gap-1.5 border-b-2 px-4 py-3 text-xs font-bold transition ${
                  activeTab === 'compare'
                    ? 'border-leaf-500 text-leaf-800 bg-white'
                    : 'border-transparent text-ink-600 hover:text-ink-900'
                }`}
              >
                <GitCompare className="h-4 w-4" />
                <span>{isTa ? 'ஆவணங்களை ஒப்பிடுக' : 'Compare Documents'}</span>
              </button>
            )}
          </div>

          {/* Tab Content */}
          <div className="p-6 space-y-6 flex-1">
            {activeTab === 'upload' && !analyzedDoc && (
              <>
                {/* Upload Drag & Drop Zone */}
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-leaf-300 bg-leaf-50/50 p-10 text-center cursor-pointer transition hover:border-leaf-500 hover:bg-leaf-50"
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,.docx,.txt,.png,.jpg,.jpeg,.webp"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileUpload(file);
                    }}
                    className="hidden"
                  />

                  <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-leaf-100 text-leaf-700 shadow-sm">
                    <Upload className="h-8 w-8" />
                  </div>

                  <p className="text-sm font-bold text-ink-900">
                    {isTa
                      ? 'உங்கள் விவசாய ஆவணத்தை இங்கே பதிவேற்றவும்'
                      : 'Upload your agricultural document (PDF, DOCX, TXT, Photo)'}
                  </p>
                  <p className="mt-1 text-xs text-ink-500 max-w-md">
                    {isTa
                      ? 'விதை சான்றிதழ் அட்டை, உரக் கொள்முதல் ரசீது, பூச்சிக்கொல்லி பில், அல்லது மண்டி விற்பனை ரசீது. உண்மையான ஆவணத் தகவல்கள் பிரித்தெடுக்கப்படும்.'
                      : 'Certified seed tags, fertilizer bills, pesticide receipts, mandi sale vouchers, or soil reports. Real text and parameters will be extracted dynamically.'}
                  </p>
                </div>

                {isProcessing && (
                  <div className="flex flex-col items-center justify-center gap-2 text-xs font-bold text-leaf-700 py-6">
                    <Loader2 className="h-7 w-7 text-leaf-600 animate-spin" />
                    <span>{isTa ? 'ஆவணம் AI மூலம் பகுப்பாய்வு செய்யப்படுகிறது...' : 'AgriKnow is parsing and verifying document structure...'}</span>
                  </div>
                )}

                {error && (
                  <div className="rounded-xl border border-danger-200 bg-danger-50 p-4 text-xs font-medium text-danger-700 flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5 text-danger-600" />
                    <span>{error}</span>
                  </div>
                )}
              </>
            )}

            {/* Analyzed Document View */}
            {analyzedDoc && (
              <div className="space-y-5">
                <div className="flex items-center justify-between rounded-xl bg-leaf-100 p-3.5 text-xs font-bold text-leaf-900">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="h-4 w-4 text-leaf-600" />
                    <span>{isTa ? 'ஆவணம் வெற்றிகரமாக பிரித்தெடுக்கப்பட்டது' : 'Document Verified & Parsed'}</span>
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setAnalyzedDoc(null)}
                      className="text-xs font-semibold text-leaf-700 hover:underline"
                    >
                      {isTa ? 'மற்றொரு ஆவணம்' : 'Back / Upload New'}
                    </button>
                  </div>
                </div>

                {/* Key Extracted Badges */}
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <div className="rounded-xl border border-ink-200 bg-ink-50/70 p-3">
                    <span className="flex items-center gap-1 text-[11px] font-medium text-ink-500">
                      <Tag className="h-3 w-3 text-leaf-600" />
                      {isTa ? 'பயிர் & ரகம்' : 'Crop & Variety'}
                    </span>
                    <p className="mt-1 text-xs font-bold text-ink-900 truncate">
                      {analyzedDoc.crop || 'Document record'} {analyzedDoc.variety ? `— ${analyzedDoc.variety}` : ''}
                    </p>
                  </div>

                  <div className="rounded-xl border border-ink-200 bg-ink-50/70 p-3">
                    <span className="flex items-center gap-1 text-[11px] font-medium text-ink-500">
                      <FileCheck className="h-3 w-3 text-aqua-600" />
                      {isTa ? 'குவியல் / வரிசை எண்' : 'Lot / Tag No'}
                    </span>
                    <p className="mt-1 text-xs font-bold text-ink-900 truncate">
                      {analyzedDoc.lotOrBatchNumber || 'Extracted'}
                    </p>
                  </div>

                  <div className="rounded-xl border border-ink-200 bg-ink-50/70 p-3">
                    <span className="flex items-center gap-1 text-[11px] font-medium text-ink-500">
                      <ShieldCheck className="h-3 w-3 text-sun-600" />
                      {isTa ? 'முளைப்புத் திறன்' : 'Germination Rate'}
                    </span>
                    <p className="mt-1 text-xs font-bold text-ink-900">
                      {analyzedDoc.germinationPercent || 'Certified'}
                    </p>
                  </div>

                  <div className="rounded-xl border border-ink-200 bg-ink-50/70 p-3">
                    <span className="flex items-center gap-1 text-[11px] font-medium text-ink-500">
                      <Calendar className="h-3 w-3 text-lilac-600" />
                      {isTa ? 'செல்லுபடியாகும் காலம்' : 'Validity'}
                    </span>
                    <p className="mt-1 text-xs font-bold text-ink-900 truncate">
                      {analyzedDoc.expiryDate || 'Official Record'}
                    </p>
                  </div>
                </div>

                {/* Key Findings List */}
                {analyzedDoc.keyFindings && analyzedDoc.keyFindings.length > 0 && (
                  <div className="rounded-xl border border-ink-200 bg-white p-4">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-ink-600 mb-2">
                      {isTa ? 'முக்கிய கண்டுபிடிப்புகள் (Extracted Parameters)' : 'Extracted Parameters & Values'}
                    </h4>
                    <div className="grid gap-2 sm:grid-cols-2">
                      {analyzedDoc.keyFindings.map((kf, i) => (
                        <div key={i} className="flex items-center justify-between text-xs py-1 border-b border-ink-100">
                          <span className="text-ink-600">{isTa ? kf.labelTa : kf.labelEn}:</span>
                          <span className="font-bold text-ink-900">{kf.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Summary Box */}
                <div className="rounded-2xl border border-ink-200 bg-ink-50/50 p-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-ink-600 mb-2 flex items-center gap-1.5">
                    <Layers className="h-3.5 w-3.5 text-leaf-600" />
                    {isTa ? 'விரிவான ஆவண விளக்கம்' : 'Full Document Analysis Summary'}
                  </h4>
                  <div className="text-xs leading-relaxed text-ink-800 whitespace-pre-line">
                    {isTa ? analyzedDoc.summaryTa : analyzedDoc.summaryEn}
                  </div>
                </div>

                {/* Interactive Q&A on this specific document */}
                <div className="rounded-2xl border border-leaf-300 bg-leaf-50/40 p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <HelpCircle className="h-4 w-4 text-leaf-700" />
                    <h4 className="text-xs font-bold uppercase tracking-wider text-leaf-900">
                      {isTa ? 'இந்த ஆவணம் குறித்து AI-யிடம் கேளுங்கள்' : 'Ask AI about this specific document'}
                    </h4>
                  </div>

                  {qaHistory.length > 0 && (
                    <div className="space-y-2 max-h-40 overflow-y-auto no-scrollbar">
                      {qaHistory.map((item, idx) => (
                        <div key={idx} className="rounded-xl bg-white p-2.5 text-xs border border-leaf-200 space-y-1">
                          <p className="font-bold text-ink-900">Q: {item.q}</p>
                          <p className="text-leaf-800 leading-relaxed">A: {item.a}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={qaInput}
                      onChange={(e) => setQaInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleAskQuestion()}
                      placeholder={
                        isTa
                          ? 'எ.கா: இதில் என்னென்ன மருந்துகள் அல்லது காலாவதி தேதி உள்ளது?'
                          : 'e.g. What is the certified purity, lot number, or expiry?'
                      }
                      className="h-9 flex-1 rounded-xl border border-leaf-300 bg-white px-3 text-xs text-ink-900 placeholder:text-ink-400 focus:outline-none focus:ring-2 focus:ring-leaf-400"
                    />
                    <button
                      type="button"
                      disabled={qaLoading || !qaInput.trim()}
                      onClick={handleAskQuestion}
                      className="flex h-9 items-center justify-center gap-1 rounded-xl bg-leaf-600 px-3 text-xs font-bold text-white transition hover:bg-leaf-500 disabled:opacity-50"
                    >
                      {qaLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
                      <span>{isTa ? 'கேள்' : 'Ask'}</span>
                    </button>
                  </div>
                </div>

                {/* Confirm Action Button */}
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={handleConfirmAddToChat}
                    className="flex w-full items-center justify-center gap-2 rounded-2xl bg-leaf-600 py-3.5 text-sm font-bold text-white shadow-lg shadow-leaf-600/30 transition hover:bg-leaf-500 active:scale-98"
                  >
                    <span>{isTa ? 'உரையாடலில் இணைத்து தொடரவும்' : 'Set as Active Document in Chat'}</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            )}

            {/* User Upload History Tab */}
            {activeTab === 'history' && !analyzedDoc && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-ink-600">
                    {isTa ? 'நீங்கள் பதிவேற்றிய ஆவணங்கள்' : 'Your Uploaded Documents'}
                  </h4>
                  <span className="text-xs text-ink-500">
                    {userDocs.length} {isTa ? 'ஆவணங்கள்' : 'records stored'}
                  </span>
                </div>

                {userDocs.length === 0 ? (
                  <div className="rounded-2xl border border-ink-200 p-8 text-center bg-ink-50/50">
                    <FileText className="mx-auto h-8 w-8 text-ink-400" />
                    <p className="mt-2 text-xs font-bold text-ink-700">
                      {isTa ? 'பதிவேற்றிய ஆவணங்கள் எதுவும் இல்லை' : 'No documents uploaded yet'}
                    </p>
                    <p className="mt-1 text-xs text-ink-500">
                      {isTa
                        ? 'உங்கள் விதை அட்டை அல்லது உர ரசீதைப் பதிவேற்றி பகுப்பாய்வு செய்யவும்.'
                        : 'Upload a seed tag or fertilizer bill from the Upload tab to start.'}
                    </p>
                    <button
                      type="button"
                      onClick={() => setActiveTab('upload')}
                      className="mt-4 rounded-xl bg-leaf-600 px-4 py-2 text-xs font-bold text-white hover:bg-leaf-500 transition"
                    >
                      {isTa ? 'இப்போது பதிவேற்று' : 'Upload Document Now'}
                    </button>
                  </div>
                ) : (
                  <div className="grid gap-3 sm:grid-cols-2">
                    {userDocs.map((doc) => (
                      <div
                        key={doc.id}
                        className="flex flex-col justify-between rounded-xl border border-ink-200 bg-white p-4 shadow-2xs hover:border-leaf-400 transition"
                      >
                        <div>
                          <div className="flex items-center justify-between gap-2">
                            <span className="rounded-md bg-leaf-100 px-2 py-0.5 text-[10px] font-bold text-leaf-800">
                              {isTa ? doc.categoryLabelTa : doc.categoryLabelEn}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleDelete(doc.id)}
                              className="text-ink-400 hover:text-danger-600 transition"
                              title="Delete"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>

                          <h5 className="mt-2 text-xs font-bold text-ink-900 truncate">{doc.fileName}</h5>
                          <p className="text-[11px] text-ink-500">
                            {doc.crop ? `${doc.crop} ${doc.variety || ''}` : 'Agricultural Record'} • {doc.uploadedAt}
                          </p>
                        </div>

                        <div className="mt-4 flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setAnalyzedDoc(doc)}
                            className="flex-1 rounded-lg border border-leaf-300 bg-leaf-50 py-1.5 text-xs font-bold text-leaf-800 hover:bg-leaf-100 transition"
                          >
                            {isTa ? 'ஆய்வு செய்' : 'View Intelligence'}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Document Comparison Tab */}
            {activeTab === 'compare' && !analyzedDoc && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-ink-600 flex items-center gap-1.5">
                    <GitCompare className="h-4 w-4 text-leaf-600" />
                    <span>{isTa ? 'இரண்டு ஆவணங்களை ஒப்பிடுக' : 'Side-by-Side Document Comparison'}</span>
                  </h4>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-ink-700 block mb-1">
                      {isTa ? 'ஆவணம் 1:' : 'Document 1:'}
                    </label>
                    <select
                      value={compareDocId1}
                      onChange={(e) => setCompareDocId1(e.target.value)}
                      className="w-full rounded-xl border border-ink-200 p-2 text-xs text-ink-900"
                    >
                      {userDocs.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.fileName}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-ink-700 block mb-1">
                      {isTa ? 'ஆவணம் 2:' : 'Document 2:'}
                    </label>
                    <select
                      value={compareDocId2}
                      onChange={(e) => setCompareDocId2(e.target.value)}
                      className="w-full rounded-xl border border-ink-200 p-2 text-xs text-ink-900"
                    >
                      {userDocs.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.fileName}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {doc1 && doc2 && (
                  <div className="overflow-x-auto rounded-xl border border-ink-200 bg-white">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-ink-50 text-ink-700 font-bold border-b border-ink-200">
                        <tr>
                          <th className="p-3">Parameter</th>
                          <th className="p-3">{doc1.fileName}</th>
                          <th className="p-3">{doc2.fileName}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-ink-100 text-ink-800">
                        <tr>
                          <td className="p-3 font-semibold text-ink-600">Category</td>
                          <td className="p-3 font-bold">{doc1.categoryLabelEn}</td>
                          <td className="p-3 font-bold">{doc2.categoryLabelEn}</td>
                        </tr>
                        <tr>
                          <td className="p-3 font-semibold text-ink-600">Crop & Variety</td>
                          <td className="p-3">{doc1.crop ? `${doc1.crop} ${doc1.variety || ''}` : '—'}</td>
                          <td className="p-3">{doc2.crop ? `${doc2.crop} ${doc2.variety || ''}` : '—'}</td>
                        </tr>
                        <tr>
                          <td className="p-3 font-semibold text-ink-600">Lot / Tag No</td>
                          <td className="p-3 font-mono">{doc1.lotOrBatchNumber || '—'}</td>
                          <td className="p-3 font-mono">{doc2.lotOrBatchNumber || '—'}</td>
                        </tr>
                        <tr>
                          <td className="p-3 font-semibold text-ink-600">Germination %</td>
                          <td className="p-3 font-bold text-leaf-700">{doc1.germinationPercent || '—'}</td>
                          <td className="p-3 font-bold text-leaf-700">{doc2.germinationPercent || '—'}</td>
                        </tr>
                        <tr>
                          <td className="p-3 font-semibold text-ink-600">Valid Until</td>
                          <td className="p-3">{doc1.expiryDate || '—'}</td>
                          <td className="p-3">{doc2.expiryDate || '—'}</td>
                        </tr>
                        <tr>
                          <td className="p-3 font-semibold text-ink-600">Total Price</td>
                          <td className="p-3 font-bold text-ink-900">{doc1.pricePaid || '—'}</td>
                          <td className="p-3 font-bold text-ink-900">{doc2.pricePaid || '—'}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
