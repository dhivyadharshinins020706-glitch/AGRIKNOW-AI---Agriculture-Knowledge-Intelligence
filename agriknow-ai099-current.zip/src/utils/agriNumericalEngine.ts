/**
 * AGRIKNOW AI - Deterministic Agricultural Numerical Intelligence Engine
 * 
 * Provides verifiable, deterministic calculations for:
 * 1. Land Area conversions (Acres, Hectares, Cents, Gunthas, Sq.ft)
 * 2. Weight & Volume conversions (kg, grams, quintals, tonnes, litres, ml)
 * 3. Fertilizer Nutrient Content calculation (Actual N, P2O5, K2O kg from bag weight & grade)
 * 4. Application Rate & Spray Dilution dosage (per tank / per acre)
 * 5. Soil Parameter benchmark evaluations (pH, EC, OC, Available N, P, K)
 */

export interface LandAreaConversionResult {
  originalValue: number;
  originalUnit: 'acre' | 'hectare' | 'cents' | 'sq_ft' | 'guntha';
  targetUnit: 'acre' | 'hectare' | 'cents' | 'sq_ft' | 'guntha';
  convertedValue: number;
  formula: string;
  displayFormatted: string;
}

export interface FertilizerNutrientCalculation {
  productName: string;
  bagWeightKg: number;
  nitrogenKg: number;
  phosphorusP2O5Kg: number;
  potassiumK2OKg: number;
  sulphurKg?: number;
  formula: string;
  summaryEn: string;
  summaryTa: string;
}

export interface SprayDilutionResult {
  productDosagePerLitre: number;
  dosageUnit: 'ml' | 'g';
  tankSizeLitres: number;
  numberOfTanksPerAcre: number;
  totalProductPerTank: number;
  totalProductPerAcre: number;
  totalWaterLitresPerAcre: number;
  formula: string;
  displayEn: string;
  displayTa: string;
}

export interface SoilParameterBenchmark {
  parameter: 'pH' | 'EC' | 'OC' | 'N' | 'P' | 'K' | 'Zn' | 'Fe' | 'S';
  value: number;
  unit: string;
  status: 'very_low' | 'low' | 'optimal' | 'high' | 'very_high' | 'saline' | 'alkaline' | 'acidic';
  classificationEn: string;
  classificationTa: string;
  recommendedActionEn: string;
  recommendedActionTa: string;
}

/**
 * Deterministic Land Area Converter
 * 1 Hectare = 2.47105 Acres
 * 1 Acre = 100 Cents = 43,560 sq.ft = 40 Gunthas = 0.404686 Hectare
 */
export function convertLandArea(
  value: number,
  from: 'acre' | 'hectare' | 'cents' | 'sq_ft' | 'guntha',
  to: 'acre' | 'hectare' | 'cents' | 'sq_ft' | 'guntha'
): LandAreaConversionResult {
  // Convert 'from' to square feet as base unit
  let sqFt = 0;
  switch (from) {
    case 'acre':
      sqFt = value * 43560;
      break;
    case 'hectare':
      sqFt = value * 107639.1;
      break;
    case 'cents':
      sqFt = value * 435.6;
      break;
    case 'guntha':
      sqFt = value * 1089;
      break;
    case 'sq_ft':
      sqFt = value;
      break;
  }

  // Convert from square feet to 'to'
  let converted = 0;
  let formula = '';
  switch (to) {
    case 'acre':
      converted = sqFt / 43560;
      formula = `${value} ${from} = (${sqFt.toFixed(1)} sq.ft ÷ 43,560) = ${converted.toFixed(3)} acres`;
      break;
    case 'hectare':
      converted = sqFt / 107639.1;
      formula = `${value} ${from} = (${sqFt.toFixed(1)} sq.ft ÷ 107,639.1) = ${converted.toFixed(3)} hectares`;
      break;
    case 'cents':
      converted = sqFt / 435.6;
      formula = `${value} ${from} = (${sqFt.toFixed(1)} sq.ft ÷ 435.6) = ${converted.toFixed(1)} cents`;
      break;
    case 'guntha':
      converted = sqFt / 1089;
      formula = `${value} ${from} = (${sqFt.toFixed(1)} sq.ft ÷ 1,089) = ${converted.toFixed(2)} gunthas`;
      break;
    case 'sq_ft':
      converted = sqFt;
      formula = `${value} ${from} = ${converted.toFixed(0)} sq.ft`;
      break;
  }

  const rounded = parseFloat(converted.toFixed(4));
  return {
    originalValue: value,
    originalUnit: from,
    targetUnit: to,
    convertedValue: rounded,
    formula,
    displayFormatted: `${value} ${from} = ${rounded} ${to}`,
  };
}

/**
 * Metric Weight & Volume Conversions
 */
export function convertMetricWeight(
  value: number,
  from: 'kg' | 'grams' | 'quintal' | 'metric_ton',
  to: 'kg' | 'grams' | 'quintal' | 'metric_ton'
): { value: number; unit: string; formula: string } {
  // Base in grams
  let grams = 0;
  switch (from) {
    case 'grams':
      grams = value;
      break;
    case 'kg':
      grams = value * 1000;
      break;
    case 'quintal':
      grams = value * 100000;
      break;
    case 'metric_ton':
      grams = value * 1000000;
      break;
  }

  let result = 0;
  switch (to) {
    case 'grams':
      result = grams;
      break;
    case 'kg':
      result = grams / 1000;
      break;
    case 'quintal':
      result = grams / 100000;
      break;
    case 'metric_ton':
      result = grams / 1000000;
      break;
  }

  const finalVal = parseFloat(result.toFixed(3));
  return {
    value: finalVal,
    unit: to,
    formula: `${value} ${from} = ${finalVal} ${to}`,
  };
}

/**
 * Calculates actual elemental nutrient content from standard commercial fertilizer bags.
 * - Urea: 46% Nitrogen (N)
 * - DAP: 18% Nitrogen (N) & 46% Phosphorus (P2O5)
 * - MOP: 60% Potassium (K2O)
 * - SSP: 16% P2O5 & 11% Sulphur
 * - Complex 20:20:0:13: 20% N, 20% P2O5, 13% S
 * - Ammonium Sulphate: 20.6% N, 24% S
 */
export function calculateFertilizerNutrients(
  fertilizerName: string,
  bagWeightKg = 50
): FertilizerNutrientCalculation {
  const lower = fertilizerName.toLowerCase();

  let nPercent = 0;
  let pPercent = 0;
  let kPercent = 0;
  let sPercent: number | undefined = undefined;
  let normalizedName = fertilizerName;

  if (lower.includes('urea') && !lower.includes('nano')) {
    normalizedName = 'Urea (Prilled/Neem Coated)';
    nPercent = 46.0;
  } else if (lower.includes('dap') || lower.includes('diammonium')) {
    normalizedName = 'Di-Ammonium Phosphate (DAP 18-46-0)';
    nPercent = 18.0;
    pPercent = 46.0;
  } else if (lower.includes('mop') || lower.includes('potash') || lower.includes('muriate')) {
    normalizedName = 'Muriate of Potash (MOP 0-0-60)';
    kPercent = 60.0;
  } else if (lower.includes('ssp') || lower.includes('super phosphate')) {
    normalizedName = 'Single Super Phosphate (SSP 0-16-0-11S)';
    pPercent = 16.0;
    sPercent = 11.0;
  } else if (lower.includes('20:20:0:13') || lower.includes('ammonium phosphate sulphate')) {
    normalizedName = 'Ammonium Phosphate Sulphate (20:20:0:13S)';
    nPercent = 20.0;
    pPercent = 20.0;
    sPercent = 13.0;
  } else if (lower.includes('ammonium sulphate')) {
    normalizedName = 'Ammonium Sulphate (20.6-0-0-24S)';
    nPercent = 20.6;
    sPercent = 24.0;
  } else if (lower.includes('10:26:26') || lower.includes('iffco 10-26-26')) {
    normalizedName = 'Complex NPK (10:26:26)';
    nPercent = 10.0;
    pPercent = 26.0;
    kPercent = 26.0;
  } else if (lower.includes('17:17:17')) {
    normalizedName = 'Complex NPK (17:17:17)';
    nPercent = 17.0;
    pPercent = 17.0;
    kPercent = 17.0;
  } else {
    // Default fallback parsing from numbers like "20-20-20"
    const match = lower.match(/(\d{1,2})[-:](\d{1,2})[-:](\d{1,2})/);
    if (match) {
      nPercent = parseFloat(match[1]);
      pPercent = parseFloat(match[2]);
      kPercent = parseFloat(match[3]);
      normalizedName = `NPK (${nPercent}:${pPercent}:${kPercent})`;
    }
  }

  const nKg = parseFloat(((bagWeightKg * nPercent) / 100).toFixed(2));
  const pKg = parseFloat(((bagWeightKg * pPercent) / 100).toFixed(2));
  const kKg = parseFloat(((bagWeightKg * kPercent) / 100).toFixed(2));
  const sKg = sPercent !== undefined ? parseFloat(((bagWeightKg * sPercent) / 100).toFixed(2)) : undefined;

  const formulaParts: string[] = [];
  if (nPercent > 0) formulaParts.push(`N: ${bagWeightKg}kg × ${nPercent}% = ${nKg} kg N`);
  if (pPercent > 0) formulaParts.push(`P₂O₅: ${bagWeightKg}kg × ${pPercent}% = ${pKg} kg P₂O₅`);
  if (kPercent > 0) formulaParts.push(`K₂O: ${bagWeightKg}kg × ${kPercent}% = ${kKg} kg K₂O`);
  if (sPercent && sKg !== undefined) formulaParts.push(`S: ${bagWeightKg}kg × ${sPercent}% = ${sKg} kg S`);

  const formula = `${normalizedName} [${bagWeightKg} kg bag]: ${formulaParts.join(' | ')}`;

  const summaryEn = `A ${bagWeightKg} kg bag of **${normalizedName}** provides **${nKg} kg Nitrogen (N)**, **${pKg} kg Phosphorus (P₂O₅)**, and **${kKg} kg Potassium (K₂O)**${sKg ? `, plus **${sKg} kg Sulphur**` : ''}.`;

  const summaryTa = `ஒரு ${bagWeightKg} கிலோ **${normalizedName}** மூட்டையில் **${nKg} கிலோ தழைச்சத்து (N)**, **${pKg} கிலோ மணிச்சத்து (P₂O₅)**, மற்றும் **${kKg} கிலோ சாம்பல் சத்து (K₂O)**${sKg ? `, மற்றும் **${sKg} கிலோ கந்தகம்**` : ''} கிடைக்கிறது.`;

  return {
    productName: normalizedName,
    bagWeightKg,
    nitrogenKg: nKg,
    phosphorusP2O5Kg: pKg,
    potassiumK2OKg: kKg,
    sulphurKg: sKg,
    formula,
    summaryEn,
    summaryTa,
  };
}

/**
 * Calculates spray tank dilution dosage accurately:
 * Prevents dangerous overdose of agrochemicals.
 */
export function calculateSprayDilution(
  dosagePerLitre: number,
  dosageUnit: 'ml' | 'g',
  tankSizeLitres = 10,
  tanksPerAcre = 10
): SprayDilutionResult {
  const totalPerTank = parseFloat((dosagePerLitre * tankSizeLitres).toFixed(2));
  const totalPerAcre = parseFloat((totalPerTank * tanksPerAcre).toFixed(2));
  const totalWater = tankSizeLitres * tanksPerAcre;

  const formula = `Dosage: ${dosagePerLitre} ${dosageUnit}/L × ${tankSizeLitres} L tank = ${totalPerTank} ${dosageUnit} per tank. For 1 acre (${tanksPerAcre} tanks = ${totalWater} L water): ${totalPerAcre} ${dosageUnit}.`;

  const displayEn = `**Recommended Spray Preparation:**
• **Per ${tankSizeLitres} Litre Tank:** Add **${totalPerTank} ${dosageUnit}** of product to ${tankSizeLitres} L water.
• **Per Acre Total (${tanksPerAcre} tanks):** **${totalPerAcre} ${dosageUnit}** (dissolved in **${totalWater} Litres** water).`;

  const displayTa = `**பரிந்துரைக்கப்பட்ட தெளிப்பு முறை:**
• **${tankSizeLitres} லிட்டர் டேங்க் ஒன்றுக்கு:** **${totalPerTank} ${dosageUnit}** மருந்தை ${tankSizeLitres} லிட்டர் நீரில் கலக்கவும்.
• **ஏக்கர் ஒன்றுக்கு மொத்தம் (${tanksPerAcre} டேங்குகள்):** **${totalPerAcre} ${dosageUnit}** மருந்தை **${totalWater} லிட்டர்** நீரில் கலந்து தெளிக்கவும்.`;

  return {
    productDosagePerLitre: dosagePerLitre,
    dosageUnit,
    tankSizeLitres,
    numberOfTanksPerAcre: tanksPerAcre,
    totalProductPerTank: totalPerTank,
    totalProductPerAcre: totalPerAcre,
    totalWaterLitresPerAcre: totalWater,
    formula,
    displayEn,
    displayTa,
  };
}

/**
 * Classifies Soil Health Card parameters against official TNAU/ICAR soil fertility benchmarks.
 */
export function evaluateSoilParameter(
  parameter: 'pH' | 'EC' | 'OC' | 'N' | 'P' | 'K' | 'Zn' | 'Fe' | 'S',
  value: number
): SoilParameterBenchmark {
  switch (parameter) {
    case 'pH':
      if (value < 6.0) {
        return {
          parameter,
          value,
          unit: 'pH scale',
          status: 'acidic',
          classificationEn: 'Acidic Soil (Low pH)',
          classificationTa: 'அமில மண் (குறைந்த pH)',
          recommendedActionEn: 'Apply agricultural lime @ 200–400 kg/acre to neutralize soil acidity and improve phosphorus availability.',
          recommendedActionTa: 'மண் அமிலத்தன்மையை சமன் செய்ய ஏக்கருக்கு 200–400 கிலோ விவசாய சுண்ணாம்பு இடவும்.',
        };
      } else if (value > 8.5) {
        return {
          parameter,
          value,
          unit: 'pH scale',
          status: 'alkaline',
          classificationEn: 'Alkaline / Sodic Soil (High pH)',
          classificationTa: 'கார / களர் மண் (அதிக pH)',
          recommendedActionEn: 'Apply agricultural gypsum @ 500 kg/acre with farmyard manure and green manuring (Daincha) to displace exchangeable sodium.',
          recommendedActionTa: 'களர் நிலத்தை சீர்திருத்த ஏக்கருக்கு 500 கிலோ ஜிப்சம் மற்றும் தக்கைப்பூண்டு பசுந்தாள் உரம் இடவும்.',
        };
      } else {
        return {
          parameter,
          value,
          unit: 'pH scale',
          status: 'optimal',
          classificationEn: 'Optimal Neutral pH (6.5 – 8.0)',
          classificationTa: 'ஏற்ற நடுநிலை pH (6.5 – 8.0)',
          recommendedActionEn: 'Ideal pH range for maximum crop nutrient availability. Maintain current organic matter management.',
          recommendedActionTa: 'அனைத்து பயிர்களுக்கும் ஏற்ற உகந்த pH நிலை. சத்துக்கள் எளிதில் பயிருக்குக் கிடைக்கும்.',
        };
      }

    case 'EC':
      if (value > 1.0) {
        return {
          parameter,
          value,
          unit: 'dS/m',
          status: 'saline',
          classificationEn: 'High Salinity (Hazardous to seedlings)',
          classificationTa: 'அதிக உவர்ப்புத் தன்மை (நாற்றுகளுக்கு நச்சு)',
          recommendedActionEn: 'Provide deep leaching irrigation with quality water and ensure drainage channels are cleared.',
          recommendedActionTa: 'வடிகால் வசதியை அமைத்து நல்ல பாசன நீரால் உப்பைக் கழுவி வெளியேற்றவும்.',
        };
      } else {
        return {
          parameter,
          value,
          unit: 'dS/m',
          status: 'optimal',
          classificationEn: 'Non-Saline / Normal (EC < 1.0 dS/m)',
          classificationTa: 'சாதாரண உப்பு நிலை (EC < 1.0 dS/m)',
          recommendedActionEn: 'Safe electrical conductivity. Normal irrigation practice recommended.',
          recommendedActionTa: 'பாதுகாப்பான உவர்ப்பு நிலை. பயிர் வளர்ச்சிக்கு நன்று.',
        };
      }

    case 'OC':
      if (value < 0.5) {
        return {
          parameter,
          value,
          unit: '%',
          status: 'low',
          classificationEn: 'Low Organic Carbon (< 0.5%)',
          classificationTa: 'குறைந்த கரிம கார்பன் (< 0.5%)',
          recommendedActionEn: 'Apply 5 tonnes/acre well-decomposed Farmyard Manure (FYM) or 2 tonnes/acre Vermicompost + in-situ green manuring with Daincha/Sunnhemp.',
          recommendedActionTa: 'ஏக்கருக்கு 5 டன் மக்கிய தொழு உரம் அல்லது 2 டன் மண்புழு உரம் இட்டு பசுந்தாள் உரம் பயிரிடவும்.',
        };
      } else if (value <= 0.75) {
        return {
          parameter,
          value,
          unit: '%',
          status: 'optimal',
          classificationEn: 'Medium Organic Carbon (0.5 – 0.75%)',
          classificationTa: 'நடுத்தர கரிம கார்பன் (0.5 – 0.75%)',
          recommendedActionEn: 'Incorporate crop residues and maintain split organic additions annually.',
          recommendedActionTa: 'பயிர் கழிவுகளை மக்க வைத்து ஆண்டுதோறும் தொழு உரம் இடவும்.',
        };
      } else {
        return {
          parameter,
          value,
          unit: '%',
          status: 'high',
          classificationEn: 'High Organic Carbon (> 0.75%)',
          classificationTa: 'உயர் கரிம கார்பன் (> 0.75%)',
          recommendedActionEn: 'Excellent biological soil fertility with high moisture and nutrient retention.',
          recommendedActionTa: 'சிறந்த மண் வளம் மற்றும் நுண்ணுயிர் செயல்பாடு. தற்போதைய இயற்கை உர முறையைத் தொடரவும்.',
        };
      }

    case 'N':
      if (value < 113) {
        return {
          parameter,
          value,
          unit: 'kg/acre',
          status: 'low',
          classificationEn: 'Low Available Nitrogen (< 113 kg/acre or < 280 kg/ha)',
          classificationTa: 'குறைந்த தழைச்சத்து (< 113 கிலோ/ஏக்கர்)',
          recommendedActionEn: 'Increase recommended nitrogen dose by 25%. Apply in 3–4 splits (basal, tillering, panicle initiation).',
          recommendedActionTa: 'பரிந்துரைக்கப்பட்ட தழைச்சத்தை 25% அதிகரித்து 3 தவணைகளாகப் பிரித்து இடவும்.',
        };
      } else if (value <= 226) {
        return {
          parameter,
          value,
          unit: 'kg/acre',
          status: 'optimal',
          classificationEn: 'Medium Available Nitrogen (113 – 226 kg/acre)',
          classificationTa: 'நடுத்தர தழைச்சத்து (113 – 226 கிலோ/ஏக்கர்)',
          recommendedActionEn: 'Apply 100% of standard recommended nitrogen schedule according to crop variety.',
          recommendedActionTa: 'பயிருக்கு பரிந்துரைக்கப்பட்ட சமச்சீரான வழக்கமான தழைச்சத்து அளவை இடவும்.',
        };
      } else {
        return {
          parameter,
          value,
          unit: 'kg/acre',
          status: 'high',
          classificationEn: 'High Available Nitrogen (> 226 kg/acre)',
          classificationTa: 'அதிக தழைச்சத்து (> 226 கிலோ/ஏக்கர்)',
          recommendedActionEn: 'Reduce chemical nitrogen by 25% to prevent excessive vegetative growth, lodging, and pest attacks.',
          recommendedActionTa: 'பூச்சி மற்றும் பூஞ்சண தாக்குதலைத் தவிர்க்க யூரியா அளவை 25% குறைக்கவும்.',
        };
      }

    case 'P':
      if (value < 4.5) {
        return {
          parameter,
          value,
          unit: 'kg/acre',
          status: 'low',
          classificationEn: 'Low Available Phosphorus (< 4.5 kg/acre or < 11 kg/ha)',
          classificationTa: 'குறைந்த மணிச்சத்து (< 4.5 கிலோ/ஏக்கர்)',
          recommendedActionEn: 'Apply DAP or Single Super Phosphate (SSP) as basal dose; use Phosphobacteria biofertilizer @ 2 kg/acre.',
          recommendedActionTa: 'அடி உரமாக டி.ஏ.பி அல்லது சூப்பர் பாஸ்பேட் இடவும்; பாஸ்போபாக்டீரியா 2 கிலோ பயன்படுத்தவும்.',
        };
      } else if (value <= 9.0) {
        return {
          parameter,
          value,
          unit: 'kg/acre',
          status: 'optimal',
          classificationEn: 'Medium Available Phosphorus (4.5 – 9.0 kg/acre)',
          classificationTa: 'நடுத்தர மணிச்சத்து (4.5 – 9.0 கிலோ/ஏக்கர்)',
          recommendedActionEn: 'Apply normal recommended basal phosphorus dose.',
          recommendedActionTa: 'பயிருக்கு வழக்கமான அடி உர அளவை இடவும்.',
        };
      } else {
        return {
          parameter,
          value,
          unit: 'kg/acre',
          status: 'high',
          classificationEn: 'High Available Phosphorus (> 9.0 kg/acre)',
          classificationTa: 'அதிக மணிச்சத்து (> 9.0 கிலோ/ஏக்கர்)',
          recommendedActionEn: 'Reduce phosphorus fertilizers; rely on soil reserves to avoid zinc deficiency.',
          recommendedActionTa: 'மணிச்சத்து உரங்களைக் குறைக்கவும்; துத்தநாகப் பற்றாக்குறை ஏற்படாமல் கண்காணிக்கவும்.',
        };
      }

    case 'K':
      if (value < 48) {
        return {
          parameter,
          value,
          unit: 'kg/acre',
          status: 'low',
          classificationEn: 'Low Available Potassium (< 48 kg/acre or < 118 kg/ha)',
          classificationTa: 'குறைந்த சாம்பல் சத்து (< 48 கிலோ/ஏக்கர்)',
          recommendedActionEn: 'Apply Muriate of Potash (MOP) in split doses to improve pest resistance and grain weight.',
          recommendedActionTa: 'பயிர் எதிர்ப்புத் திறனுக்கும் மணி எடைக்கும் பொட்டாஷ் உரத்தை பிரித்து இடவும்.',
        };
      } else if (value <= 113) {
        return {
          parameter,
          value,
          unit: 'kg/acre',
          status: 'optimal',
          classificationEn: 'Medium Available Potassium (48 – 113 kg/acre)',
          classificationTa: 'நடுத்தர சாம்பல் சத்து (48 – 113 கிலோ/ஏக்கர்)',
          recommendedActionEn: 'Apply standard MOP schedule at basal and panicle emergence stage.',
          recommendedActionTa: 'பரிந்துரைக்கப்பட்ட பொட்டாஷ் அளவை அடி உரம் மற்றும் கதிர் வரும் தருணத்தில் இடவும்.',
        };
      } else {
        return {
          parameter,
          value,
          unit: 'kg/acre',
          status: 'high',
          classificationEn: 'High Available Potassium (> 113 kg/acre)',
          classificationTa: 'அதிக சாம்பல் சத்து (> 113 கிலோ/ஏக்கர்)',
          recommendedActionEn: 'Adequate potassium reserve in soil; maintenance dose sufficient.',
          recommendedActionTa: 'மண்ணில் போதுமான சாம்பல் சத்து உள்ளது. குறைந்த அளவு போதுமானது.',
        };
      }

    case 'Zn':
      if (value < 0.8) {
        return {
          parameter,
          value,
          unit: 'ppm',
          status: 'low',
          classificationEn: 'Deficient Zinc (< 0.8 ppm DTPA)',
          classificationTa: 'துத்தநாக பற்றாக்குறை (< 0.8 ppm)',
          recommendedActionEn: 'Apply Zinc Sulphate @ 10 kg/acre as soil application (do not mix directly with DAP).',
          recommendedActionTa: 'ஏக்கருக்கு 10 கிலோ ஜிங்க் சல்பேட் இடவும் (டி.ஏ.பி-யுடன் நேரடியாக கலக்கக் கூடாது).',
        };
      } else {
        return {
          parameter,
          value,
          unit: 'ppm',
          status: 'optimal',
          classificationEn: 'Sufficient Zinc (≥ 0.8 ppm DTPA)',
          classificationTa: 'போதுமான துத்தநாக சத்து (≥ 0.8 ppm)',
          recommendedActionEn: 'Zinc level is adequate for healthy crop enzymatic function.',
          recommendedActionTa: 'துத்தநாக சத்து போதுமான அளவில் உள்ளது.',
        };
      }

    case 'Fe':
      if (value < 4.5) {
        return {
          parameter,
          value,
          unit: 'ppm',
          status: 'low',
          classificationEn: 'Deficient Iron (< 4.5 ppm DTPA)',
          classificationTa: 'இரும்பு சத்து பற்றாக்குறை (< 4.5 ppm)',
          recommendedActionEn: 'Apply Ferrous Sulphate @ 10 kg/acre + foliar spray of 0.5% FeSO4 + 0.1% citric acid during active tillering.',
          recommendedActionTa: 'ஏக்கருக்கு 10 கிலோ அன்னபேதி இடவும் அல்லது 0.5% இலைவழி தெளிப்பு செய்யவும்.',
        };
      } else {
        return {
          parameter,
          value,
          unit: 'ppm',
          status: 'optimal',
          classificationEn: 'Sufficient Iron (≥ 4.5 ppm DTPA)',
          classificationTa: 'போதுமான இரும்பு சத்து (≥ 4.5 ppm)',
          recommendedActionEn: 'Adequate iron available for chlorophyll synthesis.',
          recommendedActionTa: 'இரும்பு சத்து போதுமான அளவில் உள்ளது.',
        };
      }

    case 'S':
      if (value < 10) {
        return {
          parameter,
          value,
          unit: 'ppm',
          status: 'low',
          classificationEn: 'Deficient Sulphur (< 10 ppm)',
          classificationTa: 'கந்தக பற்றாக்குறை (< 10 ppm)',
          recommendedActionEn: 'Apply Gypsum @ 100 kg/acre or Single Super Phosphate to boost oilseed/pulse yield.',
          recommendedActionTa: 'எண்ணெய்வித்து பயிர்களுக்கு ஏக்கருக்கு 100 கிலோ ஜிப்சம் இடவும்.',
        };
      } else {
        return {
          parameter,
          value,
          unit: 'ppm',
          status: 'optimal',
          classificationEn: 'Sufficient Sulphur (≥ 10 ppm)',
          classificationTa: 'போதுமான கந்தக சத்து (≥ 10 ppm)',
          recommendedActionEn: 'Adequate soil sulphur.',
          recommendedActionTa: 'போதுமான கந்தக சத்து உள்ளது.',
        };
      }
  }
}
