export type Severity = 'Low' | 'Medium' | 'High';

export interface Source {
  id: string;
  title: string;
  publisher: string;
  year: number;
  kind: 'Government advisory' | 'Research paper' | 'Extension guide' | 'Field manual';
  language: 'English' | 'Tamil' | 'English & Tamil';
  reliability: 'Verified' | 'Peer reviewed';
  topics: string[];
  summary: string;
  excerpts: Excerpt[];
}

export interface Excerpt {
  section: string;
  text: string;
  relevance: 'high' | 'medium';
}

export interface Disease {
  id: string;
  name: string;
  nameTa?: string;
  cropId: string;
  cropName: string;
  scientificName?: string;
  type: 'Disease' | 'Pest' | 'Fungus';
  severity: Severity;
  symptoms: string[];
  symptomsTa?: string[];
  causes?: string[];
  causesTa?: string[];
  organicTreatment?: string[];
  chemicalTreatment?: string[];
  chemicalControl?: string[];
  chemicalControlTa?: string[];
  biologicalControl?: string[];
  biologicalControlTa?: string[];
  preventiveMeasures?: string[];
  preventiveMeasuresTa?: string[];
  prevention?: string[];
  sourceIds?: string[];
  image?: string;
  confidence?: number;
}

export interface Crop {
  id: string;
  name: string;
  nameTa: string;
  season: 'Kharif' | 'Rabi';
  durationDays: number;
  waterNeed: 'Low' | 'Medium' | 'High';
  yieldQuintalPerAcre: number;
  pricePerQuintal: number;
  costPerAcre: number;
  risk: Severity;
  bestFor: string;
}

export interface SoilNutrient {
  key: 'nitrogen' | 'phosphorus' | 'potassium' | 'organicCarbon';
  label: string;
  value: number;
  unit: string;
  low: number;
  high: number;
  max: number;
}

export interface SoilSample {
  id: string;
  label: string;
  location: string;
  crop: string;
  pH: number;
  nutrients: SoilNutrient[];
  plan: { stage: string; product: string; dose: string; timing: string }[];
  isCustom?: boolean;
}

import type { RagExecutionTrace } from '@/services/rag/advancedRagEngine';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  sourceIds?: string[];
  isLiveBackend?: boolean;
  provider?: string;
  confidence?: number;
  timestamp?: number;
  ragTrace?: RagExecutionTrace;
  suggestedFollowUps?: { en: string; ta: string }[];
  documentContext?: AnalyzedDocument;
  imageUrl?: string;
}

export type AgriDocumentCategory =
  | 'seed_certificate'
  | 'seed_bill'
  | 'purchase_invoice'
  | 'fertilizer_bill'
  | 'fertilizer_label'
  | 'mandi_receipt'
  | 'soil_health_card'
  | 'water_quality_report'
  | 'pesticide_bill'
  | 'pesticide_label'
  | 'nursery_bill'
  | 'insurance_policy'
  | 'crop_insurance_doc'
  | 'government_scheme_doc'
  | 'farm_expense_record'
  | 'research_paper'
  | 'general_agri_doc';

export type DocumentQaMode =
  | 'mode_a_document_only'
  | 'mode_b_document_plus_knowledge'
  | 'mode_c_general_agri';

export interface DocumentExtractedField {
  key: string;
  labelEn: string;
  labelTa: string;
  originalValue: string;
  normalizedValue?: number | string;
  unit?: string;
  pageNumber?: number;
  section?: string;
  confidence: number;
  exactSupportingText?: string;
  benchmarkStatus?: 'optimal' | 'low' | 'high' | 'warning' | 'info';
}

export interface DocumentTable {
  title?: string;
  headers: string[];
  rows: string[][];
  pageNumber?: number;
}

export interface DocumentSoilParameters {
  pH?: number;
  ec?: number; // dS/m
  organicCarbon?: number; // %
  availableN?: number; // kg/acre or kg/ha
  availableP?: number; // kg/acre or kg/ha
  availableK?: number; // kg/acre or kg/ha
  zinc?: number; // ppm
  iron?: number; // ppm
  sulphur?: number; // ppm
  copper?: number;
  manganese?: number;
  boron?: number;
  soilType?: string;
}

export interface DocumentFertilizerParameters {
  brandName?: string;
  fertilizerType?: string;
  grade?: string;
  bagWeightKg?: number;
  batchNumber?: string;
  nitrogenWeightKg?: number;
  phosphorusWeightKg?: number;
  potassiumWeightKg?: number;
  mrp?: string;
  subsidyAmount?: string;
}

export interface DocumentPesticideParameters {
  productName?: string;
  activeIngredient?: string;
  concentration?: string;
  cibrcRegNumber?: string;
  targetPests?: string[];
  targetCrops?: string[];
  recommendedDosage?: string;
  waitingPeriodDays?: number;
  toxicityClassification?: string;
  antidote?: string;
  bannedStatus?: 'approved' | 'restricted' | 'banned';
}

export interface DocumentSeedParameters {
  crop?: string;
  variety?: string;
  seedClass?: 'Breeder' | 'Foundation' | 'Certified' | 'Truthfully Labelled' | string;
  lotNumber?: string;
  tagNumber?: string;
  germinationPercent?: number;
  physicalPurityPercent?: number;
  geneticPurityPercent?: number;
  inertMatterPercent?: number;
  moisturePercent?: number;
  weedSeedsPercent?: number;
  testingDate?: string;
  validUpto?: string;
  treatedWithFungicide?: string;
}

export interface DocumentKeyFinding {
  labelEn: string;
  labelTa: string;
  value: string;
  status?: 'verified' | 'warning' | 'info';
  pageNumber?: number;
  confidence?: number;
  exactQuote?: string;
}

export interface AnalyzedDocument {
  id: string;
  fileName: string;
  fileType: 'pdf' | 'image' | 'text';
  category: AgriDocumentCategory;
  categoryLabelEn: string;
  categoryLabelTa: string;
  crop?: string;
  variety?: string;
  lotOrBatchNumber?: string;
  issuerOrDealer?: string;
  testingDate?: string;
  expiryDate?: string;
  germinationPercent?: string;
  purityPercent?: string;
  moisturePercent?: string;
  chemicalTreatment?: string;
  quantity?: string;
  pricePaid?: string;
  subsidyDetail?: string;
  summaryEn: string;
  summaryTa: string;
  summary?: { en?: string; ta?: string };
  actionableAdvice?: { en?: string[]; ta?: string[] };
  actionableGuidanceEn?: string;
  actionableGuidanceTa?: string;
  lotNumber?: string;
  fileSize?: number;
  rawText: string;
  suggestedQuestions: { en: string; ta: string }[];
  keyFindings: DocumentKeyFinding[];
  analyzedAt: string;
  // Enhanced dynamic parameters
  extractedFields?: DocumentExtractedField[];
  tables?: DocumentTable[];
  soilParameters?: DocumentSoilParameters;
  fertilizerParameters?: DocumentFertilizerParameters;
  pesticideParameters?: DocumentPesticideParameters;
  seedParameters?: DocumentSeedParameters;
  warnings?: string[];
  isUnreadable?: boolean;
  unreadableNotice?: string;
}

export interface CannedAnswer {
  keywords: string[];
  en: string;
  ta: string;
  sourceIds: string[];
}

export interface Retrieval {
  sourceId: string;
  score: number;
}

export interface FarmerProfile {
  name: string;
  village: string;
  district: string;
  state: string;
  phone: string;
  acres: number;
  soilType: 'Alluvial Clay' | 'Red Sandy Loam' | 'Black Cotton' | 'Laterite' | 'Coastal Sand';
  irrigationSource: 'Canal' | 'Borewell' | 'Open Well' | 'Rainfed' | 'Drip Irrigation';
  cropIds: string[];
}

export interface FarmerPreferences {
  weatherAlerts: boolean;
  diseaseAlerts: boolean;
  priceAlerts: boolean;
  voiceAutoRead: boolean;
  offlineMode: boolean;
}

export interface FarmTask {
  id: string;
  title: string;
  titleTa?: string;
  when: string;
  done: boolean;
  crop?: string;
  priority?: 'High' | 'Medium' | 'Low';
}

export interface AiAnswerResult {
  text: string;
  sourceIds: string[];
  isLiveBackend: boolean;
  provider: 'Live AI Model' | 'Verified Agricultural Corpus' | string;
  confidence: number;
  ragTrace?: RagExecutionTrace;
  suggestedFollowUps?: { en: string; ta: string }[];
  isError?: boolean;
  retryable?: boolean;
}

export interface MarketPriceItem {
  crop: string;
  cropTa: string;
  mandi: string;
  price: number;
  change: number;
  unit: string;
  updatedAt: string;
}

export interface AgriWeather {
  location: string;
  tempC: number;
  humidity: number;
  windKmh: number;
  rainChance: number;
  condition: string;
  conditionTa: string;
  farmingAdvice: string;
  farmingAdviceTa: string;
}
