// AGRIKNOW AI — Comprehensive Farmer Robot Guide Knowledge Base
// Detailed, friendly, agricultural explanations in English and Tamil.

export interface GuideContent {
  id: string;
  titleEn: string;
  titleTa: string;
  categoryEn: string;
  categoryTa: string;
  whatItDoesEn: string;
  whatItDoesTa: string;
  whyUsefulEn: string;
  whyUsefulTa: string;
  howToUseEn: string;
  howToUseTa: string;
}

export const farmerGuideDictionary: Record<string, GuideContent> = {
  // Navigation Items
  'nav-dashboard': {
    id: 'nav-dashboard',
    titleEn: 'Farm Dashboard',
    titleTa: 'பண்ணை முதன்மைப் பக்கம் (Dashboard)',
    categoryEn: 'Navigation',
    categoryTa: 'வழிகாட்டி',
    whatItDoesEn: 'Gives an instant bird’s-eye view of your farm health score, local weather, live Mandi market prices, and seasonal crop advisories.',
    whatItDoesTa: 'உங்கள் பண்ணையின் ஒட்டுமொத்த ஆரோக்கியம், நேரடி வானிலை முன்னறிவிப்பு, உள்ளூர் தானிய கொள்முதல் விலைகள் மற்றும் அவசர பூச்சி எச்சரிக்கைகளை ஒரே பார்வையில் காட்டுகிறது.',
    whyUsefulEn: 'Helps you make fast daily decisions on irrigation, spraying, harvesting, and grain selling based on real-time delta weather.',
    whyUsefulTa: 'வானிலை மற்றும் சந்தை நிலவரத்தை முன்கூட்டியே அறிந்து, இன்று நீர் பாய்ச்சலாமா அல்லது உரம் தெளிக்கலாமா என்பதை துல்லியமாக முடிவு செய்ய உதவுகிறது.',
    howToUseEn: 'Click to return to the main overview. Check your Farm Health progress ring and tap any alert for immediate steps.',
    howToUseTa: 'எப்போது வேண்டுமானாலும் முதன்மைப் பக்கத்திற்குத் திரும்ப இதை கிளிக் செய்யவும். வண்ண எச்சரிக்கைகளைத் தட்டி உடனடி வழிகாட்டுதலைப் பெறலாம்.',
  },
  'nav-assistant': {
    id: 'nav-assistant',
    titleEn: 'Ask AgriKnow AI Assistant',
    titleTa: 'அக்ரினோ AI உதவியாளர் (Ask AI)',
    categoryEn: 'AI Intelligence',
    categoryTa: 'செயற்கை நுண்ணறிவு',
    whatItDoesEn: 'A conversational agricultural intelligence assistant powered by Google Gemini that answers any farming doubt, calculation, or crop symptom query.',
    whatItDoesTa: 'வேளாண்மை, உரம் கணக்கீடு, பயிர் பூச்சிகள், சந்தை விலைகள் மற்றும் அரசு திட்டங்கள் குறித்து எந்த கேள்விக்கும் தமிழில் பதிலளிக்கும் AI வழிகாட்டி.',
    whyUsefulEn: 'Get 24/7 expert agricultural guidance verified against TNAU and ICAR standards without waiting for an extension officer visit.',
    whyUsefulTa: 'வேளாண் அலுவலரின் வருகைக்காகக் காத்திருக்காமல், தமிழ்நாடு வேளாண் பல்கலைக்கழகத் தரவுகளுடன் கூடிய துல்லியமான தீர்வை எந்த நேரத்திலும் பெறலாம்.',
    howToUseEn: 'Type your question, click the microphone to speak in Tamil, or attach a leaf photo/soil document to get instant advice.',
    howToUseTa: 'உங்கள் கேள்வியைத் தட்டச்சு செய்யவும், அல்லது மைக் பொத்தானை அழுத்தி நேரடியாகப் பேசவும்; புகைப்படங்களையும் இணைக்கலாம்.',
  },
  'nav-diseases': {
    id: 'nav-diseases',
    titleEn: 'Crop Health & Disease Doctor',
    titleTa: 'பயிர் மருத்துவர் (Crop Health & Doctor)',
    categoryEn: 'Plant Pathology',
    categoryTa: 'பயிர் பாதுகாப்பு',
    whatItDoesEn: 'Diagnoses leaf spots, blights, stem borers, and pests by analyzing your uploaded photos with multimodal computer vision.',
    whatItDoesTa: 'பாதிக்கப்பட்ட இலை அல்லது பயிரின் புகைப்படத்தை ஆய்வு செய்து, நோய் அல்லது பூச்சியைக் கண்டறிந்து சிகிச்சை முறைகளை வழங்குகிறது.',
    whyUsefulEn: 'Catches crop infections in early vegetative stages before yield loss occurs, giving exact certified chemical doses and bio-controls.',
    whyUsefulTa: 'பயிர் கருகல் அல்லது பூச்சி தாக்குதலை ஆரம்பத்திலேயே கண்டறிந்து, மகசூல் இழப்பைத் தடுத்து, சரியான மருந்து அளவுகளைத் தருகிறது.',
    howToUseEn: 'Select your crop, snap a clear leaf photo in daylight, enter optional symptoms, and click "Run Differential Diagnosis".',
    howToUseTa: 'பயிரைத் தேர்ந்தெடுத்து, நல்ல வெளிச்சத்தில் எடுத்த இலை புகைப்படத்தைப் பதிவேற்றி "அறிகுறிகளை ஆய்வு செய்" என்பதை கிளிக் செய்யவும்.',
  },
  'nav-soil': {
    id: 'nav-soil',
    titleEn: 'Soil & Fertilizer Advisor',
    titleTa: 'மண் & உர வழிகாட்டி (Soil & Fertilizer)',
    categoryEn: 'Nutrient Management',
    categoryTa: 'மண் மேலாண்மை',
    whatItDoesEn: 'Calculates custom stage-by-stage fertilizer application plans (Basal, Tillering, Panicle) based on soil NPK levels and target crop.',
    whatItDoesTa: 'உங்கள் மண் பரிசோதனை அளவுகளைக் கொண்டு, அடி உரம், முதல் மேலுரம், இரண்டாம் மேலுரம் என குறிப்பிட்ட பயிருக்கான உர அட்டவணையை உருவாக்குகிறது.',
    whyUsefulEn: 'Prevents wasteful over-application of Urea and DAP, cuts fertilizer input costs by up to 25%, and prevents soil acidification.',
    whyUsefulTa: 'அளவுக்கு அதிகமாக யூரியா அல்லது டிஏபி இடுவதைத் தவிர்த்து, உரச் செலவை 25% வரை குறைத்து மண்ணின் வளத்தைப் பாதுகாக்கிறது.',
    howToUseEn: 'Upload your Soil Health Card or move the Nitrogen, Phosphorus, Potassium sliders, then click "Generate Schedule".',
    howToUseTa: 'மண் பரிசோதனை அட்டையைப் பதிவேற்றவும் அல்லது NPK அளவுகளை சரிசெய்து "உர அட்டவணை உருவாக்கு" என்பதை அழுத்தவும்.',
  },
  'nav-crops': {
    id: 'nav-crops',
    titleEn: 'Crop Choice & Profit Planner',
    titleTa: 'பயிர் தேர்வு & லாபத் திட்டம் (Crop Advisor)',
    categoryEn: 'Farm Economics',
    categoryTa: 'பண்ணை பொருளாதாரம்',
    whatItDoesEn: 'Compares expected crop yield, cultivation costs, duration days, water demands, and net profit per acre for your region.',
    whatItDoesTa: 'பல்வேறு பயிர்களின் ஒரு ஏக்கர் சாகுபடி செலவு, சராசரி மகசூல், தண்ணீர் தேவை மற்றும் நிகர லாபத்தை ஒப்பிட்டுப் பார்க்க உதவுகிறது.',
    whyUsefulEn: 'Helps you diversify from water-heavy paddy to high-value pulses, groundnut, or cotton when canal water is limited.',
    whyUsefulTa: 'பாசன நீர் பற்றாக்குறை உள்ள காலங்களில் நெல்லுக்கு மாற்றாக நிலக்கடலை, பருத்தி அல்லது பயறு வகைகளைப் பயிரிட வழிகாட்டுகிறது.',
    howToUseEn: 'Filter by season (Kharif/Rabi), examine duration and water needs, and review estimated net return per acre.',
    howToUseTa: 'பருவக்காலத்தைத் தேர்வு செய்து, ஒவ்வொரு பயிரின் லாப கணக்கீட்டையும் ஒப்பிட்டுப் பார்த்து சிறந்த பயிரைத் தேர்ந்தெடுக்கவும்.',
  },
  'nav-library': {
    id: 'nav-library',
    titleEn: 'Verified Knowledge Library',
    titleTa: 'வேளாண் களஞ்சியம் & அரசு திட்டங்கள் (Knowledge)',
    categoryEn: 'University Corpus',
    categoryTa: 'பல்கலைக்கழக ஆவணங்கள்',
    whatItDoesEn: 'A searchable repository of verified agronomic extension manuals from TNAU, ICAR, IRRI, and government subsidy schemes.',
    whatItDoesTa: 'தமிழ்நாடு வேளாண் பல்கலைக்கழகம், ICAR மற்றும் அரசு திட்டங்கள் குறித்த முழுமையான கையேடுகள் அடங்கிய தேடல் களஞ்சியம்.',
    whyUsefulEn: 'Provides authentic, non-hallucinated farming guides with published authors, bulletin dates, and institutional citations.',
    whyUsefulTa: 'போலி அல்லது தவறான வதந்திகளைத் தவிர்த்து, உண்மையான அரசு மற்றும் பல்கலைக்கழக ஆராய்ச்சி ஆதாரங்களை நேரடியாகப் படிக்கலாம்.',
    howToUseEn: 'Type a keyword like "SRI paddy" or "Tikka disease", or filter by category to read and download certified advice.',
    howToUseTa: 'தேடல் பெட்டியில் "செம்மை நெல்" அல்லது "மானியம்" என தட்டச்சு செய்து தேவையான கையேடுகளைப் படிக்கலாம்.',
  },
  'nav-ingestion': {
    id: 'nav-ingestion',
    titleEn: 'Ingestion Pipeline & Vector Admin',
    titleTa: 'ஆவணப் பதிவேற்றம் (Ingestion Pipeline)',
    categoryEn: 'System Admin',
    categoryTa: 'கணினி நிர்வாகம்',
    whatItDoesEn: 'Processes uploaded agricultural PDF manuals, splits them into semantic chunks, and generates 768-D semantic vector embeddings.',
    whatItDoesTa: 'புதிய வேளாண் நூல்கள் மற்றும் பிடிஎப் (PDF) ஆவணங்களை உட்பொதித்து, AI பதில்களுக்கான தரவுத்தளத்தை விரிவாக்குகிறது.',
    whyUsefulEn: 'Keeps your AI assistant updated with the latest university advisories, newly approved pesticide molecules, and government circulars.',
    whyUsefulTa: 'சமீபத்திய அரசு அரசாணைகள் மற்றும் புதிய பூச்சிக்கொல்லி விவரங்களை AI-இல் உடனுக்குடன் இணைக்க உதவுகிறது.',
    howToUseEn: 'Upload a PDF manual, inspect the extracted text chunks and token distribution, and click "Re-Embed Corpus".',
    howToUseTa: 'பிடிஎப் ஆவணத்தைப் பதிவேற்றி, துண்டுகளைப் பார்வையிட்டு, வெக்டர் உட்பொதிவை இயக்கவும்.',
  },
  'nav-sources': {
    id: 'nav-sources',
    titleEn: 'Evidence & Institutional Sources',
    titleTa: 'ஆதாரங்கள் & மேற்கோள்கள் (Evidence Explorer)',
    categoryEn: 'Verification',
    categoryTa: 'சான்றளிப்பு',
    whatItDoesEn: 'Displays the exact bibliographic source records and page excerpts that justify every diagnosis and recommendation.',
    whatItDoesTa: 'AI வழங்கும் ஒவ்வொரு பரிந்துரைக்கும் பின்னணியில் உள்ள ஆராய்ச்சி ஏடுகள் மற்றும் ஆதாரப் பக்கங்களை நேரடியாகக் காட்டுகிறது.',
    whyUsefulEn: 'Ensures absolute scientific accountability and safety, proving every chemical dose is approved by CIBRC and TNAU.',
    whyUsefulTa: 'பரிந்துரைக்கப்படும் மருந்துகள் அங்கீகரிக்கப்பட்டவை என்பதை உறுதிசெய்து, பயிர் பாதுகாப்பில் முழு நம்பிக்கையை அளிக்கிறது.',
    howToUseEn: 'Browse source titles, view publishing years, and click on citations to inspect underlying research excerpts.',
    howToUseTa: 'ஆதார தலைப்புகளை கிளிக் செய்து, தொடர்புடைய பல்கலைக்கழக ஆராய்ச்சி குறிப்புகளைப் படிக்கவும்.',
  },
  'nav-settings': {
    id: 'nav-settings',
    titleEn: 'Farm Profile & Preferences',
    titleTa: 'பண்ணை விவரக்குறிப்பு & அமைப்புகள் (Settings)',
    categoryEn: 'Personalization',
    categoryTa: 'தனிப்பயனாக்கம்',
    whatItDoesEn: 'Configures your local farm parameters including acreage, soil type, irrigation source (Canal/Borewell), and preferred language.',
    whatItDoesTa: 'உங்கள் நிலத்தின் பரப்பு, மண் வகை, பாசன முறை மற்றும் மொழி விருப்பங்களை சேமித்து வைக்கிறது.',
    whyUsefulEn: 'Tailors all AI calculations, fertilizer doses, and water advisories to the exact ground realities of your land.',
    whyUsefulTa: 'உங்கள் வயலின் உண்மையான அளவுக்கு ஏற்ப உர அளவுகளையும் பாசனத் தேவைகளையும் துல்லியமாக மாற்றியமைக்கிறது.',
    howToUseEn: 'Fill in your farm details and save. The AI assistant will automatically use these settings in all subsequent chats.',
    howToUseTa: 'உங்கள் பண்ணை விவரங்களை உள்ளிட்டு சேமிக்கவும்; AI பதில்கள் தானாகவே உங்கள் நிலத்திற்கேற்ப அமையும்.',
  },

  // TopBar & Global Controls
  'top-guide-toggle': {
    id: 'top-guide-toggle',
    titleEn: 'Farmer Robot Guide Switch',
    titleTa: 'உழவன் பாட் வழிகாட்டி சுவிட்ச் (Guide ON/OFF)',
    categoryEn: 'Companion Control',
    categoryTa: 'உதவியாளர் கட்டுப்பாடு',
    whatItDoesEn: 'Turns this cute agricultural robot companion ON or OFF across the entire web application.',
    whatItDoesTa: 'இந்த உழவன் ரோபோ வழிகாட்டியை முழு பயன்பாட்டிலும் இயக்கவோ அல்லது அணைக்கவோ பயன்படுகிறது.',
    whyUsefulEn: 'Keep it ON while learning new features; turn it OFF when you want a completely clean, unobstructed screen.',
    whyUsefulTa: 'புதிய அம்சங்களைக் கற்றுக்கொள்ளும்போது ஆன் செய்து வைத்துக்கொள்ளலாம்; முழு திரை தேவைப்படும்போது ஆஃப் செய்துகொள்ளலாம்.',
    howToUseEn: 'Click this button anytime or press the "G" key on your keyboard to instantly toggle the guide.',
    howToUseTa: 'சுட்டியை வைத்து கிளிக் செய்யவும் அல்லது உங்கள் கீபோர்டில் "G" விசையை அழுத்தி உடனடியாக ஆன்/ஆஃப் செய்யலாம்.',
  },
  'top-language': {
    id: 'top-language',
    titleEn: 'Bilingual Language Switcher',
    titleTa: 'இருமொழி மாற்றி (English / தமிழ்)',
    categoryEn: 'Localization',
    categoryTa: 'மொழித் தேர்வு',
    whatItDoesEn: 'Instantly switches the entire user interface and AI diagnostic models between English and fluent Tamil.',
    whatItDoesTa: 'முழு இணையதளம் மற்றும் AI உரையாடல்களை ஆங்கிலம் மற்றும் தூய தமிழிற்கு இடையில் உடனடியாக மாற்றுகிறது.',
    whyUsefulEn: 'Allows farmers and family members to read comfortably in Tamil with technical chemical names preserved in parentheses.',
    whyUsefulTa: 'விவசாயிகள் தாய்மொழியான தமிழில் சுலபமாகப் படித்து புரிந்து கொள்ளவும், மருந்து பெயர்களை ஆங்கிலத்தில் அறியவும் உதவுகிறது.',
    howToUseEn: 'Click "தமிழ்" to switch everything to Tamil, or "English" to revert back. No page reload required.',
    howToUseTa: 'தமிழுக்கு மாற "தமிழ்" என்பதையும், ஆங்கிலத்திற்கு மாற "English" என்பதையும் கிளிக் செய்யவும்.',
  },
  'top-status-online': {
    id: 'top-status-online',
    titleEn: 'AgriKnow AI Live Connectivity',
    titleTa: 'நேரடி AI இணைப்பு நிலை (AgriKnow Online)',
    categoryEn: 'System Status',
    categoryTa: 'இயக்க நிலை',
    whatItDoesEn: 'Verifies real-time connectivity to Google Gemini multimodal AI reasoning models and university databases.',
    whatItDoesTa: 'கூகுள் ஜெமினி (Gemini) செயற்கை நுண்ணறிவு சேவையகத்துடன் நேரடி இணைப்பில் இருப்பதைக் குறிக்கிறது.',
    whyUsefulEn: 'Assures you that all pest diagnoses, market prices, and answers are being processed dynamically by live AI.',
    whyUsefulTa: 'பயிர் நோய்கள் மற்றும் பதில்கள் சேமிக்கப்பட்ட பழையவை அல்லாமல், நேரடி AI மூலம் துல்லியமாக ஆய்வு செய்யப்படுவதை உறுதிசெய்கிறது.',
    howToUseEn: 'Green sparkles badge indicates full live AI connectivity. Hover to inspect connection status.',
    howToUseTa: 'பச்சை நிறத்தில் ஒளிரும் போது இணையம் மற்றும் AI முழு செயல்பாட்டில் உள்ளது என்று பொருள்.',
  },
  'top-health': {
    id: 'top-health',
    titleEn: 'System Health Diagnostics',
    titleTa: 'கணினி நிலை & நம்பகத்தன்மை (Health)',
    categoryEn: 'Telemetry',
    categoryTa: 'கணினி ஆய்வு',
    whatItDoesEn: 'Displays live latency (ms), token consumption counters, and database telemetry.',
    whatItDoesTa: 'சேவையகத்தின் பதில் வேகம் (மில்லி விநாடிகள்), டோக்கன் பயன்பாடு மற்றும் இயக்க நிலையை காட்டுகிறது.',
    whyUsefulEn: 'Provides total transparency into backend response times and model availability.',
    whyUsefulTa: 'கணினியின் வேகம் மற்றும் நம்பகத்தன்மையை விவசாயிகளும் தொழில்நுட்பக் குழுவும் வெளிப்படையாக அறியலாம்.',
    howToUseEn: 'Click the heartbeat icon to view system health scores and connection latency meters.',
    howToUseTa: 'துடிப்பு ஐகானை கிளிக் செய்து கணினி வேகத்தை உடனுக்குடன் தெரிந்துகொள்ளலாம்.',
  },
  'top-alerts': {
    id: 'top-alerts',
    titleEn: 'Emergency Agricultural Alerts',
    titleTa: 'அவசர வேளாண் எச்சரிக்கைகள் (Alerts)',
    categoryEn: 'Scouting Alerts',
    categoryTa: 'கள எச்சரிக்கை',
    whatItDoesEn: 'Notifies you of active seasonal pest outbreaks (like Brown Planthopper) and incoming thundershowers in your district.',
    whatItDoesTa: 'உங்கள் மாவட்டத்தில் புகையான் பூச்சி தாக்குதல் அபாயம் அல்லது திடீர் மழை வாய்ப்பு குறித்த எச்சரிக்கைகளை வழங்குகிறது.',
    whyUsefulEn: 'Prevents washing away expensive fertilizers or chemical sprays by warning you of rain 24 hours in advance.',
    whyUsefulTa: 'மழை பெய்வதற்கு முன் உரம் அல்லது மருந்து தெளித்து வீணாவதைத் தடுத்து, உரிய நேரத்தில் பயிரைப் பாதுகாக்க உதவுகிறது.',
    howToUseEn: 'Click the bell icon to open notifications, read the warning, and click the link for action steps.',
    howToUseTa: 'மணி ஐகானை கிளிக் செய்து எச்சரிக்கை விவரங்களைப் படித்து, அதற்கான தடுப்பு நடவடிக்கைகளைப் பின்பற்றவும்.',
  },

  // Ask AI Controls
  'ask-input': {
    id: 'ask-input',
    titleEn: 'Question Input Bar',
    titleTa: 'கேள்வி தட்டச்சுப் பெட்டி (Ask Question)',
    categoryEn: 'Chat Interaction',
    categoryTa: 'உரையாடல்',
    whatItDoesEn: 'The primary text box where you can ask any farming question in plain English, Tamil, or Tanglish.',
    whatItDoesTa: 'பயிர், பூச்சி, உரம் அல்லது சந்தை விலை குறித்த உங்கள் எந்த சந்தேகத்தையும் தட்டச்சு செய்யும் இடம்.',
    whyUsefulEn: 'Supports natural, conversational language without requiring formal technical terminology.',
    whyUsefulTa: 'தொழில்நுட்ப வார்த்தைகள் தேவையின்றி, நீங்கள் சாதாரணமாக பேசும் முறையிலேயே கேள்விகளைக் கேட்கலாம்.',
    howToUseEn: 'Type your question (e.g. "When should I apply urea to paddy?") and press Enter or the Send button.',
    howToUseTa: 'கேள்வியை எழுதி கீபோர்டில் Enter அழுத்தவும் அல்லது பச்சை நிற அம்பு பட்டனை கிளிக் செய்யவும்.',
  },
  'ask-mic': {
    id: 'ask-mic',
    titleEn: 'Voice Microphone Input',
    titleTa: 'குரல்வழி மைக்ரோஃபோன் (Voice Input)',
    categoryEn: 'Accessibility',
    categoryTa: 'குரல் வசதி',
    whatItDoesEn: 'Converts spoken voice in Tamil or English directly into text inside the chat box.',
    whatItDoesTa: 'நீங்கள் தமிழில் அல்லது ஆங்கிலத்தில் பேசுவதை உடனடியாகக் கேட்டு தட்டச்சாக மாற்றுகிறது.',
    whyUsefulEn: 'Ideal when working in the field with wet or soiled hands, eliminating the need to type on small keyboards.',
    whyUsefulTa: 'வயலில் வேலை செய்யும்போது கைகளில் மண் அல்லது ஈரம் இருந்தாலும், எளிதாகப் பேசி பதில் பெறலாம்.',
    howToUseEn: 'Click the green microphone, allow browser mic permission, speak clearly, and click stop to send.',
    howToUseTa: 'மைக் ஐகானை கிளிக் செய்து தெளிவாகப் பேசவும்; பேசி முடித்ததும் தானாகவே AI பதில் அளிக்கும்.',
  },
  'ask-camera': {
    id: 'ask-camera',
    titleEn: 'Camera & Image Attachment',
    titleTa: 'பயிர் புகைப்பட கேமரா (Camera Attachment)',
    categoryEn: 'Multimodal Vision',
    categoryTa: 'பட ஆய்வு',
    whatItDoesEn: 'Uploads a leaf or pest photo directly into the conversational chat for visual multimodal inspection.',
    whatItDoesTa: 'பாதிக்கப்பட்ட இலை அல்லது பூச்சியின் படத்தை உரையாடலில் இணைத்து நேரடி பார்வை ஆய்வு செய்ய வைக்கிறது.',
    whyUsefulEn: 'Enables quick second-opinion checks while having an ongoing conversation with AgriKnow AI.',
    whyUsefulTa: 'உரையாடிக்கொண்டே வயலின் நிலவரப் படங்களை அனுப்பி கூடுதல் விளக்கம் பெறலாம்.',
    howToUseEn: 'Click the camera icon, select a JPG/PNG file from your phone or laptop, and ask your question.',
    howToUseTa: 'கேமரா ஐகானைத் தட்டி படத்தைத் தேர்வு செய்து, அதனுடன் உங்கள் கேள்வியையும் சேர்த்து அனுப்பவும்.',
  },
  'ask-doc-analyzer': {
    id: 'ask-doc-analyzer',
    titleEn: 'Agricultural Document Analyzer',
    titleTa: 'ஆவணப் பகுப்பாய்வு (Analyze Document)',
    categoryEn: 'Document OCR',
    categoryTa: 'ஆவண ஆய்வு',
    whatItDoesEn: 'Extracts and verifies data from seed tags, soil test cards, pesticide bills, or mandi receipts using OCR and AI.',
    whatItDoesTa: 'விதை சான்றிதழ் அட்டை, மண் பரிசோதனை அறிக்கை அல்லது உர பில்களைப் படித்து முக்கியமான விவரங்களைப் பிரித்தெடுக்கிறது.',
    whyUsefulEn: 'Instantly calculates seed germination viability, identifies expired lots, and checks if government subsidies apply.',
    whyUsefulTa: 'விதையின் முளைப்புத்திறன் சரியாக உள்ளதா, காலாவதி தேதி கடந்துவிட்டதா மற்றும் மானிய விவரங்களை உடனே அறியலாம்.',
    howToUseEn: 'Click the cyan "Analyze Document" button, drag & drop a PDF or image, and view the structured summary.',
    howToUseTa: '"Analyze Document" பட்டனை கிளிக் செய்து, பிடிஎப் அல்லது ரசீது படத்தை பதிவேற்றி ஆய்வறிக்கையைக் காணவும்.',
  },
  'ask-send-btn': {
    id: 'ask-send-btn',
    titleEn: 'Send Query Button',
    titleTa: 'கேள்வி அனுப்புதல் (Send)',
    categoryEn: 'Action',
    categoryTa: 'செயல்',
    whatItDoesEn: 'Submits your question and any attached media to Google Gemini for real-time agronomic analysis.',
    whatItDoesTa: 'உங்கள் கேள்வியை AI சேவையகத்திற்கு அனுப்பி உடனடி பதிலைப் பெறுகிறது.',
    whyUsefulEn: 'Delivers prompt responses formatted with bullet points, chemical doses, and biological solutions.',
    whyUsefulTa: 'பயிர்க்கான மருந்து அளவுகள் மற்றும் இயற்கை தீர்வுகளுடன் கூடிய முழுமையான பதிலை விநாடிகளில் வழங்குகிறது.',
    howToUseEn: 'Click this upward arrow button or press Enter on your keyboard after typing your doubt.',
    howToUseTa: 'கேள்வியை உள்ளிட்ட பின் இந்த அம்பு குறி பட்டனை கிளிக் செய்யவும்.',
  },

  // Crop Doctor / Diseases Page Controls
  'crop-select': {
    id: 'crop-select',
    titleEn: 'Crop Selection Dropdown',
    titleTa: 'பயிர் தேர்வு பட்டியல் (Select Crop)',
    categoryEn: 'Crop Diagnostic',
    categoryTa: 'பயிர் மருத்துவர்',
    whatItDoesEn: 'Specifies which crop species is being inspected (Paddy, Groundnut, Cotton, Tomato, Chilli, Wheat, etc.).',
    whatItDoesTa: 'நீங்கள் ஆய்வு செய்யும் குறிப்பிட்ட பயிரை (நெல், நிலக்கடலை, பருத்தி, தக்காளி போன்றவை) தேர்வு செய்கிறது.',
    whyUsefulEn: 'Narrows the diagnostic search space, ensuring symptoms like "leaf spot" are accurately classified for that specific crop.',
    whyUsefulTa: 'ஒவ்வொரு பயிருக்கும் தனித்தனி நோய்கள் இருப்பதால், சரியான பயிரைத் தேர்ந்தெடுப்பது துல்லியமான சிகிச்சையை உறுதிசெய்கிறது.',
    howToUseEn: 'Select your crop from the dropdown. If your crop is not listed, choose "Auto-detect / Other".',
    howToUseTa: 'பட்டியலில் உங்கள் பயிரைத் தேர்ந்தெடுக்கவும்; பட்டியலில் இல்லையெனில் "தானாகக் கண்டறி" என்பதைத் தேர்வு செய்யவும்.',
  },
  'symptom-input': {
    id: 'symptom-input',
    titleEn: 'Observed Symptoms & Field Signs',
    titleTa: 'கண்டறிந்த கள அறிகுறிகள் (Observed Symptoms)',
    categoryEn: 'Clinical Input',
    categoryTa: 'கள அறிகுறிகள்',
    whatItDoesEn: 'Accepts your direct observations from the field (e.g. spindle lesions, dead heart, collar rot, leaf curling).',
    whatItDoesTa: 'வயலில் நீங்கள் கண்ணால் கண்ட அறிகுறிகளை (வைர வடிவ புள்ளிகள், தூர் நடுக்குருத்து காய்வு போன்றவை) உள்ளிடும் இடம்.',
    whyUsefulEn: 'Combines field context with image pixels for higher diagnostic accuracy and differential ruling out.',
    whyUsefulTa: 'புகைப்படத்துடன் உங்கள் கள அனுபவக் குறிப்புகளையும் இணைக்கும்போது நோயை 100% துல்லியமாக உறுதிப்படுத்த முடிகிறது.',
    howToUseEn: 'Type 2–4 key visual traits you notice on the stems, tillers, or leaves before running the scan.',
    howToUseTa: 'இலையில் அல்லது தண்டுப் பகுதியில் நீங்கள் கவனித்த மாற்றங்களை சுருக்கமாக தட்டச்சு செய்யவும்.',
  },
  'photo-upload-zone': {
    id: 'photo-upload-zone',
    titleEn: 'Leaf Photo Upload Dropzone',
    titleTa: 'இலை புகைப்படப் பதிவேற்றம் (Upload Leaf Photo)',
    categoryEn: 'Image Acquisition',
    categoryTa: 'புகைப்படத் தேர்வு',
    whatItDoesEn: 'Captures or uploads a high-resolution close-up photo of an affected leaf, stem, or insect specimen.',
    whatItDoesTa: 'பாதிக்கப்பட்ட இலை அல்லது பூச்சியின் தெளிவான புகைப்படத்தைப் பதிவேற்றும் பகுதி.',
    whyUsefulEn: 'Allows Gemini Vision models to inspect lesion margins, fungal mycelia, and insect frass microscopically.',
    whyUsefulTa: 'இலையின் புள்ளிகள், ஓரங்கள் மற்றும் பூஞ்சை இழைகளை AI நுண்ணோக்கி போல ஆய்வு செய்ய உதவுகிறது.',
    howToUseEn: 'Click the upload box to open your camera or file gallery. Pick a well-lit photo of one leaf.',
    howToUseTa: 'இந்த பெட்டியைத் தட்டி கேமரா மூலம் நல்ல வெளிச்சத்தில் எடுத்த ஒரு இலையின் படத்தை தேர்வு செய்யவும்.',
  },
  'run-diagnosis-btn': {
    id: 'run-diagnosis-btn',
    titleEn: 'Run Differential Diagnosis',
    titleTa: 'அறிகுறிகளை ஆய்வு செய் (Run Diagnosis)',
    categoryEn: 'AI Execution',
    categoryTa: 'ஆய்வு தொடங்கு',
    whatItDoesEn: 'Executes multimodal vision and pathology matching against verified TNAU and ICAR datasets.',
    whatItDoesTa: 'இலையின் படத்தையும் அறிகுறிகளையும் ஆராய்ந்து நோயைக் கண்டறியும் ஆய்வைத் தொடங்குகிறது.',
    whyUsefulEn: 'Provides primary condition name, % confidence, why suggested, bio-controls, and exact chemical dosages.',
    whyUsefulTa: 'நோயின் பெயர், அது உருவான காரணம், இயற்கை மேலாண்மை மற்றும் தெளிக்க வேண்டிய ரசாயன மருந்து அளவுகளைத் தருகிறது.',
    howToUseEn: 'Click after choosing your crop and uploading a photo or typing symptoms. Results appear in seconds.',
    howToUseTa: 'படம் அல்லது அறிகுறிகளை உள்ளிட்ட பின் இந்த பொத்தானை கிளிக் செய்யவும்; சில விநாடிகளில் அறிக்கை வரும்.',
  },
  'diff-report-btn': {
    id: 'diff-report-btn',
    titleEn: 'View Detailed Differential Report',
    titleTa: 'முழு மருத்துவ அறிக்கை (Differential Report)',
    categoryEn: 'Clinical Report',
    categoryTa: 'மருத்துவ அறிக்கை',
    whatItDoesEn: 'Opens a comprehensive pathology modal with environmental risk factors, safety precautions, and alternative diseases.',
    whatItDoesTa: 'சுற்றுச்சூழல் காரணிகள், மாற்று சாத்தியக்கூறுகள் மற்றும் பாதுகாப்பு நெறிமுறைகளுடன் கூடிய முழு அறிக்கையைத் திறக்கிறது.',
    whyUsefulEn: 'Helps distinguish between lookalike diseases (e.g. Rice Blast vs Brown Spot) before applying expensive chemicals.',
    whyUsefulTa: 'ஒரே மாதிரி தோற்றமளிக்கும் நோய்களுக்கு (எ.கா: குலை நோய் vs பழுப்பு புள்ளி) இடையே உள்ள வேறுபாட்டைத் தெளிவாக விளக்குகிறது.',
    howToUseEn: 'Click the stethoscope icon button after diagnosis finishes to view or print the full clinical dossier.',
    howToUseTa: 'ஆய்வு முடிந்ததும் "முழு மருத்துவ அறிக்கை" பொத்தானை கிளிக் செய்து விரிவான தகவல்களைப் படிக்கலாம்.',
  },

  // Soil & Fertilizer Page Controls
  'soil-nutrient-sliders': {
    id: 'soil-nutrient-sliders',
    titleEn: 'NPK Soil Nutrient Sliders',
    titleTa: 'மண் சத்து அளவீடுகள் (NPK Sliders)',
    categoryEn: 'Soil Chemistry',
    categoryTa: 'மண் பரிசோதனை',
    whatItDoesEn: 'Interactive sliders to enter available Nitrogen (N), Phosphorus (P), Potassium (K), and Organic Carbon.',
    whatItDoesTa: 'உங்கள் நிலத்தில் உள்ள தழைச்சத்து (N), மணிச்சத்து (P), சாம்பல்சத்து (K) அளவுகளை நகர்த்தி அமைக்கும் ஸ்லைடர்கள்.',
    whyUsefulEn: 'Customizes fertilizer recommendations to match your specific field rather than using generic blanket doses.',
    whyUsefulTa: 'பொதுவான உர அளவுகளைத் தவிர்த்து, உங்கள் மண்ணில் ஏற்கனவே உள்ள சத்துக்களுக்கு ஏற்ப துல்லியமான அளவைக் கணக்கிடுகிறது.',
    howToUseEn: 'Slide the handles to match the numbers from your Soil Health Card, or click a Cauvery Delta preset.',
    howToUseTa: 'உங்கள் மண் அட்டையில் உள்ள எண்களுக்கு ஏற்ப ஸ்லைடர்களை நகர்த்தவும் அல்லது மாதிரிப் பகுதியைத் தேர்வு செய்யவும்.',
  },
  'soil-generate-plan': {
    id: 'soil-generate-plan',
    titleEn: 'Generate Fertilizer Schedule',
    titleTa: 'உர அட்டவணை உருவாக்கு (Generate Schedule)',
    categoryEn: 'Nutrition Plan',
    categoryTa: 'உரத் திட்டம்',
    whatItDoesEn: 'Calculates the exact kilograms of Urea, DAP, MOP, and micronutrients needed across crop growth stages.',
    whatItDoesTa: 'பயிர் நடவு முதல் அறுவடை வரை இட வேண்டிய யூரியா, டிஏபி, பொட்டாஷ் அளவுகளை கிலோவில் கணக்கிடுகிறது.',
    whyUsefulEn: 'Tells you exactly WHEN and HOW MUCH to apply, preventing nutrient burn and maximizing panicle grain filling.',
    whyUsefulTa: 'எந்த வளர்ச்சி நிலையில் எவ்வளவு உரம் இட வேண்டும் என்பதைத் தெளிவாகக் கூறி, விளைச்சலை அதிகப்படுத்த உதவுகிறது.',
    howToUseEn: 'Click after setting your crop and soil values. Review the stage-by-stage table and print or save it.',
    howToUseTa: 'சத்து அளவுகளை அமைத்த பின் இதை அழுத்தவும்; வளர்ச்சி நிலை வாரியாக உரம் இடும் அட்டவணை தோன்றும்.',
  },

  // Search & Catalog Filter Controls
  'search-catalog': {
    id: 'search-catalog',
    titleEn: 'Knowledge & Disease Search',
    titleTa: 'தேடல் பெட்டி (Search)',
    categoryEn: 'Search',
    categoryTa: 'தேடல்',
    whatItDoesEn: 'Instantly filters diseases, pests, crop guides, and government schemes by keyword or symptom name.',
    whatItDoesTa: 'நோய் பெயர், பூச்சி பெயர் அல்லது அறிகுறியைத் தட்டச்சு செய்து பட்டியலை உடனடியாக வடிகட்டுகிறது.',
    whyUsefulEn: 'Find immediate answers without scrolling through dozens of library cards or crop manuals.',
    whyUsefulTa: 'நூற்றுக்கணக்கான கையேடுகளைத் தேடாமல், உங்களுக்குத் தேவையான தகவலை ஒரு நொடியில் கண்டுபிடிக்கலாம்.',
    howToUseEn: 'Click the search bar and type words like "blast", "stem borer", "potash", or "subsidy".',
    howToUseTa: 'இங்கு "குலை நோய்", "யூரியா" அல்லது "மானியங்கள்" என்று எழுதி உடனே தேடலாம்.',
  },
  'crop-filter-chips': {
    id: 'crop-filter-chips',
    titleEn: 'Crop Category Filter Chips',
    titleTa: 'பயிர் வடிகட்டி பொத்தான்கள் (Filter Chips)',
    categoryEn: 'Filters',
    categoryTa: 'வடிகட்டி',
    whatItDoesEn: 'Filters the disease and pest catalog to show only conditions relevant to Paddy, Groundnut, Wheat, Cotton, or Tomato.',
    whatItDoesTa: 'நெல், நிலக்கடலை, பருத்தி, கோதுமை அல்லது தக்காளி என குறிப்பிட்ட பயிருக்கான நோய்களை மட்டும் பிரித்துக் காட்டுகிறது.',
    whyUsefulEn: 'Focuses strictly on your specific crop without clutter from other agricultural categories.',
    whyUsefulTa: 'தேவையற்ற பிற பயிர் விவரங்களை நீக்கி, உங்கள் வயல் பயிருக்கான தகவல்களை மட்டும் தெளிவாகப் பார்க்கலாம்.',
    howToUseEn: 'Click any crop pill (e.g. "Paddy" or "Groundnut") to instantly filter the cards below.',
    howToUseTa: 'விரும்பிய பயிரின் பொத்தானை கிளிக் செய்து அந்த பயிருக்கான நோய் பட்டியலை மட்டும் பார்வையிடவும்.',
  },
};

/**
 * Finds the best guide content matching a DOM element or its attributes.
 */
export function matchGuideContent(target: HTMLElement | null): GuideContent | null {
  if (!target) return null;

  let current: HTMLElement | null = target;
  let depth = 0;

  while (current && depth < 6) {
    // 1. Direct data-guide attribute
    const dataGuide = current.getAttribute('data-guide');
    if (dataGuide && farmerGuideDictionary[dataGuide]) {
      return farmerGuideDictionary[dataGuide];
    }

    // 2. Element ID match
    const id = current.id;
    if (id && farmerGuideDictionary[id]) {
      return farmerGuideDictionary[id];
    }

    // 3. Navigation href match
    const href = current.getAttribute('href');
    if (href) {
      if (href.includes('/dashboard') || href.includes('#/dashboard')) return farmerGuideDictionary['nav-dashboard'];
      if (href.includes('/assistant') || href.includes('#/assistant')) return farmerGuideDictionary['nav-assistant'];
      if (href.includes('/diseases') || href.includes('#/diseases')) return farmerGuideDictionary['nav-diseases'];
      if (href.includes('/soil') || href.includes('#/soil')) return farmerGuideDictionary['nav-soil'];
      if (href.includes('/crops') || href.includes('#/crops')) return farmerGuideDictionary['nav-crops'];
      if (href.includes('/library') || href.includes('#/library')) return farmerGuideDictionary['nav-library'];
      if (href.includes('/ingestion') || href.includes('#/ingestion')) return farmerGuideDictionary['nav-ingestion'];
      if (href.includes('/evidence') || href.includes('#/sources')) return farmerGuideDictionary['nav-sources'];
      if (href.includes('/settings') || href.includes('#/settings') || href.includes('/profile')) return farmerGuideDictionary['nav-settings'];
    }

    // 4. Common semantic attributes
    const ariaLabel = (current.getAttribute('aria-label') || '').toLowerCase();
    const placeholder = (current.getAttribute('placeholder') || '').toLowerCase();
    const textContent = (current.textContent || '').trim().toLowerCase();

    // Language switcher
    if (current.id === 'top-language' || ariaLabel.includes('language') || textContent.includes('தமிழ்')) {
      return farmerGuideDictionary['top-language'];
    }

    // Guide switch
    if (current.id === 'top-guide-toggle' || ariaLabel.includes('guide') || textContent.includes('guide')) {
      return farmerGuideDictionary['top-guide-toggle'];
    }

    // System Health
    if (ariaLabel.includes('health') || ariaLabel.includes('கணினி நிலை') || current.title?.includes('Health')) {
      return farmerGuideDictionary['top-health'];
    }

    // Alerts
    if (ariaLabel.includes('alert') || ariaLabel.includes('எச்சரிக்கை')) {
      return farmerGuideDictionary['top-alerts'];
    }

    // Mic button
    if (ariaLabel.includes('voice') || ariaLabel.includes('குரல்') || ariaLabel.includes('mic')) {
      return farmerGuideDictionary['ask-mic'];
    }

    // Camera button
    if (ariaLabel.includes('camera') || ariaLabel.includes('photo') || ariaLabel.includes('படம்')) {
      return farmerGuideDictionary['ask-camera'];
    }

    // Document Analyzer
    if (textContent.includes('analyze document') || textContent.includes('ஆவணப் பகுப்பாய்வு')) {
      return farmerGuideDictionary['ask-doc-analyzer'];
    }

    // Question input
    if (current.tagName === 'TEXTAREA' || (current.tagName === 'INPUT' && placeholder.includes('describe the problem'))) {
      return farmerGuideDictionary['ask-input'];
    }

    // Crop dropdown
    if (current.id === 'crop-select' || (current.tagName === 'SELECT' && current.closest('[id*="crop"]'))) {
      return farmerGuideDictionary['crop-select'];
    }

    // Symptoms input
    if (current.id === 'symptom-input' || placeholder.includes('spindle')) {
      return farmerGuideDictionary['symptom-input'];
    }

    // Run diagnosis button
    if (textContent.includes('differential diagnosis') || textContent.includes('ஆய்வு செய்')) {
      return farmerGuideDictionary['run-diagnosis-btn'];
    }

    // Photo scanner upload zone
    if (current.tagName === 'LABEL' && (textContent.includes('choose a leaf photo') || textContent.includes('கேமரா புகைப்படம்'))) {
      return farmerGuideDictionary['photo-upload-zone'];
    }

    // Differential report button
    if (textContent.includes('differential report') || textContent.includes('முழு மருத்துவ ஆய்வு')) {
      return farmerGuideDictionary['diff-report-btn'];
    }

    // Soil sliders
    if (current.classList.contains('soil-slider') || current.getAttribute('type') === 'range') {
      return farmerGuideDictionary['soil-nutrient-sliders'];
    }

    // Search input
    if (current.tagName === 'INPUT' && (placeholder.includes('search') || placeholder.includes('தேட'))) {
      return farmerGuideDictionary['search-catalog'];
    }

    current = current.parentElement;
    depth++;
  }

  return null;
}
